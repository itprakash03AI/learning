/**
 * The report designer (2026-11-07, the simple builder -- plan
 * docs/REPORT_SIMPLE_BUILDER_PLAN_2026_11_06.html, section 3, the layout the
 * owner accepted; the owner: "should be same as powerbi ... should not be so
 * complex").  Before this it was the canvas builder of 2026-10-26: one
 * property column with page-level and visual-level settings mixed.
 *
 *   top      <- name · Data · Refresh · More · Save
 *   middle   the canvas (the SAME component the viewer shows) with the page
 *            tabs along the bottom
 *   right    Filters | Fields (ticks) over the Visuals grid over Build / Format
 *
 * How a person builds: pick the data, click a visual, tick or drag fields,
 * drag to place, Save.  The visuals DRAW THEMSELVES (plan section 5,
 * designer/autoRun.ts): the first field keeps a draft only its author sees,
 * a new field or value starts one debounced run, a field the last run holds
 * draws from it with no new query, "Refresh by itself" can be turned off.  Every check is the model's ``canvasProblems`` (the
 * server applies the same on save): each problem is shown on its visual and
 * Save stays off until there are none.  The report runs ONE query whose
 * columns are every field the canvas uses.  Nothing about the saved shape
 * changed: same layout_config.canvas, same routes.
 *
 * The pure editing rules live in canvasEdit.ts and the wells in
 * canvasWells.ts; both are re-exported here for the tests that import them
 * from this module.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  Alert, Autocomplete, Box, Button, CircularProgress, Divider, FormControlLabel, IconButton, ListItemIcon, ListItemText, Menu, MenuItem, Paper, Stack,
  Switch, Tab, Tabs, TextField, Tooltip, Typography,
} from '@mui/material';
import AppDialog from '../../common/AppDialog';
import AddIcon from '@mui/icons-material/Add';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import PlayIcon from '@mui/icons-material/PlayArrow';
import SaveIcon from '@mui/icons-material/Save';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import SettingsIcon from '@mui/icons-material/SettingsOutlined';
import TuneIcon from '@mui/icons-material/Tune';
import LaunchIcon from '@mui/icons-material/Launch';
import TouchAppIcon from '@mui/icons-material/TouchApp';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import api from '../../../services/api';
import { useAuth } from '../../../context/AuthContext';
import { isAdminLike } from '../../../utils/reportLifecycle';
import { SourceFilter, askedParameter, filterForSave, isUnfilledFilter } from '../../../utils/reportFilters';
import { paramRowsFromServer, paramRowsToBatchItems, ParamRow } from '../reportAuthoringModel';
import { ReportParameterEditor } from '../ReportParameterEditor';
import FiltersPane, { toAuthoringColumn } from '../designer/FiltersPane';
import { NEW_REPORT_FROM_TEMPLATE_PATH, reportEditPath, reportPath, REPORTS_PATH } from '../../../utils/reportUrls';
import ReportLookPanel, { DEFAULT_INSIGHTS, LookInsights, lookOf } from '../ReportLookPanel';
import ReportSettingsDialog from '../designer/ReportSettingsDialog';
import PowerBiImportDialog from '../designer/PowerBiImportDialog';
import { appConfirm } from '../../common/appDialogs';
import { draftName, missingRequired, needsRun, notRunWords, overrideColumnsFor, readAutoRefresh, RUN_SETTINGS, runKey, unsavedFixedFilters, writeAutoRefresh } from '../designer/autoRun';
import ReportParamControl from '../ReportParamControl';
import ReportCanvasView, { FIELD_MIME } from './ReportCanvasView';
import { CanvasActionsEditor } from './canvasActions';
import { CanvasThemeContext, resolveTheme, ThemeSpec } from './canvasTheme';
import { CanvasCompareContext, compareFrom } from './canvasCompare';
import {
  CanvasColumn, canvasColumnIds, canvasProblems, CanvasTile, pageOfTile, effectiveCanvas, makeTile,
  ReportCanvas, rowsAreGrouped, TileKind, TileLayout, tileName,
} from './canvasModel';
import { CanvasBandContext } from './CanvasOutlineTile';
import { newOutlineFields } from './canvasOutline';
import { insightColumnIds, newInsight } from './canvasInsights';
import {
  addFieldToTile, changeKind, fieldHoverText, OWN_SETTINGS, removeFieldFromTile, tileFieldIds, tileForField, toCol, valueLimit,
} from './canvasEdit';
import VisualsGrid from '../designer/VisualsGrid';
import FieldsPane from '../designer/FieldsPane';
import BuildTab from '../designer/BuildTab';
import { ReportFormat, VisualFormat } from '../designer/FormatTab';

// the pure rules, re-exported for the tests that import them from here
export { addFieldToTile, changeKind, fieldHoverText, tileForField, valueLimit } from './canvasEdit';

/** The signed-in user when an AuthProvider is above us; null otherwise (a test renders the designer alone). */
const useOptionalUser = (): any => {
  try { return useAuth().user; } catch { return null; }   // eslint-disable-line react-hooks/rules-of-hooks
};

interface ParamDraft {
  id?: number;
  name: string;
  label: string;
  parameter_type: string;
  lov_column_id?: number | null;
  is_required?: boolean;
  default_value?: any;
  [k: string]: any;
}

/** A side pane sits within the window (sticky under the top bar) and scrolls inside -- at 1366x768 the
 *  Build / Format body sat below the fold when the pane grew with the page (the rig's first screenshot). */
const PANE_SX = { p: 0.5, display: 'flex', flexDirection: 'column', minHeight: 0, alignSelf: 'start', position: 'sticky', top: 8,
                  maxHeight: 'calc(100vh - 120px)', overflow: 'hidden' } as const;

/** A pane's header: its name and a chevron that folds it to a thin rail. */
function PaneHeader({ title, open, onToggle, testId, right }: { title: string; open: boolean; onToggle: () => void; testId: string; right?: React.ReactNode }) {
  return (
    <Stack direction="row" alignItems="center" sx={{ px: 0.5, minHeight: 32 }}>
      {open && <Typography variant="subtitle2" sx={{ flex: 1 }}>{title}</Typography>}
      {open && right}
      <Tooltip title={open ? `Hide ${title.toLowerCase()}` : `Show ${title.toLowerCase()}`}>
        <IconButton size="small" onClick={onToggle} aria-label={open ? `Hide ${title.toLowerCase()}` : `Show ${title.toLowerCase()}`} data-testid={testId}
          aria-expanded={open}>
          {open ? <ChevronRightIcon fontSize="small" /> : <ChevronLeftIcon fontSize="small" />}
        </IconButton>
      </Tooltip>
    </Stack>
  );
}

export default function CanvasReportBuilder() {
  const { id: routeId } = useParams<{ id: string }>();
  const [search] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  const isNew = !routeId || routeId === 'new';
  // a new report's Save lands on /design (a remount): the "Saved." it earned travels in the navigation state
  useEffect(() => {
    const carried = (location.state as any)?.message;
    if (carried) {
      setMessage({ kind: 'success', text: String(carried) });
      navigate(location.pathname + location.search, { replace: true, state: null });
    }
  }, []);   // eslint-disable-line react-hooks/exhaustive-deps
  const user = useOptionalUser();
  const canListGroups = isAdminLike(user);
  // the one editor's old tabs keep working as the panel to open (plan section 4): ?tab=look the Theme
  // group, ?tab=actions the popups editor, ?tab=parameters the Filters pane, ?tab=settings Report settings
  const urlTab = search.get('tab') || (search.get('focus') === 'actions' ? 'actions' : null);

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [report, setReport] = useState<any>(null);
  const [viewersMayRearrange, setViewersMayRearrange] = useState(false);
  const [datasets, setDatasets] = useState<any[]>([]);
  const [datasetId, setDatasetId] = useState<number | null>(Number(search.get('dataset')) || null);
  // 2026-11-08 -- "+ Same data from another source": a second dataset whose rows are stacked under the first
  // (UNION ALL, matched by column name).  The report stores it as merged_dataset_id + merge_config union.
  const [mergedDatasetId, setMergedDatasetId] = useState<number | null>(null);
  const [secondPick, setSecondPick] = useState(false);
  const [secondColumns, setSecondColumns] = useState<string[] | null>(null);
  const [secondLabel, setSecondLabel] = useState<string | null>(null);
  const [columns, setColumns] = useState<CanvasColumn[]>([]);
  const [datasetLabel, setDatasetLabel] = useState<string | null>(null);
  const [hasMetrics, setHasMetrics] = useState(false);
  const [name, setName] = useState('');
  const [canvas, setCanvas] = useState<ReportCanvas>({ version: 1, tiles: [] });
  const [reportTableCols, setReportTableCols] = useState<number[]>([]);
  const [params, setParams] = useState<ParamDraft[]>([]);
  const [paramsDirty, setParamsDirty] = useState(false);
  // 2026-10-29 -- the conditions of the dataset's own SQL WHERE a parameter
  // may fill ("Filter at the source", backend core/source_filters.py)
  const [sourceFilters, setSourceFilters] = useState<SourceFilter[]>([]);
  const [filters, setFilters] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [fieldQuery, setFieldQuery] = useState('');
  const [askOpen, setAskOpen] = useState(false);
  const [askCol, setAskCol] = useState<CanvasColumn | null>(null);
  const [paramValues, setParamValues] = useState<Record<string, any>>({});
  // VISUALS THAT DRAW THEMSELVES (2026-11-07, plan section 5; the rules in designer/autoRun.ts): the last run
  // and the fields it ran WITH -- a visual needing a field the run lacks says so instead of failing; a new field
  // (or a new value) starts one debounced run; a newer run supersedes an older one (its answer is dropped)
  const [lastRun, setLastRun] = useState<{ id: string; total: number | null; truncated: boolean; fields: number[]; valuesKey: string; at: Date } | null>(null);
  const [running, setRunning] = useState(false);
  const [runError, setRunError] = useState('');
  const [runNote, setRunNote] = useState('');   // 2026-11-08 -- the run went to the background: the server's words
  const [autoRefresh, setAutoRefresh] = useState(true);
  const runSeq = useRef(0);
  const attempted = useRef<string>('');
  // a DRAFT: the report the designer saved the moment the first field was added, not yet saved by the person
  const [draft, setDraft] = useState(false);
  const creatingDraft = useRef(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ kind: 'error' | 'success' | 'info'; text: string } | null>(null);
  const [serverProblems, setServerProblems] = useState<Record<string, string[]>>({});
  // the panes (2026-11-07): each folds to a rail; the right pane's Build / Format tab
  const [filtersOpen, setFiltersOpen] = useState(true);
  const [fieldsOpen, setFieldsOpen] = useState(true);
  const [sideTab, setSideTab] = useState<'build' | 'format'>(urlTab === 'look' ? 'format' : 'build');
  // More: Report settings (code, description, owner group), Popups and downloads (the actions editor), the theme
  const [moreAnchor, setMoreAnchor] = useState<null | HTMLElement>(null);
  // Filters > Viewer can change > Settings: the ONE parameter editor over every row
  const [paramEditorRows, setParamEditorRows] = useState<ParamRow[] | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(urlTab === 'settings');
  const [popupsOpen, setPopupsOpen] = useState(urlTab === 'actions');
  const [pbiOpen, setPbiOpen] = useState(false);   // More > Import from Power BI (2026-11-07)
  const [description, setDescription] = useState('');
  const [ownerGroupId, setOwnerGroupId] = useState<number | ''>('');
  const [metaDirty, setMetaDirty] = useState(false);
  const [userGroups, setUserGroups] = useState<{ id: number; name: string }[]>([]);
  const [look, setLook] = useState<{ spec: ThemeSpec; insights: LookInsights }>({ spec: {}, insights: DEFAULT_INSIGHTS });
  const [lookDirty, setLookDirty] = useState(false);
  useEffect(() => {
    if (!canListGroups) return;
    (api as any).listUserGroups?.({ is_active: true })
      .then((groups: any) => setUserGroups(Array.isArray(groups) ? groups : []))
      .catch(() => setUserGroups([]));
  }, [canListGroups]);

  // ── load ────────────────────────────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true); setLoadError('');
      try {
        if (isNew) {
          const ds = await api.listDatasets();
          if (!cancelled) {
            const list = Array.isArray(ds) ? ds : (ds?.items || ds?.datasets || []);
            setDatasets(list);
            setCanvas({ version: 1, tiles: [] });
          }
        } else {
          const r = /^\d+$/.test(routeId!) ? await api.getBusinessReport(Number(routeId)) : await api.getBusinessReportBySlug(routeId!);
          if (cancelled) return;
          setReport(r);
          setViewersMayRearrange(!!r?.layout_config?.viewers_may_rearrange);
          setName(r.name || '');
          setDescription(r.description || '');
          setOwnerGroupId((r.owner_group_id ?? '') || '');
          setLook(lookOf(r.layout_config));
          setDatasetId(r.dataset_id ?? null);
          const mcType = String(r.merge_config?.merge_type || '').toLowerCase();
          setMergedDatasetId(mcType === 'union' && r.merged_dataset_id ? Number(r.merged_dataset_id) : null);
          setSecondPick(mcType === 'union' && !!r.merged_dataset_id);
          setFilters(Array.isArray(r.filter_specs) ? r.filter_specs : []);
          setParams((r.parameters || []).map((p: any) => ({ ...p })));
          // every report is a canvas: one with none stored opens as ONE tile, its own table
          const c = effectiveCanvas(r.layout_config);
          setCanvas(c);
          setReportTableCols((r.column_ids || []).map(Number));
          // a table-only report opens with its report table selected (plan section 4)
          if (c.tiles.length === 1 && c.tiles[0].kind === 'report') setSelectedId(c.tiles[0].id);
        }
      } catch (e: any) {
        if (!cancelled) setLoadError(e?.message || 'The report could not be loaded.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [isNew, routeId]);

  useEffect(() => {
    if (!datasetId) { setColumns([]); return; }
    let cancelled = false;
    (async () => {
      try {
        const ds = await api.getDataset(datasetId);
        if (cancelled) return;
        // (rig 2026-11-01) a hidden column stays in the data -- a tile counting `id` is not "no longer in the
        // data"; it is kept for the check and left out of the field list
        setColumns((ds?.columns || []).map((c: any) => ({ ...toCol(c), hidden: !!c.is_hidden })));
        if (ds?.name) setDatasetLabel(String(ds.name));
        api.getDatasetSourceFilters(datasetId)
          .then((r: any) => { if (!cancelled) setSourceFilters((r?.filters || []).filter((f: any) => f.offered)); })
          .catch(() => { if (!cancelled) setSourceFilters([]); });
        // a calculated metric makes the stored rows grouped (the server's rule)
        const metrics = ds?.calculated_metrics ?? ds?.metrics;
        setHasMetrics(Array.isArray(metrics) ? metrics.length > 0 : false);
      } catch (e: any) {
        if (!cancelled) setLoadError(e?.message || 'The dataset could not be loaded.');
      }
    })();
    return () => { cancelled = true; };
  }, [datasetId]);


  const cols = useMemo(() => new Map(columns.map(c => [c.id, c])), [columns]);
  const grouped = useMemo(() => rowsAreGrouped(columns, hasMetrics), [columns, hasMetrics]);
  const hasReportTile = canvas.tiles.some(t => t.kind === 'report');
  /** the report's ONE query returns every field the canvas uses (+ its own table's columns) */
  const unionIds = useMemo(() => {
    const ids = new Set<number>(canvasColumnIds(canvas));
    if (hasReportTile) reportTableCols.forEach(i => ids.add(i));
    // a STORED column a parameter filters on is kept (a template puts them there; a Save with no edit
    // changes nothing) -- never added: the old builder did not, and the filter needs no projection
    const bound = new Set<number>(params.flatMap(p => [p.lov_column_id, p.cascade_filter_column_id].filter((x): x is number => x != null).map(Number)));
    ((report?.column_ids as number[] | undefined) ?? []).map(Number).filter(i => bound.has(i)).forEach(i => ids.add(i));
    return [...ids].filter(i => cols.has(i));
  }, [canvas, hasReportTile, reportTableCols, cols, params, report?.column_ids]);

  // the second dataset's column names: a field it lacks is said here, before the save refuses it
  useEffect(() => {
    if (!mergedDatasetId) { setSecondColumns(null); return; }
    let cancelled = false;
    api.getDataset(mergedDatasetId)
      .then((ds: any) => {
        if (cancelled) return;
        setSecondColumns((ds?.columns || []).map((c: any) => String(c.physical_name || '')));
        if (ds?.name) setSecondLabel(String(ds.name));
      })
      .catch(() => { if (!cancelled) setSecondColumns(null); });
    return () => { cancelled = true; };
  }, [mergedDatasetId]);
  const missingInSecond = useMemo(() => {
    if (!mergedDatasetId || !secondColumns) return [] as string[];
    const have = new Set(secondColumns.map(n => n.toLowerCase()));
    return columns.filter(c => unionIds.includes(c.id) && !have.has(String(c.physical_name || '').toLowerCase())).map(c => c.label || c.physical_name || String(c.id));
  }, [mergedDatasetId, secondColumns, columns, unionIds]);
  const unionFields = mergedDatasetId ? { merged_dataset_id: mergedDatasetId, merge_config: { merge_type: 'union' } } : {};

  const problems = useMemo(() => canvasProblems(canvas, columns, { grouped, selected: unionIds }), [canvas, columns, grouped, unionIds]);
  const problemsByTile = useMemo(() => {
    const out: Record<string, string[]> = {};
    for (const p of problems) if (p.tileId) (out[p.tileId] ||= []).push(p.message);
    for (const [k, v] of Object.entries(serverProblems)) (out[k] ||= []).push(...v);
    return out;
  }, [problems, serverProblems]);
  const pageProblems = problems.filter(p => !p.tileId).map(p => p.message);
  if (hasReportTile && unionIds.length === 0) pageProblems.push("The report's table has no columns. Pick at least one on its visual.");
  if (!name.trim()) pageProblems.push('Give the report a name.');
  // a fixed filter with no value is REFUSED, never dropped (the server refuses it too)
  if (filters.some(f => isUnfilledFilter(f))) pageProblems.push('A fixed filter has no value. Give it one or remove it.');
  if (!datasetId) pageProblems.push('Pick the data the report is built on.');
  const canSave = problems.length === 0 && pageProblems.length === 0 && !saving;

  const staleFields = useMemo(() => {
    if (!lastRun) return {} as Record<string, string[]>;
    const ran = new Set(lastRun.fields);
    const out: Record<string, string[]> = {};
    for (const t of canvas.tiles) {
      if (t.kind === 'report') continue;
      const need = [...t.dimensions, ...t.measures.map(m => m.column_id), ...(t.series != null ? [t.series] : []), ...(t.levels ?? []),
        ...insightColumnIds(t.insight)];
      const missing = [...new Set(need.filter(i => !ran.has(i)))].map(i => cols.get(i)?.label ?? `column #${i}`);
      if (missing.length) out[t.id] = missing;
    }
    return out;
  }, [lastRun, canvas, cols]);
  const runIsStale = Object.keys(staleFields).length > 0;

  const selected = canvas.tiles.find(t => t.id === selectedId) ?? null;
  const updateTile = useCallback((id: string, f: (t: CanvasTile) => CanvasTile) => {
    setCanvas(c => ({ ...c, tiles: c.tiles.map(t => t.id === id ? f(t) : t) }));
    setServerProblems({});
  }, []);
  const deleteTile = useCallback((id: string) => {
    setCanvas(c => ({ ...c, tiles: c.tiles.filter(t => t.id !== id) }));
    setSelectedId(s => (s === id ? null : s));
  }, []);
  // the Delete key removes the selected visual when the focus is on the page, not in a field
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Delete' || !selectedId) return;
      const el = e.target as HTMLElement | null;
      const tag = (el?.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select' || el?.isContentEditable) return;
      deleteTile(selectedId);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedId, deleteTile]);

  const addTile = (kind: TileKind) => {
    if (kind === 'report' && hasReportTile) { setMessage({ kind: 'info', text: "The report's table is already on the page." }); return; }
    const t = makeTile(kind, kind === 'report' ? { id: 'report' } : kind === 'insight' ? { insight: newInsight('explain_change') } : newOutlineFields(kind), canvas.tiles);
    setCanvas(c => ({ ...c, tiles: [...c.tiles, t] }));
    setSelectedId(t.id);
    setSideTab('build');
  };
  /** the Visuals grid: with a switchable visual selected a click changes its kind, else it adds one */
  const pickVisual = (kind: TileKind) => {
    if (selected && !OWN_SETTINGS.includes(selected.kind) && !OWN_SETTINGS.includes(kind)) {
      updateTile(selected.id, t => changeKind(t, kind));
      return;
    }
    addTile(kind);
  };
  const onDropField = (columnId: number, tileId: string | null) => {
    const col = cols.get(columnId);
    if (!col) return;
    if (tileId) {
      const t = canvas.tiles.find(x => x.id === tileId);
      if (t?.kind === 'report') { setReportTableCols(r => r.includes(columnId) ? r : [...r, columnId]); setSelectedId(tileId); return; }
      updateTile(tileId, x => addFieldToTile(x, col, grouped));
      setSelectedId(tileId);
    } else {
      const t = tileForField(col, canvas.tiles, grouped);
      setCanvas(c => ({ ...c, tiles: [...c.tiles, t] }));
      setSelectedId(t.id);
    }
  };
  /** the Fields pane: a tick adds the field to the selected visual, unticking takes it off */
  const toggleField = (col: CanvasColumn, on: boolean) => {
    if (!selected) { onDropField(col.id, null); return; }
    if (selected.kind === 'report') {
      setReportTableCols(r => on ? (r.includes(col.id) ? r : [...r, col.id]) : r.filter(i => i !== col.id));
      return;
    }
    if (on) {
      const before = selected;
      const after = addFieldToTile(before, col, grouped);
      if (after === before && !tileFieldIds(before).includes(col.id)) {
        setMessage({ kind: 'info', text: `${tileName(before, cols)} has no room for ${col.label}: it takes ${valueLimit(before.kind)} value${valueLimit(before.kind) === 1 ? '' : 's'} and one category. Take a field out first, or drop it in a well.` });
        return;
      }
      updateTile(before.id, () => after);
    } else {
      updateTile(selected.id, t => removeFieldFromTile(t, col.id));
    }
  };
  const usedIds = useMemo(() => {
    if (!selected) return new Set<number>();
    if (selected.kind === 'report') return new Set(reportTableCols);
    return new Set([...tileFieldIds(selected), ...insightColumnIds(selected.insight)]);
  }, [selected, reportTableCols]);
  const onLayout = (layouts: Record<string, TileLayout>) => {
    setCanvas(c => {
      let changed = false;
      const tiles = c.tiles.map(t => {
        const l = layouts[t.id];
        if (l && (l.x !== t.layout.x || l.y !== t.layout.y || l.w !== t.layout.w || l.h !== t.layout.h)) { changed = true; return { ...t, layout: l }; }
        return t;
      });
      return changed ? { ...c, tiles } : c;
    });
  };

  // ── parameters asked when the report runs ───────────────────────────────
  /** a question on a field; false when it is already asked (the caller keeps its fixed row -- review P3) */
  const addAsked = (col: CanvasColumn): boolean => {
    const p = askedParameter({ column_id: col.id, operator: 'eq' } as any,
      { id: col.id, friendly_name: col.label, physical_name: col.physical_name, data_type: col.data_type || '' });
    if (params.some(x => x.name === p.name)) { setMessage({ kind: 'info', text: `${col.label} is already asked when the report runs.` }); return false; }
    setParams(ps => [...ps, { ...p, is_required: false, default_value: '' }]);
    setParamsDirty(true);
    return true;
  };
  /** the Filters pane changed the parameter list (a source condition ticked, a parameter removed) */
  const changeParams = (next: ParamDraft[]) => { setParams(next); setParamsDirty(true); };
  /** the parameter editor's rows back into the designer's list; a saved parameter keeps its id by name */
  const applyParamEditor = (rows: ParamRow[]) => {
    const ids = new Map(params.filter(p => p.id).map(p => [p.name, p.id]));
    changeParams(paramRowsToBatchItems(rows).map(p => ({ ...p, ...(ids.has(p.name) ? { id: ids.get(p.name) } : {}) })));
    setParamEditorRows(null);
  };

  // ── save ────────────────────────────────────────────────────────────────
  const save = async () => {
    setSaving(true); setMessage(null); setServerProblems({});
    try {
      let saved: any;
      // the look (theme + insights) and the settings (description, owner group) travel only when this
      // session changed them: a report saved untouched keeps its stored layout_config byte for byte
      const lookFields = lookDirty ? { theme: Object.keys(look.spec).length ? look.spec : undefined, insights: look.insights } : {};
      const metaFields = metaDirty ? { description: description.trim(), owner_group_id: ownerGroupId === '' ? null : Number(ownerGroupId) } : {};
      // a DRAFT already exists on the /new road: Save UPDATES it (the create road made a second report)
      if (!report) {
        saved = await api.createBusinessReport({
          name: name.trim(), dataset_id: datasetId, data_source_type: 'saved_query', column_ids: unionIds,
          filter_specs: filters.map(f => filterForSave(f)), ...metaFields, ...unionFields,
          layout_config: { report_type: 'table', canvas, viewers_may_rearrange: viewersMayRearrange, ...lookFields },
        });
      } else {
        // PUT replaces layout_config: send the stored object with the canvas
        // merged in, from a FRESH read, and only if nobody saved since we loaded
        const fresh = await api.getBusinessReport(report.id);
        if (String(fresh.updated_at) !== String(report.updated_at)) {
          setMessage({ kind: 'error', text: `Someone saved this report after you opened it${fresh.updated_by ? ` (${fresh.updated_by})` : ''}. Your changes were not saved. Reload to see theirs, then make your changes again.` });
          return;
        }
        saved = await api.updateBusinessReport(report.id, {
          name: name.trim(), column_ids: unionIds, filter_specs: filters.map(f => filterForSave(f)), ...metaFields,
          // the switch travels only when on, or when the stored config already carries it (an untouched Save adds no key)
          layout_config: { ...(fresh.layout_config || {}), canvas,
                           ...(viewersMayRearrange || 'viewers_may_rearrange' in (fresh.layout_config || {}) ? { viewers_may_rearrange: viewersMayRearrange } : {}),
                           ...lookFields },
          expected_updated_at: report.updated_at,
        });
      }
      setLookDirty(false); setMetaDirty(false);
      const rid = saved?.id ?? report?.id;
      if (paramsDirty && rid) {
        await api.batchSaveBusinessReportParams(rid, params.map(p => ({ ...p })));
        setParamsDirty(false);
      }
      const reread = await api.getBusinessReport(rid);
      setReport(reread);
      setDraft(false);
      setParams((reread.parameters || []).map((p: any) => ({ ...p })));
      setMessage({ kind: 'success', text: 'Saved.' });
      if (isNew) navigate(`/finance-reports/${reread.slug || reread.id}/design`, { replace: true, state: { message: 'Saved.' } });
    } catch (e: any) {
      const detail = e?.detail ?? e?.body?.detail;
      if (detail?.problems) {
        const byTile: Record<string, string[]> = {};
        for (const p of detail.problems) if (p.tile_id) (byTile[p.tile_id] ||= []).push(p.message);
        setServerProblems(byTile);
      }
      setMessage({ kind: 'error', text: detail?.message || e?.message || 'The report could not be saved.' });
    } finally {
      setSaving(false);
    }
  };

  // ── the run (visuals that draw themselves) ──────────────────────────────
  const unionKey = unionIds.join(',');
  // the fixed filter rows not yet saved: the run applies them as extra, narrow-only filters (review P2) and
  // they are part of the run's key; a question (parameter) not yet saved cannot be applied -- the status says so
  const extraFilters = useMemo(() => unsavedFixedFilters(filters, report?.filter_specs, { filled: f => !isUnfilledFilter(f), normalise: filterForSave }),
                               [filters, report?.filter_specs]);
  const unsavedQuestions = params.filter(p => !p.id).map(p => p.label || p.name);
  const vKey = runKey(paramValues, extraFilters);
  const missing = useMemo(() => missingRequired(params, paramValues), [params, paramValues]);
  const runNow = async (force: boolean) => {
    if (!report || unionIds.length === 0 || missing.length) return;
    if (!force && !needsRun(unionIds, paramValues, lastRun, extraFilters)) return;
    attempted.current = `${unionKey}|${vKey}`;
    const seq = ++runSeq.current;
    setRunning(true); setRunError('');
    try {
      // the same run Preview made: the saved report with THIS canvas's columns (named only when they differ from
      // the saved ones, so an unchanged report's run is its own and may be served from its stored copy), the chosen
      // values and the fixed filters not yet saved; admission, cost and row security are the server's, as for any run
      const override = overrideColumnsFor(unionIds, report.column_ids);
      const res: any = await api.executeBusinessReport(report.id, {
        parameter_values: paramValues,
        allow_background: true,   // 2026-11-08: the designer shows the words when a large run goes to the background
        ...(override ? { override_column_ids: override } : {}),
        ...(extraFilters.length ? { extra_filters: extraFilters } : {}),
      });
      if (seq !== runSeq.current) return;   // a newer run started: this answer is dropped
      if (res?.background) {   // 2026-11-08 -- more rows than the threshold: the run goes on in the background
        setRunNote(String(res.words || 'This report runs in the background; its result will be in the Download Centre.'));
        return;
      }
      setRunNote('');
      const id = res?.execution_id;
      if (!id) throw new Error('The run did not return a result to show.');
      setLastRun({ id, total: typeof res.total_rows === 'number' ? res.total_rows : null, truncated: !!res.truncated,
                   fields: [...unionIds], valuesKey: vKey, at: new Date() });
      // a run never moves the report's updated_at (the server pins it, 2026-11-07): the Save's "someone saved
      // after you" check keeps comparing against the row as it was OPENED.  (The designer once re-read
      // updated_at after each run, which also adopted a real save by someone else in between -- theirs was
      // then overwritten without a word.)
    } catch (e: any) {
      if (seq === runSeq.current) setRunError(e?.message || 'The report could not run.');
    } finally {
      if (seq === runSeq.current) setRunning(false);
    }
  };
  const runNowRef = useRef(runNow);
  runNowRef.current = runNow;
  // "Refresh by itself": remembered per report; on until someone turns it off
  useEffect(() => { if (report?.id && !draft) setAutoRefresh(readAutoRefresh(report.id)); }, [report?.id]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!autoRefresh || !report || unionIds.length === 0 || missing.length) return;
    const key = `${unionKey}|${vKey}`;
    if (attempted.current === key) return;                       // this very set was run (or failed): not again by itself
    if (!needsRun(unionIds, paramValues, lastRun, extraFilters)) return;   // the last run holds every field and filter: no new query
    const t = setTimeout(() => runNowRef.current(false), RUN_SETTINGS.debounceMs);
    return () => clearTimeout(t);
  }, [autoRefresh, report, unionKey, vKey, lastRun, missing.length]);   // eslint-disable-line react-hooks/exhaustive-deps
  // a report EXISTS from the moment data is picked: the first field saves a draft only its author sees
  // (is_published false; no version until Publish) through the create route; Save keeps it with its name
  useEffect(() => {
    if (report || creatingDraft.current || !isNew || !datasetId || unionIds.length === 0) return;
    creatingDraft.current = true;
    const nm = name.trim() || draftName();
    (async () => {
      try {
        const created = await api.createBusinessReport({
          name: nm, dataset_id: datasetId, data_source_type: 'saved_query', column_ids: unionIds, filter_specs: [],
          layout_config: { report_type: 'table' }, ...unionFields,
        });
        const full = await api.getBusinessReport(created.id);
        if (!name.trim()) setName(nm);
        setReport(full); setDraft(true);
        setMessage({ kind: 'info', text: `Kept as a draft, "${nm}", that only you can see. Save keeps it with the name you give it; Back discards it.` });
      } catch (e: any) {
        creatingDraft.current = false;
        setMessage({ kind: 'error', text: e?.message || 'The draft could not be kept. Save when you are ready.' });
      }
    })();
  }, [report, isNew, datasetId, unionKey]);   // eslint-disable-line react-hooks/exhaustive-deps
  // ── leaving with a draft (review P3 2026-11-07: only Back asked; a sidebar link, More > template or a closed tab
  //    left the draft behind).  ONE road out: ask, discard on yes, then go.  Open the report / Data and advanced
  //    settings wait for a Save (a draft has no page to open and the tabular builder would orphan it).
  const draftRef = useRef<{ draft: boolean; report: any; name: string }>({ draft: false, report: null, name: '' });
  draftRef.current = { draft, report, name };
  const leavingRef = useRef(false);
  /** asks when a draft exists; on yes discards it; returns whether to go */
  const mayLeave = async (): Promise<boolean> => {
    const { draft: d, report: r, name: n } = draftRef.current;
    if (!d || !r) return true;
    const ok = await appConfirm(`"${n || r.name}" is a draft that only you can see; what you changed since is not saved. Discard the draft?`,
      { title: 'Discard this draft?', confirmText: 'Discard', danger: true });
    if (!ok) return false;
    try { await api.deleteBusinessReport(r.id); } catch { /* switched off or already gone: leave anyway */ }
    setDraft(false);
    return true;
  };
  const leaveTo = async (path: string) => { if (await mayLeave()) navigate(path); };
  const goBack = () => leaveTo(draft && report ? REPORTS_PATH : report ? reportPath(report) : REPORTS_PATH);
  // a link anywhere in the app (the sidebar, the top bar) while a draft exists: caught before the router sees it
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (!draftRef.current.draft || leavingRef.current || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey) return;
      const a = (e.target as HTMLElement | null)?.closest?.('a[href]') as HTMLAnchorElement | null;
      if (!a || a.target === '_blank' || a.hasAttribute('download')) return;
      let to: URL;
      try { to = new URL(a.href, window.location.href); } catch { return; }
      if (to.origin !== window.location.origin) return;
      const path = to.pathname + to.search + to.hash;
      if (to.pathname === window.location.pathname) return;
      e.preventDefault(); e.stopPropagation();
      leavingRef.current = true;
      mayLeave().then(ok => { leavingRef.current = false; if (ok) navigate(path); }).catch(() => { leavingRef.current = false; });
    };
    document.addEventListener('click', onClick, true);
    return () => document.removeEventListener('click', onClick, true);
  }, []);   // eslint-disable-line react-hooks/exhaustive-deps
  // closing or reloading the tab: the browser's own question (the draft stays, only its author sees it; Back discards it)
  useEffect(() => {
    if (!draft) return;
    const onUnload = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = 'This report is a draft that only you can see. Save keeps it; Back discards it.'; return e.returnValue; };
    window.addEventListener('beforeunload', onUnload);
    return () => window.removeEventListener('beforeunload', onUnload);
  }, [draft]);

  if (loading) return <Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>;
  if (loadError) return <Alert severity="error" sx={{ m: 3 }}>{loadError}</Alert>;

  const paramNames = params.map(p => ({ name: p.name, label: p.label || p.name, type: p.parameter_type }));
  const datasetName = datasets.find((d: any) => d.id === datasetId)?.name ?? datasetLabel ?? report?.dataset_name ?? null;
  const secondName = mergedDatasetId ? (datasets.find((d: any) => d.id === mergedDatasetId)?.name ?? secondLabel ?? `dataset #${mergedDatasetId}`) : null;

  return (
    <Box sx={{ p: 1.5, display: 'flex', flexDirection: 'column', gap: 1, minHeight: 'calc(100vh - 80px)' }} data-testid="canvas-builder">
      {/* ── top bar ── */}
      <Paper variant="outlined" sx={{ p: 1 }}>
        <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
          <IconButton aria-label="Back" onClick={goBack} data-testid="canvas-back"><ArrowBackIcon /></IconButton>
          <TextField size="small" label="Report name" value={name} onChange={e => setName(e.target.value)}
            sx={{ minWidth: 240 }} inputProps={{ 'data-testid': 'canvas-name' }} />
          {isNew ? (
            // the data is picked BEFORE the first field: a draft is a report on THAT dataset, so once it exists the
            // pick is locked (review P2: the draft stayed on A while fields came from B; the save was refused and the
            // draft orphaned).  Back discards the draft and offers the pick again.
            <Tooltip title={report ? 'The draft is built on this data. Press Back to discard it and pick other data.' : ''}>
              <TextField select size="small" label="Data" value={datasetId ?? ''} sx={{ minWidth: 220 }} disabled={!!report}
                onChange={e => { setDatasetId(Number(e.target.value) || null); setCanvas({ version: 1, tiles: [] }); setReportTableCols([]); setSelectedId(null); }}
                SelectProps={{ native: false }} inputProps={{ 'data-testid': 'canvas-dataset' }}
                helperText={report ? 'Locked while the draft exists' : undefined} FormHelperTextProps={{ 'data-testid': 'canvas-dataset-locked' } as any}>
                {datasets.map((d: any) => <MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
              </TextField>
            </Tooltip>
          ) : (
            <Typography variant="body2" color="text.secondary" data-testid="canvas-dataset-name">
              Data: {datasetName ?? `dataset #${datasetId}`}{secondName ? ` + ${secondName} (stacked by column name)` : ''}
            </Typography>
          )}
          {isNew && datasetId && !report && !secondPick && (
            <Button size="small" variant="text" onClick={() => setSecondPick(true)} data-testid="canvas-second-source">
              + Same data from another source
            </Button>
          )}
          {isNew && datasetId && secondPick && (
            <Tooltip title={report ? 'The draft is built on these two. Press Back to discard it and pick other data.'
              : 'Rows from this second dataset are stacked under the first (UNION ALL), matched by column name. The fields are the first dataset\'s.'}>
              <TextField select size="small" label="Same data from another source" value={mergedDatasetId ?? ''} sx={{ minWidth: 260 }} disabled={!!report}
                onChange={e => setMergedDatasetId(Number(e.target.value) || null)}
                SelectProps={{ native: false }} inputProps={{ 'data-testid': 'canvas-second-dataset' }}
                helperText={report ? 'Locked while the draft exists' : 'Stacked under the first, matched by column name'}>
                <MenuItem value="">(none)</MenuItem>
                {datasets.filter((d: any) => d.id !== datasetId).map((d: any) => <MenuItem key={d.id} value={d.id}>{d.name}</MenuItem>)}
              </TextField>
            </Tooltip>
          )}
          {missingInSecond.length > 0 && (
            <Typography variant="caption" color="error" data-testid="canvas-second-missing">
              Not in {secondName}: {missingInSecond.join(', ')} -- a UNION lines the two up by column name, so the save will refuse these fields.
            </Typography>
          )}
          <Box sx={{ flex: 1 }} />
          <Tooltip title={!report ? 'Add a field: the data is read as soon as the report exists' : missing.length ? `Pick a value for ${missing.join(', ')} in Filters first` : 'Read the data again with this canvas and the chosen values -- nothing is saved'}>
            <span>
              <Button variant="outlined" startIcon={running ? <CircularProgress size={14} /> : <PlayIcon />}
                disabled={!report || running || unionIds.length === 0 || missing.length > 0} onClick={() => runNow(true)}
                data-testid="canvas-refresh">{running ? 'Reading…' : 'Refresh'}</Button>
            </span>
          </Tooltip>
          <Tooltip title="On: every new field or value reads the data by itself. Off: the visuals wait for Refresh (for a large source).">
            <FormControlLabel sx={{ mr: 0 }} label={<Typography variant="caption">Refresh by itself</Typography>}
              control={<Switch size="small" checked={autoRefresh} slotProps={{ input: { 'data-testid': 'canvas-auto-refresh' } as any }}
                onChange={e => { setAutoRefresh(e.target.checked); writeAutoRefresh(report?.id ?? null, e.target.checked); }} />} />
          </Tooltip>
          <Button variant="outlined" endIcon={<MoreVertIcon />} onClick={e => setMoreAnchor(e.currentTarget)} data-testid="canvas-more"
            aria-haspopup="menu" aria-expanded={!!moreAnchor}>More</Button>
          <Menu anchorEl={moreAnchor} open={!!moreAnchor} onClose={() => setMoreAnchor(null)} transitionDuration={0} data-testid="canvas-more-menu">
            <MenuItem data-testid="canvas-more-settings" onClick={() => { setMoreAnchor(null); setSettingsOpen(true); }}>
              <ListItemIcon><SettingsIcon fontSize="small" /></ListItemIcon><ListItemText primary="Report settings" secondary="Code, description, owner group" />
            </MenuItem>
            <MenuItem data-testid="canvas-more-popups" onClick={() => { setMoreAnchor(null); setPopupsOpen(true); }}>
              <ListItemIcon><TouchAppIcon fontSize="small" /></ListItemIcon><ListItemText primary="Popups and downloads" secondary="What a click on a value does" />
            </MenuItem>
            <MenuItem data-testid="canvas-more-advanced" disabled={!report || draft}
              onClick={() => { setMoreAnchor(null); if (report && !draft) navigate(reportEditPath(report, 'data')); }}>
              <ListItemIcon><TuneIcon fontSize="small" /></ListItemIcon>
              <ListItemText primary="Data and advanced settings" secondary={report && !draft ? 'Row limit, calculations, grouping, a second dataset' : 'Save the report first'} />
            </MenuItem>
            <MenuItem data-testid="canvas-more-template" onClick={() => { setMoreAnchor(null); void leaveTo(NEW_REPORT_FROM_TEMPLATE_PATH); }}>
              <ListItemIcon><DashboardCustomizeIcon fontSize="small" /></ListItemIcon><ListItemText primary="Start from a template" secondary={draft ? 'Discards this draft' : undefined} />
            </MenuItem>
            <MenuItem data-testid="canvas-more-powerbi" onClick={() => { setMoreAnchor(null); setPbiOpen(true); }}>
              <ListItemIcon><UploadFileIcon fontSize="small" /></ListItemIcon><ListItemText primary="Import from Power BI" secondary="A .pbix, .pbit or .pbip file becomes a new report" />
            </MenuItem>
            <MenuItem data-testid="canvas-more-open" disabled={!report || draft} onClick={() => { setMoreAnchor(null); if (report && !draft) navigate(reportPath(report)); }}>
              <ListItemIcon><LaunchIcon fontSize="small" /></ListItemIcon><ListItemText primary="Open the report" secondary={draft ? 'Save the report first' : undefined} />
            </MenuItem>
          </Menu>
          <Tooltip title={canSave ? '' : [...pageProblems, ...problems.map(p => p.message)].slice(0, 3).join(' ')}>
            <span>
              <Button variant="contained" startIcon={saving ? <CircularProgress size={14} /> : <SaveIcon />}
                disabled={!canSave} onClick={save} data-testid="canvas-save">Save</Button>
            </span>
          </Tooltip>
        </Stack>
      </Paper>

      {message && <Alert severity={message.kind} onClose={() => setMessage(null)} data-testid="canvas-message">{message.text}</Alert>}
      {pageProblems.length > 0 && canvas.tiles.length > 0 && (
        <Alert severity="warning" data-testid="canvas-page-problems">{pageProblems.join(' ')}</Alert>
      )}
      {runNote && (
        <Alert severity="info" sx={{ mb: 1 }} onClose={() => setRunNote('')}>{runNote}</Alert>
      )}
      {runError && (
        <Alert severity="error" onClose={() => setRunError('')} data-testid="canvas-run-error"
          action={<Button size="small" color="inherit" onClick={() => runNow(true)}>Try again</Button>}>{runError}</Alert>
      )}
      {(lastRun || running) && (
        <Typography variant="caption" color="text.secondary" data-testid="canvas-run-status" sx={{ px: 0.5 }}>
          {running ? 'Reading the data…' : lastRun ? `Showing the run of ${lastRun.at.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}${lastRun.total != null ? ` · ${lastRun.total.toLocaleString()} rows` : ''}${lastRun.truncated ? ' (cut: the result was capped)' : ''}. Nothing is saved by a run.` : ''}
          {!running && runIsStale && (autoRefresh ? ' The canvas changed since: reading again.' : ' The canvas changed since: press Refresh.')}
          {lastRun && extraFilters.length > 0 && <span data-testid="run-extra-filters">{` ${extraFilters.length} fixed filter${extraFilters.length === 1 ? '' : 's'} not yet saved narrow${extraFilters.length === 1 ? 's' : ''} this run.`}</span>}
          {unsavedQuestions.length > 0 && <span data-testid="run-unsaved-questions">{` ${unsavedQuestions.join(', ')}: a question is not applied until Save.`}</span>}
        </Typography>
      )}

      {/* ── canvas | filters | fields + visuals + build / format ── */}
      <Box sx={{ display: 'grid', gap: 1, alignItems: 'stretch', flex: 1, minHeight: 0,
                 gridTemplateColumns: { xs: '1fr', md: `1fr ${filtersOpen ? '220px' : '36px'} ${fieldsOpen ? '300px' : '36px'}` } }}
           data-testid="designer-panes">
        {/* the canvas, the page tabs along the bottom */}
        <Box sx={{ minWidth: 0 }}>
          {canvas.tiles.length === 0 && (
            <Alert severity="info" sx={{ mb: 1 }} data-testid="canvas-empty-offer"
              action={<Button size="small" color="inherit" onClick={() => void leaveTo(NEW_REPORT_FROM_TEMPLATE_PATH)} data-testid="canvas-start-template">Start from a template</Button>}>
              Pick a visual on the right and tick its fields -- or start from one of the ready designs.
            </Alert>
          )}
          <CanvasThemeContext.Provider value={resolveTheme({ theme: look.spec })}>
          <CanvasCompareContext.Provider value={compareFrom(canvas, params.map(p => ({ name: p.name, value: paramValues[p.name], label: p.label })), params)}>
          <CanvasBandContext.Provider value={{
            reportName: name, reportCode: canvas.report_code ?? null,
            parameters: lastRun ? params.filter(p => p.id).map(p => ({ name: p.name, label: p.label || p.name, value: paramValues[p.name] })) : null,
          }}>
          <ReportCanvasView canvas={canvas} reportId={report?.id ?? null} cols={cols} grouped={grouped} editable pagesAt="bottom"
            selectedId={selectedId} onSelect={setSelectedId} onLayout={onLayout} onDropField={onDropField}
            onPagesChange={pages => setCanvas(c => { const { pages: _p, ...rest } = c; return pages && pages.length ? { ...rest, pages } : rest; })}
            problems={problemsByTile} staleFields={staleFields}
            reportTable={<Typography variant="body2" color="text.secondary">
              The report&apos;s own table: {reportTableCols.filter(i => cols.has(i)).map(i => cols.get(i)!.label).join(', ') || 'no columns yet'}.
              It pages through every row when the report runs.
            </Typography>}
            notRunWords={notRunWords({ auto: autoRefresh, reading: running, missing, hasReport: !!report, error: runError })}
            run={{ executionId: lastRun?.id ?? null, totalRows: lastRun?.total ?? null, truncated: lastRun?.truncated ?? false }} />
          </CanvasBandContext.Provider>
          </CanvasCompareContext.Provider>
          </CanvasThemeContext.Provider>
        </Box>

        {/* the Filters pane (its three groups are stage D; today's chips live here until then) */}
        <Paper variant="outlined" sx={{ ...PANE_SX }} data-testid="filters-pane" data-open={filtersOpen ? 'yes' : 'no'}>
          <PaneHeader title="Filters" open={filtersOpen} onToggle={() => setFiltersOpen(o => !o)} testId="filters-pane-toggle" />
          {filtersOpen && (
            <>
              <FiltersPane cols={cols} columns={columns} datasetId={datasetId} canApply={!report || ['saved_query', 'dataset'].includes(String(report.data_source_type || 'saved_query'))}
                params={params} onParamsChange={changeParams} onAskField={addAsked} onAskPick={() => { setAskCol(null); setAskOpen(true); }}
                onOpenSettings={() => setParamEditorRows(paramRowsFromServer(params))}
                valueControl={p => p.id && report
                  ? <ReportParamControl param={p} params={params.filter(x => x.id)} values={paramValues} onValues={setParamValues}
                      fetchValues={(body: any) => api.getBusinessReportParamValues(report.id, body)} showRequiredError={false} />
                  : <Typography variant="caption" color="text.disabled">A value can be picked once the report is saved.</Typography>}
                sourceFilters={sourceFilters} filters={filters} onFiltersChange={f => setFilters(fs => f(fs))} />
              {paramsDirty && <Typography variant="caption" color="text.secondary" sx={{ px: 1 }}>New questions are added when you save.</Typography>}
            </>
          )}
        </Paper>

        {/* Fields over the Visuals grid over Build / Format */}
        <Paper variant="outlined" sx={{ ...PANE_SX }} data-testid="side-pane" data-open={fieldsOpen ? 'yes' : 'no'}>
          <PaneHeader title="Fields" open={fieldsOpen} onToggle={() => setFieldsOpen(o => !o)} testId="fields-pane-toggle" />
          {fieldsOpen && (
            <>
              <Box sx={{ maxHeight: '26vh', display: 'flex', flexDirection: 'column', minHeight: 0, px: 0.5 }}>
                <FieldsPane columns={columns} query={fieldQuery} onQuery={setFieldQuery} usedIds={usedIds} hasData={!!datasetId}
                  selectedName={selected ? 'the selected visual' : null} onToggle={toggleField} />
              </Box>
              <Divider sx={{ my: 0.5 }} />
              <Box sx={{ px: 0.5 }}>
                <Typography variant="subtitle2" sx={{ mb: 0.5 }}>Visuals</Typography>
                <VisualsGrid selectedKind={selected?.kind ?? null} hasReportTile={hasReportTile} onPick={pickVisual} />
              </Box>
              <Divider sx={{ my: 0.5 }} />
              <Tabs value={sideTab} onChange={(_e, v) => setSideTab(v)} variant="fullWidth" sx={{ minHeight: 32 }} aria-label="Build or Format">
                <Tab value="build" label="Build" sx={{ minHeight: 32, py: 0 }} data-testid="side-tab-build" />
                <Tab value="format" label="Format" sx={{ minHeight: 32, py: 0 }} data-testid="side-tab-format" />
              </Tabs>
              <Box sx={{ p: 0.5, overflow: 'auto', flex: 1, minHeight: 160 }} data-testid="canvas-properties">
                {sideTab === 'build' && (selected ? (
                  <BuildTab tile={selected} cols={cols} columns={columns} grouped={grouped} datasetId={datasetId} paramNames={paramNames}
                    reportTableCols={reportTableCols} setReportTableCols={setReportTableCols}
                    onChange={f => updateTile(selected.id, f)} onNote={words => setMessage({ kind: 'info', text: words })} />
                ) : (
                  <Typography variant="body2" color="text.secondary" data-testid="build-nothing-selected">
                    Click a visual to see its fields, or pick one above to add it.
                  </Typography>
                ))}
                {sideTab === 'format' && (selected ? (
                  <VisualFormat tile={selected} cols={cols} columns={columns} grouped={grouped} pages={canvas.pages}
                    pageOf={(id: string) => pageOfTile(canvas, id)}
                    movePage={(id: string, k: number) => setCanvas(c => ({ ...c, pages: (c.pages ?? []).map((p, i) => ({ ...p, tiles: i === k ? [...p.tiles.filter(x => x !== id), id] : p.tiles.filter(x => x !== id) })) }))}
                    hasCompare={!!canvas.compare} paramNames={paramNames} problems={problemsByTile[selected.id] ?? []}
                    onChange={f => updateTile(selected.id, f)} onDelete={() => deleteTile(selected.id)} />
                ) : (
                  <ReportFormat canvas={canvas} columns={columns} params={params} viewersMayRearrange={viewersMayRearrange}
                    setViewersMayRearrange={setViewersMayRearrange} setCanvas={setCanvas} openGroup={urlTab === 'look' ? 'theme' : null}
                    theme={<ReportLookPanel report={report ?? { id: null, name, layout_config: {} }}
                      embedded={{ spec: look.spec, insights: look.insights, onChange: (spec, insights) => { setLook({ spec, insights }); setLookDirty(true); } }} />} />
                ))}
              </Box>
            </>
          )}
        </Paper>
      </Box>

      <ReportSettingsDialog open={settingsOpen} onClose={() => setSettingsOpen(false)} groups={userGroups} canListGroups={canListGroups} saved={!!report}
        values={{ reportCode: canvas.report_code ?? '', description, ownerGroupId }}
        onChange={v => {
          if (v.reportCode !== (canvas.report_code ?? '')) setCanvas(c => ({ ...c, report_code: v.reportCode || undefined }));
          if (v.description !== description || v.ownerGroupId !== ownerGroupId) setMetaDirty(true);
          setDescription(v.description); setOwnerGroupId(v.ownerGroupId);
        }} />

      {/* More > Import from Power BI: a NEW report from a .pbix / .pbit / .pbip, on a dataset picked there (2026-11-07) */}
      <PowerBiImportDialog open={pbiOpen} onClose={() => setPbiOpen(false)} datasets={datasets.map((d: any) => ({ id: d.id, name: d.name }))}
        initialDatasetId={datasetId} onCreated={made => { setPbiOpen(false); void leaveTo(reportEditPath(made.report)); }} />

      {/* More > Popups and downloads: the actions editor, as a side panel */}
      <AppDialog open={popupsOpen} onClose={() => setPopupsOpen(false)} size="md" title="Popups and downloads" testId="popups-panel"
        subtitle="What a click on a value does: a popup with the detail, or a download. Saved with the report's Save."
        actions={<Button variant="contained" onClick={() => setPopupsOpen(false)} data-testid="popups-panel-done">Done</Button>}>
        <CanvasActionsEditor reportId={report?.id ?? null} canvas={canvas} setCanvas={setCanvas} cols={cols} parameters={params} reportCode={canvas.report_code}
          reportDatasetId={report?.dataset_id ?? null} />
      </AppDialog>

      {/* Filters > Viewer can change > Settings: the one parameter editor, every row */}
      <AppDialog open={paramEditorRows !== null} onClose={() => setParamEditorRows(null)} size="lg" title="Parameter settings" testId="param-settings"
        subtitle="Every parameter of the report: its type, where its choices come from, its default, and more. Saved with the report's Save."
        actions={<>
          <Button onClick={() => setParamEditorRows(null)}>Cancel</Button>
          <Button variant="contained" onClick={() => paramEditorRows && applyParamEditor(paramEditorRows)} data-testid="param-settings-done">Done</Button>
        </>}>
        {paramEditorRows && (
          <ReportParameterEditor rows={paramEditorRows} onChange={setParamEditorRows} columns={columns.filter(c => !c.hidden).map(toAuthoringColumn)}
            datasetId={datasetId} sourceFilters={sourceFilters} />
        )}
      </AppDialog>

      {/* + Ask for a value */}
      <AppDialog open={askOpen}
        onClose={() => setAskOpen(false)}
        size="xs"
        title="Ask for a value when the report runs"
        actions={<>
          <Button onClick={() => setAskOpen(false)}>Cancel</Button>
          <Button variant="contained" disabled={!askCol} onClick={() => { if (askCol) addAsked(askCol); setAskOpen(false); }}>Add</Button>
        </>}>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1.5 }}>
            The person running the report picks the value from the data -- a date field takes any date on a
            calendar. Left empty, the report shows every value.
          </Typography>
          <Autocomplete options={columns} value={askCol} onChange={(_, v) => setAskCol(v)}
            getOptionLabel={c => c.label} renderInput={p => <TextField {...p} label="Field" autoFocus />} />
      </AppDialog>

    </Box>
  );
}
