import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { ensureAppConfig } from './runtimeConfig';

// 2026-06-30 BUG FIX -- App is dynamically imported AFTER
// ensureAppConfig() resolves.  Pre-fix it was a static top-level
// import which triggers the entire App import graph (including
// services/api/core.ts) at module-parse time -- BEFORE the async
// /config.json fallback ran.  services/api/core.ts captured
// API_BASE_URL as a const at parse time, freezing it to "" when
// config.js shipped with empty apiUrl.  The /config.json fallback
// then updated window.APP_CONFIG correctly but core.ts had already
// snapshotted the empty value, so every API call went same-origin,
// hit the SPA catch-all, and surfaced as "Unexpected token '<'"
// errors.  Dynamic import defers core.ts evaluation until after the
// fallback resolves the real apiUrl.

// 2026-06-17 — Runtime config strategy.
//
// PRIMARY (synchronous): index.html loads /config.js via a regular
// <script> tag BEFORE this module evaluates.  config.js sets
// window.APP_CONFIG synchronously.  When main.tsx runs (and every
// downstream module like services/api/core.ts), window.APP_CONFIG is
// guaranteed to be set.
//
// FALLBACK (async, backward-compat): if config.js failed to load — for
// example because the deploy environment is still serving the legacy
// /config.json — we attempt a content-type-guarded fetch as a one-shot
// rescue.  The content-type check prevents the historical failure mode
// where a static-server SPA catch-all returned <!doctype html>... and
// JSON.parse threw a confusing "Unexpected token '<'" error.
//
// In ANY failure scenario, window.APP_CONFIG falls back to an empty
// apiUrl (same-origin fetches), and a console warning explains why.
//
// Why not just keep the old async-fetch bootstrap?
//   - Async fetch raced against ES-module pre-evaluation by the browser.
//   - SPA catch-all returning HTML caused silent fallback to empty URL
//     (a bug that only surfaced as "Unexpected token '<'" much later).
//   - Helm ConfigMap mounting works identically for .js vs .json files,
//     so deploying the synchronous variant has zero infra cost.

// Deep-dive #8 (2026-06-30): single source of truth for the
// window.APP_CONFIG runtime contract lives in
// src/types/app-config.d.ts.  tsconfig `include: ["src"]` picks
// it up automatically -- no runtime import needed.

// Deep-dive #8 (2026-06-30): expose the bootstrap failure mode so
// downstream code (AuthContext offline banner) can show the operator
// what happened.  Pre-fix the SPA booted silently with apiUrl='' and
// the operator saw cryptic "Unexpected token '<'" errors deep in the
// UI instead of a clear "Backend not configured" message.
//
// 2026-07-12: BootstrapStatus + the Window.__QS_BOOTSTRAP_STATUS__
// augmentation moved to src/types/app-config.d.ts (the single source of
// truth for the Window contract) so the IDE's TS server always sees it --
// a `declare global` here was only picked up once main.tsx was loaded,
// which made AuthContext.tsx flag "__QS_BOOTSTRAP_STATUS__ does not exist".

// 2026-09-28: ensureAppConfig() moved to ./runtimeConfig.ts -- the Excel
// add-in pages (/addin/*.html) bootstrap through the SAME function, so
// "where is the API" is decided once for every page the UI image serves.

// FB-47 (2026-09-20): when the deployment changed under an open tab and the
// user does a FULL navigation, the chunk that fails can be one in App's own
// static import graph -- and that failure happens HERE, before React exists,
// so no ErrorBoundary can name it.  Measured: intercepting a static chunk
// left an empty <body> and a console-only "Failed to fetch dynamically
// imported module: App-*.js".  This is the last line: a plain-DOM message
// with a Reload, rendered without React, for that one class of failure.
function isChunkLoadFailure(err: unknown): boolean {
  const text = String((err as { message?: unknown })?.message ?? err ?? '');
  return /Failed to fetch dynamically imported module|error loading dynamically imported module|Importing a module script failed|Loading chunk [\w-]+ failed/i.test(text);
}

function renderStaleBuildFallback(err: unknown): void {
  const root = document.getElementById('root');
  if (!root) return;
  root.innerHTML = '';
  const box = document.createElement('div');
  box.setAttribute('data-testid', 'stale-build-boot');
  box.setAttribute('style', 'font-family:system-ui,sans-serif;max-width:560px;margin:15vh auto;padding:24px;text-align:center;color:#16181d');
  const h = document.createElement('h2'); h.textContent = 'QueryStudio was updated';
  const p = document.createElement('p');
  p.textContent = 'This tab is running an older build and part of it no longer exists on the server. Reload to get the current version; nothing you saved is affected.';
  const pre = document.createElement('pre');
  pre.setAttribute('style', 'font-size:12px;color:#5b626e;white-space:pre-wrap');
  pre.textContent = String((err as { message?: unknown })?.message ?? err ?? '');
  const btn = document.createElement('button');
  btn.textContent = 'Reload'; btn.setAttribute('data-testid', 'stale-build-boot-reload');
  btn.setAttribute('style', 'font-size:15px;padding:8px 20px;border-radius:6px;border:0;background:#2563eb;color:#fff;cursor:pointer');
  btn.onclick = () => window.location.reload();
  box.append(h, p, pre, btn);
  root.appendChild(box);
}

ensureAppConfig().then(async () => {
  // Dynamic import so App + services/api/core.ts evaluate AFTER
  // window.APP_CONFIG has been finalized (see top-of-file comment).
  let App: React.ComponentType;
  try {
    ({ default: App } = await import('./App'));
  } catch (err) {
    if (isChunkLoadFailure(err)) {
      console.error('[bootstrap] the App bundle could not be loaded -- the deployment changed under this tab:', err);
      renderStaleBuildFallback(err);
      return;
    }
    throw err;
  }
  ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
  // Desktop step one (2026-11-08): the app-shell worker, production builds only; after the first
  // paint so it never delays the app (src/installable/registerShellWorker.ts).
  import('./installable/registerShellWorker').then(m => m.registerShellWorker()).catch(() => undefined);
});
