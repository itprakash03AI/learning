/**
 * Phase 87 — System Accounts Management Page.
 * Admin CRUD for service/system accounts used for auto-credential fetching.
 *
 * Phase 154 (2026-06-25) -- vault-resolver fields.  When use_vault is
 * enabled, the QueryStudio qs_credentials (mirrors ETL pattern) reads
 * credentials from QSClient + Vault at runtime instead of the
 * encrypted password column.  Same vault entries serve both ETL +
 * QueryStudio pods so operators don't onboard secrets twice.
 */
import { appConfirm } from './common/appDialogs';
import React, { useState, useEffect, useCallback } from 'react';
import {
  Box, Typography, Button, Paper, Table, TableBody, TableCell, TableContainer,
  TableHead, TableRow, Chip, TextField, MenuItem, Alert, CircularProgress, Tooltip, Stack,
  FormControlLabel, Switch, Accordion, AccordionSummary, AccordionDetails,
} from '@mui/material';
import RowActions from './common/RowActions';
import AppDialog from './common/AppDialog';
import { STICKY_ACTIONS_SX, TABLE_SCROLL_SX } from './common/stickyActions';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  PlayArrow as TestIcon,
  Refresh as RefreshIcon,
  CheckCircle as SuccessIcon,
  Error as ErrorIcon,
  VpnKey as VaultIcon,
  ExpandMore as ExpandMoreIcon,
} from '@mui/icons-material';
import api from '../services/api';
import ListPager, { clientPage } from './common/ListPager';

interface SystemAccount {
  id: number;
  name: string;
  account_type: string;
  username: string;
  password: string;
  config: any;
  is_active: boolean;
  last_used_at: string | null;
  last_status: string | null;
  last_error: string | null;
  created_by: string | null;
  created_at: string | null;
  updated_at: string | null;
  // Phase 154 vault-resolver surface (server returns these from to_dict).
  use_vault?: boolean;
  secret_ref?: string | null;
  secret_type?: string | null;
  vault_field_map?: Record<string, string> | null;   // 2026-11-08: the Vault entry's own field names
  vault_role_name?: string | null;
  vault_role_type?: string | null;
}

const ACCOUNT_TYPES = [
  { value: 'aws_portal',    label: 'AWS Portal (S3 / STS)' },
  { value: 'snowflake_sso', label: 'Snowflake service account (username + password or key)' },
  // 2026-11-09: the secret may be a PASSWORD or a TOKEN -- a Databricks access token, a Starburst / Trino
  // session token (the owner's on-prem Hive) -- held as the account's password or a kv `token` field
  { value: 'db_account',    label: 'DB Account (Trino / Snowflake / Oracle / Databricks; a password or a token)' },
  { value: 'ad_account',    label: 'AD Account (Starburst / LDAP; a password or a session token)' },
  { value: 's3_keys',       label: 'S3 Access Keys (KV vault entry)' },
  // AQD-11 -- an SFTP login: {username, private_key} or {username, password} in a KV vault entry
  { value: 'sftp_account',  label: 'SFTP Login (private key or password, KV vault entry)' },
  // 2026-10-03 -- a Snowflake key-pair login: {username, private_key[, private_key_passphrase]} in a KV vault entry
  { value: 'snowflake_keypair', label: 'Snowflake Key Pair (private key, KV vault entry)' },
];

/** Types whose credential exists ONLY as a Vault kv_secrets entry -- the
 *  backend validator refuses them otherwise (admin_api SystemAccountCreate). */
const KV_VAULT_ONLY_TYPES = ['snowflake_keypair'];

const SECRET_TYPES = [
  { value: 'DB_accounts', label: 'DB_accounts — (user, password) tuple from Vault' },
  { value: 'AD_accounts', label: 'AD_accounts — (user, password) tuple from Vault' },
  { value: 'kv_secrets',  label: 'kv_secrets — key/value entry (Snowflake: username + password or private_key; S3: access_key + secret_key; Databricks / Starburst token login: token)' },
];

type FormState = {
  name: string;
  account_type: string;
  username: string;
  password: string;
  config: any;
  // Phase 154 vault-resolver fields.
  use_vault: boolean;
  secret_ref: string;
  secret_type: string;
  vault_auth_url: string;
  vault_role_name: string;
  vault_role_type: string;
  vault_secret_url: string;
  vault_rotate_url: string;
  // 2026-07-13 — ETL parity: AppRole / JWT-step-up fields (optional).
  vault_step_up_name: string;
  vault_step_up_auth_url: string;
  vault_approle_secret_id_url: string;
  vault_approle_auth_url: string;
  vault_role_id: string;
  // 2026-11-08 -- the Vault entry's own field names (value -> field in Vault); {} = the names match
  vault_field_map: Record<string, string>;
};

/** The values QueryStudio reads from a Vault entry, in plain words (core/qs_credentials/field_map.py). */
const VAULT_VALUE_WORDS: Array<[string, string]> = [
  ['username', 'Login name'], ['password', 'Password (or the API token sent as a password)'],
  ['token', 'Token (Databricks personal access token)'], ['private_key', 'Private key (Snowflake key pair)'],
  ['private_key_passphrase', 'Private key passphrase'], ['access_key', 'Access key (S3, Athena)'],
  ['secret_key', 'Secret key (S3, Athena)'],
];

const EMPTY_FORM: FormState = {
  name: '', account_type: 'aws_portal', username: '', password: '', config: {},
  use_vault: false,
  secret_ref: '', secret_type: '',
  vault_auth_url: '', vault_role_name: '', vault_role_type: '',
  vault_secret_url: '', vault_rotate_url: '',
  vault_step_up_name: '', vault_step_up_auth_url: '',
  vault_approle_secret_id_url: '', vault_approle_auth_url: '', vault_role_id: '',
  vault_field_map: {},
};

interface SystemAccountsPageProps {
  /** When true, skip the outer padding + h5 title.  Set by AdminPage
   *  (which already renders its own content header + p:3 panel) so we
   *  don't double up.  Default false preserves standalone-route shape
   *  (still reachable at /system-accounts deep links). */
  embedded?: boolean;
}

/** "Allowed hosts" (2026-10-29): where an SFTP account's login may be sent. */
export const allowedHostsText = (config: any): string =>
  (Array.isArray(config?.allowed_hosts) ? config.allowed_hosts : []).join(', ');

export const withAllowedHosts = (config: any, text: string): any => {
  const hosts = text.split(/[\s,]+/).map(h => h.trim()).filter(Boolean);
  const next = { ...(config || {}) };
  if (hosts.length) next.allowed_hosts = hosts; else delete next.allowed_hosts;
  return next;
};

const SystemAccountsPage: React.FC<SystemAccountsPageProps> = ({ embedded = false }) => {
  const [accounts, setAccounts] = useState<SystemAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [roleIdSaved, setRoleIdSaved] = useState(false);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  // the Allowed hosts text as typed (the list is parsed from it); null = show
  // the stored list -- rebuilding the text from the list on every key ate commas
  const [hostsText, setHostsText] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState<number | null>(null);
  const [testResult, setTestResult] = useState<{ id: number; success: boolean; message: string } | null>(null);
  // Pages (2026-10-13, "pagination in all grids"): accounts grow with use.
  const [acctPage, setAcctPage] = useState(1);
  const [acctPageSize, setAcctPageSize] = useState(50);
  const [error, setError] = useState('');

  const loadAccounts = useCallback(async () => {
    setLoading(true);
    try {
      const res: any = await api.get('/api/admin/system-accounts');
      setAccounts(res.accounts || []);
    } catch (e: any) {
      setError(e?.message || 'Failed to load system accounts');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadAccounts(); }, [loadAccounts]);

  // Phase 154 -- validation parity with the backend Pydantic validator.
  // When use_vault=True, the 5 vault fields are required.  Surface the
  // error inline before the user hits Save so they don't get bounced.
  const vaultFieldsValid = (): { ok: boolean; missing: string[] } => {
    if (!form.use_vault) return { ok: true, missing: [] };
    const missing: string[] = [];
    if (!form.secret_type.trim())      missing.push('secret_type');
    if (!form.vault_auth_url.trim())   missing.push('vault_auth_url');
    if (!form.vault_role_name.trim())  missing.push('vault_role_name');
    if (!form.vault_role_type.trim())  missing.push('vault_role_type');
    if (!form.vault_secret_url.trim()) missing.push('vault_secret_url');
    return { ok: missing.length === 0, missing };
  };

  const handleSave = async () => {
    if (KV_VAULT_ONLY_TYPES.includes(form.account_type)
        && (!form.use_vault || form.secret_type !== 'kv_secrets')) {
      setError('A Snowflake Key Pair account reads its private key from Vault: turn on "Use Vault" and pick Secret Type kv_secrets.');
      return;
    }
    const v = vaultFieldsValid();
    if (!v.ok) {
      setError(`Vault mode requires: ${v.missing.join(', ')}`);
      return;
    }
    setSaving(true);
    setError('');
    try {
      // Build payload with vault fields ONLY when use_vault or the
      // fields are filled.  Avoids clobbering existing rows with
      // empty strings.
      const vaultFields: Record<string, any> = {};
      if (form.use_vault !== undefined) vaultFields.use_vault = form.use_vault;
      if (form.secret_ref.trim())       vaultFields.secret_ref = form.secret_ref.trim();
      if (form.secret_type.trim())      vaultFields.secret_type = form.secret_type.trim();
      if (form.vault_auth_url.trim())   vaultFields.vault_auth_url = form.vault_auth_url.trim();
      if (form.vault_role_name.trim())  vaultFields.vault_role_name = form.vault_role_name.trim();
      if (form.vault_role_type.trim())  vaultFields.vault_role_type = form.vault_role_type.trim();
      if (form.vault_secret_url.trim()) vaultFields.vault_secret_url = form.vault_secret_url.trim();
      if (form.vault_rotate_url.trim()) vaultFields.vault_rotate_url = form.vault_rotate_url.trim();
      // ETL-parity AppRole / JWT-step-up fields (only sent when filled).
      if (form.vault_step_up_name.trim())          vaultFields.vault_step_up_name = form.vault_step_up_name.trim();
      if (form.vault_step_up_auth_url.trim())      vaultFields.vault_step_up_auth_url = form.vault_step_up_auth_url.trim();
      if (form.vault_approle_secret_id_url.trim()) vaultFields.vault_approle_secret_id_url = form.vault_approle_secret_id_url.trim();
      if (form.vault_approle_auth_url.trim())      vaultFields.vault_approle_auth_url = form.vault_approle_auth_url.trim();
      if (form.vault_role_id.trim())               vaultFields.vault_role_id = form.vault_role_id.trim();
      // the Vault field names: only the pairs that name a field; on an edit an empty map clears it.
      // 2026-11-08 (review): a map applies to a kv_secrets entry only (the server refuses it on any other
      // type) -- for every other secret type an EMPTY map is sent, so switching the type clears it.
      const fieldMap: Record<string, string> = {};
      if (form.secret_type.trim() === 'kv_secrets') {
        Object.entries(form.vault_field_map || {}).forEach(([k, v]) => { if ((v || '').trim()) fieldMap[k] = v.trim(); });
      }
      if (editingId || Object.keys(fieldMap).length) vaultFields.vault_field_map = fieldMap;

      if (editingId) {
        const updates: any = { ...vaultFields };
        if (form.name)     updates.name = form.name;
        if (form.username) updates.username = form.username;
        if (form.password && form.password !== '***') updates.password = form.password;
        // 2026-10-29: the account's config travels on an edit too, so its
        // Allowed hosts can be set (it was sent on create only).
        updates.config = form.config || {};
        await api.put(`/api/admin/system-accounts/${editingId}`, updates);
      } else {
        await api.post('/api/admin/system-accounts', {
          name: form.name,
          account_type: form.account_type,
          username: form.username,
          password: form.password,
          config: form.config,
          ...vaultFields,
        });
      }
      setDialogOpen(false);
      loadAccounts();
    } catch (e: any) {
      setError(e?.message || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!await appConfirm('Delete this system account? Connections using it will lose credential access.')) return;
    try {
      await api.delete(`/api/admin/system-accounts/${id}`);
      loadAccounts();
    } catch (e: any) {
      setError(e?.message || 'Delete failed');
    }
  };

  const handleTest = async (id: number) => {
    setTesting(id);
    setTestResult(null);
    try {
      const res: any = await api.post(`/api/admin/system-accounts/${id}/test`);
      setTestResult({ id, success: res.success, message: res.message });
    } catch (e: any) {
      setTestResult({ id, success: false, message: e?.message || 'Test failed' });
    } finally {
      setTesting(null);
    }
  };

  const handleRefresh = async (id: number) => {
    setTesting(id);
    try {
      const res: any = await api.post(`/api/admin/system-accounts/${id}/refresh`);
      setTestResult({ id, success: res.success, message: res.message });
      loadAccounts();
    } catch (e: any) {
      setTestResult({ id, success: false, message: e?.message || 'Refresh failed' });
    } finally {
      setTesting(null);
    }
  };

  const openCreate = () => {
    setEditingId(null);
    setForm({ ...EMPTY_FORM });
    setHostsText(null);
    setDialogOpen(true);
    setError('');
  };

  const openEdit = async (acct: SystemAccount) => {
    setHostsText(null);
    setEditingId(acct.id);
    setRoleIdSaved(false);
    setForm({
      name:           acct.name,
      account_type:   acct.account_type,
      username:       acct.username,
      password:       '***',
      config:         acct.config || {},
      use_vault:        !!acct.use_vault,
      secret_ref:       acct.secret_ref       || '',
      secret_type:      acct.secret_type      || '',
      vault_auth_url:   '',  // filled from the one-account read below
      vault_role_name:  acct.vault_role_name  || '',
      vault_role_type:  acct.vault_role_type  || '',
      vault_secret_url: '',
      vault_rotate_url: '',
      vault_step_up_name:          '',
      vault_step_up_auth_url:      '',
      vault_approle_secret_id_url: '',
      vault_approle_auth_url:      '',
      vault_role_id:               '',  // never sent back; roleIdSaved says if one is stored
      vault_field_map:             acct.vault_field_map || {},
    });
    setDialogOpen(true);
    setError('');
    // 2026-10-28: the list leaves the vault addresses out, so the form showed
    // every one blank and refused to save until they were typed again.  The
    // one-account read returns what is saved (never the password or role_id).
    try {
      const full: any = await api.get(`/api/admin/system-accounts/${acct.id}`);
      setRoleIdSaved(!!full.vault_role_id_saved);
      setForm(f => ({
        ...f,
        vault_auth_url:              full.vault_auth_url              || '',
        vault_secret_url:            full.vault_secret_url            || '',
        vault_rotate_url:            full.vault_rotate_url            || '',
        vault_step_up_name:          full.vault_step_up_name          || '',
        vault_step_up_auth_url:      full.vault_step_up_auth_url      || '',
        vault_approle_secret_id_url: full.vault_approle_secret_id_url || '',
        vault_approle_auth_url:      full.vault_approle_auth_url      || '',
      }));
    } catch (e: any) {
      setError(`Could not load this account's saved Vault details: ${e?.message || 'unknown error'}`);
    }
  };

  const shownAccounts = clientPage(accounts, acctPage, acctPageSize);

  const isAppRole = form.vault_role_type.trim().toLowerCase() === 'approle';
  // a saved AppRole value is never hidden, whatever the role type says
  const showAppRole = isAppRole || [form.vault_step_up_name, form.vault_step_up_auth_url,
    form.vault_approle_secret_id_url, form.vault_approle_auth_url, form.vault_role_id]
    .some(v => String(v || '').trim() !== '') || roleIdSaved;
  const roleTypeChoices = ROLE_TYPES.some(t => t.value === form.vault_role_type) || !form.vault_role_type
    ? ROLE_TYPES : [...ROLE_TYPES, { value: form.vault_role_type, label: form.vault_role_type }];
  // said only beside a box that holds a saved value
  const savedHint = (value: string, otherwise?: string) =>
    (editingId && String(value || '').trim() ? 'The saved value is shown. Edit it to change it.' : otherwise);
  const set = (key: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm(f => ({ ...f, [key]: e.target.value }));

  return (
    // 2026-11-10 (owner: "why system account screen is so ugly"): a list page uses the
    // width (qs-frontend "A list page uses the width"), row actions go through RowActions
    <Box sx={embedded ? undefined : { p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        {/* When embedded under Admin, the panel header already renders
            "System Accounts" -- skip the duplicate title here.  The
            Add button still anchors top-right. */}
        {embedded ? <Box /> : (
          <Typography variant="h5" sx={{ fontWeight: 600 }}>System Accounts</Typography>
        )}
        <Button variant="contained" startIcon={<AddIcon />} onClick={openCreate} size="small">
          Add System Account
        </Button>
      </Box>

      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        The accounts QueryStudio signs in with — to databases, S3 and SFTP servers — so no
        person's password is used. Turn on <b>Use Vault</b> to fetch the credential from
        HashiCorp Vault each time it is needed; otherwise the password is stored here,
        encrypted.
      </Typography>

      {error && !dialogOpen && <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError('')}>{error}</Alert>}

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
      ) : accounts.length === 0 ? (
        <Alert severity="info">
          No system accounts configured. Click "Add System Account" to create one.
        </Alert>
      ) : (
        <TableContainer component={Paper} variant="outlined" sx={TABLE_SCROLL_SX}>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Signs in as</TableCell>
                <TableCell>Password from</TableCell>
                <TableCell>Last test</TableCell>
                <TableCell>Last used</TableCell>
                <TableCell>Active</TableCell>
                <TableCell align="right" sx={STICKY_ACTIONS_SX}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {shownAccounts.rows.map(acct => (
                <TableRow key={acct.id} hover>
                  <TableCell><Typography variant="body2" fontWeight={600}>{acct.name}</Typography></TableCell>
                  <TableCell>
                    <Chip label={ACCOUNT_TYPES.find(t => t.value === acct.account_type)?.label || acct.account_type}
                          size="small" variant="outlined" />
                  </TableCell>
                  <TableCell>
                    {acct.username || (acct.use_vault
                      ? <Typography variant="caption" color="text.secondary">from Vault</Typography> : '—')}
                  </TableCell>
                  <TableCell>
                    {acct.use_vault ? (
                      <Tooltip title={`Vault entry: ${acct.secret_ref || acct.name}`}>
                        <Chip icon={<VaultIcon />} label="Vault" size="small" color="primary" variant="outlined" />
                      </Tooltip>
                    ) : (
                      <Chip label="Saved here" size="small" variant="outlined" />
                    )}
                  </TableCell>
                  <TableCell>
                    {acct.last_status === 'success' && <Chip icon={<SuccessIcon />} label="OK" size="small" color="success" variant="outlined" />}
                    {acct.last_status === 'failed' && (
                      <Tooltip title={acct.last_error || ''}>
                        <Chip icon={<ErrorIcon />} label="Failed" size="small" color="error" variant="outlined" />
                      </Tooltip>
                    )}
                    {!acct.last_status && <Chip label="Not tested" size="small" variant="outlined" />}
                    {testing === acct.id && <CircularProgress size={14} sx={{ ml: 1 }} />}
                    {testResult?.id === acct.id && (
                      <Typography variant="caption" display="block" sx={{ mt: 0.5 }}
                                  color={testResult.success ? 'success.main' : 'error.main'}>
                        {testResult.message}
                      </Typography>
                    )}
                  </TableCell>
                  <TableCell>
                    {acct.last_used_at ? new Date(acct.last_used_at).toLocaleDateString() : '—'}
                  </TableCell>
                  <TableCell>
                    <Chip label={acct.is_active ? 'Active' : 'Inactive'} size="small"
                          color={acct.is_active ? 'success' : 'default'} variant="outlined" />
                  </TableCell>
                  <TableCell align="right" sx={STICKY_ACTIONS_SX}>
                    <RowActions rowName={acct.name}
                      primary={[
                        { label: 'Test', ariaLabel: 'Test credentials', icon: <TestIcon fontSize="small" />,
                          onClick: () => handleTest(acct.id), disabled: testing === acct.id },
                        { label: 'Edit', ariaLabel: 'Edit', icon: <EditIcon fontSize="small" />, onClick: () => openEdit(acct) },
                      ]}
                      more={[
                        { label: 'Refresh saved credentials', icon: <RefreshIcon fontSize="small" />,
                          description: 'Forget the copy every server holds and read it again',
                          onClick: () => handleRefresh(acct.id), disabled: testing === acct.id },
                        { label: 'Delete', icon: <DeleteIcon fontSize="small" />, danger: true,
                          onClick: () => handleDelete(acct.id) },
                      ]} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <ListPager paging={shownAccounts.paging} onPage={setAcctPage} onPageSize={setAcctPageSize}
                     testid="system-accounts-pager" />
        </TableContainer>
      )}

      {/* Create/Edit Dialog */}
      <AppDialog open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        size="md"
        title={editingId ? 'Edit System Account' : 'Create System Account'}
        actions={<>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSave}
            disabled={saving || !form.name
                       || (!form.use_vault && (!form.username || (!editingId && !form.password)))
                       || (form.use_vault && !vaultFieldsValid().ok)}>
            {saving ? <CircularProgress size={20} /> : (editingId ? 'Save' : 'Create')}
          </Button>
        </>}>
          <Stack spacing={2.5} sx={{ mt: 1 }}>
            <Section title="The account">
              <Box sx={TWO_COLUMNS}>
                <TextField label="Name" required size="small" fullWidth
                  value={form.name} onChange={set('name')}
                  placeholder="production-aws-portal"
                  helperText="A unique name. Connections and feeds pick the account by it."
                />
                <TextField select label="Account Type" required size="small" fullWidth
                  value={form.account_type}
                  onChange={e => {
                    const t = e.target.value;
                    // A Vault-only type starts in Vault mode with the kv shape it needs.
                    setForm(f => (KV_VAULT_ONLY_TYPES.includes(t)
                      ? { ...f, account_type: t, use_vault: true, secret_type: 'kv_secrets' }
                      : { ...f, account_type: t }));
                  }}
                  disabled={!!editingId}
                  helperText={editingId ? 'The type cannot change once the account is saved.' : ' '}
                >
                  {ACCOUNT_TYPES.map(t => (
                    <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>
                  ))}
                </TextField>
              </Box>
              {form.account_type === 'sftp_account' && (
                <TextField label="Allowed hosts" size="small" fullWidth
                  inputProps={{ 'data-testid': 'sa-allowed-hosts' }}
                  value={hostsText ?? allowedHostsText(form.config)}
                  onChange={e => {
                    const text = e.target.value;
                    setHostsText(text);
                    setForm(f => ({ ...f, config: withAllowedHosts(f.config, text) }));
                  }}
                  placeholder="sftp.bank.com, 10.1.2.3:2222"
                  helperText="The only SFTP servers this login may be sent to, separated by commas. When you save, QueryStudio reads each server's key and approves it with the account: a login goes only to the server with that key. Feed authors who are not admins can use this account only with these hosts. Left empty, only an admin can point a feed at a new host."
                />
              )}
              {form.account_type === 'sftp_account' && Object.keys(form.config?.host_keys || {}).length > 0 && (
                <Box data-testid="sa-host-keys" sx={{ fontSize: 12, color: 'text.secondary' }}>
                  Approved server keys:{' '}
                  {Object.entries(form.config.host_keys).map(([h, k]: [string, any]) =>
                    `${h} ${k?.key_type || ''} ${k?.fingerprint_sha256 || ''}`.trim()).join('; ')}
                </Box>
              )}
            </Section>

            <Section title="Where the login comes from">
              <FormControlLabel
                control={
                  <Switch
                    checked={form.use_vault}
                    onChange={e => setForm(f => ({ ...f, use_vault: e.target.checked }))}
                  />
                }
                label={
                  <Stack direction="row" spacing={1} alignItems="center">
                    <VaultIcon fontSize="small" color={form.use_vault ? 'primary' : 'disabled'} />
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>
                      Use Vault — read the username and password from Vault each time
                    </Typography>
                  </Stack>
                }
              />
              {/* 2026-10-30 (owner: "in case vault ... create system account for
                  snowflake ... username n password mandatory"): with Use Vault on,
                  Vault gives the username and the password -- the boxes are not
                  asked for.  Shown only for an account that keeps its own. */}
              {!form.use_vault && (
                <Box sx={TWO_COLUMNS}>
                  <TextField label="Username" required size="small" fullWidth
                    value={form.username} onChange={set('username')}
                    inputProps={{ 'data-testid': 'sa-username' }}
                  />
                  <TextField label="Password" required={!editingId} size="small" fullWidth type="password"
                    value={form.password} onChange={set('password')}
                    inputProps={{ 'data-testid': 'sa-password' }}
                    helperText="Saved encrypted. Type a new one to change it."
                  />
                </Box>
              )}
              {form.use_vault && (
                <>
                  <Alert severity="info" variant="outlined" sx={{ py: 0.5 }}>
                    This account keeps no password of its own. The same Vault entry can serve
                    the ETL platform too.
                  </Alert>
                  {form.account_type === 'sftp_account' && (
                    <Alert severity="info" sx={{ py: 0.5 }} data-testid="sftp-vault-shape">
                      For an SFTP login use Secret Type <b>kv_secrets</b>. The Vault entry holds
                      {' '}<code>username</code> and either <code>private_key</code> (the key
                      text; add <code>private_key_passphrase</code> if the key has one) or
                      {' '}<code>password</code>. Feeds then pick this account under
                      {' '}<i>Sign-in method → Vault SFTP account</i>.
                    </Alert>
                  )}
                  {form.account_type === 'snowflake_keypair' && (
                    <Alert severity="info" sx={{ py: 0.5 }} data-testid="snowflake-keypair-vault-shape">
                      For a Snowflake key pair use Secret Type <b>kv_secrets</b>. The Vault entry holds
                      {' '}<code>username</code> (the Snowflake user) and <code>private_key</code> (the
                      .p8 text; <code>private_key_pem</code>, <code>rsa_private_key</code> and
                      {' '}<code>snowflake_private_key</code> are also read), plus
                      {' '}<code>private_key_passphrase</code> if the key is encrypted. A Snowflake
                      connection then picks this account under <i>Key Pair → Private key source →
                      From Vault</i>. Test checks that the key opens.
                    </Alert>
                  )}
                  <Box sx={TWO_COLUMNS}>
                    <TextField select label="Secret Type" required size="small" fullWidth
                      value={form.secret_type} onChange={set('secret_type')}
                    >
                      {SECRET_TYPES.map(t => (
                        <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>
                      ))}
                    </TextField>
                    <TextField label="Secret Ref" size="small" fullWidth
                      value={form.secret_ref} onChange={set('secret_ref')}
                      placeholder={form.name || 'the account name'}
                      helperText="The entry's name in Vault. Blank = the account name."
                    />
                    <TextField label="Vault Role Name" required size="small" fullWidth
                      value={form.vault_role_name} onChange={set('vault_role_name')}
                      placeholder="prod-trino-svc"
                      helperText="The Vault role QueryStudio logs in as."
                    />
                    <TextField select label="Vault Role Type" required size="small" fullWidth
                      value={form.vault_role_type} onChange={set('vault_role_type')}
                      helperText="How QueryStudio logs in to Vault."
                    >
                      {roleTypeChoices.map(t => (
                        <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>
                      ))}
                    </TextField>
                  </Box>
                  <TextField label="Vault Auth URL" required size="small" fullWidth
                    value={form.vault_auth_url} onChange={set('vault_auth_url')}
                    placeholder="https://vault.internal/v1/auth/..."
                    helperText={savedHint(form.vault_auth_url, 'Where QueryStudio logs in to Vault.')}
                  />
                  <TextField label="Vault Secret URL" required size="small" fullWidth
                    value={form.vault_secret_url} onChange={set('vault_secret_url')}
                    placeholder="https://vault.internal/v1/db/creds/prod_trino_svc"
                    helperText={savedHint(form.vault_secret_url, 'Where the username and password are read from.')}
                  />

                  {showAppRole && (
                    <Box data-testid="sa-approle" sx={{ p: 2, border: 1, borderColor: 'divider', borderRadius: 1 }}>
                      <Typography variant="subtitle2" sx={{ mb: 0.5 }}>AppRole login</Typography>
                      <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1.5 }}>
                        Used only when the role type is AppRole: QueryStudio first logs in with the
                        step-up role, gets a secret ID, then logs in with the role ID.
                      </Typography>
                      <Box sx={TWO_COLUMNS}>
                        <TextField label="Step-Up Role Name" size="small" fullWidth
                          value={form.vault_step_up_name} onChange={set('vault_step_up_name')}
                          placeholder="prod-stepup-role"
                        />
                        <TextField label="Step-Up Auth URL" size="small" fullWidth
                          value={form.vault_step_up_auth_url} onChange={set('vault_step_up_auth_url')}
                          placeholder="https://vault.internal/v1/auth/jwt/login"
                          helperText={savedHint(form.vault_step_up_auth_url)}
                        />
                        <TextField label="AppRole Secret-ID URL" size="small" fullWidth
                          value={form.vault_approle_secret_id_url} onChange={set('vault_approle_secret_id_url')}
                          placeholder="https://vault.internal/v1/auth/approle/role/<role>/secret-id"
                          helperText={savedHint(form.vault_approle_secret_id_url)}
                        />
                        <TextField label="AppRole Auth URL" size="small" fullWidth
                          value={form.vault_approle_auth_url} onChange={set('vault_approle_auth_url')}
                          placeholder="https://vault.internal/v1/auth/approle/login"
                          helperText={savedHint(form.vault_approle_auth_url)}
                        />
                      </Box>
                      <TextField label="AppRole role_id" size="small" fullWidth sx={{ mt: 2 }}
                        value={form.vault_role_id} onChange={set('vault_role_id')}
                        placeholder="the AppRole role_id"
                        helperText={editingId
                          ? (roleIdSaved ? 'A role_id is saved (hidden). Leave blank to keep it, or type a new one to replace it.' : 'No role_id is saved for this account.')
                          : 'The secret ID is made at each login; only the role ID is kept.'}
                      />
                    </Box>
                  )}

                  <Accordion variant="outlined" disableGutters
                    defaultExpanded={!!form.vault_rotate_url
                      || Object.values(form.vault_field_map || {}).some(v => String(v || '').trim() !== '')}>
                    <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                      <Typography variant="body2">More Vault settings (optional)</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Stack spacing={2}>
                        <TextField label="Vault Rotate URL (optional)" size="small" fullWidth
                          value={form.vault_rotate_url} onChange={set('vault_rotate_url')}
                          placeholder="https://vault.internal/v1/db/rotate-root/prod_trino_svc"
                          helperText="Only if Vault rotates this password. Leave blank otherwise."
                        />
                        {form.secret_type === 'kv_secrets' && (
                          <Box data-testid="vault-field-names">
                            <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600 }}>
                              Vault field names (only if your entry uses other names)
                            </Typography>
                            <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 1 }}>
                              QueryStudio reads a login name, a password, a token, a private key and S3 keys from the Vault entry.
                              If your entry stores them under its own names (for example &quot;access key&quot; for the login name),
                              say which field holds each value. Leave a line blank when the name already matches.
                              A named field the entry does not have stops the login with a message naming it.
                            </Typography>
                            <Box sx={TWO_COLUMNS}>
                              {VAULT_VALUE_WORDS.map(([key, words]) => (
                                <TextField key={key} label={`Field in Vault for: ${words}`} size="small" fullWidth
                                  value={form.vault_field_map?.[key] || ''}
                                  onChange={e => setForm(f => ({ ...f, vault_field_map: { ...(f.vault_field_map || {}), [key]: e.target.value } }))}
                                  placeholder={key}
                                />
                              ))}
                            </Box>
                          </Box>
                        )}
                      </Stack>
                    </AccordionDetails>
                  </Accordion>
                </>
              )}
            </Section>

            {error && <Alert severity="error">{error}</Alert>}
          </Stack>
      </AppDialog>
    </Box>
  );
};

const TWO_COLUMNS = { display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 2 } as const;

const ROLE_TYPES = [
  { value: 'jwt', label: "JWT (the pod's own token)" },
  { value: 'k8s', label: 'Kubernetes service account' },
  { value: 'approle', label: 'AppRole (step-up, then role ID)' },
];

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Box>
      <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.25 }}>{title}</Typography>
      <Stack spacing={2}>{children}</Stack>
    </Box>
  );
}

export default SystemAccountsPage;
