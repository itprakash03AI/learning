/* The ONE cache rule of the app-shell service worker (desktop step one, 2026-11-08; review the same day).
 *
 * Plain script, no module syntax: it is concatenated into build/sw.js by the Vite plugin
 * (sw/build.cjs) and evaluated by the vitest tests with a fake `self`.  It decides, for a
 * request the installed app makes, ONE of three things -- as an ALLOWLIST: what is not named is
 * never touched.
 *
 *   'asset'      -- the static app shell, by PATH only: /assets/* (the hashed JS, CSS and the fonts
 *                   the build emits), /icons/*, /logo.svg, /company-logo.svg.  Cache-first.
 *   'navigation' -- a page the browser NAVIGATES to (request.mode === 'navigate'), network-first;
 *                   the answer is stored as the offline page ONLY when it is HTML of THIS build
 *                   (the <meta name="qs-build-id"> the build stamps), so /openapi.json, /metrics,
 *                   /health, an auth proxy's login page or a NEWER build's page never become the
 *                   shell; offline, the build's own stored page.
 *   'never'      -- everything else: any other origin, any non-GET, any query string, every path not
 *                   in the allowlist (an API under a same-origin path prefix, a picture, a download),
 *                   and explicitly /api/, /auth/, /ws and /ws/*, the runtime config, /version.json,
 *                   the worker and the manifest, /addin/, /docs/, plus the same-origin PATHS of the
 *                   deployment's apiUrl / publishedApiUrl / reportApiUrl / downloadApiUrl read from
 *                   /config.json.  Nothing per-user is ever cached: a shared PC keeps no one's data.
 *
 * Caches are named per BUILD: qs-shell-<build id>.  A new deploy installs a new worker whose
 * activate step deletes every other qs-shell-* cache -- no stale UI after a bundle.
 */
(function (root) {
  var PREFIX = 'qs-shell-';
  var ASSET_PREFIXES = ['/assets/', '/icons/'];
  var ASSET_EXACT = ['/logo.svg', '/company-logo.svg'];
  var NEVER_PREFIXES = ['/api/', '/auth/', '/ws/', '/addin/', '/docs/'];
  var NEVER_EXACT = ['/ws', '/config.js', '/config.json', '/version.json', '/sw.js', '/manifest.webmanifest'];

  function cacheName(buildId) {
    return PREFIX + String(buildId || 'dev');
  }

  /** A cache this worker owns but another build made: deleted on activate. */
  function isOwnStaleCache(name, buildId) {
    return String(name).indexOf(PREFIX) === 0 && String(name) !== cacheName(buildId);
  }

  /** The same-origin path prefixes of the deployment's API addresses (config.json): never cached. */
  function neverPrefixesFromConfig(cfg, selfOrigin) {
    var out = [];
    var keys = ['apiUrl', 'publishedApiUrl', 'reportApiUrl', 'downloadApiUrl', 'internalApiUrl'];
    for (var i = 0; i < keys.length; i++) {
      var v = cfg && cfg[keys[i]];
      if (!v) continue;
      var u;
      try { u = new URL(String(v), selfOrigin); } catch (e) { continue; }
      if (u.origin !== selfOrigin) continue;
      var p = u.pathname.replace(/\/+$/, '');
      if (!p || p === '/') continue;        // the API at the root: its /api/ prefix is already never
      out.push(p + '/');
      out.push(p);
    }
    return out;
  }

  function startsWithAny(p, prefixes) {
    for (var i = 0; i < (prefixes || []).length; i++) if (p.indexOf(prefixes[i]) === 0) return true;
    return false;
  }

  function policyFor(url, selfOrigin, request, configNever) {
    var method = (request && request.method) || 'GET';
    if (method !== 'GET') return 'never';
    var u;
    try { u = new URL(String(url), selfOrigin); } catch (e) { return 'never'; }
    if (u.origin !== selfOrigin) return 'never';
    if (u.search) return 'never';
    var p = u.pathname;
    if (NEVER_EXACT.indexOf(p) !== -1) return 'never';
    if (startsWithAny(p, NEVER_PREFIXES)) return 'never';
    if (configNever && (startsWithAny(p, configNever) || configNever.indexOf(p) !== -1)) return 'never';
    if (request && request.mode === 'navigate') return 'navigation';
    if (startsWithAny(p, ASSET_PREFIXES) || ASSET_EXACT.indexOf(p) !== -1) return 'asset';
    return 'never';
  }

  function isHtml(contentType) {
    return String(contentType || '').toLowerCase().indexOf('text/html') === 0;
  }

  /** The page the build stamped: <meta name="qs-build-id" content="..."> equal to this worker's id. */
  function pageIsThisBuild(htmlText, buildId) {
    var m = /<meta\s+name=["']qs-build-id["']\s+content=["']([^"']*)["']/i.exec(String(htmlText || ''));
    return !!m && m[1] === String(buildId);
  }

  root.qsShellRules = {
    PREFIX: PREFIX, cacheName: cacheName, isOwnStaleCache: isOwnStaleCache, neverPrefixesFromConfig: neverPrefixesFromConfig,
    policyFor: policyFor, isHtml: isHtml, pageIsThisBuild: pageIsThisBuild,
  };
})(typeof self !== 'undefined' ? self : this);
