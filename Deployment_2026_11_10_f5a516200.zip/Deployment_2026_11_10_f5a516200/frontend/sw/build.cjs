/* Builds the app-shell service worker and the web app manifest (desktop step one, 2026-11-08).
 *
 * Shared by the Vite plugin (vite.config.ts writes build/sw.js per build) and by spa-server.cjs
 * (which composes /manifest.webmanifest from the deployment's config.json at request time), and
 * imported by the vitest tests.  CommonJS on purpose: both callers are Node scripts. */
'use strict';
const fs = require('fs');
const path = require('path');

/** The worker script for ONE build: the rules, then the body with the build id and the shell list filled. */
function buildServiceWorker(buildId, precache) {
  const rules = fs.readFileSync(path.join(__dirname, 'shell-rules.js'), 'utf-8');
  const body = fs.readFileSync(path.join(__dirname, 'sw-body.js'), 'utf-8');
  const list = Array.from(new Set(['/index.html'].concat(precache || []))).filter(p => typeof p === 'string' && p.startsWith('/'));
  return rules + '\n' + body
    .replace('__QS_BUILD_ID__', String(buildId || 'dev').replace(/[^A-Za-z0-9._-]/g, ''))
    .replace('__QS_PRECACHE__', JSON.stringify(list));
}

/** The shell files PRECACHED at install -- what the first paint needs: the entry chunks (index-*),
 *  every stylesheet and font under /assets, the icons and logos.  Every other hashed chunk is cached
 *  the first time the app asks for it (the worker's cache-first asset rule), so installing stays
 *  small and a lazy screen is never downloaded for nothing. */
function shellFilesOf(outDir) {
  const out = [];
  const assets = path.join(outDir, 'assets');
  if (fs.existsSync(assets)) {
    for (const name of fs.readdirSync(assets).sort()) {
      if (/^index-.*\.(js|mjs)$/i.test(name) || /\.(css|woff2?|ttf|otf)$/i.test(name)) out.push('/assets/' + name);
    }
  }
  const icons = path.join(outDir, 'icons');
  if (fs.existsSync(icons)) {
    for (const name of fs.readdirSync(icons).sort()) out.push('/icons/' + name);
  }
  for (const f of ['logo.svg', 'company-logo.svg']) if (fs.existsSync(path.join(outDir, f))) out.push('/' + f);
  return out;
}

/** The product's installable name: the deployment's config (appName), else the product's own default --
 *  the Reports app is installed per team under its own name, nothing hard-coded. */
function appNameOf(cfg) {
  const c = cfg || {};
  const given = String(c.appName || '').trim();
  if (given) return given;
  return String(c.product || '').trim().toLowerCase() === 'reports' ? 'Reports' : 'QueryStudio';
}

/** The web app manifest for a deployment's config.json. */
function manifestFor(cfg) {
  const name = appNameOf(cfg);
  const shortName = name.length <= 12 ? name : name.slice(0, 12);
  return {
    id: '/',
    name: name,
    short_name: shortName,
    description: String((cfg || {}).appDescription || '').trim()
      || (String((cfg || {}).product || '').toLowerCase() === 'reports'
        ? 'Finance reports: run, drill, share and sign off.'
        : 'Query and report on data across S3, Iceberg, Snowflake, Trino and Databricks.'),
    start_url: '/',
    scope: '/',
    display: 'standalone',
    orientation: 'any',
    background_color: '#ffffff',
    theme_color: '#2563eb',
    lang: 'en',
    icons: [
      { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  };
}

module.exports = { buildServiceWorker, shellFilesOf, manifestFor, appNameOf };
