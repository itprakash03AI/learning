/* The app-shell service worker body (desktop step one, 2026-11-08).  Concatenated after
 * shell-rules.js by sw/build.cjs; the two placeholders are filled per BUILD. */
var QS_BUILD_ID = '__QS_BUILD_ID__';
var QS_PRECACHE = __QS_PRECACHE__;
var QS_RULES = self.qsShellRules;
var QS_CACHE = QS_RULES.cacheName(QS_BUILD_ID);
var QS_CONFIG_NEVER = [];        // the same-origin paths of the deployment's API addresses, from /config.json

function qsReadConfig() {
  return fetch('/config.json', { cache: 'no-store' })
    .then(function (res) { return res && res.ok ? res.json() : {}; })
    .then(function (cfg) { QS_CONFIG_NEVER = QS_RULES.neverPrefixesFromConfig(cfg || {}, self.location.origin); })
    .catch(function () { /* unreadable: the allowlist alone still caches nothing it does not know */ });
}

self.addEventListener('install', function (event) {
  event.waitUntil(
    qsReadConfig()
      .then(function () { return caches.open(QS_CACHE); })
      .then(function (cache) {
        // the shell of THIS build; a file that is not there yet is skipped, never fatal
        return Promise.all(QS_PRECACHE.map(function (p) {
          return cache.add(p).catch(function () { return null; });
        }));
      })
      .then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (event) {
  event.waitUntil(
    qsReadConfig()
      .then(function () { return caches.keys(); })
      .then(function (names) {
        return Promise.all(names
          .filter(function (n) { return QS_RULES.isOwnStaleCache(n, QS_BUILD_ID); })
          .map(function (n) { return caches.delete(n); }));
      })
      .then(function () { return self.clients.claim(); })
  );
});

/** A navigation answer becomes the offline page ONLY when it is HTML of THIS build. */
function qsStorePageIfOurs(res) {
  try {
    if (!res || !res.ok || !QS_RULES.isHtml(res.headers && res.headers.get && res.headers.get('content-type'))) return;
    var copy = res.clone();
    copy.text().then(function (html) {
      if (!QS_RULES.pageIsThisBuild(html, QS_BUILD_ID)) return;
      return caches.open(QS_CACHE).then(function (cache) {
        return cache.put('/index.html', new Response(html, { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } }));
      });
    }).catch(function () { /* not stored */ });
  } catch (e) { /* not stored */ }
}

self.addEventListener('fetch', function (event) {
  var policy = QS_RULES.policyFor(event.request.url, self.location.origin, event.request, QS_CONFIG_NEVER);
  if (policy === 'never') return;                       // the browser does what it always did
  if (policy === 'asset') {
    event.respondWith(
      caches.open(QS_CACHE).then(function (cache) {
        return cache.match(event.request).then(function (hit) {
          if (hit) return hit;
          return fetch(event.request).then(function (res) {
            if (res && res.ok) cache.put(event.request, res.clone());
            return res;
          });
        });
      })
    );
    return;
  }
  // navigation: the network first (a deploy is seen at once); the build's own page when it is away
  event.respondWith(
    fetch(event.request).then(function (res) {
      qsStorePageIfOurs(res);
      return res;
    }).catch(function () {
      return caches.open(QS_CACHE).then(function (cache) { return cache.match('/index.html'); })
        .then(function (hit) { return hit || Response.error(); });
    })
  );
});
