/**
 * API barrel — composes all domain modules into a single `api` object.
 * Maintains backward compatibility: `import api from '../services/api'` still works.
 */

// Re-export shared types and utilities for direct imports
export { ApiError, safeFetch, sharedFetch, openDownload, uploadFetch, rawFetch, toBackendQueryConfig, API_BASE_URL, PUBLISHED_API_BASE_URL, REPORT_API_BASE_URL } from './core';
export type {
  QueryConfig, Connection, SavedQuery, Execution, Dataset,
  BusinessReport, DashboardItem, Widget, Schedule, Notification,
} from './core';

import connections from './connections';
import queries from './queries';
import execution from './execution';
import reports from './reports';
import datasets from './datasets';
import businessReports from './businessReports';
import powerbiImport from './powerbiImport';  // 2026-11-07 - a Power BI report file imported as a report
import admin from './admin';
import publishedViews from './publishedViews';
import feeds from './feeds';
// 2026-09-02 — dependency gate ops (skip-deps, blocking reverse index, run steps)
import feedDependencies from './feedDependencies';
// 2026-09-03 — operator controls: backfill, delivery ops, child file-runs,
// deployment windows, service review, lifecycle, budgets + feed groups
import feedOperations from './feedOperations';
// 2026-09-28 - date tokens: the vocabulary a picker offers + a server preview
import dateTokens from './dateTokens';
// 2026-09-28 - business-date readiness on a report, and its SLO
import reportReadiness from './reportReadiness';
import feedGroups from './feedGroups';
// 2026-09-28 - My Feeds: delivery receipts + self-subscription for feed CONSUMERS
import myFeeds from './myFeeds';
// 2026-09-05 - the STEP MODEL: catalogue, flows, plan, verdicts, re-run
import feedSteps from './feedSteps';
// 2026-09-10 - Clockwork, the scheduler: jobs, preview, fires, why-not-run
import clockwork from './clockwork';
// Phase 133 — source-vs-destination reconciliation reports
import reconciliation from './reconciliation';
import federationViews from './federationViews';
import metadataCatalog from './metadataCatalog';
import dataQuality from './dataQuality';
import userPreferences from './userPreferences';
import sqlFilesService from './sqlFiles';
import sapTasksService from './sapTasks';
import businessQueryBuilder from './businessQueryBuilder';
import dataflows from './dataflows';
// BF-430A — namespaced access to the S3 reader admin endpoints (used by
// PublishViewDialog + MV admin to populate the reader_override dropdown).
import { s3Readers } from './s3Readers';
import { _setApiRef as _setQueryApiRef } from './queries';
import { _setApiRef as _setExecApiRef } from './execution';
import { safeFetch } from './core';

const api = {
  ...admin,
  ...connections,
  ...queries,
  ...execution,
  ...reports,
  ...datasets,
  ...businessReports,
  ...powerbiImport,
  ...publishedViews,
  ...feeds,
  ...feedDependencies,
  ...feedOperations,
  ...dateTokens,
  ...reportReadiness,
  ...feedGroups,
  ...myFeeds,
  ...federationViews,
  ...metadataCatalog,
  ...dataQuality,
  ...userPreferences,
  sqlFiles: sqlFilesService,
  sapTasks: sapTasksService,
  businessQueryBuilder,
  dataflows,
  feedSteps,  // 2026-09-05 - the FeedGen step model
  clockwork,  // 2026-09-10 - the scheduler
  s3Readers,  // BF-430A
  reconciliation,  // Phase 133 — source vs destination recon reports

  // Raw HTTP shortcut methods — used by components that need ad-hoc endpoints
  get: (url: string, options?: RequestInit) =>
    safeFetch(url, { method: 'GET', ...options }),
  post: (url: string, data?: any, options?: RequestInit) =>
    safeFetch(url, { method: 'POST', body: data !== undefined ? JSON.stringify(data) : undefined, ...options }),
  put: (url: string, data?: any, options?: RequestInit) =>
    safeFetch(url, { method: 'PUT', body: data !== undefined ? JSON.stringify(data) : undefined, ...options }),
  delete: (url: string, options?: RequestInit) =>
    safeFetch(url, { method: 'DELETE', ...options }),
};

// Wire up cross-references (getExecutionStatus → listDownloads, getSavedQueries → listQueries)
_setQueryApiRef(api);
_setExecApiRef(api);

export default api;
