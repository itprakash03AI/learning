/**
 * API -- a Power BI report file imported as a canvas report (2026-11-07, the report
 * framework's stage 8; server: backend/api/powerbi_import_api.py).
 *
 * Both calls send the file as multipart (``uploadFetch``): ``file``, ``dataset_id`` and
 * ``options`` (JSON).  The preview SAVES NOTHING; create saves through the screen's own
 * report-creation route and answers the report.
 */
import { uploadFetch } from './core';

export interface PowerBiImportOptions {
  /** "Table.Column" (or "Column") -> the dataset column id the author picked */
  field_map?: Record<string, number>;
  /** "Table.Measure" -> the column and how it is added up (a .pbix carries no measure definitions) */
  measure_map?: Record<string, { column_id: number; aggregation: string }>;
  /** visual names (the file's own ids) the author leaves out */
  exclude_visuals?: string[];
  /** page names the author leaves out */
  exclude_pages?: string[];
  /** the report's name (the file's name when absent) */
  name?: string;
}

export interface PowerBiField {
  ref: string; kind: string; status: 'column' | 'measure' | 'unmatched' | 'listed';
  column_id: number | null; label: string | null; aggregation: string | null; how: string; words: string;
  dax: string | null; role: string; active: boolean;
}
export interface PowerBiVisual {
  name: string; visual_type: string; title: string; layout: { x: number; y: number; w: number; h: number };
  becomes: string | null; words: string; fields: PowerBiField[]; listed: string[]; excluded: boolean; text?: string;
}
export interface PowerBiPage {
  name: string; title: string; width: number; height: number; included: boolean; words: string; visuals: PowerBiVisual[];
}
export interface PowerBiPreview {
  format: 'legacy' | 'pbir'; file_name: string; report_name: string; dataset_id: number; dataset_name: string | null;
  model_in_file: boolean; relationships: string[]; tables_in_model: Record<string, number>;
  pages: PowerBiPage[]; tiles: number;
  parameters: { name: string; label: string; parameter_type: string; lov_column_id: number; from: string[] }[];
  filters: { name: string; scope: string; where: string; field: string; status: string; words: string; column_id: number | null }[];
  refusals: { what: string; why: string; where: string; field: string }[];
  not_brought_across: { what: string; why: string; where: string }[];
  unmatched_fields: { ref: string; kind: string; entity: string; property: string; used_by: string[]; why: string }[];
  measures: { ref: string; table: string; name: string; dax: string | null; status: string; column_id: number | null; aggregation: string | null; words: string; used_by: string[] }[];
  theme: any; theme_words: string;
  columns: { id: number; label: string; data_type: string; column_type: string }[];
  notes: string[]; can_create: boolean; report: any;
}
export interface PowerBiCreated {
  report: any; report_id: number; slug: string | null; tiles: number; parameters: number;
  not_brought_across: PowerBiPreview['not_brought_across']; measures: PowerBiPreview['measures'];
  theme_words: string; parameters_problem: string | null;
}

export function powerBiImportForm(file: File, datasetId: number, options: PowerBiImportOptions): FormData {
  const fd = new FormData();
  fd.append('file', file, file.name);
  fd.append('dataset_id', String(datasetId));
  fd.append('options', JSON.stringify(options || {}));
  return fd;
}

export default {
  powerbiImportPreview: (file: File, datasetId: number, options: PowerBiImportOptions): Promise<PowerBiPreview> =>
    uploadFetch('/api/powerbi-import/preview', powerBiImportForm(file, datasetId, options)),
  powerbiImportCreate: (file: File, datasetId: number, options: PowerBiImportOptions): Promise<PowerBiCreated> =>
    uploadFetch('/api/powerbi-import/create', powerBiImportForm(file, datasetId, options)),
};
