/**
 * API — Business Reports, Portal, Delivery & Subscriptions
 */
import { safeFetch, openDownload, rawFetch } from './core';
import { safeStringify } from '../../utils/safeStringify';
import { queryReportCubeArrow } from './cubeArrow';
import { getReportPageArrow } from './pageArrow';

/**
 * Server-side sort keys for the report portal.  Kept in lockstep with
 * ``DatabaseManager._BR_SORTS`` — the backend rejects anything else with a
 * 400 rather than silently falling back to a different order.
 */
export type PortalSort = 'updated' | 'name' | 'last_run';

// ── Commentary + sign-off on a report INSTANCE (2026-09-28) — the SERVER's
// shapes (backend/core/reports/signoff.py); every nullable is guarded here.
export type SignoffRole = 'preparer' | 'reviewer' | 'approver';

export interface InstanceSignoff {
  id: number;
  instance_id: number;
  execution_id: string;
  role: SignoffRole;
  signed_by: string;
  signed_at: string | null;
  business_date: string | null;
  note: string | null;
  status: 'active' | 'revoked';
  revoked_by: string | null;
  revoked_at: string | null;
  revoke_reason: string | null;
  /** the warning the signer overrode */
  overrode?: { mode: string; status: string; count: number; words: string; items: string[] } | null;
  semantic_version: string | null;
  source_version: string | null;
  row_count: number | null;
  /** "open", or a short label of the row-security scope — never the hash */
  scope_label: string;
  can_revoke?: boolean;
}

export interface InstanceComment {
  id: number;
  instance_id: number;
  parent_id: number | null;
  username: string;
  text: string;
  mentions: string[];
  anchor: NoteAnchor;
  business_date: string | null;
  is_resolved: boolean;
  resolved_by?: string | null;
  resolved_at?: string | null;
  /** began as a draft, or carried from an earlier run (the server checked it) */
  origin?: { kind: 'draft' | 'carried'; source?: string; from_business_date?: string | null; from_comment_id?: number } | null;
  created_at: string | null;
  scope_label?: string;
  /** on a post: who was told of a mention, and who was not and why */
  told?: CommentTold;
}

/** What a comment is on, named by key VALUES (core/reports/commentary.py). */
export interface NoteAnchor {
  kind: string;
  key?: Record<string, any>;
  column?: string;
  tile_id?: string;
  label?: string;
}

export interface CommentTold {
  told: string[];
  cannot_see: string[];
  not_known: string[];
  not_told: string[];
}

export interface CommentDraft {
  refused?: string;
  text?: string;
  source?: 'template' | 'assistant';
  reason?: string | null;
  grounded?: boolean;
}

export interface CarryCandidate {
  found: boolean;
  comment_id?: number;
  text?: string;
  username?: string;
  business_date?: string | null;
  created_at?: string | null;
}

export interface CommentarySettings {
  measure_column_id: number | null;
  dimensions: number[];
  limit_amount: number | null;
  limit_percent: number | null;
  at_signoff: 'warn' | 'block';
}

export interface NeedsExplaining {
  /** off | ok | no_comparison (a reason) | unknown (a reason) */
  status: string;
  reason?: string;
  mode?: 'warn' | 'block';
  settings?: CommentarySettings | null;
  items: { key: Record<string, any>; column: string; label: string; a: any; b: any; change: any; comment_ids: number[] }[];
  total: number;
  unexplained: number;
  limit_words?: string;
  measure_words?: string;
  against?: string;
  may_change_settings?: boolean;
}

export interface InstanceSignoffState {
  /** "known" | "unknown" (with reason) | "no_instance" (with reason) */
  status: string;
  reason?: string;
  instance_id?: number | null;
  signed?: boolean;
  signoffs?: InstanceSignoff[];
  signed_version?: InstanceSignoff | null;
  newer_than_signed?: boolean;
  definition_changed_since_signed?: boolean;
}

export interface InstanceSignoffHeader {
  report_id: number;
  instance: {
    id: number; execution_id: string; created_at: string | null; created_by: string | null;
    status: string; row_count: number | null; scope_label: string;
  } | null;
  can_sign: boolean;
  can_comment: boolean;
  sees_all_scopes: boolean;
  roles: SignoffRole[];
  signoff: InstanceSignoffState;
  comments: InstanceComment[];
}

/** One table of a report, on one side, as the Data version control lists it. */
export interface ReportDataVersionTable {
  table: string;
  /** the connection the table is read on */
  side: string;
  connection_id: number;
  dataset_id: number;
  /** what the dataset's own SQL pins (null = latest) -- "As saved" */
  saved: { snapshot_id: string | null; as_of_ms: number | null } | null;
  current_snapshot_id?: string | null;
  versions: import('../../components/common/tableVersionWords').TableVersionRow[] | null;
  access?: 'full' | 'limited' | 'refused' | null;
  access_words?: string | null;
  reason?: string | null;
  error?: string | null;
  /** the same table name on two sides: only a time / latest can be asked for it */
  on_several_sides?: boolean;
}

/** GET /api/business-reports/{id}/business-day */
export interface ReportBusinessDay { report_id: number; from: string; step: number; date: string; calendar: string | null; calendar_words: string }

export interface ReportDataVersions {
  report_id: number;
  supported: boolean;
  reason: string | null;
  tables: ReportDataVersionTable[];
}

export interface InstanceDiff {
  /** set = the diff was not computed, and this is why */
  refused: string | null;
  base?: { instance_id: number; created_at?: string | null } | null;
  current?: { instance_id: number; created_at?: string | null } | null;
  definition_changed?: boolean;
  columns_added?: string[];
  columns_removed?: string[];
  keyed?: boolean;
  key_columns?: string[];
  key_reason?: string | null;
  rows?: { base: number; current: number; added?: number; removed?: number; changed?: number; unchanged?: number };
  measures?: { column: string; base_sum: number | null; current_sum: number | null; delta: number | null }[];
  top_movers?: { column: string; key: Record<string, any>; before: any; after: any; delta: number | null }[];
  /** 2026-11-01 -- did the data move between the two runs (core/reports/instance_diff.data_versions_changed) */
  data_versions?: { known: boolean; changed: { table: string; signed: string | null; current: string | null }[]; words: string } | null;
  column_summary?: { column: string; numeric: boolean;
    base: { count: number; nulls: number; distinct: number; sum: number | null };
    current: { count: number; nulls: number; distinct: number; sum: number | null } }[];
}

/**
 * Publish-lifecycle fetch (2026-08-17): like safeFetch but the thrown error
 * CARRIES the HTTP status (core's ApiError does not), because the lifecycle
 * UI must tell "this backend does not have that endpoint yet" (404/405 →
 * degrade gracefully) apart from a real failure.  Uses rawFetch so auth /
 * workspace / request-id headers and API_BASE_URL resolution are shared.
 */
const lifecycleFetch = async (url: string, options: RequestInit = {}): Promise<any> => {
  const resp = await rawFetch(url, {
    ...options,
    headers: {
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...(options.headers as Record<string, string>),
    },
  });
  if (!resp.ok) {
    let detail = `HTTP ${resp.status}`;
    try {
      const e: any = await resp.json();
      if (typeof e?.detail === 'string') detail = e.detail;
      else if (e?.detail?.message) detail = e.detail.message;
      else if (typeof e?.message === 'string') detail = e.message;
    } catch { /* non-JSON error body */ }
    const err: any = new Error(detail);
    err.status = resp.status;
    throw err;
  }
  if (resp.status === 204 || resp.headers.get('content-length') === '0') return null;
  const ct = (resp.headers.get('content-type') || '').toLowerCase();
  if (ct && !ct.includes('json')) {
    // SPA HTML fallback served a 200 for an unknown /api route — the
    // older-backend case in disguise.  Report endpoint-missing, not success.
    const err: any = new Error(`Endpoint ${url} is not available on this backend`);
    err.status = 404;
    throw err;
  }
  return resp.json();
};

/**
 * A PINNED progressive page fetch (2026-09-05).
 *
 * Identical to a plain GET except that a non-2xx carries the server's
 * structured refusal through untouched: ``err.status`` and ``err.detail``
 * ({error, reason, message, consolidated, requested_dataset_version}).  The
 * viewer renders the server's own ``message`` and branches on its ``reason``
 * — it never composes a reason of its own, because "the build finished, your
 * answer is intact" and "those rows are gone" are not paraphrases of each
 * other.
 */
const pinnedPageFetch = async (url: string): Promise<any> => {
  const resp = await rawFetch(url);
  if (!resp.ok) {
    let payload: any = null;
    try { payload = await resp.json(); } catch { /* non-JSON error body */ }
    const detail = payload?.detail;
    const message = typeof detail === 'string'
      ? detail
      : (detail?.message || `Could not load this page of results (HTTP ${resp.status})`);
    const err: any = new Error(message);
    err.status = resp.status;
    err.detail = detail;   // preserves {error, reason, ...} for the 409
    throw err;
  }
  return resp.json();
};

/**
 * Did the server refuse this pinned page because the snapshot it named has
 * MOVED?  Read from the payload the backend actually sends — never inferred
 * from a status code alone, because a 409 from anywhere else is not this.
 */
/** POST a token cube body; a failure keeps its status and structured detail. */
async function tokenCube(path: string, body: any) {
  const resp = await rawFetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: safeStringify(body) });
  if (!resp.ok) {
    let payload: any = null;
    try { payload = await resp.json(); } catch { /* non-JSON error body */ }
    const detail = payload?.detail;
    const err: any = new Error(typeof detail === 'string' ? detail : (detail?.message || `Tile query failed (HTTP ${resp.status})`));
    err.status = resp.status;
    err.detail = detail;
    throw err;
  }
  return resp.json();
}

export const isSnapshotMoved = (err: any): boolean =>
  !!err && err.status === 409 && err.detail?.error === 'result_snapshot_moved';

const businessReports = {
  // ── Business Reports ────────────────────────────────────────────────────
  // 2026-08-09 (metadata-scale audit finding 1): pagination params.  With
  // `limit` (and optional `cursor`/`q`) the server returns the paginated
  // envelope {items, next_cursor, has_more, limit} of SLIM list projections;
  // without them the legacy full array is returned (backwards compatible).
  listBusinessReports: (params?: {
    owner?: string; dataset_id?: number; published_only?: boolean;
    limit?: number; cursor?: string; q?: string; include_samples?: boolean;
  }) => {
    const qs = new URLSearchParams();
    if (params?.owner) qs.set('owner', params.owner);
    // 2026-09-18 — omitted means FALSE server-side, which hides seeded demos
    // and probe reports.  Sent only when the caller opts in, so the default
    // list stays uncluttered.
    if (params?.include_samples) qs.set('include_samples', 'true');
    if (params?.dataset_id) qs.set('dataset_id', String(params.dataset_id));
    if (params?.published_only) qs.set('published_only', 'true');
    if (params?.limit != null) qs.set('limit', String(params.limit));
    if (params?.cursor) qs.set('cursor', params.cursor);
    if (params?.q) qs.set('q', params.q);
    const q = qs.toString();
    return safeFetch(`/api/business-reports${q ? '?' + q : ''}`);
  },
  createBusinessReport: (data: any) =>
    safeFetch('/api/business-reports', { method: 'POST', body: safeStringify(data) }),
  getBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}`),
  // 2026-09-25 -- the columns + hierarchies a VIEWER needs, under the
  // REPORT's view rule (the dataset itself may be unpublished and not theirs)
  getBusinessReportDatasetMeta: (id: number) =>
    safeFetch(`/api/business-reports/${id}/dataset-meta`),
  // 2026-09-27 -- the NON-admin scan/engine disclosure for one run of this
  // report (files read of listed, manifests, engine), under the report's
  // view rule.  Each fact is null when not recorded, never 0.
  getReportScanDisclosure: (id: number, executionId: string) =>
    safeFetch(`/api/business-reports/${id}/execution/${encodeURIComponent(executionId)}/scan-disclosure`),
  // 2026-10-30 -- the Diagnostics panel: how THIS run applied each parameter,
  // which engine read the data, the SQL sent (editors), time, rows, cache,
  // the canvas tiles and the action runs (backend core/reports/diagnostics.py).
  getReportRunDiagnostics: (id: number, executionId: string) =>
    safeFetch(`/api/business-reports/${id}/executions/${encodeURIComponent(executionId)}/diagnostics`),
  // the values a run used, in words -- for a canvas band tile
  getReportRunParameterValues: (id: number, executionId: string) =>
    safeFetch(`/api/business-reports/${id}/executions/${encodeURIComponent(executionId)}/parameters`),
  // 2026-11-01 -- report themes (the look is configuration; backend core/reports/themes.py)
  listReportThemes: () => safeFetch('/api/report-themes'),
  // 2026-11-02 -- report templates (a report started from a design; backend core/reports/templates.py)
  listReportTemplates: () => safeFetch('/api/report-templates'),
  suggestReportTemplateSlots: (templateId: string, datasetId: number) =>
    safeFetch(`/api/report-templates/${encodeURIComponent(templateId)}/suggest?dataset_id=${datasetId}`),
  buildReportFromTemplate: (templateId: string, body: { dataset_id: number; slots: Record<string, number[]>; name: string; theme?: string }) =>
    safeFetch(`/api/report-templates/${encodeURIComponent(templateId)}/build`, { method: 'POST', body: safeStringify(body) }),
  checkReportTheme: (theme: any) => safeFetch('/api/report-themes/check', { method: 'POST', body: safeStringify({ theme }) }),
  createReportTheme: (data: any) => safeFetch('/api/report-themes', { method: 'POST', body: safeStringify(data) }),
  updateReportTheme: (id: number, data: any) => safeFetch(`/api/report-themes/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteReportTheme: (id: number) => safeFetch(`/api/report-themes/${id}`, { method: 'DELETE' }),
  setReportDiagnosticsAccess: (id: number, forViewers: boolean) =>
    safeFetch(`/api/business-reports/${id}/diagnostics-access`,
      { method: 'PUT', body: safeStringify({ for_viewers: forViewers }) }),
  // 2026-09-20 -- the browser URL is /finance-reports/<slug>; this is the
  // ONE way the UI resolves a slug (payload identical to getBusinessReport).
  getBusinessReportBySlug: (slug: string) =>
    safeFetch(`/api/business-reports/by-slug/${encodeURIComponent(slug)}`),
  // 2026-09-26 (FB-60) -- the finance report a retired parametric report was
  // migrated into; an old /reports/<id> bookmark resolves through this.
  getBusinessReportByLegacyId: (legacyId: number) =>
    safeFetch(`/api/business-reports/by-legacy-id/${legacyId}`),
  updateBusinessReport: (id: number, data: any) =>
    safeFetch(`/api/business-reports/${id}`, { method: 'PUT', body: safeStringify(data) }),
  // 2026-09-27 -- a report that ACTIVE published views serve is refused
  // (409 naming them); ``acknowledgeDependents`` deletes anyway (audited).
  deleteBusinessReport: (id: number, acknowledgeDependents = false) =>
    safeFetch(`/api/business-reports/${id}${acknowledgeDependents ? '?acknowledge_dependents=true' : ''}`,
      { method: 'DELETE' }),
  executeBusinessReport: (id: number, body: any) =>
    safeFetch(`/api/business-reports/${id}/execute`, { method: 'POST', body: safeStringify(body) }),

  // ── Phase 81: Async execution ───────────────────────────────────────────
  executeBusinessReportAsync: (id: number, body: any) =>
    safeFetch(`/api/business-reports/${id}/execute-async`, { method: 'POST', body: safeStringify(body) }),
  // 2026-11-01 -- the run panel's "Data version" control: the Iceberg tables the
  // report reads, one row per table per side, with their versions (backend
  // api/report_data_versions_api.py; ``supported: false`` = draw nothing).
  getReportDataVersions: (id: number): Promise<ReportDataVersions> =>
    safeFetch(`/api/business-reports/${id}/data-versions`),
  /** 2026-11-01 -- the band's previous / next BUSINESS day on the report's own calendar */
  getReportBusinessDay: (id: number, date: string, step: 1 | -1, param?: string): Promise<ReportBusinessDay> =>
    safeFetch(`/api/business-reports/${id}/business-day?date=${encodeURIComponent(date)}&step=${step}${param ? `&param=${encodeURIComponent(param)}` : ''}`),
  getBusinessReportAsyncStatus: (reportId: number, execId: string) =>
    safeFetch(`/api/business-reports/${reportId}/execution/${execId}/status`),
  /**
   * One page of an execution's results.
   *
   * ``datasetVersion`` (2026-09-05) is the PROGRESSIVE-SERVING PIN: the
   * ``dataset_version`` a previous page of the same paging session returned.
   * A report whose query declares a partition column lands its rows as
   * immutable PARTS while it is still running, and that dataset GROWS
   * between two page requests — so a session that does not echo the pin is
   * served page N and page N+1 from two different datasets.  Measured on a
   * real growing build: 17 rows duplicated, 32 skipped, behind eight 200s.
   * Echo it on EVERY page after the first.
   *
   * The pinned request goes through rawFetch rather than safeFetch for the
   * same reason ``queryReportCube`` does: a pin that no longer names a
   * servable snapshot is a 409 whose detail is a STRUCTURED payload
   * ({error, reason, message, consolidated}) and ``reason`` decides what the
   * user is told — ``consolidated`` (the build finished, the answer is
   * intact, refresh) and ``rebuilt`` (those rows are gone) lead to opposite
   * actions.  safeFetch's parser flattens detail to a message string and
   * would lose it.  The UNPINNED call keeps safeFetch untouched — it is the
   * ordinary path every non-partitioned report takes, a 409 cannot arise on
   * it (the backend only raises it for a pin), and it keeps the retry and
   * session-expiry handling that path has always had.
   */
  // 2026-10-24 -- the deployment's row limits a person meets (read-only).
  getReportLimits: () => safeFetch('/api/business-reports/limits').catch(() => null),
  getBusinessReportPagedResults: (reportId: number, execId: string, page: number, pageSize: number, sortColumn?: string | null, sortDirection?: string | null, datasetVersion?: string | null, links?: string | null) => {
    const qs = new URLSearchParams({ page: String(page), page_size: String(pageSize) });
    if (sortColumn) qs.set('sort_column', sortColumn);
    if (sortDirection) qs.set('sort_direction', sortDirection);
    // 2026-10-30: the canvas's clicked values -> the report table's MATCHING rows (absent = as before)
    if (links) qs.set('links', links);
    if (!datasetVersion) {
      return safeFetch(`/api/business-reports/${reportId}/results/${execId}?${qs}`);
    }
    qs.set('dataset_version', datasetVersion);
    return pinnedPageFetch(`/api/business-reports/${reportId}/results/${execId}?${qs}`);
  },
  cancelBusinessReportAsync: (reportId: number, execId: string) =>
    safeFetch(`/api/business-reports/${reportId}/execution/${execId}`, { method: 'DELETE' }),

  // ── Phase 2 UX (2026-08-09): instance probe ─────────────────────────────
  // "Is opening this report free, or would it cost a live query?"  Raw
  // parameter values travel as JSON — the backend fingerprints them through
  // the same canonicalisation the serve path uses (a client-side replica
  // would drift, making probe and serve disagree).  404 = not free.
  probeLatestReportInstance: (reportId: number, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return safeFetch(`/api/business-reports/${reportId}/instances/latest${qs}`);
  },

  // ── Commentary + sign-off on a report INSTANCE (2026-09-28) ─────────────
  // The header is resolved ONCE on the server: which instance the viewer is
  // looking at (served instance id, else the live run's execution id, else
  // the caller's newest instance for the parameters), its sign-off state,
  // the signed version it supersedes, the visible thread and what THIS
  // caller may do.  The client never derives any of that.
  getInstanceSignoffHeader: (reportId: number, key: {
    instanceId?: number | null; executionId?: string | null; params?: Record<string, any>;
  }): Promise<InstanceSignoffHeader> => {
    const qs = new URLSearchParams();
    if (key.instanceId != null) qs.set('instance_id', String(key.instanceId));
    else if (key.executionId) qs.set('execution_id', key.executionId);
    else if (key.params) qs.set('params', JSON.stringify(key.params));
    const q = qs.toString();
    const suffix = q ? '?' + q : '';
    return safeFetch(`/api/business-reports/${reportId}/instances/header${suffix}`);
  },
  signReportInstance: (reportId: number, instanceId: number, body: {
    role: SignoffRole; note?: string; business_date?: string; accept_unexplained?: boolean;
  }): Promise<InstanceSignoff> =>
    safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/signoffs`, {
      method: 'POST', body: JSON.stringify(body),
    }),
  revokeReportInstanceSignoff: (reportId: number, instanceId: number, signoffId: number,
    reason: string): Promise<InstanceSignoff> =>
    safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/signoffs/${signoffId}/revoke`, {
      method: 'POST', body: JSON.stringify({ reason }),
    }),
  listSignedRuns: (reportId: number, includeRevoked = false): Promise<{
    report_id: number; signed_runs: InstanceSignoff[]; total: number; sees_all_scopes: boolean;
  }> =>
    safeFetch(`/api/business-reports/${reportId}/signed-runs?include_revoked=${includeRevoked ? 'true' : 'false'}`),
  listInstanceComments: (reportId: number, instanceId: number): Promise<{
    instance_id: number; comments: InstanceComment[]; total: number; can_comment: boolean;
  }> =>
    safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/comments`),
  postInstanceComment: (reportId: number, instanceId: number, body: {
    text: string; parent_id?: number | null; anchor?: Record<string, any>; business_date?: string;
    origin?: Record<string, any>;
  }): Promise<InstanceComment> =>
    safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/comments`, {
      method: 'POST', body: JSON.stringify(body),
    }),
  updateInstanceComment: (reportId: number, instanceId: number, commentId: number, body: {
    text?: string; is_resolved?: boolean;
  }): Promise<InstanceComment> =>
    safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/comments/${commentId}`, {
      method: 'PUT', body: JSON.stringify(body),
    }),
  findPeopleToMentionOnReport: (reportId: number, q: string): Promise<{ people: string[] }> =>
    safeFetch(`/api/business-reports/${reportId}/commentary/people?q=${encodeURIComponent(q)}`),
  draftInstanceComment: (reportId: number, instanceId: number, anchor: NoteAnchor | null): Promise<CommentDraft> =>
    safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/commentary/draft`, {
      method: 'POST', body: JSON.stringify({ anchor }),
    }),
  findCarryForward: (reportId: number, instanceId: number, anchor: NoteAnchor | null, businessDate: string | null): Promise<CarryCandidate> =>
    safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/commentary/carry`, {
      method: 'POST', body: JSON.stringify({ anchor, business_date: businessDate }),
    }),
  findPeopleToMention: (reportId: number, instanceId: number, q: string): Promise<{ people: string[] }> =>
    safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/commentary/people?q=${encodeURIComponent(q)}`),
  getNeedsExplaining: (reportId: number, instanceId: number): Promise<NeedsExplaining> =>
    safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/commentary/needs-explaining`),
  setCommentarySettings: (reportId: number, settings: Record<string, any> | null) =>
    safeFetch(`/api/business-reports/${reportId}/commentary-settings`, {
      method: 'PUT', body: JSON.stringify({ settings }),
    }),
  deleteInstanceComment: (reportId: number, instanceId: number, commentId: number) =>
    safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/comments/${commentId}`, {
      method: 'DELETE',
    }),
  diffReportInstances: (reportId: number, instanceId: number, against?: number | null): Promise<InstanceDiff> => {
    const suffix = against != null ? '?against=' + String(against) : '';
    return safeFetch(`/api/business-reports/${reportId}/instances/${instanceId}/diff${suffix}`);
  },

  // ── Reporting rewire Phase 3 (2026-08-09): server-side microcube ────────
  // One bounded DuckDB query per drill/banding/running-calc/slicer gesture
  // over the result artifact — used when the server stamped engine:"server".
  // Uses rawFetch (not safeFetch) because the 422 non_additive_measures
  // response carries a STRUCTURED detail payload ({error, refused:[{column,
  // reason}]}) that the viewer must surface per measure — safeFetch's error
  // parser flattens detail objects to a message string and would lose it.
  // 2026-10-30: the canvas tiles' road -- the same route, Arrow preferred
  // (services/api/cubeArrow.ts); every other caller keeps queryReportCube's JSON
  queryReportCubeFast: (reportId: number, execId: string, body: any) => queryReportCubeArrow(reportId, execId, body),
  // 2026-10-30 (every report a canvas): a page of the report's OWN table, Arrow
  // preferred (services/api/pageArrow.ts); an unpinned page only -- a pinned
  // (progressive) page and every error keep the JSON road above
  getBusinessReportPagedResultsFast: (reportId: number, execId: string, page: number, pageSize: number,
                                      sortColumn?: string | null, sortDirection?: string | null, links?: string | null) =>
    getReportPageArrow(reportId, execId, page, pageSize, sortColumn, sortDirection, links,
      () => businessReports.getBusinessReportPagedResults(reportId, execId, page, pageSize, sortColumn, sortDirection, null, links)),
  queryReportCube: async (reportId: number, execId: string, body: any) => {
    const resp = await rawFetch(
      `/api/business-reports/${reportId}/results/${execId}/cube`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: safeStringify(body),
      },
    );
    if (!resp.ok) {
      let payload: any = null;
      try { payload = await resp.json(); } catch { /* non-JSON error body */ }
      const detail = payload?.detail;
      const message = typeof detail === 'string'
        ? detail
        : (detail?.message || `Cube query failed (HTTP ${resp.status})`);
      const err: any = new Error(message);
      err.status = resp.status;
      err.detail = detail;  // preserves the structured 422 payload
      throw err;
    }
    return resp.json();
  },
  // retainDays (2026-08-30): how long the produced file stays in the
  // Download Centre.  Omitted -> the operator-configured default, which
  // is exactly the pre-existing behaviour.  An explicit 0 is never sent:
  // the API refuses it so it cannot be read as 'keep forever'.
  downloadBusinessReportPDF: (id: number, paramValues?: Record<string, any>,
                             retainDays?: number, columns?: string, links?: string, theme?: string,
                             notes?: { include: boolean; instanceId?: number | null }) => {
    const p = new URLSearchParams();
    if (paramValues && Object.keys(paramValues).length > 0) {
      p.set('params', JSON.stringify(paramValues));
    }
    if (retainDays && retainDays > 0) p.set('retain_days', String(retainDays));
    // Column NAMES as shown in the report, so the file matches the
    // screen.  Omitted when the viewer has hidden nothing.
    if (columns) p.set('columns', columns);
    // the canvas's linked values (canvasLinks.linksExportParam); omitted when none
    if (links) p.set('links', links);
    // 2026-11-03 -- the viewer's "View in another theme": a theme NAME; the server
    // resolves it (an unknown name = the report's own theme).  Omitted when none picked.
    if (theme) p.set('theme', theme.slice(0, 100));
    // 2026-11-07 -- the comments on the run on screen, or none; the server's default is with them
    if (notes && !notes.include) p.set('commentary', 'false');
    if (notes?.include && notes.instanceId) p.set('comments_from', String(notes.instanceId));
    const qs = p.toString() ? `?${p.toString()}` : '';
    return openDownload(`/api/business-reports/${id}/download-pdf${qs}`);
  },
  // retainDays (2026-08-30): how long the produced file stays in the
  // Download Centre.  Omitted -> the operator-configured default, which
  // is exactly the pre-existing behaviour.  An explicit 0 is never sent:
  // the API refuses it so it cannot be read as 'keep forever'.
  downloadBusinessReportExcel: (id: number, paramValues?: Record<string, any>,
                             retainDays?: number, columns?: string, links?: string, theme?: string,
                             notes?: { include: boolean; instanceId?: number | null }) => {
    const p = new URLSearchParams();
    if (paramValues && Object.keys(paramValues).length > 0) {
      p.set('params', JSON.stringify(paramValues));
    }
    if (retainDays && retainDays > 0) p.set('retain_days', String(retainDays));
    // Column NAMES as shown in the report, so the file matches the
    // screen.  Omitted when the viewer has hidden nothing.
    if (columns) p.set('columns', columns);
    // the canvas's linked values (canvasLinks.linksExportParam); omitted when none
    if (links) p.set('links', links);
    // 2026-11-03 -- the viewer's "View in another theme": a theme NAME; the server
    // resolves it (an unknown name = the report's own theme).  Omitted when none picked.
    if (theme) p.set('theme', theme.slice(0, 100));
    // 2026-11-07 -- the comments on the run on screen, or none; the server's default is with them
    if (notes && !notes.include) p.set('commentary', 'false');
    if (notes?.include && notes.instanceId) p.set('comments_from', String(notes.instanceId));
    const qs = p.toString() ? `?${p.toString()}` : '';
    return openDownload(`/api/business-reports/${id}/download-excel${qs}`);
  },
  // retainDays (2026-08-30): how long the produced file stays in the
  // Download Centre.  Omitted -> the operator-configured default, which
  // is exactly the pre-existing behaviour.  An explicit 0 is never sent:
  // the API refuses it so it cannot be read as 'keep forever'.
  downloadBusinessReportCSV: (id: number, paramValues?: Record<string, any>,
                             retainDays?: number, columns?: string) => {
    const p = new URLSearchParams();
    if (paramValues && Object.keys(paramValues).length > 0) {
      p.set('params', JSON.stringify(paramValues));
    }
    if (retainDays && retainDays > 0) p.set('retain_days', String(retainDays));
    // Column NAMES as shown in the report, so the file matches the
    // screen.  Omitted when the viewer has hidden nothing.
    if (columns) p.set('columns', columns);
    const qs = p.toString() ? `?${p.toString()}` : '';
    return openDownload(`/api/business-reports/${id}/download-csv${qs}`);
  },
  duplicateBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/duplicate`, { method: 'POST' }),
  // ── Publish lifecycle (2026-08-17) ──────────────────────────────────────
  // publish = publish OR republish (a new version).  The intent is ALWAYS
  // sent: with no body the backend used to TOGGLE, and "Republish" on a
  // published report unpublished it for every viewer (rig 2026-10-24).
  // 'unpublish' is only the fallback for a backend without /unpublish.
  publishBusinessReport: (id: number, action: 'publish' | 'unpublish' = 'publish') =>
    safeFetch(`/api/business-reports/${id}/publish`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action }),
    }),
  // The endpoints below only exist on the lifecycle backend.  They throw an
  // Error carrying ``.status`` so callers can degrade on 404/405 (see
  // utils/reportLifecycle.isEndpointMissing) instead of white-screening.
  unpublishBusinessReport: (id: number) =>
    lifecycleFetch(`/api/business-reports/${id}/unpublish`, { method: 'POST' }),
  listBusinessReportVersions: (id: number) =>
    lifecycleFetch(`/api/business-reports/${id}/versions`),
  // 2026-08-25 — these called /archive, /deprecate and /restore, which the
  // backend NEVER served (0 routes).  Every click 404'd and the UI reported
  // "this deployment does not support lifecycle states yet" — while the
  // backend has supported them since 2026-08-17 through ONE endpoint,
  // POST /lifecycle {status}, fully wired: _br_can_edit authz, version
  // snapshots, listing chokepoints that hide archived/deprecated, and a 410
  // on consumer execution of an archived report.  Three verbs were invented
  // client-side for an API that takes a status.
  archiveBusinessReport: (id: number) =>
    lifecycleFetch(`/api/business-reports/${id}/lifecycle`, {
      method: 'POST', body: safeStringify({ status: 'archived' }),
    }),
  deprecateBusinessReport: (id: number, reason?: string) =>
    lifecycleFetch(`/api/business-reports/${id}/lifecycle`, {
      // The endpoint's field is `notes`; sending `reason` dropped it silently.
      method: 'POST', body: safeStringify({ status: 'deprecated', notes: reason || null }),
    }),
  // Restore has no "clear the status" transition, and it must not invent one:
  // archived/deprecated leave `is_published` untouched precisely so the report
  // stays resolvable, so restoring means returning to the state is_published
  // already implies. The CALLER knows that, so it passes it rather than this
  // layer guessing. Re-publishing an unchanged draft reuses the existing
  // version instead of minting a duplicate, so this is not a hidden republish.
  restoreBusinessReport: (id: number, wasPublished?: boolean) =>
    lifecycleFetch(`/api/business-reports/${id}/lifecycle`, {
      method: 'POST',
      body: safeStringify({ status: wasPublished ? 'published' : 'draft' }),
    }),

  // ── Certification review queue (admin) ──────────────────────────────────
  // Backend endpoints exist today (business_reports_api.py:6305-6342); this
  // is the first frontend caller — before it, certification requests went
  // into a void.  Pass '' as status to list ALL requests.
  listCertificationQueue: (status: string = 'pending') =>
    safeFetch(`/api/admin/business-reports/certification-queue?status=${encodeURIComponent(status)}`),
  approveCertificationRequest: (requestId: number, reviewNote?: string) =>
    safeFetch(`/api/admin/business-reports/certification-requests/${requestId}/approve`,
      { method: 'POST', body: safeStringify({ review_note: reviewNote || null }) }),
  denyCertificationRequest: (requestId: number, reviewNote?: string) =>
    safeFetch(`/api/admin/business-reports/certification-requests/${requestId}/deny`,
      { method: 'POST', body: safeStringify({ review_note: reviewNote || null }) }),

  // ── Business Report Parameters ──────────────────────────────────────────
  listBusinessReportParams: (reportId: number) =>
    safeFetch(`/api/business-reports/${reportId}/parameters`),
  createBusinessReportParam: (reportId: number, data: any) =>
    safeFetch(`/api/business-reports/${reportId}/parameters`, { method: 'POST', body: safeStringify(data) }),
  updateBusinessReportParam: (paramId: number, data: any) =>
    safeFetch(`/api/business-reports/parameters/${paramId}`, { method: 'PUT', body: safeStringify(data) }),
  deleteBusinessReportParam: (paramId: number) =>
    safeFetch(`/api/business-reports/parameters/${paramId}`, { method: 'DELETE' }),
  // 2026-08-31 -- the caller's own in-flight runs.  Always self-scoped
  // server-side; there is no 'all users' variant to reach for.
  listRunningBusinessReports: () =>
    safeFetch('/api/business-reports/running'),
  getBusinessReportParamValues: (reportId: number, body: any) =>
    safeFetch(`/api/business-reports/${reportId}/parameter-values`, { method: 'POST', body: safeStringify(body) }),
  batchSaveBusinessReportParams: (reportId: number, parameters: any[]) =>
    safeFetch(`/api/business-reports/${reportId}/parameters/batch`, { method: 'PUT', body: safeStringify({ parameters }) }),

  // ── Certification & Templates ───────────────────────────────────────────
  certifyBusinessReport: (id: number, templateCategory: string) =>
    safeFetch(`/api/business-reports/${id}/certify`, { method: 'POST', body: safeStringify({ template_category: templateCategory }) }),
  uncertifyBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/certify`, { method: 'DELETE' }),
  listTemplates: (category?: string, limit = 50) =>
    safeFetch(`/api/business-reports/templates?limit=${limit}${category ? `&category=${encodeURIComponent(category)}` : ''}`),
  listTemplateCategories: () =>
    safeFetch('/api/business-reports/template-categories'),
  cloneBusinessReport: (id: number) =>
    safeFetch(`/api/business-reports/${id}/clone`, { method: 'POST' }),

  // ── Share Tokens ────────────────────────────────────────────────────────
  createBusinessReportShare: (id: number, expiresHours?: number) =>
    safeFetch(`/api/business-reports/${id}/share`, { method: 'POST', body: safeStringify({ expires_hours: expiresHours }) }),
  listBusinessReportShares: (id: number) =>
    safeFetch(`/api/business-reports/${id}/shares`),
  revokeBusinessReportShare: (id: number, token: string) =>
    safeFetch(`/api/business-reports/${id}/shares/${token}`, { method: 'DELETE' }),
  getSharedBusinessReport: (token: string) =>
    safeFetch(`/api/shared-business-report/${token}`),
  // 2026-10-26 -- a canvas tile of a share link's / embed's OWN run: the
  // handle that run returned is the only key (api: _token_cube)
  querySharedReportCube: (token: string, body: any) => tokenCube(`/api/shared-business-report/${token}/cube`, body),
  queryEmbeddedReportCube: (token: string, body: any) => tokenCube(`/api/embedded-business-report/${token}/cube`, body),
  // 2026-10-26 -- a finance-report tile of a SHARED DASHBOARD link: the run
  // (rows + the report's layout + a sealed canvas handle) and its tiles'
  // cube, scoped to that dashboard's token (api: execute_shared_dashboard_report)
  executeSharedDashboardReport: (token: string, widgetId: number, body?: { filter_values?: Record<string, any> }) =>
    safeFetch(`/api/shared-dashboard/${token}/widgets/${widgetId}/execute`, { method: 'POST', body: safeStringify(body || {}) }),
  querySharedDashboardCube: (token: string, widgetId: number, body: any) =>
    tokenCube(`/api/shared-dashboard/${token}/widgets/${widgetId}/cube`, body),
  executeSharedBusinessReport: (token: string, body: any) =>
    safeFetch(`/api/shared-business-report/${token}/execute`, { method: 'POST', body: safeStringify(body) }),
  getSharedReportParamValues: (token: string, body: any) =>
    safeFetch(`/api/shared-business-report/${token}/parameter-values`, { method: 'POST', body: safeStringify(body) }),
  getEmbeddedReportParamValues: (token: string, body: any) =>
    safeFetch(`/api/embedded-business-report/${token}/parameter-values`, { method: 'POST', body: safeStringify(body) }),
  downloadSharedReportPDF: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/shared/${token}/download-pdf${qs}`);
  },
  downloadSharedReportExcel: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/shared/${token}/download-excel${qs}`);
  },
  downloadSharedReportCSV: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/shared/${token}/download-csv${qs}`);
  },

  // ── Embed Tokens ────────────────────────────────────────────────────────
  // ``groups`` is the optional per-group scope (2026-08-29): AD group
  // names, QueryStudio-native user-group names, or both.  Omitting it
  // mints exactly the token this call minted before.
  createBusinessReportEmbed: (
    id: number,
    expiresInDays?: number,
    groups?: { allowed_ad_groups?: string[]; allowed_user_groups?: string[] },
    fixedValues?: Record<string, any>,
    options?: { controls?: boolean; full_report?: boolean; downloads?: boolean; details?: boolean },
  ) =>
    safeFetch(`/api/business-reports/${id}/embed-tokens`, { method: 'POST', body: safeStringify({ expires_in_days: expiresInDays, fixed_values: fixedValues, options, ...(groups || {}) }) }),
  listBusinessReportEmbeds: (id: number) =>
    safeFetch(`/api/business-reports/${id}/embed-tokens`),
  revokeBusinessReportEmbed: (token: string) =>
    safeFetch(`/api/business-reports/embed-tokens/${token}`, { method: 'DELETE' }),
  getEmbeddedBusinessReport: (token: string) =>
    safeFetch(`/api/embedded-business-report/${token}`),
  executeEmbeddedBusinessReport: (token: string, body: any) =>
    safeFetch(`/api/embedded-business-report/${token}/execute`, { method: 'POST', body: safeStringify(body) }),
  downloadEmbeddedReportPDF: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/embedded/${token}/download-pdf${qs}`);
  },
  downloadEmbeddedReportExcel: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/embedded/${token}/download-excel${qs}`);
  },
  downloadEmbeddedReportCSV: (token: string, paramValues?: Record<string, any>) => {
    const qs = paramValues && Object.keys(paramValues).length > 0
      ? `?params=${encodeURIComponent(JSON.stringify(paramValues))}` : '';
    return openDownload(`/api/business-reports/embedded/${token}/download-csv${qs}`);
  },

  // ── Business Portal ─────────────────────────────────────────────────────
  getPortalSummary: () =>
    safeFetch('/api/portal/summary'),
  /**
   * The published reports mapped to the current user — the portal grid.
   * Returns the keyset envelope {items, next_cursor, has_more, limit} of slim
   * summary projections.  Visibility is decided server-side by the
   * ``list_visible_business_reports_page`` chokepoint; the client never
   * filters, so a report the caller may not see is never sent at all.
   */
  listPortalReports: (params?: {
    limit?: number; cursor?: string; q?: string;
    sort?: PortalSort; favoritesOnly?: boolean;
    folderId?: number | null; tagId?: number | null;
  }) => {
    const qs = new URLSearchParams();
    if (params?.limit != null) qs.set('limit', String(params.limit));
    if (params?.cursor) qs.set('cursor', params.cursor);
    if (params?.q) qs.set('q', params.q);
    // Sorting is SERVER-side: the keyset cursor encodes the sort it was
    // minted under, so sorting a page in the browser would disagree with the
    // next page's ordering as soon as the user pressed "Load more".
    if (params?.sort) qs.set('sort', params.sort);
    if (params?.favoritesOnly) qs.set('favorites_only', 'true');
    if (params?.folderId != null) qs.set('folder_id', String(params.folderId));
    if (params?.tagId != null) qs.set('tag_id', String(params.tagId));
    const q = qs.toString();
    return safeFetch(`/api/portal/reports${q ? '?' + q : ''}`);
  },

  /** Star / unstar a business report for the calling user. */
  togglePortalFavorite: (reportId: number) =>
    safeFetch(`/api/portal/reports/${reportId}/favorite`, { method: 'POST' }),

  // ── Delivery & Subscriptions ────────────────────────────────────────────
  createSubscription: (data: any) =>
    safeFetch('/api/subscriptions', { method: 'POST', body: safeStringify(data) }),
  listSubscriptions: (reportId?: number, reportType?: string) => {
    const params = new URLSearchParams();
    if (reportId != null) params.set('report_id', String(reportId));
    if (reportType) params.set('report_type', reportType);
    const qs = params.toString();
    return safeFetch(`/api/subscriptions${qs ? '?' + qs : ''}`);
  },
  getSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}`),
  updateSubscription: (id: number, data: any) =>
    safeFetch(`/api/subscriptions/${id}`, { method: 'PUT', body: safeStringify(data) }),
  deleteSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}`, { method: 'DELETE' }),
  testSendSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}/test-send`, { method: 'POST' }),
  pauseSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}/pause`, { method: 'POST' }),
  resumeSubscription: (id: number) =>
    safeFetch(`/api/subscriptions/${id}/resume`, { method: 'POST' }),
  getSubscriptionHistory: (id: number, limit = 50) =>
    safeFetch(`/api/subscriptions/${id}/history?limit=${limit}`),

  // ── Calculated metrics (semantic layer) ────────────────────────────────
  // 2026-08-30 — first frontend caller of GET /api/datasets/{id}/metrics.
  // Backed by datasets_api list_metrics; the route default is
  // active_only=False, so authoring passes true explicitly — active metrics
  // are exactly the population _validate_metric_selection accepts on a
  // report's metric_ids (an inactive metric is a named 400 at save).  Lives
  // here because its only consumer is business-report authoring.
  listDatasetMetrics: (datasetId: number, activeOnly = true) =>
    safeFetch(`/api/datasets/${datasetId}/metrics${activeOnly ? '?active_only=true' : ''}`),

  // ── Viewer Preferences ─────────────────────────────────────────────────
  updateViewerPrefs: (id: number, prefs: { column_order?: string[] }) =>
    safeFetch(`/api/business-reports/${id}/viewer-prefs`, { method: 'PATCH', body: safeStringify(prefs) }),

  // ── Execution History ──────────────────────────────────────────────────
  getExecutionHistory: (reportId: number, page = 1, pageSize = 20) =>
    safeFetch(`/api/business-reports/${reportId}/execution-history?page=${page}&page_size=${pageSize}`),

  // 2026-11-07 (the report framework): the sources known here, in plain words, with what each can do
  listReportSources: () =>
    safeFetch('/api/report-sources'),

};

export default businessReports;
