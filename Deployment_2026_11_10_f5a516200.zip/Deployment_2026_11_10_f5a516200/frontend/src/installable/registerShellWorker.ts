/**
 * Registers the app-shell service worker (build/sw.js, written per build by vite.config.ts from
 * frontend/sw/*).  Production builds only: in dev there is no sw.js and Vite serves everything
 * fresh.  The worker caches the static shell alone -- never the API, never the runtime config,
 * never anything per-user (frontend/sw/shell-rules.js).
 */
export async function registerShellWorker(opts?: {
  nav?: Pick<Navigator, 'serviceWorker'> | Navigator;
  prod?: boolean;
  scriptUrl?: string;
}): Promise<boolean> {
  const prod = opts?.prod ?? Boolean(import.meta.env?.PROD);
  const nav = opts?.nav ?? (typeof navigator !== 'undefined' ? navigator : undefined);
  if (!prod || !nav || !('serviceWorker' in nav) || !nav.serviceWorker) return false;
  try {
    await nav.serviceWorker.register(opts?.scriptUrl ?? '/sw.js', { scope: '/' });
    return true;
  } catch (err) {
    // an installable shell is a convenience: the app runs the same without it
    console.info('[installable] the app-shell worker was not registered:', err);
    return false;
  }
}
