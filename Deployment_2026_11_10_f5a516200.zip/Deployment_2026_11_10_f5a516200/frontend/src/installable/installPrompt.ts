/**
 * Desktop step one (2026-11-08): the browser's own "install this app" offer, held until the person
 * asks for it from the user menu.  Edge / Chrome fire `beforeinstallprompt` when the manifest and
 * the service worker make the app installable; the event is kept and shown as "Install <name>"
 * only then -- nothing is shown when the browser does not offer it (Safari, an already installed
 * app, an iframe).  `appinstalled` clears it.
 */
import { useEffect, useState } from 'react';
import { isReportsApp } from '../utils/product';

export interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice?: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

/** The product's name as installed: the deployment's `appName`, else the product's own default
 *  (the Reports app is self-installed per team under its own name -- nothing hard-coded). */
export function installableAppName(): string {
  const cfg = (typeof window !== 'undefined' ? window.APP_CONFIG : undefined) || {};
  const given = String((cfg as any).appName || '').trim();
  if (given) return given;
  return isReportsApp() ? 'Reports' : 'QueryStudio';
}

export function useInstallPrompt(): { prompt: InstallPromptEvent | null; install: () => Promise<'accepted' | 'dismissed' | 'unavailable'> } {
  const [prompt, setPrompt] = useState<InstallPromptEvent | null>(null);
  useEffect(() => {
    const onOffer = (e: Event) => {
      e.preventDefault();            // the browser's mini bar stays quiet; the user menu offers it
      setPrompt(e as InstallPromptEvent);
    };
    const onInstalled = () => setPrompt(null);
    window.addEventListener('beforeinstallprompt', onOffer);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onOffer);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);
  const install = async () => {
    if (!prompt) return 'unavailable' as const;
    const p = prompt;
    setPrompt(null);                 // the offer can be used once
    try {
      await p.prompt();
      const choice = await (p.userChoice ?? Promise.resolve({ outcome: 'accepted' as const }));
      if (choice.outcome !== 'accepted') setPrompt(p);   // declined: the entry stays for next time
      return choice.outcome;
    } catch {
      return 'unavailable' as const;
    }
  };
  return { prompt, install };
}
