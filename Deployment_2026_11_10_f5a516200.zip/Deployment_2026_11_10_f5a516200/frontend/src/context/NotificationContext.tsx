import React, { createContext, useContext, useState, useCallback, useEffect, useRef, ReactNode } from 'react';
import { useWebSocket } from './WebSocketContext';
import { useAuth } from './AuthContext';
import api from '../services/api';
import { engineLabel } from '../utils/engineLabel';

export interface Notification {
  id: number;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
  action?: { label: string; href: string };
  data?: unknown;
  timestamp?: string;
}

export interface ExecLogEntry {
  ts: string;        // ISO timestamp
  execId: string;    // execution ID
  message: string;
}

export type AddNotificationInput = Omit<Notification, 'id' | 'timestamp'> & { timestamp?: string };

interface NotificationContextValue {
  notifications: Notification[];
  runningCount: number;
  execLogs: ExecLogEntry[];
  unreadLogCount: number;
  unreadNotifCount: number;
  refreshUnreadCount: () => void;
  markLogsRead: () => void;
  clearLogs: () => void;
  addNotification: (notification: AddNotificationInput) => void;
  removeNotification: (id: number) => void;
  clearAll: () => void;
}

const NotificationContext = createContext<NotificationContextValue | null>(null);

/** Executions the PAGE runs in the background (dashboard widgets): their
 *  result is rendered in place, so their completion is logged, never toasted.
 *  2026-09-24: a dashboard with one widget stacked two "Query Completed
 *  Successfully" toasts (their "View Results" pointed at Downloads). */
const quietExecutions = new Set<string>();
export const markExecutionQuiet = (executionId?: string | null) => {
  if (!executionId) return;
  quietExecutions.add(executionId);
  if (quietExecutions.size > 500) quietExecutions.clear();
};
export const isExecutionQuiet = (executionId?: string | null) =>
  !!executionId && quietExecutions.has(executionId);

/** A completion under this many seconds, while the tab is visible, is not
 *  toasted -- its result is already in front of the person. */
export const QUIET_COMPLETION_SECONDS = 10;

export const shouldToastCompletion = (durationSeconds: unknown): boolean => {
  const visible = typeof document === 'undefined' || document.visibilityState === 'visible';
  const d = Number(durationSeconds);
  if (!visible) return true;                      // they are elsewhere: tell them
  if (!Number.isFinite(d)) return true;           // unknown duration: say it
  return d >= QUIET_COMPLETION_SECONDS;
};

/**
 * 2026-09-27 — ENGINE ATTRIBUTION on a completion.  The backend stamps
 * `{engine, engine_label}` on every `execution_completed` event
 * (core/engine_attribution.py) and this context used to drop it.  The
 * summary a person reads — in the log line and the toast — now names the
 * engine after the counts, and a completion that recorded no engine says
 * nothing about it rather than guessing.
 */
export const completionSummary = (message: Record<string, unknown>): string => {
  const stats = (message.stats as any) || {};
  const rows = stats.total_rows ?? (message as any).total_rows;
  const cols = stats.total_columns;
  const duration = stats.duration_seconds ?? (message as any).elapsed_seconds;
  const parts: string[] = [];
  if (rows != null) parts.push(`${Number(rows).toLocaleString()} rows`);
  if (cols != null) parts.push(`${cols} columns`);
  if (duration != null && Number.isFinite(Number(duration))) parts.push(`${Number(duration).toFixed(1)}s`);
  const engine = engineLabel((message as any).engine, (message as any).engine_label);
  if (engine) parts.push(`via ${engine}`);
  return parts.length > 0 ? parts.join(' · ') : 'Results available';
};

/**
 * 2026-09-27 — an `execution_engine_fallback` event is the server saying
 * "this ran on DuckDB instead of Spark, and here is why".  The frontend
 * ignored the event.  It is INFORMATION, not an alarm: the query is still
 * running and will complete; the person only needs to know why it may be
 * slower.  Reasons the server considers silent are never sent
 * (`_SPARK_FALLBACK_MESSAGES` maps them to None), so any message that
 * arrives is one the server meant a person to read.  Returns null for an
 * event with no message — nothing to say is not a notification.
 */
export const fallbackNotification = (
  message: Record<string, unknown>,
): AddNotificationInput | null => {
  const text = typeof message.message === 'string' ? message.message.trim() : '';
  if (!text) return null;
  const reason = typeof message.reason === 'string' ? message.reason : '';
  return {
    type: 'info',
    title: 'Query engine changed',
    message: text,
    data: { reason, execution_id: message.execution_id },
    timestamp: typeof message.timestamp === 'string' ? message.timestamp : undefined,
  };
};

export const useNotifications = (): NotificationContextValue => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within NotificationProvider');
  }
  return context;
};

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [execLogs, setExecLogs] = useState<ExecLogEntry[]>([]);
  const [unreadLogCount, setUnreadLogCount] = useState(0);
  // Track active execution IDs so we can decrement correctly
  const runningRef = useRef<Set<string>>(new Set());
  const [runningCount, setRunningCount] = useState(0);
  // Dedup guard — prevent double-notification if multiple listeners fire for the same execution
  const notifiedRef = useRef<Set<string>>(new Set());
  // Dedup guard for exec logs — prevent same log message appearing twice
  const lastLogRef = useRef<string>('');
  const { addListener } = useWebSocket();
  const { user } = useAuth();
  const userRole = (user as any)?.role || 'viewer';

  // ── Persistent notification badge (bell icon) ──────────────────────────
  const [unreadNotifCount, setUnreadNotifCount] = useState(0);
  const refreshUnreadCount = useCallback(() => {
    api.getUnreadCount().then((r: any) => setUnreadNotifCount(r.count || 0)).catch(() => {});
  }, []);

  // Poll unread count as fallback (WebSocket handles real-time updates).
  // 120s interval is sufficient since refreshUnreadCount() is also called
  // on execution_completed / execution_failed via WebSocket.
  const UNREAD_POLL_MS = 120_000;
  useEffect(() => {
    refreshUnreadCount();
    const interval = setInterval(refreshUnreadCount, UNREAD_POLL_MS);
    return () => clearInterval(interval);
  }, [refreshUnreadCount]);

  const markLogsRead = useCallback(() => setUnreadLogCount(0), []);
  const clearLogs = useCallback(() => { setExecLogs([]); setUnreadLogCount(0); }, []);

  const addNotification = useCallback((notification: AddNotificationInput) => {
    const id = Date.now() + Math.random();
    const newNotification: Notification = {
      id,
      ...notification,
      timestamp: notification.timestamp || new Date().toISOString(),
    };
    setNotifications(prev => [newNotification, ...prev].slice(0, 50));

    // Errors and notifications with actions persist until manually dismissed
    if (notification.type !== 'error' && !notification.action) {
      setTimeout(() => removeNotification(id), 5000);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const removeNotification = useCallback((id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  // ── Global execution tracker ────────────────────────────────────────────────
  // Tracks ALL executions across every page so users see results after navigation.
  useEffect(() => {
    const removeListener = addListener((message) => {
      const execId = message.execution_id as string | undefined;

      if (message.type === 'execution_started' && execId) {
        runningRef.current.add(execId);
        setRunningCount(runningRef.current.size);
        return;
      }

      if (message.type === 'execution_progress') {
        // Capture step logs from backend
        const logMsg = (message.data as any)?.log;
        if (logMsg && execId) {
          // Dedup: skip if identical to last log for same execution
          const dedupKey = `${execId}:${logMsg}`;
          if (lastLogRef.current === dedupKey) return;
          lastLogRef.current = dedupKey;
          const entry: ExecLogEntry = {
            ts: new Date().toISOString(),
            execId,
            message: logMsg,
          };
          setExecLogs(prev => [...prev.slice(-99), entry]);
          setUnreadLogCount(prev => prev + 1);
        }
        return;
      }

      if (message.type === 'execution_background' || message.type === 'result_ready') {
        // 2026-11-08 -- a run that reads more rows than the threshold goes on in the background,
        // and its result when ready (core/background_queries.py): the toast says the server's
        // words; the bell's count is re-read (the notice itself is in notification_log)
        const key = `${execId || ''}:${message.type}`;
        if (notifiedRef.current.has(key)) return;
        notifiedRef.current.add(key);
        addNotification({
          type: message.type === 'result_ready' ? 'success' : 'info',
          title: message.type === 'result_ready' ? String(message.title || 'Your result is ready') : 'Running in the background',
          message: String(message.message || message.words || ''),
        });
        refreshUnreadCount();
        return;
      }

      if (message.type === 'execution_engine_fallback' && execId) {
        // 2026-09-27: the server's own sentence about why the engine
        // changed, as an info notice.  Logged too, so it is findable after
        // the toast is gone.  Dedup per execution: the same run can only
        // fall back once.
        const notice = fallbackNotification(message as Record<string, unknown>);
        if (!notice) return;
        const key = `${execId}:fallback`;
        if (notifiedRef.current.has(key)) return;
        notifiedRef.current.add(key);
        setExecLogs(prev => [...prev.slice(-99), {
          ts: new Date().toISOString(), execId,
          message: `[ENGINE] ${notice.message} (${execId.slice(0, 8)})`,
        }]);
        setUnreadLogCount(prev => prev + 1);
        addNotification(notice);
        return;
      }

      if (message.type === 'execution_completed' && execId) {
        const wasTracked = runningRef.current.delete(execId);
        if (wasTracked) setRunningCount(runningRef.current.size);
        // Dedup: only notify once per execution_id
        if (notifiedRef.current.has(execId)) return;
        notifiedRef.current.add(execId);
        if (notifiedRef.current.size > 200) notifiedRef.current.clear(); // prevent memory leak
        const stats = message.stats as any;
        const duration = stats?.duration_seconds;
        const shortId = execId.slice(0, 8);
        const summary = completionSummary(message as Record<string, unknown>);
        setExecLogs(prev => [...prev.slice(-99), {
          ts: new Date().toISOString(), execId,
          message: `[COMPLETED] ${summary} (${shortId})`,
        }]);
        setUnreadLogCount(prev => prev + 1);
        // 2026-09-24 (walked in a real browser): a 0.1s query stacked two
        // toasts over its own results grid.  A quick query finished while
        // the person is looking at the page needs no toast -- the result is
        // on screen, and the log above still records it.  A long query, or
        // one that finishes while they are elsewhere, still announces itself.
        if (isExecutionQuiet(execId) || !shouldToastCompletion(duration)) {
          refreshUnreadCount();
          return;
        }
        addNotification({
          type: 'success',
          title: 'Query Completed Successfully',
          message: summary,
          action: { label: 'View Results', href: '/downloads' },
          timestamp: message.timestamp as string,
        });
        refreshUnreadCount();
        return;
      }

      if (message.type === 'execution_failed' && execId) {
        const wasTracked = runningRef.current.delete(execId);
        if (wasTracked) setRunningCount(runningRef.current.size);
        const isTokenExpired = (message as any).error_code === 'TOKEN_EXPIRED';
        const rawError = (message.error as string) || 'An error occurred';
        const shortId = execId.slice(0, 8);
        // Clean up common error prefixes for readability
        const cleanError = rawError.replace(/^(Error|Exception|Traceback):\s*/i, '');
        setExecLogs(prev => [...prev.slice(-99), {
          ts: new Date().toISOString(), execId,
          message: `[ERROR] ${cleanError} (${shortId})`,
        }]);
        setUnreadLogCount(prev => prev + 1);
        addNotification({
          type: 'error',
          title: isTokenExpired ? 'Session Token Expired' : `Execution Failed`,
          message: cleanError,
          ...(isTokenExpired ? { action: { label: 'Update Connection', href: '/connections' } } : {}),
          timestamp: message.timestamp as string,
        });
        refreshUnreadCount();
        return;
      }

      if (message.type === 'execution_cancelled' && execId) {
        runningRef.current.delete(execId);
        setRunningCount(runningRef.current.size);
        const shortId = execId.slice(0, 8);
        setExecLogs(prev => [...prev.slice(-99), {
          ts: new Date().toISOString(), execId,
          message: `[CANCELLED] Query cancelled by user (${shortId})`,
        }]);
        setUnreadLogCount(prev => prev + 1);
        addNotification({
          type: 'warning',
          title: 'Query Cancelled',
          message: `Execution ${shortId} was cancelled`,
          timestamp: message.timestamp as string,
        });
        return;
      }

      // ── DataFlow notification policies (Phase 132.21 — wired in 132.28) ──
      // The notification engine broadcasts `event: dataflow_notification`
      // with severity + run / dataflow context.  Surface as a toast.
      if (message.event === 'dataflow_notification') {
        const sev = (message as any).severity || 'warning';
        const policy = (message as any).policy_name || 'policy';
        const trigger = (message as any).trigger || 'event';
        const dfName = (message as any).dataflow_name || '';
        const runId = (message as any).run_id;
        addNotification({
          type: sev === 'error' ? 'error' :
                  sev === 'warning' ? 'warning' :
                  sev === 'success' ? 'success' : 'info',
          title: `DataFlow ${trigger}${dfName ? ` — ${dfName}` : ''}`,
          message: `${policy}${runId ? ` · run #${runId}` : ''}`,
          data: message,
          timestamp: (message as any).timestamp || new Date().toISOString(),
        });
        return;
      }

      // ── Agent suggestions (Phase 120) ────────────────────────────────────
      if (message.type === 'agent_suggestion') {
        const agent = (message as any).agent || 'agent';
        const reason = (message as any).reason || '';
        const issues = (message as any).issues as any[] | undefined;
        if (agent === 'data_pipeline' && issues?.length) {
          const issueList = issues.map((i: any) => i.message || i.type).join('; ');
          addNotification({
            type: 'warning',
            title: 'Upload Data Quality',
            message: `${reason}: ${issueList}`,
            data: message,
          });
        } else if (agent === 'dq_monitor') {
          addNotification({
            type: 'warning',
            title: 'Data Quality Alert',
            message: reason || 'DQ rules triggered',
            data: message,
          });
        } else if (agent === 'query_resilience') {
          const fix = (message as any).fix_applied || '';
          addNotification({
            type: 'info',
            title: 'Query Fix Suggested',
            message: fix ? `${reason} — ${fix}` : reason,
            data: message,
          });
        } else {
          addNotification({
            type: 'info',
            title: 'Agent Suggestion',
            message: reason,
            data: message,
          });
        }
        return;
      }

      // ── API Key Request notifications ────────────────────────────────────
      if (message.type === 'api_key_request') {
        const action = (message as any).action;
        const target = (message as any).target;
        // BF-121: Only show "new_request" notifications to admin users
        if (action === 'new_request') {
          if (!target || target === 'admins') {
            const isAdmin = userRole === 'admin' || userRole === 'super_admin';
            if (isAdmin) {
              addNotification({
                type: 'info',
                title: 'New API Key Request',
                message: `${(message as any).requester || 'User'} requested API key "${(message as any).key_name || ''}"`,
                data: message,
              });
            }
          }
        } else if (action === 'approved') {
          addNotification({
            type: 'success',
            title: 'API Key Approved',
            message: `Your API key request was approved${(message as any).note ? `: ${(message as any).note}` : ''}`,
            data: message,
          });
        } else if (action === 'denied') {
          addNotification({
            type: 'warning',
            title: 'API Key Denied',
            message: `Your API key request was denied${(message as any).note ? `: ${(message as any).note}` : ''}`,
            data: message,
          });
        }
        return;
      }

      // ── Feed gave up waiting on its dependencies (2026-09-27) ──────────────
      // The 48 h escalation failed the run, e-mailed the feed's addresses
      // and wrote a bell row for the owner; this is the live half.
      if (message.type === 'feed_dep_wait_escalated') {
        const m = message as any;
        addNotification({
          type: 'error',
          title: 'Feed gave up waiting on its dependencies',
          message: `${m.feed_name || `Feed #${m.feed_config_id ?? '?'}`} for ${m.business_date || 'today'}`
            + ` was marked failed after ${m.hours_waiting ?? '?'}h in WAIT`
            + (m.wait_reason ? ` (${m.wait_reason})` : '')
            + '. Skip the dependency with a reason, or re-run once the upstream lands.',
          action: { label: 'Open Feeds Today', href: '/feeds/today' },
          data: message,
        });
        refreshUnreadCount();
        return;
      }

      // ── All other events → show as notification ────────────────────────────
      // -- A feed CONSUMER notice (2026-09-28): delivered / late / failed --
      // Raised once per event by core/feed/consumer_notices.py, addressed to
      // the subscriber; the bell row was written first, this is the live half.
      if (message.type === 'feed_consumer_delivered'
          || message.type === 'feed_consumer_late'
          || message.type === 'feed_consumer_failed') {
        const m = message as any;
        const run = m.feed_run_id != null ? `?receipt=${m.feed_run_id}` : '';
        addNotification({
          type: message.type === 'feed_consumer_delivered' ? 'success'
            : message.type === 'feed_consumer_late' ? 'warning' : 'error',
          title: m.title || `${m.feed_name || 'A feed'}: ${String(message.type).replace('feed_consumer_', '')}`,
          message: m.message || '',
          action: { label: 'Open receipt', href: `/feeds/mine${run}` },
          data: message,
        });
        refreshUnreadCount();
        return;
      }

      const SILENT = new Set(['pong', 'connection_established']);
      if (message.type && !SILENT.has(message.type)) {
        const getType = (t: string): Notification['type'] => {
          if (t.includes('completed')) return 'success';
          if (t.includes('failed') || t.includes('error')) return 'error';
          return 'info';
        };
        const titles: Record<string, string> = {
          download_ready: 'Download Ready',
          export_completed: 'Export Complete',
          schedule_completed: 'Schedule Completed',
          schedule_failed: 'Schedule Failed',
        };
        if (titles[message.type]) {
          addNotification({
            type: getType(message.type),
            title: titles[message.type],
            message: (message.message as string) || message.type,
            data: message,
            timestamp: (message.timestamp as string) || new Date().toISOString(),
          });
        }
      }
    });

    return () => removeListener();
  }, [addListener, addNotification, refreshUnreadCount]);

  return (
    <NotificationContext.Provider value={{ notifications, runningCount, execLogs, unreadLogCount, unreadNotifCount, refreshUnreadCount, markLogsRead, clearLogs, addNotification, removeNotification, clearAll }}>
      {children}
    </NotificationContext.Provider>
  );
};
