/**
 * The person's Text size (2026-11-10, the owner on UAT): a MULTIPLIER on the screen-based size, never a
 * fixed size -- src/index.css grows the root font size smoothly with the screen width and reads
 * `--qs-text-scale` from `data-text-size` on <html>.  Remembered in this browser only (a convenience).
 */
export type TextSize = 'small' | 'default' | 'large' | 'xlarge';

export const TEXT_SIZES: { value: TextSize; label: string; scale: number }[] = [
  { value: 'small', label: 'Smaller', scale: 0.9 },
  { value: 'default', label: 'Default', scale: 1 },
  { value: 'large', label: 'Larger', scale: 1.125 },
  { value: 'xlarge', label: 'Largest', scale: 1.25 },
];

const KEY = 'qs.textSize';

export function readTextSize(): TextSize {
  try {
    const v = window.localStorage.getItem(KEY);
    if (v && TEXT_SIZES.some(t => t.value === v)) return v as TextSize;
  } catch { /* no storage: the default */ }
  return 'default';
}

/** Put the size on <html> (the CSS does the rest) and remember it. */
export function applyTextSize(size: TextSize, remember = false): void {
  const root = typeof document !== 'undefined' ? document.documentElement : null;
  if (root) {
    if (size === 'default') root.removeAttribute('data-text-size');
    else root.setAttribute('data-text-size', size);
  }
  if (remember) {
    try { window.localStorage.setItem(KEY, size); } catch { /* not kept */ }
  }
}
