/** System Account types that can log in to the AWS portal.
 *
 *  The portal takes an AD username + password, which an AD account (its own
 *  password or a Vault AD_accounts entry) holds as well as an AWS Portal
 *  account -- the server resolves either the same way
 *  (backend core/credential_manager.py::system_account_login).  Used by the
 *  S3 connection form and Admin -> AWS Portal (2026-10-28).
 *  2026-11-09 (owner: "connection has all details ... accept normal system account like trino
 *  or ad based"): the portal ADDRESS (base URL / JWT URL, role, account) is on the connection, so
 *  any account holding a username + password logs in -- a database account (the kind a Trino /
 *  Starburst connection uses) too. */
export const PORTAL_ACCOUNT_TYPES = ['aws_portal', 'ad_account', 'db_account'];

/** The plain word for an account type in a picker. */
export const portalAccountKind = (accountType: string): string =>
  accountType === 'ad_account' ? 'AD account' : accountType === 'db_account' ? 'database account' : 'AWS Portal';
