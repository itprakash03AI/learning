/**
 * ReportStudioPage -- the ONE editor of a report (2026-11-01; the simple
 * builder of 2026-11-07 made it one SCREEN).
 *
 * /finance-reports/:id/design opens the report DESIGNER (CanvasReportBuilder:
 * the canvas, the Filters pane, Fields over the Visuals grid over Build /
 * Format, More for the rest).  The six old tabs are gone as a strip; their
 * words keep working as the panel the designer opens:
 *   ?tab=design       the designer, as it opens by default
 *   ?tab=look         the Format tab with the Theme group open
 *   ?tab=actions      More > Popups and downloads, open
 *   ?tab=parameters   the Filters pane (Viewer can change), open
 *   ?tab=settings     More > Report settings, open
 *   ?tab=data         More > Data and advanced settings = the EXISTING tabular
 *                     builder, unchanged, with its own Save, and a way back
 * A report that is not built on a dataset (your own SQL, a published API, a
 * file, a REST API) has no fields for the designer: it opens on the tabular
 * builder, as before.  /edit and /canvas REDIRECT here (App.tsx).
 */
import React, { Suspense, lazy, useEffect, useMemo, useState } from 'react';
import { Box, Button, CircularProgress, Typography } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import api from '../../services/api';
import { STUDIO_TABS, StudioTab, reportEditPath, reportPath } from '../../utils/reportUrls';

const UnifiedReportBuilder = lazy(() => import('../UnifiedReportBuilder'));
const CanvasReportBuilder = lazy(() => import('./canvas/CanvasReportBuilder'));

export const TAB_LABEL: Record<StudioTab, string> = {
  data: 'Data and advanced settings', parameters: 'Filters', design: 'Design', look: 'Theme', actions: 'Popups and downloads', settings: 'Report settings',
};
export const TAB_HELP: Record<StudioTab, string> = {
  data: 'The dataset, the columns, the row limit, calculations, grouping and the chart view -- the full builder.',
  parameters: 'What the report asks for when it runs, and where each list of choices comes from.',
  design: 'The visuals: cards, charts, tables, the finance grid and the header band.',
  look: 'Colours, fonts and number styles -- a theme, or this report\'s own.',
  actions: 'What a click on a value does: a popup with the detail, or a download.',
  settings: 'Code, description and owner group.',
};

/** The kinds the designer can show fields for: a report on a dataset. */
/** Why the designer cannot open this report, in plain words -- or null when it can.
 *  Review P2 (2026-11-07): a PIVOT report (layout_config.report_type 'pivot') and a report that JOINS two
 *  datasets (merge_config) opened in the designer, which draws one dataset's fields on a canvas: a Save there
 *  would have rewritten the pivot as a table and dropped the join. */
export function designerCannotOpenBecause(report: any | null): string | null {
  if (!report) return null;   // not read yet: the designer says so itself
  const dst = String(report.data_source_type || 'saved_query');
  if (!(dst === 'saved_query' || dst === 'dataset')) return 'This report is not built on a dataset, so it is set up here rather than on the designer.';
  if (String(report.layout_config?.report_type || '') === 'pivot') return 'This report is a pivot, so it is set up here rather than on the designer.';
  const mc = report.merge_config;
  // 2026-11-08: a UNION of two datasets (the same data from another source, stacked by column name) is the
  // designer's: one dataset's fields, both sources' rows.  A JOIN (merge keys, inner / left) still is not.
  if (mc && typeof mc === 'object' && Object.keys(mc).length > 0 && String(mc.merge_type || 'inner').toLowerCase() !== 'union') {
    return 'This report joins two datasets, so it is set up here rather than on the designer.';
  }
  return null;
}

export function designerCanOpen(report: any | null): boolean {
  return designerCannotOpenBecause(report) === null;
}

/** Which view a report opens on when the URL names none: the designer, unless it has no dataset. */
export function defaultTab(report: any | null): StudioTab {
  return designerCanOpen(report) ? 'design' : 'data';
}

/** The URL tab, or the report's default; an unknown word is the default. */
export function tabOf(param: string | null, report: any | null): StudioTab {
  const t = String(param || '').toLowerCase() as StudioTab;
  return STUDIO_TABS.includes(t) ? t : defaultTab(report);
}

export default function ReportStudioPage() {
  const { id } = useParams<{ id: string }>();
  const [sp, setSp] = useSearchParams();
  const navigate = useNavigate();
  const [report, setReport] = useState<any | null>(null);
  const [loadErr, setLoadErr] = useState('');
  useEffect(() => {
    let off = false;
    if (!id) return;
    const read = /^\d+$/.test(id) ? api.getBusinessReport(Number(id)) : api.getBusinessReportBySlug(id);
    read.then((r: any) => { if (!off) setReport(r); })
      .catch((e: any) => { if (!off) setLoadErr(String(e?.message || 'The report could not be read.')); });
    return () => { off = true; };
  }, [id]);
  const tab = useMemo(() => tabOf(sp.get('tab'), report), [sp, report]);
  const advanced = tab === 'data' || !designerCanOpen(report);

  // the tabular builder reads its step from the URL: ?tab=data opens its Columns step
  useEffect(() => {
    if (!advanced) return;
    const n = new URLSearchParams(sp);
    if ((n.get('step') || null) !== 'data') { n.set('step', 'data'); setSp(n, { replace: true }); }
  }, [advanced]);   // eslint-disable-line react-hooks/exhaustive-deps

  if (!report && !loadErr) return <Box sx={{ p: 4, textAlign: 'center' }} data-testid="report-studio"><CircularProgress /></Box>;
  return (
    <Box data-testid="report-studio" data-view={advanced ? 'advanced' : 'designer'}>
      {loadErr && <Typography color="error" sx={{ p: 2 }} data-testid="studio-load-error">{loadErr}</Typography>}
      {advanced && report && (
        <Box sx={{ borderBottom: 1, borderColor: 'divider', px: 2, py: 0.5, display: 'flex', alignItems: 'center', gap: 2 }}>
          {designerCanOpen(report) ? (
            <Button size="small" startIcon={<ArrowBackIcon />} onClick={() => navigate(reportEditPath(report, 'design'))} data-testid="studio-back-to-designer">
              Back to the designer
            </Button>
          ) : (
            <Typography variant="caption" color="text.secondary" data-testid="studio-no-designer">
              {designerCannotOpenBecause(report)}
            </Typography>
          )}
          <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto', display: { xs: 'none', md: 'block' } }} data-testid="studio-tab-help">
            {TAB_HELP.data}
          </Typography>
          <Typography variant="caption" sx={{ cursor: 'pointer', color: 'primary.main' }} onClick={() => navigate(reportPath(report))}
            data-testid="studio-open-report">Open the report</Typography>
        </Box>
      )}
      <Suspense fallback={<Box sx={{ p: 4, textAlign: 'center' }}><CircularProgress /></Box>}>
        {report && (advanced ? <UnifiedReportBuilder key="data" /> : <CanvasReportBuilder key="designer" />)}
      </Suspense>
    </Box>
  );
}
