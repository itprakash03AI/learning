/**
 * The kinds of visual: their icons and plain words (2026-11-07, the simple builder).  2026-11-09: the
 * 18-icon grid that sat in the side pane is gone -- a visual is picked in its STEPS (VisualSteps.tsx, the
 * Type step: named groups, the same `canvas-add-<kind>` test ids); these two tables stay the one place
 * for a kind's icon and word.  QueryStudio's own icons, nothing copied.
 */
import React from 'react';
import NumbersIcon from '@mui/icons-material/Numbers';
import TableChartIcon from '@mui/icons-material/TableChart';
import PivotTableChartIcon from '@mui/icons-material/PivotTableChart';
import GridOnIcon from '@mui/icons-material/GridOn';
import BarChartIcon from '@mui/icons-material/BarChart';
import AlignHorizontalLeftIcon from '@mui/icons-material/AlignHorizontalLeft';
import StackedBarChartIcon from '@mui/icons-material/StackedBarChart';
import ShowChartIcon from '@mui/icons-material/ShowChart';
import AreaChartIcon from '@mui/icons-material/AreaChart';
import StackedLineChartIcon from '@mui/icons-material/StackedLineChart';
import AddchartIcon from '@mui/icons-material/Addchart';
import RadarIcon from '@mui/icons-material/Radar';
import PieChartIcon from '@mui/icons-material/PieChart';
import DonutLargeIcon from '@mui/icons-material/DonutLarge';
import ViewQuiltIcon from '@mui/icons-material/ViewQuilt';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import StairsIcon from '@mui/icons-material/Stairs';
import ScatterPlotIcon from '@mui/icons-material/ScatterPlot';
import BubbleChartIcon from '@mui/icons-material/BubbleChart';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import ViewHeadlineIcon from '@mui/icons-material/ViewHeadline';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import TableRowsIcon from '@mui/icons-material/TableRows';
import { KIND_LABEL, TileKind } from '../canvas/canvasModel';


export const KIND_ICON: Record<TileKind, React.ReactElement> = {
  number: <NumbersIcon />, table: <TableChartIcon />, pivot: <PivotTableChartIcon />, heatmap: <GridOnIcon />,
  bar: <BarChartIcon />, hbar: <AlignHorizontalLeftIcon />, stacked_bar: <StackedBarChartIcon />, line: <ShowChartIcon />,
  area: <AreaChartIcon />, stacked_area: <StackedLineChartIcon />, combo: <AddchartIcon />, radar: <RadarIcon />,
  pie: <PieChartIcon />, donut: <DonutLargeIcon />, treemap: <ViewQuiltIcon />, funnel: <FilterAltIcon />,
  waterfall: <StairsIcon />, scatter: <ScatterPlotIcon />, bubble: <BubbleChartIcon />,
  outline: <AccountTreeIcon />, band: <ViewHeadlineIcon />, insight: <LightbulbIcon />, report: <TableRowsIcon />,
};

/** plain words for the grid (KIND_LABEL keeps the longer names used elsewhere) */
export const GRID_LABEL: Record<TileKind, string> = {
  ...KIND_LABEL,
  number: 'Card', bar: 'Column', hbar: 'Bar', stacked_bar: 'Stacked column', line: 'Line', area: 'Area', stacked_area: 'Stacked area',
  combo: 'Columns and lines', pie: 'Pie', pivot: 'Matrix', heatmap: 'Heat map', scatter: 'Scatter', bubble: 'Bubble',
  outline: 'Finance grid', band: 'Header band', insight: 'Insight', report: "The report's table",
};
