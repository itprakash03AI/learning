/**
 * More > Report settings (2026-11-07, the simple builder): the report code
 * (shown top right of the header band), the description and the owner
 * group -- the fields of the old Settings tab that are not the name (the
 * name is in the top bar).  Sharing, the schedule and publishing stay where
 * they are: the report page's More menu, once the report is saved.  The
 * dialog edits the designer's state; the designer's Save writes it.
 */
import React from 'react';
import { Button, MenuItem, Stack, TextField, Typography } from '@mui/material';
import AppDialog from '../../common/AppDialog';
import { MAX_REPORT_CODE } from '../canvas/canvasOutline';

export interface ReportSettingsValues { reportCode: string; description: string; ownerGroupId: number | '' }

export default function ReportSettingsDialog({ open, onClose, values, onChange, groups, canListGroups, saved }: {
  open: boolean; onClose: () => void;
  values: ReportSettingsValues; onChange: (v: ReportSettingsValues) => void;
  groups: { id: number; name: string }[]; canListGroups: boolean;
  /** the report is saved: sharing / schedule / publish live on its page */
  saved: boolean;
}) {
  return (
    <AppDialog open={open} onClose={onClose} size="sm" title="Report settings" testId="report-settings"
      actions={<Button variant="contained" onClick={onClose} data-testid="report-settings-done">Done</Button>}>
      <Stack spacing={2} sx={{ mt: 0.5 }}>
        <TextField size="small" label="Report code" value={values.reportCode} fullWidth
          helperText="Shown top right of the header band, e.g. PLEXPRA-04. Up to 40 characters."
          onChange={e => onChange({ ...values, reportCode: e.target.value.slice(0, MAX_REPORT_CODE) })}
          inputProps={{ 'data-testid': 'canvas-report-code' }} />
        <TextField size="small" label="Description" value={values.description} fullWidth multiline rows={2}
          onChange={e => onChange({ ...values, description: e.target.value })} inputProps={{ 'data-testid': 'report-description' }} />
        <TextField select size="small" label="Owner group (optional)" value={values.ownerGroupId === '' ? '' : String(values.ownerGroupId)} fullWidth
          onChange={e => onChange({ ...values, ownerGroupId: e.target.value === '' ? '' : Number(e.target.value) })}
          inputProps={{ 'data-testid': 'report-owner-group' }}
          helperText={canListGroups ? 'Members of the group may open and edit the report by their access level.'
            : 'Only an admin can list the groups; a saved group is kept as it is.'}>
          <MenuItem value="">None</MenuItem>
          {groups.map(g => <MenuItem key={g.id} value={String(g.id)}>{g.name}</MenuItem>)}
          {!canListGroups && values.ownerGroupId !== '' && !groups.some(g => g.id === values.ownerGroupId) && (
            <MenuItem value={String(values.ownerGroupId)}>Group #{values.ownerGroupId} (saved)</MenuItem>
          )}
        </TextField>
        <Typography variant="caption" color="text.secondary">
          {saved ? 'Sharing, publishing and the schedule are on the report\'s own page, under More.'
            : 'Save the report first; sharing, publishing and the schedule are then on its page, under More.'}
        </Typography>
      </Stack>
    </AppDialog>
  );
}
