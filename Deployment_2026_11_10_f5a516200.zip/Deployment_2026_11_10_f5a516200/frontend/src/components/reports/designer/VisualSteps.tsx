/**
 * Set up a visual step by step (2026-11-09, the owner on UAT: "edit report very confusing ... how to
 * configure existing tile ... some stepper ... what needs to configure", then "both option right or
 * popup ... iframe").  Plan: docs/REPORT_DESIGNER_STEPS_PLAN_2026_11_09.html, section 3.
 *
 *   1 Type                 the kinds as named groups (Cards, Charts, Tables, Finance); a NEW visual
 *                          also sees the visuals this dataset suits (designer/visualSuggest.ts)
 *   2 Fields               the kind's slots (BuildTab) with the dataset's suggestion per slot
 *   3 Look                 title, labels, sort, colours (VisualFormat)
 *   4 Clicks and drill-down  the report's clicks between visuals + drill-down, and popups / downloads
 *
 * ONE component; the designer shows it docked on the right OR in a popup (``mode``).  It edits the
 * canvas live through ``onChange``; Done / Cancel are the designer's (Cancel puts back what was).
 * Nothing here decides a rule: the slots are canvasWells', the problems canvasProblems'.
 */
import React from 'react';
import { Alert, Box, Button, Chip, IconButton, Stack, Step, StepButton, StepLabel, Stepper, Tooltip, Typography } from '@mui/material';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import DockIcon from '@mui/icons-material/ViewSidebarOutlined';
import { CanvasColumn, CanvasTile, TileKind } from '../canvas/canvasModel';
import { OWN_SETTINGS } from '../canvas/canvasEdit';
import { Well } from '../canvas/canvasWells';
import { GRID_LABEL, KIND_ICON } from './VisualsGrid';
import type { SuggestedField, VisualSuggestions } from './visualSuggest';
import { suggestedVisuals } from './visualSuggest';

export type StepsMode = 'dock' | 'popup';
export const STEP_NAMES = ['Type', 'Fields', 'Look', 'Clicks and drill-down'] as const;

/** the kinds in named groups, in the order a person looks for them */
export const KIND_GROUPS: { name: string; kinds: TileKind[] }[] = [
  { name: 'Cards', kinds: ['number'] },
  { name: 'Charts', kinds: ['bar', 'hbar', 'stacked_bar', 'line', 'area', 'stacked_area', 'combo', 'pie', 'donut', 'treemap', 'funnel', 'waterfall', 'scatter', 'bubble', 'radar'] },
  { name: 'Tables', kinds: ['table', 'pivot', 'heatmap'] },
  { name: 'Finance', kinds: ['outline', 'band', 'insight', 'report'] },
];
export const ALL_KINDS: TileKind[] = KIND_GROUPS.flatMap(g => g.kinds);

/** the one-line answer to "what does this need from me?" per kind */
export const KIND_NEEDS: Partial<Record<TileKind, string>> = {
  number: 'One value.', bar: 'A category and one or more values.', hbar: 'A category and one or more values.',
  stacked_bar: 'A category, values, and a legend to stack by.', line: 'A date (or category) along the bottom and one or more values.',
  area: 'A date (or category) and values.', stacked_area: 'A date (or category), values and a legend.',
  combo: 'A category, one value as columns and others as lines.', pie: 'A category and one value.', donut: 'A category and one value.',
  treemap: 'A category and one value.', funnel: 'A category and one value.', waterfall: 'A category and one value -- or 2 to 8 values for a bridge.',
  scatter: 'Each point (a category), and two values for X and Y.', bubble: 'Each point, and three values for X, Y and size.',
  radar: 'A category and values.', table: 'The columns to show; with a value the rows are grouped.',
  pivot: 'Rows, optional columns, and values.', heatmap: 'Rows, columns and one value for the colour.',
  outline: 'The finance grid: its rows and their open / close lines.', band: 'The chosen values to show at the top.',
  insight: 'What to explain.', report: "The report's own table: its columns.",
};

export interface VisualStepsProps {
  /** the visual being set up; null = a NEW one whose type is not picked yet */
  tile: CanvasTile | null;
  isNew: boolean;
  step: number;
  onStep: (n: number) => void;
  mode: StepsMode;
  onMode: (m: StepsMode) => void;
  /** pick (or change) the type; a new visual is made by the designer, pre-filled from the suggestions */
  onPickType: (kind: TileKind) => void;
  /** a suggested visual (Type step, new visual): its kind with its fields */
  onUseSuggested: (v: VisualSuggestions['visuals'][number]) => void;
  hasReportTile: boolean;
  problems: string[];
  suggestions: VisualSuggestions | null;
  suggest: (well: Well) => SuggestedField | null;
  suggested: Set<number>;
  /** the bodies of steps 2-4, from the designer (the same components the old tabs showed) */
  fields: (extra: { suggest: VisualStepsProps['suggest']; suggested: Set<number> }) => React.ReactNode;
  look: React.ReactNode;
  clicks: React.ReactNode;
  onDone: () => void;
  onCancel: () => void;
  onDelete?: () => void;
}

export default function VisualSteps(p: VisualStepsProps) {
  const { tile, step } = p;
  const kindName = tile ? GRID_LABEL[tile.kind] : 'New visual';
  const done = [!!tile, !!tile && p.problems.length === 0, false, false];
  const needs = [!tile, !!tile && p.problems.length > 0, false, false];
  const last = STEP_NAMES.length - 1;
  return (
    <Stack spacing={1} sx={{ minHeight: 0, height: '100%' }} data-testid="visual-steps" data-mode={p.mode} data-step={step}>
      <Stack direction="row" alignItems="center" spacing={1}>
        <Typography variant="subtitle1" sx={{ flex: 1, fontWeight: 600 }} data-testid="visual-steps-title">
          {kindName}: step {step + 1} of {STEP_NAMES.length}
        </Typography>
        <Tooltip title={p.mode === 'popup' ? 'Dock on the right' : 'Show as a popup'}>
          <IconButton size="small" onClick={() => p.onMode(p.mode === 'popup' ? 'dock' : 'popup')} data-testid="visual-steps-mode"
            aria-label={p.mode === 'popup' ? 'Dock on the right' : 'Show as a popup'}>
            {p.mode === 'popup' ? <DockIcon fontSize="small" /> : <OpenInNewIcon fontSize="small" />}
          </IconButton>
        </Tooltip>
      </Stack>
      <Stepper nonLinear activeStep={step} alternativeLabel sx={{ '& .MuiStepLabel-label': { fontSize: 12, mt: 0.5 } }}>
        {STEP_NAMES.map((name, i) => (
          <Step key={name} completed={done[i]} disabled={!tile && i > 0}>
            <StepButton onClick={() => p.onStep(i)} data-testid={`visual-step-${i}`} optional={
              needs[i] ? <Typography variant="caption" color="error" data-testid={`visual-step-${i}-needs`}>{i === 0 ? 'pick one' : 'needs a field'}</Typography>
                : i >= 2 ? <Typography variant="caption" color="text.secondary">optional</Typography> : undefined}>
              <StepLabel error={needs[i] && i === 1}>{name}</StepLabel>
            </StepButton>
          </Step>
        ))}
      </Stepper>

      <Box sx={{ flex: 1, minHeight: 0, overflow: 'auto', pr: 0.5 }} data-testid={`visual-step-body-${step}`}>
        {step === 0 && <TypeStep {...p} />}
        {step === 1 && tile && (
          <Stack spacing={1}>
            {KIND_NEEDS[tile.kind] && <Typography variant="body2" color="text.secondary" data-testid="visual-needs">{KIND_NEEDS[tile.kind]}</Typography>}
            {p.problems.map((m, i) => <Alert key={i} severity="warning" sx={{ py: 0 }} data-testid="visual-steps-problem">{m}</Alert>)}
            {p.suggestions && !p.suggestions.enabled && p.suggestions.words && (
              <Typography variant="caption" color="text.secondary" data-testid="visual-suggest-off">{p.suggestions.words}</Typography>
            )}
            {p.fields({ suggest: p.suggest, suggested: p.suggested })}
          </Stack>
        )}
        {step === 2 && tile && p.look}
        {step === 3 && tile && p.clicks}
      </Box>

      <Stack direction="row" spacing={1} alignItems="center" sx={{ pt: 0.5, borderTop: 1, borderColor: 'divider' }}>
        {p.onDelete && tile && !p.isNew && (
          <Button color="error" size="small" onClick={p.onDelete} data-testid="visual-steps-delete">Delete</Button>
        )}
        <Box sx={{ flex: 1 }} />
        <Button size="small" onClick={p.onCancel} data-testid="visual-steps-cancel">Cancel</Button>
        <Button size="small" disabled={step === 0} onClick={() => p.onStep(step - 1)} data-testid="visual-steps-back">Back</Button>
        {step < last && <Button size="small" variant="outlined" disabled={!tile} onClick={() => p.onStep(step + 1)} data-testid="visual-steps-next">Next</Button>}
        <Button size="small" variant="contained" disabled={!tile} onClick={p.onDone} data-testid="visual-steps-done">Done</Button>
      </Stack>
    </Stack>
  );
}

function TypeStep(p: VisualStepsProps) {
  const { tile } = p;
  const switching = !!tile && !p.isNew;
  const offered = p.isNew || !tile ? suggestedVisuals(p.suggestions, ALL_KINDS) : [];
  return (
    <Stack spacing={1.5}>
      {offered.length > 0 && (
        <Box data-testid="visual-suggested">
          <Typography variant="caption" sx={{ fontWeight: 600 }}>Suggested for this data</Typography>
          <Stack direction="row" spacing={0.5} useFlexGap flexWrap="wrap" sx={{ mt: 0.5 }}>
            {offered.map((v, i) => (
              <Chip key={`${v.kind}-${i}`} icon={KIND_ICON[v.kind as TileKind]} label={`${GRID_LABEL[v.kind as TileKind]}: ${v.why}`}
                onClick={() => p.onUseSuggested(v)} variant="outlined" color="primary" data-testid={`visual-suggested-${v.kind}`} />
            ))}
          </Stack>
        </Box>
      )}
      {switching && (
        <Typography variant="caption" color="text.secondary">
          Changing the type keeps the fields that fit. The finance pieces keep their own settings, so they cannot be switched to or from.
        </Typography>
      )}
      {KIND_GROUPS.map(g => (
        <Box key={g.name}>
          <Typography variant="caption" sx={{ fontWeight: 600 }}>{g.name}</Typography>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(118px, 1fr))', gap: 0.5, mt: 0.5 }}>
            {g.kinds.map(k => {
              const own = OWN_SETTINGS.includes(k);
              const locked = switching && (own || OWN_SETTINGS.includes(tile!.kind)) && k !== tile!.kind;
              const taken = k === 'report' && p.hasReportTile && tile?.kind !== 'report';
              const on = tile?.kind === k;
              const why = taken ? "The report's table is already on the page" : locked ? 'Keeps its own settings: add it as a new visual' : KIND_NEEDS[k] ?? '';
              return (
                <Tooltip key={k} title={why}>
                  <span>
                    <Button fullWidth size="small" variant={on ? 'contained' : 'outlined'} disabled={locked || taken}
                      startIcon={KIND_ICON[k]} onClick={() => p.onPickType(k)}
                      data-testid={`canvas-add-${k}`} data-kind={k} data-selected={on ? 'yes' : undefined}
                      sx={{ justifyContent: 'flex-start', textTransform: 'none' }}>
                      {GRID_LABEL[k]}
                    </Button>
                  </span>
                </Tooltip>
              );
            })}
          </Box>
        </Box>
      ))}
    </Stack>
  );
}
