/**
 * Visuals that draw themselves (2026-11-07, the simple builder, plan section 5).
 * The pure rules the designer applies; the designer owns the effect.
 *
 *   A report exists from the moment data is picked: the first field added
 *   saves a DRAFT (a report nobody but its author sees -- is_published is
 *   false, no version is written until Publish) through the create route.
 *   Run only when needed: a field the last run already holds draws from that
 *   run through the cube; a NEW field (or a new value for a parameter) starts
 *   one debounced run with override_column_ids, as Preview did.  One run at a
 *   time: a newer one supersedes the older (its answer is dropped).
 *   Tell the truth while it reads; never a made-up number.
 *   A required parameter with no value is asked for in Filters, not run.
 *   "Refresh by itself" is on by default and remembered per report.
 */

/** the debounce before a run; a test shortens it */
export const RUN_SETTINGS = { debounceMs: 600 };

export interface LastRun { fields: number[]; valuesKey: string }

/** The one key of a set of parameter values (order-free, empty values dropped). */
export function valuesKey(values: Record<string, any> | null | undefined): string {
  const entries = Object.entries(values || {}).filter(([, v]) => !(v === '' || v == null || (Array.isArray(v) && v.length === 0)));
  entries.sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  return JSON.stringify(entries);
}

/** A fixed filter row as the run and the key see it (the fields that narrow). */
const filterShape = (f: any) => [Number(f.column_id), f.operator || 'eq', f.value ?? null, f.value2 ?? null];
/** The one key of a set of fixed filter rows (order kept: the rows are a list). */
export function filtersKey(rows: any[] | null | undefined): string {
  return JSON.stringify((rows || []).map(filterShape));
}
/** The key of a run: its parameter values, and the unsaved fixed filters it applied (none -> the values' key alone). */
export function runKey(values: Record<string, any> | null | undefined, extraFilters: any[] | null | undefined): string {
  const v = valuesKey(values);
  return extraFilters && extraFilters.length ? `${v}|${filtersKey(extraFilters)}` : v;
}

/** The fixed filter rows the designer holds that the SAVED report does not (added or changed since the last
 *  save), filled and not asked of the viewer: the run applies them as EXTRA, narrow-only filters, so the
 *  numbers on the canvas are the report's after Save (review P2 2026-11-07: a run ignored them and drew the
 *  unfiltered numbers).  `normalise` is the save's own shaping of a row (lists split), so a row compares by
 *  value with the stored one; a stored row the designer removed is still applied by the server (its save
 *  shape) -- a run can only narrow, never widen. */
export function unsavedFixedFilters(rows: any[] | null | undefined, stored: any[] | null | undefined,
                                    opts: { filled: (f: any) => boolean; normalise: (f: any) => any }): any[] {
  const key = (f: any) => JSON.stringify(filterShape(opts.normalise(f)));
  const have = new Set((stored || []).map(key));
  return (rows || []).filter(f => !f.ask_at_run && opts.filled(f) && !have.has(key(f))).map(f => opts.normalise(f));
}

/** The column choice a run sends: NONE when the canvas's columns are exactly the saved report's (as a set), so the
 *  run is the report's own and may be served from its stored copy; the union otherwise (review P2 2026-11-07:
 *  every designer run sent the override and bypassed the stored copy). */
export function overrideColumnsFor(unionIds: number[], savedColumnIds: (number | string)[] | null | undefined): number[] | undefined {
  const saved = new Set((savedColumnIds || []).map(Number));
  const same = unionIds.length === saved.size && unionIds.every(id => saved.has(id));
  return same ? undefined : unionIds;
}

/** Does the canvas need a NEW run?  Only when it uses a field the last run lacks, or the values changed, or the
 *  unsaved fixed filters changed (`extraFilters`, part of the run's key). */
export function needsRun(unionIds: number[], values: Record<string, any>, last: LastRun | null, extraFilters: any[] = []): boolean {
  if (unionIds.length === 0) return false;
  if (!last) return true;
  const have = new Set(last.fields);
  if (unionIds.some(id => !have.has(id))) return true;
  return runKey(values, extraFilters) !== last.valuesKey;
}

/** The required parameters that have neither a value nor a default: the run waits for them. */
export function missingRequired(params: { name: string; label?: string; is_required?: boolean; default_value?: any; default_rule?: string | null; effective_default?: any }[],
                                values: Record<string, any>): string[] {
  const blank = (v: any) => v === '' || v == null || (Array.isArray(v) && v.length === 0);
  return params
    .filter(p => p.is_required && blank(values[p.name]) && blank(p.default_value) && blank(p.effective_default) && !p.default_rule)
    .map(p => p.label || p.name);
}

/** The words a visual shows while there is no run to draw from. */
export function notRunWords(state: { auto: boolean; reading: boolean; missing: string[]; hasReport: boolean; error?: string }): string {
  if (state.error) return state.error;
  if (state.missing.length) return `Pick a value for ${state.missing.join(', ')} in Filters first.`;
  if (!state.hasReport) return 'Add a field to see the data.';
  if (state.reading) return 'Reading the data…';
  if (!state.auto) return 'Press Refresh to see this.';
  return 'Reading the data…';
}

/** A draft's name: a person renames it in the top bar; Save keeps the real one.  The time is in it
 *  because a report's name is unique per owner (the rig: a second draft of the day was a 409). */
export function draftName(now = new Date()): string {
  const p = (n: number) => String(n).padStart(2, '0');
  return `New report ${now.getFullYear()}-${p(now.getMonth() + 1)}-${p(now.getDate())} ${p(now.getHours())}:${p(now.getMinutes())}:${p(now.getSeconds())}`;
}
export const isDraftName = (name: string) => /^New report \d{4}-\d{2}-\d{2}( \d{2}:\d{2}:\d{2})?$/.test(String(name || '').trim());

const KEY = (reportId: number | string) => `qs.designer.autoRefresh.${reportId}`;
/** "Refresh by itself", remembered per report in this browser (on when nothing is remembered). */
export function readAutoRefresh(reportId: number | string | null): boolean {
  if (reportId == null) return true;
  try { return localStorage.getItem(KEY(reportId)) !== 'off'; } catch { return true; }
}
export function writeAutoRefresh(reportId: number | string | null, on: boolean): void {
  if (reportId == null) return;
  try { if (on) localStorage.removeItem(KEY(reportId)); else localStorage.setItem(KEY(reportId), 'off'); } catch { /* a private window: not remembered */ }
}
