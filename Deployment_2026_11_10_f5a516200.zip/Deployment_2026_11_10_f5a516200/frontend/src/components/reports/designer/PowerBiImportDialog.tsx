/**
 * Import from Power BI (2026-11-07, the report framework's stage 8): a .pbix, .pbit or
 * zipped .pbip project becomes a canvas report on a dataset the person picks.
 *
 *   1. pick the file and the data (the report's numbers come from the dataset, never from the file);
 *   2. Preview: every page and visual and what it becomes, every field and the column it matched,
 *      the measures (a .pbix carries none: pick a column and how to add it up), the filters, and
 *      what is not brought across -- nothing is saved by a preview;
 *   3. fix an unmatched field from the list of columns, leave a visual or a page out;
 *   4. Create report: saved through the same road the designer's own Save takes.
 *
 * A filter that narrows the rows on a field with no match REFUSES the import until it is matched
 * or its visual / page is left out (the server's rule: dropping it would show more rows).
 * The server does every reading (backend/core/reports/powerbi_import.py); this dialog only shows
 * it and collects the person's choices.  Drawn through the one frame, AppDialog.
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, Chip, CircularProgress, Divider, FormControlLabel, MenuItem, Stack, TextField, Typography,
} from '@mui/material';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import AppDialog from '../../common/AppDialog';
import api from '../../../services/api';
import type { PowerBiCreated, PowerBiField, PowerBiImportOptions, PowerBiPreview } from '../../../services/api/powerbiImport';
import { AGG_LABEL, AGGREGATIONS, Aggregation } from '../canvas/canvasModel';
import { getUserFriendlyError } from '../../../utils/errorMessages';

export const ACCEPTED = '.pbix,.pbit,.pbip,.zip';

const BECOMES_WORDS: Record<string, string> = {
  number: 'a number', table: 'a table', pivot: 'a pivot', outline: 'an outline (rows with totals)', bar: 'a column chart',
  hbar: 'a bar chart (sideways)', stacked_bar: 'stacked bars', line: 'a line chart', area: 'an area chart',
  stacked_area: 'stacked areas', combo: 'columns and lines', pie: 'a pie', donut: 'a donut', treemap: 'a treemap',
  funnel: 'a funnel', waterfall: 'a waterfall', scatter: 'a scatter', bubble: 'a bubble chart', parameter: 'a choice for the viewer',
};

function FieldRow({ f, columns, pick, onPick }: {
  f: PowerBiField; columns: PowerBiPreview['columns']; pick: number | undefined; onPick: (ref: string, cid: number | '') => void;
}) {
  const needsPick = f.status === 'unmatched' && f.kind !== 'measure';
  return (
    <Stack direction="row" spacing={1} alignItems="center" sx={{ pl: 2, py: 0.25 }} data-testid={`pbi-field-${f.ref}`}>
      <Typography variant="body2" sx={{ minWidth: 220 }} noWrap title={f.ref}>{f.ref}</Typography>
      <Typography variant="caption" color="text.secondary" sx={{ minWidth: 70 }}>{f.role}</Typography>
      {f.status === 'column' && <Chip size="small" color="success" variant="outlined" label={`${f.label}${f.how === 'author' ? ' (your pick)' : ''}`} />}
      {f.status === 'measure' && <Chip size="small" color="success" variant="outlined" label={`${AGG_LABEL[f.aggregation as Aggregation] ?? f.aggregation} of ${f.label}${f.how === 'author' ? ' (your pick)' : f.how === 'dax' ? ' (from its DAX)' : ''}`} />}
      {f.status === 'listed' && <Typography variant="caption" color="text.secondary">{f.words}</Typography>}
      {f.status === 'unmatched' && f.kind === 'measure' && <Typography variant="caption" color="warning.main">{f.words} (see Measures below)</Typography>}
      {needsPick && (
        <TextField select size="small" label="Column" value={pick == null ? '' : String(pick)} sx={{ minWidth: 220 }}
          onChange={e => onPick(f.ref, e.target.value === '' ? '' : Number(e.target.value))}
          inputProps={{ 'data-testid': `pbi-pick-${f.ref}` }} helperText={f.words}>
          <MenuItem value="">Not matched</MenuItem>
          {columns.map(c => <MenuItem key={c.id} value={String(c.id)}>{c.label}</MenuItem>)}
        </TextField>
      )}
    </Stack>
  );
}

export default function PowerBiImportDialog({ open, onClose, onCreated, initialDatasetId, datasets: given }: {
  open: boolean; onClose: () => void;
  /** the report is saved: the caller opens it in the designer */
  onCreated: (made: PowerBiCreated) => void;
  initialDatasetId?: number | null;
  /** the datasets, when the caller already has them (else they are read here) */
  datasets?: { id: number; name: string }[];
}) {
  const [file, setFile] = useState<File | null>(null);
  const [datasets, setDatasets] = useState<{ id: number; name: string }[]>(given || []);
  const [datasetId, setDatasetId] = useState<number | ''>(initialDatasetId ?? '');
  const [name, setName] = useState('');
  const [fieldMap, setFieldMap] = useState<Record<string, number>>({});
  const [measureMap, setMeasureMap] = useState<Record<string, { column_id: number | ''; aggregation: string }>>({});
  const [excludeVisuals, setExcludeVisuals] = useState<string[]>([]);
  const [excludePages, setExcludePages] = useState<string[]>([]);
  const [preview, setPreview] = useState<PowerBiPreview | null>(null);
  const [stale, setStale] = useState(false);
  const [busy, setBusy] = useState<'' | 'preview' | 'create'>('');
  const [error, setError] = useState('');
  const fileRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!open) return;
    if (given) { setDatasets(given); return; }
    api.listDatasets().then((ds: any) => {
      const list = Array.isArray(ds) ? ds : (ds?.items || ds?.datasets || []);
      setDatasets(list.map((d: any) => ({ id: d.id, name: d.name })));
    }).catch((e: any) => setError(`The datasets could not be read (${getUserFriendlyError(e)}).`));
  }, [open, given]);

  const options = useMemo((): PowerBiImportOptions => {
    const mm: Record<string, { column_id: number; aggregation: string }> = {};
    for (const [k, v] of Object.entries(measureMap)) if (v.column_id !== '' && v.aggregation) mm[k] = { column_id: v.column_id, aggregation: v.aggregation };
    return { field_map: fieldMap, measure_map: mm, exclude_visuals: excludeVisuals, exclude_pages: excludePages, ...(name.trim() ? { name: name.trim() } : {}) };
  }, [fieldMap, measureMap, excludeVisuals, excludePages, name]);

  const reset = () => {
    setFile(null); setPreview(null); setFieldMap({}); setMeasureMap({}); setExcludeVisuals([]); setExcludePages([]);
    setName(''); setError(''); setStale(false); setBusy('');
  };
  const close = () => { reset(); onClose(); };

  const runPreview = async () => {
    if (!file || datasetId === '') return;
    setBusy('preview'); setError('');
    try {
      const out = await api.powerbiImportPreview(file, Number(datasetId), options);
      setPreview(out); setStale(false);
      if (!name) setName(out.report_name);
    } catch (e: any) {
      setError(getUserFriendlyError(e, 'The file could not be read.'));
    } finally { setBusy(''); }
  };
  const create = async () => {
    if (!file || datasetId === '' || !preview || stale) return;
    setBusy('create'); setError('');
    try {
      const made = await api.powerbiImportCreate(file, Number(datasetId), options);
      onCreated(made);
      reset();
    } catch (e: any) {
      setError(getUserFriendlyError(e, 'The report could not be created.'));
    } finally { setBusy(''); }
  };
  const touch = () => { if (preview) setStale(true); };
  const pickField = (ref: string, cid: number | '') => {
    setFieldMap(m => { const n = { ...m }; if (cid === '') delete n[ref]; else n[ref] = cid; return n; });
    touch();
  };
  const pickMeasure = (ref: string, patch: Partial<{ column_id: number | ''; aggregation: string }>) => {
    setMeasureMap(m => ({ ...m, [ref]: { column_id: '', aggregation: 'sum', ...(m[ref] || {}), ...patch } }));
    touch();
  };
  const toggle = (list: string[], set: (v: string[]) => void, key: string) => {
    set(list.includes(key) ? list.filter(x => x !== key) : [...list, key]);
    touch();
  };

  const canPreview = !!file && datasetId !== '' && !busy;
  const canCreate = !!preview && preview.can_create && !stale && !busy && !!file && datasetId !== '';
  const pendingMeasures = preview ? preview.measures.filter(m => m.status !== 'translated' && m.status !== 'author') : [];

  return (
    <AppDialog open={open} onClose={close} size="lg" title="Import from Power BI" icon={<UploadFileIcon />} testId="pbi-import"
      closeOnBackdrop={false}
      subtitle="The design comes from the file; the numbers come from the dataset you pick. Nothing is saved until you press Create report."
      secondaryActions={preview && (
        <Button onClick={runPreview} disabled={!canPreview} data-testid="pbi-recheck">{busy === 'preview' ? 'Checking…' : 'Check again'}</Button>
      )}
      actions={<>
        <Button onClick={close} data-testid="pbi-cancel">Cancel</Button>
        {!preview && <Button variant="contained" onClick={runPreview} disabled={!canPreview} data-testid="pbi-preview"
          startIcon={busy === 'preview' ? <CircularProgress size={14} /> : undefined}>{busy === 'preview' ? 'Reading…' : 'Preview'}</Button>}
        {preview && <Button variant="contained" onClick={create} disabled={!canCreate} data-testid="pbi-create"
          startIcon={busy === 'create' ? <CircularProgress size={14} /> : undefined}>{busy === 'create' ? 'Creating…' : 'Create report'}</Button>}
      </>}>
      <Stack spacing={2}>
        <Stack direction="row" spacing={2} alignItems="flex-start" flexWrap="wrap" useFlexGap>
          <Box>
            <input ref={fileRef} type="file" accept={ACCEPTED} hidden data-testid="pbi-file"
              onChange={e => { const f = e.target.files?.[0] || null; setFile(f); setPreview(null); setStale(false); setError(''); }} />
            <Button variant="outlined" onClick={() => fileRef.current?.click()} startIcon={<UploadFileIcon />} data-testid="pbi-choose">
              {file ? file.name : 'Choose a .pbix, .pbit or zipped .pbip'}
            </Button>
            <Typography variant="caption" color="text.secondary" display="block" sx={{ mt: 0.5 }}>
              A Power BI report file. Its data is not read; only its pages, visuals, fields, filters and colours.
            </Typography>
          </Box>
          <TextField select size="small" label="Data" value={datasetId === '' ? '' : String(datasetId)} sx={{ minWidth: 260 }}
            onChange={e => { setDatasetId(e.target.value === '' ? '' : Number(e.target.value)); setPreview(null); setFieldMap({}); setMeasureMap({}); }}
            inputProps={{ 'data-testid': 'pbi-dataset' }} helperText="The dataset the report runs on; its columns are matched to the file's fields by name.">
            <MenuItem value="">Pick a dataset</MenuItem>
            {datasets.map(d => <MenuItem key={d.id} value={String(d.id)}>{d.name}</MenuItem>)}
          </TextField>
          {preview && (
            <TextField size="small" label="Report name" value={name} sx={{ minWidth: 260 }}
              onChange={e => { setName(e.target.value); touch(); }} inputProps={{ 'data-testid': 'pbi-name' }} />
          )}
        </Stack>
        {error && <Alert severity="error" data-testid="pbi-error" onClose={() => setError('')}>{error}</Alert>}
        {preview && (
          <>
            <Alert severity={preview.can_create ? 'success' : 'warning'} data-testid="pbi-summary">
              {preview.format === 'legacy' ? 'An older Power BI file (Report/Layout).' : 'A current Power BI file (PBIR).'}{' '}
              {preview.pages.filter(p => p.included).length} of {preview.pages.length} page{preview.pages.length === 1 ? '' : 's'} come across as {preview.tiles} tile{preview.tiles === 1 ? '' : 's'}
              {preview.parameters.length ? ` and ${preview.parameters.length} choice${preview.parameters.length === 1 ? '' : 's'} for the viewer (${preview.parameters.map(p => p.label).join(', ')})` : ''}.{' '}
              {preview.theme_words}
              {preview.model_in_file ? ' The file carries its model as text, so simple measures were read from their DAX.' : ' A .pbix carries no measure definitions: pick a column and how to add it up for each measure below.'}
              {stale && <strong> You changed something: press Check again before Create.</strong>}
            </Alert>
            {preview.refusals.length > 0 && (
              <Alert severity="error" data-testid="pbi-refusals">
                <Typography variant="subtitle2">The report cannot be created yet</Typography>
                <ul style={{ margin: '4px 0 0', paddingLeft: 18 }}>
                  {preview.refusals.map((r, i) => <li key={i}><strong>{r.where}:</strong> {r.why}</li>)}
                </ul>
              </Alert>
            )}
            {pendingMeasures.length > 0 && (
              <Box data-testid="pbi-measures">
                <Typography variant="subtitle2">Measures</Typography>
                <Typography variant="caption" color="text.secondary">
                  A measure is a formula in Power BI. A simple one (a sum, average, min, max or count of one column) is read from its text when the file has it; anything else is listed with its formula for you to rebuild as a calculated metric. Pick what each one means here.
                </Typography>
                {pendingMeasures.map(m => (
                  <Stack key={m.ref} direction="row" spacing={1} alignItems="center" sx={{ py: 0.5 }} flexWrap="wrap" useFlexGap data-testid={`pbi-measure-${m.ref}`}>
                    <Typography variant="body2" sx={{ minWidth: 220 }} title={m.dax || ''}>{m.ref}</Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ minWidth: 200, fontFamily: m.dax ? 'monospace' : undefined }} noWrap title={m.dax || m.words}>
                      {m.dax ? m.dax : m.status === 'not_in_file' ? 'definition not in this file' : m.words}
                    </Typography>
                    <TextField select size="small" label="Column" value={measureMap[m.ref]?.column_id == null || measureMap[m.ref]?.column_id === '' ? '' : String(measureMap[m.ref]!.column_id)} sx={{ minWidth: 200 }}
                      onChange={e => pickMeasure(m.ref, { column_id: e.target.value === '' ? '' : Number(e.target.value) })} inputProps={{ 'data-testid': `pbi-measure-col-${m.ref}` }}>
                      <MenuItem value="">Leave it out</MenuItem>
                      {preview.columns.map(c => <MenuItem key={c.id} value={String(c.id)}>{c.label}</MenuItem>)}
                    </TextField>
                    <TextField select size="small" label="Add up as" value={measureMap[m.ref]?.aggregation ?? 'sum'} sx={{ minWidth: 180 }}
                      onChange={e => pickMeasure(m.ref, { aggregation: e.target.value })} inputProps={{ 'data-testid': `pbi-measure-agg-${m.ref}` }}>
                      {AGGREGATIONS.map(a => <MenuItem key={a} value={a}>{AGG_LABEL[a]}</MenuItem>)}
                    </TextField>
                  </Stack>
                ))}
              </Box>
            )}
            <Divider />
            {preview.pages.map(pg => (
              <Box key={pg.name} data-testid={`pbi-page-${pg.name}`}>
                <Stack direction="row" spacing={1} alignItems="center">
                  <Typography variant="subtitle2">Page: {pg.title}</Typography>
                  <Typography variant="caption" color="text.secondary">{Math.round(pg.width)} x {Math.round(pg.height)}{pg.words ? ` -- ${pg.words}` : ''}</Typography>
                  {pg.words.indexOf('tooltip page') < 0 && (
                    <FormControlLabel sx={{ ml: 'auto' }} label={<Typography variant="caption">Leave this page out</Typography>}
                      control={<Checkbox size="small" checked={excludePages.includes(pg.name)} onChange={() => toggle(excludePages, setExcludePages, pg.name)}
                        inputProps={{ 'data-testid': `pbi-exclude-page-${pg.name}` } as any} />} />
                  )}
                </Stack>
                {pg.included && pg.visuals.map(v => (
                  <Box key={v.name} sx={{ borderLeft: '2px solid', borderColor: v.excluded ? 'text.disabled' : v.becomes ? 'success.light' : 'divider', pl: 1, my: 0.75 }} data-testid={`pbi-visual-${v.name}`}>
                    <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
                      <Typography variant="body2" fontWeight={600}>{v.title || v.visual_type}</Typography>
                      <Typography variant="caption" color="text.secondary">{v.visual_type}</Typography>
                      <Chip size="small" variant={v.becomes ? 'filled' : 'outlined'} color={v.excluded ? 'default' : v.becomes ? 'primary' : 'default'}
                        label={v.excluded ? 'left out' : v.becomes ? `becomes ${BECOMES_WORDS[v.becomes] ?? v.becomes}` : (v.words || 'not brought across')} data-testid={`pbi-becomes-${v.name}`} />
                      {v.becomes && v.words && <Typography variant="caption" color="text.secondary">{v.words}</Typography>}
                      {(v.fields.length > 0 || v.becomes) && (
                        <FormControlLabel sx={{ ml: 'auto' }} label={<Typography variant="caption">Leave out</Typography>}
                          control={<Checkbox size="small" checked={excludeVisuals.includes(v.name)} onChange={() => toggle(excludeVisuals, setExcludeVisuals, v.name)}
                            inputProps={{ 'data-testid': `pbi-exclude-${v.name}` } as any} />} />
                      )}
                    </Stack>
                    {!v.excluded && v.fields.map((f, i) => <FieldRow key={`${f.ref}-${f.role}-${i}`} f={f} columns={preview.columns} pick={fieldMap[f.ref]} onPick={pickField} />)}
                    {!v.excluded && v.listed.map((w, i) => <Typography key={i} variant="caption" color="text.secondary" display="block" sx={{ pl: 2 }}>{w}</Typography>)}
                  </Box>
                ))}
              </Box>
            ))}
            {preview.filters.length > 0 && (
              <Box data-testid="pbi-filters">
                <Typography variant="subtitle2">Filters</Typography>
                {preview.filters.map((f, i) => (
                  <Typography key={i} variant="body2" color={f.status === 'refused' ? 'error' : 'text.primary'} sx={{ pl: 1 }}>
                    {f.where}: {f.words}
                  </Typography>
                ))}
              </Box>
            )}
            {preview.not_brought_across.length > 0 && (
              <Box data-testid="pbi-listed">
                <Typography variant="subtitle2">Not brought across</Typography>
                <ul style={{ margin: '4px 0 0', paddingLeft: 18 }}>
                  {preview.not_brought_across.map((x, i) => <li key={i}><Typography variant="body2" component="span">{x.what}: {x.why}</Typography></li>)}
                </ul>
              </Box>
            )}
            {preview.relationships.length > 0 && (
              <Typography variant="caption" color="text.secondary" data-testid="pbi-relationships">
                The file's model joins its tables ({preview.relationships.join('; ')}); the dataset already defines the source and its joins, so these are listed, not applied.
              </Typography>
            )}
          </>
        )}
      </Stack>
    </AppDialog>
  );
}
