/**
 * The Filters pane (2026-11-07, the simple builder, plan section 3): the
 * report's filters in THREE groups by who controls them, over the state the
 * designer already keeps --
 *
 *   Viewer can change   the report's PARAMETERS: a card each, with Settings
 *                       (the one ReportParameterEditor, every row) and Remove;
 *                       a field dropped here becomes a parameter (askedParameter)
 *   In the query        the conditions of the dataset's own WHERE, each with
 *                       the tick "Ask when the report runs" (sourceParameter)
 *   Fixed               filter_specs rows: column, operator, value, remove;
 *                       an unfilled row REFUSES the save (never dropped);
 *                       "Ask the viewer instead" turns a row into a parameter
 *
 * The rules are reportFilters.ts's (the wizard's): nothing about what a row
 * means is decided here.  A report whose source cannot apply saved filters
 * or column parameters (a file, a REST API) is told so in words and offered
 * none (the framework refuses them on save and on run).
 */
import React, { useMemo, useState } from 'react';
import {
  Box, Button, Checkbox, FormControl, FormControlLabel, IconButton, InputLabel, Menu, MenuItem, Paper, Select, Stack, Tooltip, Typography, Alert,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import { CanvasColumn } from '../canvas/canvasModel';
import { FIELD_MIME } from '../canvas/ReportCanvasView';
import ReportFilterValueInput, { changeFilterField } from '../ReportFilterValueInput';
import {
  ASKABLE_OPERATORS, FILTER_OPERATORS, FilterRow, SourceFilter, isUnfilledFilter, sourceFilterWords, sourceParameter,
} from '../../../utils/reportFilters';

export interface ParamLike { id?: number; name: string; label?: string; parameter_type?: string; source_column?: string | null; lov_column_id?: number | null; [k: string]: any }

/** The words under a parameter's name. */
export function paramWords(p: ParamLike): string {
  const kind: Record<string, string> = {
    dropdown: 'one value', multi_select: 'one or several values', date: 'a date', date_range: 'a date range', text: 'text', numeric: 'a number',
    period: 'a period', cob_compare: 'two dates to compare', number_range: 'a range of numbers', boolean: 'yes or no', hierarchy: 'a level of a hierarchy',
  };
  const what = kind[String(p.parameter_type || '')] || String(p.parameter_type || 'a value');
  if (p.source_column) return `${what} -- as in the query when empty, filters at the source`;
  if (p.lov_column_id != null) return `${what} -- all values when empty, filters the results`;
  return what;
}

/** The wizard's column shape, for the value input and the parameter editor. */
export const toAuthoringColumn = (c: CanvasColumn) => ({ id: c.id, friendly_name: c.label, physical_name: c.physical_name, data_type: c.data_type, column_type: c.column_type });

export default function FiltersPane({ cols, columns, datasetId, canApply, params, onParamsChange, onAskField, onAskPick, onOpenSettings, valueControl,
  sourceFilters, filters, onFiltersChange }: {
  cols: Map<number, CanvasColumn>; columns: CanvasColumn[]; datasetId: number | null;
  /** false for a source that cannot apply saved filters or column parameters (a file, a REST API) */
  canApply: boolean;
  params: ParamLike[]; onParamsChange: (next: ParamLike[]) => void;
  /** a field dropped on "Viewer can change" / "Ask the viewer instead" -> a parameter on it; FALSE when it was
   *  not added (already asked), so the caller keeps what it has (review P3: the fixed row was removed anyway) */
  onAskField: (col: CanvasColumn) => boolean;
  /** the "+ Ask for a value" dialog */
  onAskPick: () => void;
  onOpenSettings: () => void;
  /** the value the DESIGNER runs with, per saved parameter (the viewer picks their own) */
  valueControl?: (p: ParamLike) => React.ReactNode;
  sourceFilters: SourceFilter[];
  filters: FilterRow[]; onFiltersChange: (f: (rows: FilterRow[]) => FilterRow[]) => void;
}) {
  const [menuFor, setMenuFor] = useState<{ el: HTMLElement; name: string } | null>(null);
  const authoringCols = useMemo(() => columns.filter(c => !c.hidden).map(toAuthoringColumn), [columns]);
  const dropProps = {
    onDragOver: (e: React.DragEvent) => { if (e.dataTransfer.types.includes(FIELD_MIME)) e.preventDefault(); },
    onDrop: (e: React.DragEvent) => { const c = cols.get(Number(e.dataTransfer.getData(FIELD_MIME))); if (c) { e.preventDefault(); onAskField(c); } },
  };
  const removeParam = (name: string) => onParamsChange(params.filter(p => p.name !== name));
  const tickSource = (sf: SourceFilter, on: boolean) => {
    if (on) {
      if (params.some(p => p.source_column === sf.key)) return;
      const p = sourceParameter(sf);
      onParamsChange([...params, { ...p, name: params.some(x => x.name === p.name) ? `${p.name}_source` : p.name }]);
    } else {
      onParamsChange(params.filter(p => p.source_column !== sf.key));
    }
  };
  const unfilled = filters.map((f, i) => [f, i] as const).filter(([f]) => isUnfilledFilter(f));

  if (!canApply) {
    return (
      <Alert severity="info" data-testid="filters-cannot-apply" sx={{ m: 0.5 }}>
        This report&apos;s source cannot apply saved filters or parameters bound to a column: it would ignore them and show more
        rows than it should. Filter in the source itself, or set up the report under More &gt; Data and advanced settings.
      </Alert>
    );
  }

  return (
    <Stack spacing={1} sx={{ p: 0.5, overflow: 'auto', minHeight: 0 }} data-testid="canvas-param-bar">
      {/* ── Viewer can change ── */}
      <Paper variant="outlined" sx={{ p: 0.75 }} data-testid="filters-viewer" {...dropProps}>
        <Stack direction="row" alignItems="center" sx={{ mb: 0.5 }}>
          <Typography variant="caption" sx={{ fontWeight: 600, flex: 1 }}>Viewer can change</Typography>
          <Tooltip title="Ask for a value when the report runs">
            <IconButton size="small" onClick={onAskPick} aria-label="Ask for a value when the report runs" data-testid="canvas-ask"><AddIcon fontSize="small" /></IconButton>
          </Tooltip>
        </Stack>
        {params.length === 0 && <Typography variant="caption" color="text.secondary">Nothing yet. Drag a field here, or press +.</Typography>}
        {params.map(p => (
          <Box key={p.name} data-testid={`canvas-param-${p.name}`} sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5, py: 0.25, borderTop: '1px solid', borderColor: 'divider' }}>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography variant="body2" noWrap title={p.label || p.name}>{p.label || p.name}{p.id ? '' : ' (new)'}</Typography>
              <Typography variant="caption" color="text.secondary" component="div">{paramWords(p)}</Typography>
              {valueControl && <Box sx={{ mt: 0.5, '& .MuiFormControl-root, & .MuiAutocomplete-root': { minWidth: '0 !important', width: '100%' } }} data-testid={`canvas-param-${p.name}-value`}>{valueControl(p)}</Box>}
            </Box>
            <IconButton size="small" aria-label={`More for ${p.label || p.name}`} data-testid={`canvas-param-${p.name}-menu`}
              onClick={e => setMenuFor({ el: e.currentTarget, name: p.name })}><MoreHorizIcon fontSize="small" /></IconButton>
          </Box>
        ))}
        <Menu anchorEl={menuFor?.el ?? null} open={!!menuFor} onClose={() => setMenuFor(null)} transitionDuration={0}>
          <MenuItem onClick={() => { setMenuFor(null); onOpenSettings(); }} data-testid="canvas-param-settings">Settings…</MenuItem>
          <MenuItem onClick={() => { if (menuFor) removeParam(menuFor.name); setMenuFor(null); }} sx={{ color: 'error.main' }} data-testid="canvas-param-remove">Remove</MenuItem>
        </Menu>
        {params.length > 0 && (
          <Button size="small" onClick={onOpenSettings} data-testid="canvas-params-settings" sx={{ mt: 0.5 }}>Settings for every parameter…</Button>
        )}
      </Paper>

      {/* ── In the query ── */}
      <Paper variant="outlined" sx={{ p: 0.75 }} data-testid="filters-source">
        <Typography variant="caption" sx={{ fontWeight: 600 }}>In the query</Typography>
        {sourceFilters.length === 0 && (
          <Typography variant="caption" color="text.secondary" component="div">
            {datasetId ? 'The dataset\'s query has no condition of its own to ask about.' : 'Pick the data first.'}
          </Typography>
        )}
        {sourceFilters.map(sf => {
          const checked = params.some(p => p.source_column === sf.key);
          return (
            <Box key={sf.key} sx={{ py: 0.25 }}>
              <FormControlLabel sx={{ mr: 0, alignItems: 'flex-start' }} data-testid={`canvas-source-${sf.key}`}
                label={<Typography variant="body2">{sourceFilterWords(sf)}</Typography>}
                control={<Checkbox size="small" checked={checked} sx={{ py: 0 }}
                  inputProps={{ 'aria-label': `Ask when the report runs: ${sf.column}`, 'data-testid': `source-filter-${sf.key}-ask` } as any}
                  onChange={e => tickSource(sf, e.target.checked)} />} />
              <Typography variant="caption" color="text.secondary" component="div" data-testid={`source-filter-${sf.key}-words`} sx={{ pl: 3.5 }}>
                {checked
                  ? (sf.is_date ? 'Asked when the report runs: any date on a calendar.' : 'Asked when the report runs: one value or several (several run as IN).')
                  : 'Runs as written.'}
              </Typography>
            </Box>
          );
        })}
      </Paper>

      {/* ── Fixed ── */}
      <Paper variant="outlined" sx={{ p: 0.75 }} data-testid="filters-fixed">
        <Stack direction="row" alignItems="center" sx={{ mb: 0.5 }}>
          <Typography variant="caption" sx={{ fontWeight: 600, flex: 1 }}>Fixed</Typography>
          <Tooltip title="Add a fixed filter on the results">
            <span>
              <IconButton size="small" disabled={!columns.length} aria-label="Add a fixed filter" data-testid="canvas-filter-add"
                onClick={() => onFiltersChange(rows => [...rows, { column_id: columns.find(c => !c.hidden)?.id ?? columns[0].id, operator: 'eq', value: '' }])}>
                <AddIcon fontSize="small" />
              </IconButton>
            </span>
          </Tooltip>
        </Stack>
        {filters.length === 0 && <Typography variant="caption" color="text.secondary">None. A fixed filter narrows the rows for everyone.</Typography>}
        {filters.map((f, i) => {
          const col = cols.get(Number(f.column_id));
          const bad = unfilled.some(([, k]) => k === i);
          return (
            <Stack key={i} spacing={0.5} data-testid={`canvas-filter-${i}`} sx={{ py: 0.5, borderTop: '1px solid', borderColor: 'divider' }}>
              <Stack direction="row" spacing={0.5} alignItems="center">
                <FormControl size="small" sx={{ flex: 1, minWidth: 0 }}>
                  <InputLabel id={`fixed-col-${i}`}>Filter column</InputLabel>
                  <Select labelId={`fixed-col-${i}`} label="Filter column" value={f.column_id} inputProps={{ 'data-testid': `canvas-filter-${i}-column` }}
                    onChange={e => onFiltersChange(rows => rows.map((r, k) => k === i ? changeFilterField(r, 'column_id', Number(e.target.value)) : r))}>
                    {columns.filter(c => !c.hidden).map(c => <MenuItem key={c.id} value={c.id}>{c.label}</MenuItem>)}
                  </Select>
                </FormControl>
                <Tooltip title="Remove this filter">
                  <IconButton size="small" aria-label={`Remove the filter on ${col?.label ?? 'this column'}`} data-testid={`canvas-filter-${i}-remove`}
                    onClick={() => onFiltersChange(rows => rows.filter((_, k) => k !== i))}><DeleteIcon fontSize="small" /></IconButton>
                </Tooltip>
              </Stack>
              <FormControl size="small" fullWidth>
                <InputLabel id={`fixed-op-${i}`}>Filter operator</InputLabel>
                <Select labelId={`fixed-op-${i}`} label="Filter operator" value={f.operator} inputProps={{ 'data-testid': `canvas-filter-${i}-operator` }}
                  onChange={e => onFiltersChange(rows => rows.map((r, k) => k === i ? changeFilterField(r, 'operator', String(e.target.value)) : r))}>
                  {FILTER_OPERATORS.map(op => <MenuItem key={op.value} value={op.value}>{op.label}</MenuItem>)}
                </Select>
              </FormControl>
              <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap', alignItems: 'center', '& .MuiFormControl-root, & .MuiAutocomplete-root': { minWidth: '0 !important', flex: 1 } }}>
                <ReportFilterValueInput filter={f} index={i} columns={authoringCols} datasetId={datasetId} unfilled={bad}
                  onChange={(field, v) => onFiltersChange(rows => rows.map((r, k) => k === i ? changeFilterField(r, field, v) : r))} />
              </Box>
              {ASKABLE_OPERATORS.includes(f.operator || 'eq') && col && (
                <Button size="small" sx={{ alignSelf: 'flex-start' }} data-testid={`filter-${i}-ask`}
                  onClick={() => { if (onAskField(col)) onFiltersChange(rows => rows.filter((_, k) => k !== i)); }}>
                  Ask the viewer instead
                </Button>
              )}
            </Stack>
          );
        })}
        {unfilled.length > 0 && (
          <Alert severity="warning" sx={{ mt: 0.5, py: 0 }} data-testid="unfilled-filters">
            {unfilled.map(([f, i]) => `Filter ${i + 1} on ${cols.get(Number(f.column_id))?.label ?? `column #${f.column_id}`} has no value.`).join(' ')} Give it one or remove it: a filter with no value is never saved.
          </Alert>
        )}
      </Paper>
    </Stack>
  );
}
