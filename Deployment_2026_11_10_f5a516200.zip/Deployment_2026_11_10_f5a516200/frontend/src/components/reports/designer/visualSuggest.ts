/**
 * Which suggested field fits which slot of a visual (2026-11-09, the owner: "smart prediction if
 * user select any type ... based on dataset").  The server ranks the dataset's fields per ROLE
 * (backend core/reports/visual_suggestions.py: a date to draw along, a field to group by, a value to
 * add up -- no data read); this maps each slot ("well", canvasWells.ts -- the ONE slot table) of each
 * kind onto a role, and fills a new visual's REQUIRED slots through placeInWell (its rules, its words).
 */
import { CanvasColumn, CanvasTile, TileKind } from '../canvas/canvasModel';
import { placeInWell, Well, wellItems, wellsFor } from '../canvas/canvasWells';

export interface SuggestedField { column_id: number; label: string; aggregation?: string; used: number; why: string }
export interface VisualSuggestions {
  enabled: boolean;
  words?: string;
  roles: { time: SuggestedField[]; category: SuggestedField[]; measure: SuggestedField[] };
  visuals: { kind: TileKind | string; dimensions: number[]; measures: number[]; why: string }[];
  usage_known?: boolean;
}

/** the kinds whose first category is drawn along a line: a date belongs there first */
const TIME_FIRST: TileKind[] = ['line', 'area', 'stacked_area', 'combo'];

/** the slots a visual NEEDS before it can be drawn -- what canvasProblems (the server's rule too) refuses
 *  empty.  Review 2026-11-09: Lines (combo needs 2+ values), Size (bubble needs 3), a pivot's Columns and a
 *  waterfall's Category (one category + one value is its default shape) were called optional and the pre-fill
 *  left those visuals broken.  Only the Legend may stay empty; the test runs canvasProblems on every kind. */
export function isRequiredWell(_kind: TileKind, well: Well): boolean {
  return well.id !== 'legend';
}

/** the fields already on the tile (never suggested twice) */
function onTile(tile: CanvasTile): Set<number> {
  return new Set([...tile.dimensions, ...tile.measures.map(m => m.column_id), ...(tile.series != null ? [tile.series] : [])]);
}

/** The best suggestion for ONE slot, or null when the dataset offers none (said, never invented). */
export function suggestionFor(tile: CanvasTile, well: Well, s: VisualSuggestions | null, cols: Map<number, CanvasColumn>): SuggestedField | null {
  if (!s || !s.enabled) return null;
  const taken = onTile(tile);
  const free = (list: SuggestedField[]) => list.find(f => !taken.has(f.column_id) && cols.has(f.column_id)) ?? null;
  const { time, category, measure } = s.roles;
  switch (well.role) {
    case 'measure': return free(measure);
    case 'series': return free(category);
    case 'mixed': return free(category) ?? free(measure);
    case 'dimension':
      return TIME_FIRST.includes(tile.kind) && (well.id === 'x') ? (free(time) ?? free(category)) : (free(category) ?? free(time));
  }
  return null;
}

/** Fill a NEW visual's empty REQUIRED slots with the top suggestion each; returns the tile and the
 *  ids it filled (the steps mark them "suggested"). */
export function prefillTile(tile: CanvasTile, s: VisualSuggestions | null, cols: Map<number, CanvasColumn>, grouped: boolean): { tile: CanvasTile; filled: number[] } {
  let t = tile;
  const filled: number[] = [];
  for (const well of wellsFor(t.kind)) {
    if (!isRequiredWell(t.kind, well) || wellItems(t, well).length > 0) continue;
    const want = suggestionFor(t, well, s, cols);   // a slot filled before is taken: X and Y get two values
    const col = want ? cols.get(want.column_id) : undefined;
    if (!col) continue;
    const placed = placeInWell(t, well, col, grouped);
    if (!placed.note) { t = placed.tile; filled.push(col.id); }
  }
  return { tile: t, filled };
}

/** The suggested visuals this designer can draw (the Type step shows them first). */
export function suggestedVisuals(s: VisualSuggestions | null, known: TileKind[]): VisualSuggestions['visuals'] {
  if (!s || !s.enabled) return [];
  return s.visuals.filter(v => known.includes(v.kind as TileKind));
}
