/**
 * New report: ONE chooser with three cards (2026-11-07, the simple builder,
 * plan section 4).
 *
 *   Blank report               the designer, on a dataset picked here (or in the designer)
 *   From a template            the existing template flow (/finance-reports/new/template)
 *   Tabular, pivot or SQL      the existing type picker, with its "Where the data comes from"
 *                              source picker (a dataset, a published API, your own SQL, a
 *                              file, a REST API...)
 *   Import from Power BI       a .pbix / .pbit / zipped .pbip becomes a canvas report on a dataset
 *                              (2026-11-07, PowerBiImportDialog; the server reads the file)
 *
 * The owner: "don't remove template feature".  Nothing behind the cards was
 * rewritten; this page only decides which road a person takes.  A dataset
 * carried in the URL (?dataset_id=N, the dataset screens' "Create report")
 * is handed on to the road picked.
 */
import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Alert, Box, Button, Card, CardActionArea, CardContent, Grid, MenuItem, TextField, Typography } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import AutoAwesomeMosaicIcon from '@mui/icons-material/AutoAwesomeMosaic';
import TableChartIcon from '@mui/icons-material/TableChart';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import PowerBiImportDialog from './PowerBiImportDialog';
import api from '../../../services/api';
import { NEW_REPORT_FROM_TEMPLATE_PATH, REPORTS_PATH, reportEditPath, startDatasetIdFrom } from '../../../utils/reportUrls';

/** the existing type picker's own address (it was /finance-reports/new before the chooser) */
export const NEW_REPORT_CLASSIC_PATH = `${REPORTS_PATH}/new/classic`;
export const NEW_REPORT_BLANK_PATH = `${REPORTS_PATH}/new/canvas`;

export default function NewReportChooser() {
  const navigate = useNavigate();
  const location = useLocation();
  const startDatasetId = startDatasetIdFrom(location.search);
  const [datasets, setDatasets] = useState<any[]>([]);
  const [datasetsNote, setDatasetsNote] = useState('');
  const [datasetId, setDatasetId] = useState<number | ''>(startDatasetId ?? '');
  const [pbiOpen, setPbiOpen] = useState(false);
  useEffect(() => {
    api.listDatasets().then((ds: any) => {
      const list = Array.isArray(ds) ? ds : (ds?.items || ds?.datasets || []);
      setDatasets(list);
      if (!list.length) setDatasetsNote('There is no dataset yet. A blank report needs one; make it under Datasets, or start from Tabular, pivot or SQL with another source.');
    }).catch((e: any) => setDatasetsNote(`The datasets could not be read (${e?.message || 'unknown'}). You can still pick the data in the designer.`));
  }, []);
  const blank = () => navigate(datasetId === '' ? NEW_REPORT_BLANK_PATH : `${NEW_REPORT_BLANK_PATH}?dataset=${datasetId}`);
  const classic = () => navigate(startDatasetId != null ? `${NEW_REPORT_CLASSIC_PATH}?dataset_id=${startDatasetId}` : NEW_REPORT_CLASSIC_PATH);
  const card = (testId: string, icon: React.ReactNode, title: string, words: string, onClick: () => void, extra?: React.ReactNode) => (
    <Grid size={{ xs: 12, md: 6, lg: 3 }}>
      <Card variant="outlined" sx={{ height: '100%', '&:hover': { borderColor: 'primary.main', boxShadow: 2 } }} data-testid={testId}>
        <CardActionArea onClick={onClick} sx={{ p: 2.5, height: extra ? 'auto' : '100%', alignItems: 'flex-start' }} data-testid={`${testId}-go`}>
          <Box sx={{ color: 'primary.main', mb: 1 }}>{icon}</Box>
          <Typography variant="subtitle1" fontWeight="bold">{title}</Typography>
          <Typography variant="body2" color="text.secondary">{words}</Typography>
        </CardActionArea>
        {extra && <CardContent sx={{ pt: 0 }}>{extra}</CardContent>}
      </Card>
    </Grid>
  );
  return (
    <Box sx={{ p: 3, maxWidth: 1000, mx: 'auto' }} data-testid="new-report-chooser">
      <Button size="small" startIcon={<ArrowBackIcon />} sx={{ mb: 2 }} onClick={() => navigate(REPORTS_PATH)}>Back to Reports</Button>
      <Typography variant="h5" sx={{ mb: 0.5 }}>New report</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>Pick how to start. Everything can be changed later.</Typography>
      {datasetsNote && <Alert severity="info" sx={{ mb: 2 }} data-testid="new-report-datasets-note">{datasetsNote}</Alert>}
      <Grid container spacing={2} sx={{ alignItems: 'stretch' }}>
        {card('new-report-blank', <AutoAwesomeMosaicIcon sx={{ fontSize: 44 }} />, 'Blank report',
          'Pick the data, click a visual, tick fields: the numbers appear as you build. Cards, charts, tables, the finance grid.', blank,
          <TextField select size="small" fullWidth label="Data" value={datasetId === '' ? '' : String(datasetId)} inputProps={{ 'data-testid': 'new-report-blank-dataset' }}
            onChange={e => setDatasetId(e.target.value === '' ? '' : Number(e.target.value))}
            helperText="A dataset. For a published API, your own SQL, a file or a REST API, use Tabular, pivot or SQL.">
            <MenuItem value="">Pick it in the designer</MenuItem>
            {datasets.map((d: any) => <MenuItem key={d.id} value={String(d.id)}>{d.name}</MenuItem>)}
          </TextField>)}
        {card('new-report-template', <DashboardCustomizeIcon sx={{ fontSize: 44 }} />, 'From a template',
          'Fifteen ready designs: a financial summary, day on day, a trend, a budget against actuals, a P&L bridge, a statement... pick a dataset and the fields.',
          () => navigate(NEW_REPORT_FROM_TEMPLATE_PATH))}
        {card('new-report-classic', <TableChartIcon sx={{ fontSize: 44 }} />, 'Tabular, pivot or SQL',
          'The step-by-step builder: a table with sections and running calculations, a pivot, or a report on your own SQL -- and every other source: a published API, a file, a REST API.',
          classic)}
        {card('new-report-powerbi', <UploadFileIcon sx={{ fontSize: 44 }} />, 'Import from Power BI',
          'A .pbix, .pbit or zipped .pbip file: its pages, visuals, fields, filters and colours become a report on a dataset you pick. A preview shows what comes across before anything is saved.',
          () => setPbiOpen(true))}
      </Grid>
      <PowerBiImportDialog open={pbiOpen} onClose={() => setPbiOpen(false)} datasets={datasets.map((d: any) => ({ id: d.id, name: d.name }))}
        initialDatasetId={datasetId === '' ? null : Number(datasetId)} onCreated={made => { setPbiOpen(false); navigate(reportEditPath(made.report)); }} />
    </Box>
  );
}
