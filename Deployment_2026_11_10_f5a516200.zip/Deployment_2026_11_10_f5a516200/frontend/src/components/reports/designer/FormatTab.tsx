/**
 * The Format tab (2026-11-07, the simple builder).  With a visual selected:
 * its settings in collapsed groups -- Title, Data labels, Sort and limit,
 * Colours and numbers, Comparison (a card) -- every control of the old
 * property panel, same test ids.  With none selected: the REPORT's settings
 * -- Clicks between visuals, Drill, Two-date comparison, Viewers, Theme.
 */
import React, { useState } from 'react';
import {
  Accordion, AccordionDetails, AccordionSummary, Alert, FormControlLabel, IconButton, MenuItem, Stack, Switch, TextField, Tooltip, Typography,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import {
  CanvasColumn, CanvasPage, CanvasTile, isChart, maxPointsOf, ReportCanvas, tileName,
} from '../canvas/canvasModel';
import { CanvasLinksSwitch, TileLinkedSwitch, setCanvasLinks, setTileLinked } from '../canvas/CanvasLinkChips';
import { DrillSettings } from '../canvas/canvasDrill';
import { CompareSettings } from '../canvas/canvasCompare';
import { KpiTileSettings, TileFormatSettings } from '../canvas/CanvasOutlineSettings';
import { LABEL_KINDS, LABEL_MODES, LABEL_WORDS, OVERLAY_KINDS, PERCENT_KINDS, type LabelMode } from '../canvas/canvasChartOptions';

type Change = (f: (t: CanvasTile) => CanvasTile) => void;

/** One collapsed group of settings. */
export function FormatGroup({ id, title, open, children }: { id: string; title: string; open?: boolean; children: React.ReactNode }) {
  const [expanded, setExpanded] = useState(!!open);
  return (
    <Accordion disableGutters elevation={0} variant="outlined" expanded={expanded} onChange={(_, v) => setExpanded(v)}
      data-testid={`format-group-${id}`} sx={{ '&:before': { display: 'none' } }}>
      <AccordionSummary expandIcon={<ExpandMoreIcon />} sx={{ minHeight: 36, '& .MuiAccordionSummary-content': { my: 0.5 } }}>
        <Typography variant="subtitle2">{title}</Typography>
      </AccordionSummary>
      <AccordionDetails sx={{ pt: 0 }}>{children}</AccordionDetails>
    </Accordion>
  );
}

export function VisualFormat({ tile, cols, columns, grouped, pages, pageOf, movePage, hasCompare, paramNames, problems, onChange, onDelete }: {
  tile: CanvasTile; cols: Map<number, CanvasColumn>; columns: CanvasColumn[]; grouped: boolean;
  pages: CanvasPage[] | undefined; pageOf: (id: string) => number; movePage: (id: string, k: number) => void;
  hasCompare: boolean; paramNames: { name: string; label: string; type?: string }[]; problems: string[];
  onChange: Change; onDelete: () => void;
}) {
  const chart = isChart(tile.kind);
  return (
    <Stack spacing={0.5} data-testid="tile-properties">
      <Stack direction="row" alignItems="center">
        <Typography variant="subtitle2" sx={{ flex: 1 }} noWrap title={tileName(tile, cols)}>{tileName(tile, cols)}</Typography>
        <Tooltip title="Remove this visual"><IconButton size="small" onClick={onDelete} aria-label="Remove this visual" data-testid="tile-delete"><DeleteIcon fontSize="small" /></IconButton></Tooltip>
      </Stack>
      {problems.map((p, i) => <Alert key={i} severity="error" sx={{ py: 0 }}>{p}</Alert>)}

      <FormatGroup id="title" title="Title" open>
        <Stack spacing={1}>
          <TextField size="small" label="Title" placeholder={tileName({ ...tile, title: '' }, cols)} value={tile.title}
            onChange={e => onChange(t => ({ ...t, title: e.target.value.slice(0, 200) }))} inputProps={{ 'data-testid': 'tile-title' }} />
          {(pages?.length ?? 0) > 0 && (
            <TextField select size="small" label="On page" value={pageOf(tile.id)} inputProps={{ 'data-testid': 'tile-page' }}
              onChange={e => movePage(tile.id, Number(e.target.value))}>
              {pages!.map((p, i) => <MenuItem key={p.id} value={i}>{p.title || `Page ${i + 1}`}</MenuItem>)}
            </TextField>
          )}
          <TileLinkedSwitch tile={tile} onChange={v => onChange(t => setTileLinked(t, v))} />
        </Stack>
      </FormatGroup>

      {chart && (
        <FormatGroup id="labels" title="Data labels">
          <Stack spacing={1}>
            {LABEL_KINDS.includes(tile.kind) && (
              <TextField select size="small" fullWidth label="Words on the marks" value={tile.labels ?? 'none'} inputProps={{ 'data-testid': 'tile-labels' }}
                onChange={e => onChange(t => { const { labels: _l, ...rest } = t; return e.target.value === 'none' ? rest : { ...rest, labels: e.target.value as LabelMode }; })}>
                {LABEL_MODES.filter(m => m !== 'percent' || PERCENT_KINDS.includes(tile.kind)).map(m => <MenuItem key={m} value={m}>{LABEL_WORDS[m]}</MenuItem>)}
              </TextField>
            )}
            {tile.kind === 'donut' && (
              <FormControlLabel control={<Switch size="small" checked={tile.centre === 'total'} slotProps={{ input: { 'data-testid': 'tile-centre' } as any }}
                onChange={e => onChange(t => { const { centre: _c, ...rest } = t; return e.target.checked ? { ...rest, centre: 'total' } : rest; })} />}
                label="Show the total in the centre" />
            )}
            {OVERLAY_KINDS.includes(tile.kind) && tile.series == null && hasCompare && (
              <FormControlLabel control={<Switch size="small" checked={tile.compare_overlay === true} slotProps={{ input: { 'data-testid': 'tile-overlay' } as any }}
                onChange={e => onChange(t => { const { compare_overlay: _o, ...rest } = t; return e.target.checked ? { ...rest, compare_overlay: true } : rest; })} />}
                label="Draw the two dates: B as the marks, A as a dotted line" />
            )}
            {!LABEL_KINDS.includes(tile.kind) && tile.kind !== 'donut' && <Typography variant="caption" color="text.secondary">This kind of visual has no labels to set.</Typography>}
          </Stack>
        </FormatGroup>
      )}

      {chart && (
        <FormatGroup id="sort" title="Sort and limit">
          <Stack spacing={1}>
            <TextField select size="small" label="Order" value={tile.sort ? `${tile.sort.by}:${tile.sort.dir}` : 'category'}
              onChange={e => { const v = e.target.value; onChange(t => ({ ...t, sort: v === 'category' ? null : { by: 'measure', dir: v.endsWith('asc') ? 'asc' : 'desc' } })); }}
              inputProps={{ 'data-testid': 'tile-sort' }}>
              <MenuItem value="measure:desc">Largest first</MenuItem>
              <MenuItem value="measure:asc">Smallest first</MenuItem>
              <MenuItem value="category">By category</MenuItem>
            </TextField>
            <TextField size="small" type="number" label="How many to draw" value={tile.top_n ?? 25}
              inputProps={{ min: 1, max: maxPointsOf(tile.kind, tile.series), 'data-testid': 'tile-topn' }}
              helperText={`1 to ${maxPointsOf(tile.kind, tile.series).toLocaleString('en-US')}. The rest are counted and said under the chart.`}
              onChange={e => onChange(t => ({ ...t, top_n: Math.max(1, Math.min(maxPointsOf(t.kind, t.series), Math.floor(Number(e.target.value) || 1))) }))} />
            {['pie', 'donut', 'treemap'].includes(tile.kind) && (
              <Stack direction="row" spacing={1}>
                <TextField select size="small" label="The rest" value={tile.other_mode ?? 'fold'} sx={{ flex: 1 }}
                  onChange={e => onChange(t => ({ ...t, other_mode: e.target.value as any }))} inputProps={{ 'data-testid': 'tile-other-mode' }}>
                  <MenuItem value="fold">One muted part, "Everything else"</MenuItem>
                  <MenuItem value="none">Not drawn (the top N only)</MenuItem>
                </TextField>
                <TextField size="small" type="number" label="At most, of the picture (%)" value={Math.round((tile.other_max_share ?? 0.25) * 100)} sx={{ width: 150 }}
                  disabled={(tile.other_mode ?? 'fold') === 'none'} inputProps={{ min: 5, max: 90, 'data-testid': 'tile-other-share' }}
                  onChange={e => onChange(t => ({ ...t, other_max_share: Math.min(90, Math.max(5, Number(e.target.value) || 25)) / 100 }))} />
              </Stack>
            )}
            {['line', 'area', 'bar', 'column', 'table'].includes(tile.kind) && paramNames.length > 0 && (
              <TextField select size="small" fullWidth label="Trend over the period parameter" value={tile.trend_of ?? ''}
                onChange={e => onChange(t => ({ ...t, trend_of: e.target.value || undefined }))} inputProps={{ 'data-testid': 'tile-trend-of' }}
                helperText="The visual follows the period the viewer picks (a month of days, 12 month-ends, 3 year-ends) and says so">
                <MenuItem value="">No</MenuItem>
                {paramNames.map(p => <MenuItem key={p.name} value={p.name}>{p.label}</MenuItem>)}
              </TextField>
            )}
          </Stack>
        </FormatGroup>
      )}

      {tile.kind !== 'report' && tile.kind !== 'band' && (
        <FormatGroup id="colours" title="Colours and numbers">
          <TileFormatSettings tile={tile} cols={cols} onChange={onChange} />
        </FormatGroup>
      )}

      {tile.kind === 'number' && (
        <FormatGroup id="comparison" title="Comparison and card style">
          <KpiTileSettings tile={tile} cols={cols} columns={columns} grouped={grouped} hasCompareParameter={hasCompare} onChange={onChange} />
        </FormatGroup>
      )}
    </Stack>
  );
}

export function ReportFormat({ canvas, columns, params, viewersMayRearrange, setViewersMayRearrange, setCanvas, theme, openGroup, groups, intro }: {
  canvas: ReportCanvas; columns: CanvasColumn[]; params: any[];
  viewersMayRearrange: boolean; setViewersMayRearrange: (v: boolean) => void;
  setCanvas: React.Dispatch<React.SetStateAction<ReportCanvas>>;
  /** the Theme group's body (the look panel, embedded) -- stage C */
  theme?: React.ReactNode;
  /** a group opened by the URL (?tab=look opens Theme) */
  openGroup?: string | null;
  /** 2026-11-09 -- only these groups (a visual's steps show links + drill); default every group */
  groups?: string[];
  /** the words above the groups; default: they are the report's */
  intro?: string;
}) {
  const shows = (g: string) => !groups || groups.includes(g);
  return (
    <Stack spacing={0.5} data-testid="report-format">
      <Typography variant="caption" color="text.secondary">{intro ?? <>Nothing is selected: these settings are the report&apos;s. Click a visual to see its own.</>}</Typography>
      {shows('links') && <FormatGroup id="links" title="Clicks between visuals" open={openGroup === 'links'}>
        <CanvasLinksSwitch canvas={canvas} onChange={v => setCanvas(c => setCanvasLinks(c, v))} />
      </FormatGroup>}
      {shows('drill') && <FormatGroup id="drill" title="Drill" open={openGroup === 'drill'}>
        <DrillSettings canvas={canvas} columns={columns} onChange={setCanvas} />
      </FormatGroup>}
      {shows('compare') && <FormatGroup id="compare" title="Two-date comparison" open={openGroup === 'compare'}>
        <CompareSettings canvas={canvas} params={params} onChange={setCanvas} />
      </FormatGroup>}
      {shows('viewers') && <FormatGroup id="viewers" title="Viewers" open={openGroup === 'viewers'}>
        <FormControlLabel control={<Switch checked={viewersMayRearrange} onChange={e => setViewersMayRearrange(e.target.checked)}
          slotProps={{ input: { 'data-testid': 'viewers-may-rearrange' } as any }} />}
          label="Viewers may rearrange the visuals and pick their fields (from the approved drill fields); each keeps their own layout" />
      </FormatGroup>}
      {theme && shows('theme') && (
        <FormatGroup id="theme" title="Theme and colours" open={openGroup === 'theme'}>
          {theme}
        </FormatGroup>
      )}
    </Stack>
  );
}
