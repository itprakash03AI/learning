/**
 * The Fields pane (2026-11-07, the simple builder): the dataset's fields with
 * a search box and a TICK per field.  A tick is on when the selected visual
 * uses the field; clicking the row adds it to the selected visual (or takes
 * it off), and with no visual selected it starts one (tileForField).  Rows
 * are draggable onto the canvas, a visual or a well (FIELD_MIME), and keep
 * the old `field-<physical>` test id the rig specs click.
 */
import React from 'react';
import { Box, Checkbox, InputAdornment, List, ListItemButton, ListItemText, TextField, Typography } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { CanvasColumn, isMeasureColumn } from '../canvas/canvasModel';
import { FIELD_MIME } from '../canvas/ReportCanvasView';
import { fieldHoverText, FULL_FIELD_NAME } from '../canvas/canvasEdit';

export default function FieldsPane({ columns, query, onQuery, usedIds, selectedName, onToggle, hasData }: {
  columns: CanvasColumn[];
  query: string;
  onQuery: (q: string) => void;
  /** the column ids the selected visual uses (ticked) */
  usedIds: Set<number>;
  /** words for the target of a click: "the selected visual" / "a new visual" */
  selectedName: string | null;
  onToggle: (col: CanvasColumn, on: boolean) => void;
  hasData: boolean;
}) {
  const q = query.trim().toLowerCase();
  const fields = columns.filter(c => !c.hidden).filter(c => !q || c.label.toLowerCase().includes(q) || c.physical_name.toLowerCase().includes(q));
  const dims = fields.filter(c => !isMeasureColumn(c));
  const meas = fields.filter(c => isMeasureColumn(c));
  const item = (c: CanvasColumn) => {
    const on = usedIds.has(c.id);
    return (
      <ListItemButton key={c.id} dense draggable data-testid={`field-${c.physical_name}`} selected={on}
        onDragStart={e => { e.dataTransfer.setData(FIELD_MIME, String(c.id)); e.dataTransfer.effectAllowed = 'copy'; }}
        onClick={() => onToggle(c, !on)} sx={{ py: 0.25 }}
        title={fieldHoverText(c, selectedName ?? 'a new visual')}>
        <Checkbox size="small" checked={on} tabIndex={-1} disableRipple sx={{ p: 0.25, mr: 0.5 }}
          inputProps={{ 'aria-label': `${c.label}${on ? ' -- on the selected visual' : ''}`, 'data-testid': `field-tick-${c.physical_name}` } as any} />
        <ListItemText primary={c.label} secondary={c.physical_name !== c.label ? c.physical_name : undefined}
          primaryTypographyProps={{ variant: 'body2', sx: FULL_FIELD_NAME }} secondaryTypographyProps={{ variant: 'caption', sx: FULL_FIELD_NAME }} />
        {isMeasureColumn(c) && <Typography variant="caption" color="text.secondary" sx={{ ml: 0.5 }} aria-hidden>Σ</Typography>}
      </ListItemButton>
    );
  };
  return (
    <Box data-testid="canvas-fields" sx={{ display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      <TextField size="small" fullWidth placeholder="Search fields" value={query} onChange={e => onQuery(e.target.value)}
        inputProps={{ 'aria-label': 'Search fields' }}
        InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }} />
      <Box sx={{ overflow: 'auto', flex: 1, minHeight: 0 }}>
        {!hasData && <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>Pick the data first.</Typography>}
        {dims.length > 0 && <Typography variant="overline" color="text.secondary">Fields</Typography>}
        <List dense disablePadding>{dims.map(item)}</List>
        {meas.length > 0 && <Typography variant="overline" color="text.secondary">Values</Typography>}
        <List dense disablePadding>{meas.map(item)}</List>
        {hasData && fields.length === 0 && <Typography variant="body2" color="text.secondary">No field matches.</Typography>}
      </Box>
    </Box>
  );
}
