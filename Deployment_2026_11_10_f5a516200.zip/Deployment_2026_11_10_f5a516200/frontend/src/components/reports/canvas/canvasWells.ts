/**
 * Field WELLS (2026-11-07, the simple builder, plan section 3 "Which well
 * holds what").  A well is another view of a tile's existing fields: moving
 * a field in a well writes the same `dimensions`, `measures` and `series`
 * the old Category / Add a value / Split into series controls wrote.  This
 * module is ONE table of data plus the two moves on it; `addFieldToTile`,
 * `changeKind` and `valueLimit` (canvasEdit.ts) keep their rules.
 *
 *   wellsFor(kind)              the wells of a kind, in the order they are shown
 *   wellItems(tile, well)       what sits in a well (column ids, with the measure index)
 *   placeInWell(tile, well, column, grouped)   drop a field into a well -> the tile, or why not
 *   removeFromWell(tile, item)  take a field out
 *
 * A kind with no wells (outline, band, insight, the report's table) keeps
 * its own settings in the Build tab.
 */
import {
  Aggregation, CanvasColumn, CanvasTile, defaultAggregation, MAX_BRIDGE_STEPS, MAX_SERIES_VALUES,
  SUM_ONLY, TILE_KINDS, TileKind,
} from './canvasModel';
import { valueLimit } from './canvasEdit';

export type WellRole = 'dimension' | 'series' | 'measure' | 'mixed';

export interface Well {
  /** stable id; the picker inside the well carries the OLD control's test id (`testId`) */
  id: string;
  label: string;
  role: WellRole;
  /** how many fields the well holds (null = as many as the kind allows) */
  max: number | null;
  /** measure wells: the slots of `measures` this well shows, [from, to) */
  slots?: [number, number];
  /** the data-testid of the well's own picker, kept from the old property panel */
  testId: 'tile-category' | 'tile-series' | 'tile-add-value' | 'tile-columns' | 'tile-rows';
  hint?: string;
}

export interface WellItem {
  well: string;
  kind: 'dimension' | 'series' | 'measure';
  column_id: number;
  /** a measure's index in `tile.measures` (the row's test ids `tile-agg-<i>` use it) */
  index?: number;
}

const X_AXIS: Well = { id: 'x', label: 'X axis', role: 'dimension', max: 1, testId: 'tile-category' };
const Y_VALUES: Well = { id: 'y', label: 'Y axis', role: 'measure', max: MAX_SERIES_VALUES, slots: [0, MAX_SERIES_VALUES], testId: 'tile-add-value',
  hint: 'Several values draw as several series -- or one value split by the Legend.' };
const LEGEND: Well = { id: 'legend', label: 'Legend', role: 'series', max: 1, testId: 'tile-series',
  hint: 'Splits ONE value into series. With two or more values the legend is the values.' };
const CATEGORY: Well = { id: 'category', label: 'Category', role: 'dimension', max: 1, testId: 'tile-category' };
const ONE_VALUE: Well = { id: 'values', label: 'Values', role: 'measure', max: 1, slots: [0, 1], testId: 'tile-add-value' };

/** THE table: which well holds what, per kind of visual. */
export function wellsFor(kind: TileKind): Well[] {
  switch (kind) {
    case 'bar': case 'stacked_bar': case 'line': case 'area': case 'stacked_area': case 'radar':
      return [X_AXIS, Y_VALUES, LEGEND];
    case 'hbar':
      return [{ ...X_AXIS, label: 'Y axis' }, { ...Y_VALUES, label: 'X axis' }, LEGEND];
    case 'combo':
      return [X_AXIS,
        { id: 'columns', label: 'Columns', role: 'measure', max: 1, slots: [0, 1], testId: 'tile-add-value', hint: 'The first value draws as columns.' },
        { id: 'lines', label: 'Lines', role: 'measure', max: MAX_SERIES_VALUES - 1, slots: [1, MAX_SERIES_VALUES], testId: 'tile-add-value', hint: 'Every other value draws as a line.' }];
    case 'pie': case 'donut': case 'treemap': case 'funnel':
      return [CATEGORY, ONE_VALUE];
    case 'waterfall':
      return [{ ...CATEGORY, hint: 'Leave it empty for a bridge of values: one step per value, then the total.' },
        { id: 'values', label: 'Values', role: 'measure', max: MAX_BRIDGE_STEPS, slots: [0, MAX_BRIDGE_STEPS], testId: 'tile-add-value',
          hint: 'With a category: one value. Without: 2 to 8 values, one step each.' }];
    case 'scatter':
      return [{ ...CATEGORY, id: 'point', label: 'Each point' },
        { id: 'x', label: 'X', role: 'measure', max: 1, slots: [0, 1], testId: 'tile-add-value' },
        { id: 'y', label: 'Y', role: 'measure', max: 1, slots: [1, 2], testId: 'tile-add-value' }];
    case 'bubble':
      return [{ ...CATEGORY, id: 'point', label: 'Each point' },
        { id: 'x', label: 'X', role: 'measure', max: 1, slots: [0, 1], testId: 'tile-add-value' },
        { id: 'y', label: 'Y', role: 'measure', max: 1, slots: [1, 2], testId: 'tile-add-value' },
        { id: 'size', label: 'Size', role: 'measure', max: 1, slots: [2, 3], testId: 'tile-add-value' }];
    case 'number':
      return [{ id: 'value', label: 'Value', role: 'measure', max: 1, slots: [0, 1], testId: 'tile-add-value' }];
    case 'table':
      return [{ id: 'columns', label: 'Columns', role: 'mixed', max: null, testId: 'tile-columns',
        hint: 'Fields and values. With a value the rows are grouped by the fields.' }];
    case 'pivot':
      return [{ id: 'rows', label: 'Rows', role: 'dimension', max: null, testId: 'tile-rows' },
        { id: 'columns', label: 'Columns', role: 'series', max: 1, testId: 'tile-series' },
        { id: 'values', label: 'Values', role: 'measure', max: valueLimit('pivot'), slots: [0, valueLimit('pivot')], testId: 'tile-add-value' }];
    case 'heatmap':
      return [{ id: 'rows', label: 'Rows', role: 'dimension', max: 1, testId: 'tile-category' },
        { id: 'columns', label: 'Columns', role: 'series', max: 1, testId: 'tile-series' },
        { ...ONE_VALUE, hint: 'Colours the cells.' }];
    case 'outline': case 'band': case 'insight': case 'report':
      return [];
    default: {
      const never: never = kind;
      return never;
    }
  }
}

/** Every kind the table knows -- the round-trip test fails on a kind left out. */
export const WELL_KINDS: TileKind[] = TILE_KINDS.filter(k => wellsFor(k).length > 0);

/** What sits in a well. */
export function wellItems(tile: CanvasTile, well: Well): WellItem[] {
  switch (well.role) {
    case 'dimension':
      return tile.dimensions.map(id => ({ well: well.id, kind: 'dimension', column_id: id }));
    case 'series':
      return tile.series == null ? [] : [{ well: well.id, kind: 'series', column_id: tile.series }];
    case 'measure': {
      const [from, to] = well.slots ?? [0, tile.measures.length];
      return tile.measures.slice(from, to).map((m, i) => ({ well: well.id, kind: 'measure', column_id: m.column_id, index: from + i }));
    }
    case 'mixed':
      return [...tile.dimensions.map(id => ({ well: well.id, kind: 'dimension' as const, column_id: id })),
              ...tile.measures.map((m, i) => ({ well: well.id, kind: 'measure' as const, column_id: m.column_id, index: i }))];
  }
}

export interface Placed { tile: CanvasTile; note?: string }

/** Drop a field into a well.  The well's role decides where it goes; a full well says so in words. */
export function placeInWell(tile: CanvasTile, well: Well, col: CanvasColumn, grouped: boolean): Placed {
  const alreadyHere = wellItems(tile, well).some(i => i.column_id === col.id);
  if (alreadyHere) return { tile, note: `${col.label} is already in ${well.label}.` };
  // a field moves: take it out of wherever else it sits on this tile first
  const base: CanvasTile = {
    ...tile,
    dimensions: tile.dimensions.filter(d => d !== col.id),
    measures: tile.measures.filter(m => m.column_id !== col.id),
    series: tile.series === col.id ? null : tile.series,
  };
  const agg = (SUM_ONLY.includes(tile.kind) ? 'sum' : defaultAggregation(col, grouped)) as Aggregation;
  const value = { column_id: col.id, aggregation: agg };
  switch (well.role) {
    case 'dimension': {
      if (well.max === 1) return { tile: { ...base, dimensions: [col.id] } };
      if (well.max != null && base.dimensions.length >= well.max) return { tile, note: `${well.label} holds ${well.max} field${well.max === 1 ? '' : 's'}; take one out first.` };
      return { tile: { ...base, dimensions: [...base.dimensions, col.id] } };
    }
    case 'series':
      return { tile: { ...base, series: col.id } };
    case 'mixed':
      return { tile: col.column_type === 'measure' || col.column_type === 'kpi'
        ? { ...base, measures: [...base.measures, value] }
        : { ...base, dimensions: [...base.dimensions, col.id] } };
    case 'measure': {
      const [from, to] = well.slots ?? [0, Infinity];
      const measures = [...base.measures];
      if (to - from === 1) {
        // one slot: the value goes INTO the slot and what was there moves along (a scatter's X
        // pushed onto a value dropped on Y first); past the kind's limit the last value goes
        measures.splice(Math.min(from, measures.length), 0, value);
        return { tile: { ...base, measures: measures.slice(0, valueLimit(tile.kind)) } };
      }
      const inWell = measures.slice(from, to).length;
      // the well's own max is the rule (a waterfall of values takes 8 steps though a waterfall with a
      // category takes one -- canvasProblems says which on the tile); a well with no max takes the kind's
      const limit = well.max ?? valueLimit(tile.kind);
      if (inWell >= limit) return { tile, note: `${well.label} holds ${limit} values; take one out first.` };
      measures.splice(Math.min(to, measures.length), 0, value);
      return { tile: { ...base, measures } };
    }
  }
}

/** Take a field out of a well. */
export function removeFromWell(tile: CanvasTile, item: WellItem): CanvasTile {
  if (item.kind === 'dimension') return { ...tile, dimensions: tile.dimensions.filter(d => d !== item.column_id) };
  if (item.kind === 'series') return { ...tile, series: tile.series === item.column_id ? null : tile.series };
  return { ...tile, measures: tile.measures.filter((m, i) => !(i === item.index && m.column_id === item.column_id)) };
}
