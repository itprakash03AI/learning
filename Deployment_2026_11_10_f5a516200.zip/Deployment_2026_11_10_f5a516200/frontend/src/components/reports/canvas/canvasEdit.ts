/**
 * Editing a tile -- the pure rules the designer applies (2026-11-07, moved
 * out of CanvasReportBuilder.tsx so the three-pane designer, its wells and
 * the tests share ONE copy).  Nothing here renders; nothing here decides
 * what is WRONG with a tile -- that is canvasModel.canvasProblems.
 *
 *   addFieldToTile   put a field where this kind of tile uses it
 *   tileForField     a new tile for a field dropped on the empty canvas
 *   changeKind       switch a tile's kind, keeping every field that still fits
 *   removeFieldFromTile   take a field off a tile, wherever it sits
 *   valueLimit       how many values a kind takes
 */
import {
  Aggregation, CanvasColumn, CanvasTile, defaultAggregation, isChart, isMeasureColumn, makeTile,
  MAX_SERIES_VALUES, ONE_VALUE_CHARTS, SERIES_CHARTS, SUM_ONLY, TileKind,
} from './canvasModel';
import { addFieldToOutline } from './canvasOutline';
import { addFieldToInsight, newInsight } from './canvasInsights';

/** the kinds the old "Add a tile" row offered -- kept as the order of the visuals grid's first row */
export const ADDABLE: TileKind[] = ['number', 'bar', 'line', 'pie', 'table', 'pivot', 'outline', 'band', 'insight', 'report'];
/** every kind a tile can be switched to (the old "Show as" menu; the grid changes a selected visual to one of these) */
export const SHOW_AS: TileKind[] = ['number', 'table', 'pivot', 'heatmap', 'bar', 'hbar', 'stacked_bar', 'line', 'area',
  'stacked_area', 'combo', 'radar', 'pie', 'donut', 'treemap', 'funnel', 'waterfall', 'scatter', 'bubble'];
/** the kinds that keep their own settings and are never switched to or from */
export const OWN_SETTINGS: TileKind[] = ['outline', 'band', 'insight', 'report'];

/** How many values a kind of tile takes. */
export function valueLimit(kind: TileKind): number {
  if (kind === 'number' || ONE_VALUE_CHARTS.includes(kind) || kind === 'heatmap') return 1;
  if (kind === 'scatter') return 2;
  if (kind === 'bubble') return 3;
  if (SERIES_CHARTS.includes(kind) || kind === 'combo') return MAX_SERIES_VALUES;
  return 50;
}

export const toCol = (c: any): CanvasColumn => ({
  id: Number(c.id), physical_name: c.physical_name, label: c.friendly_name || c.physical_name,
  data_type: c.data_type, column_type: c.column_type, aggregation: c.aggregation,
  format_pattern: c.format_pattern,
} as CanvasColumn);

/** Put a field on a tile in the place that kind of tile uses it. */
export function addFieldToTile(t: CanvasTile, col: CanvasColumn, grouped: boolean): CanvasTile {
  const measure = isMeasureColumn(col);
  const asValue = { column_id: col.id, aggregation: defaultAggregation(col, grouped) };
  const has = t.dimensions.includes(col.id) || t.measures.some(m => m.column_id === col.id) || t.series === col.id;
  if (has) return t;
  switch (t.kind) {
    case 'outline': return addFieldToOutline(t, col, asValue.aggregation);
    case 'band': return t;
    case 'insight':
      return { ...t, insight: addFieldToInsight(t.insight ?? newInsight('explain_change'), col) };
    case 'number':
      return { ...t, dimensions: [], measures: [asValue] };
    case 'heatmap':
      if (measure) return { ...t, measures: [asValue] };
      if (t.dimensions.length === 0) return { ...t, dimensions: [col.id] };
      return t.series == null ? { ...t, series: col.id } : t;
    case 'pivot':
      if (measure) return { ...t, measures: [...t.measures, asValue] };
      if (t.series == null && t.dimensions.length > 0) return { ...t, series: col.id };
      return { ...t, dimensions: [...t.dimensions, col.id] };
    case 'table':
      return measure ? { ...t, measures: [...t.measures, asValue] } : { ...t, dimensions: [...t.dimensions, col.id] };
    default: {
      if (!isChart(t.kind)) return t;
      if (!measure) {
        if (t.dimensions.length === 0) return { ...t, dimensions: [col.id] };
        if (SERIES_CHARTS.includes(t.kind) && t.series == null && t.measures.length <= 1) return { ...t, series: col.id };
        return t;
      }
      const limit = valueLimit(t.kind);
      const v = SUM_ONLY.includes(t.kind) ? { ...asValue, aggregation: 'sum' as Aggregation } : asValue;
      if (limit === 1) return { ...t, measures: [v] };
      if (t.measures.length >= limit) return t;
      return { ...t, measures: [...t.measures, v], series: t.measures.length >= 1 ? null : t.series };
    }
  }
}

/** Take a field off a tile, wherever it sits (a dimension, a value, the series, an outline level). */
export function removeFieldFromTile(t: CanvasTile, columnId: number): CanvasTile {
  const next: CanvasTile = {
    ...t,
    dimensions: t.dimensions.filter(d => d !== columnId),
    measures: t.measures.filter(m => m.column_id !== columnId),
    series: t.series === columnId ? null : t.series,
  };
  if (Array.isArray(t.levels) && t.levels.includes(columnId)) next.levels = t.levels.filter(l => l !== columnId);
  return next;
}

/** Every column id a tile uses in its fields (not its insight / KPI extras). */
export function tileFieldIds(t: CanvasTile): number[] {
  return [...new Set([...t.dimensions, ...t.measures.map(m => m.column_id), ...(t.series != null ? [t.series] : []), ...(t.levels ?? [])])];
}

/** A new tile for a field dropped on the empty canvas. */
export function tileForField(col: CanvasColumn, tiles: CanvasTile[], grouped: boolean): CanvasTile {
  if (isMeasureColumn(col)) {
    return makeTile('number', { measures: [{ column_id: col.id, aggregation: defaultAggregation(col, grouped) }] }, tiles);
  }
  return makeTile('table', { dimensions: [col.id] }, tiles);
}

/** Switch a tile's kind, keeping every field that still fits. */
export function changeKind(t: CanvasTile, kind: TileKind): CanvasTile {
  const fields = { dimensions: t.dimensions, measures: t.measures, series: t.series };
  let next: CanvasTile = { ...t, kind };
  if (kind === 'number') next = { ...next, dimensions: [], series: null, measures: fields.measures.slice(0, 1), top_n: null, sort: null };
  if (isChart(kind)) {
    const limit = valueLimit(kind);
    const ordered = ['line', 'area', 'stacked_area', 'waterfall', 'scatter', 'bubble'].includes(kind);
    next = { ...next, dimensions: fields.dimensions.slice(0, 1), measures: fields.measures.slice(0, limit),
             series: SERIES_CHARTS.includes(kind) && fields.measures.length <= 1 ? fields.series : null,
             top_n: t.top_n ?? 25,
             sort: ordered ? null : (t.sort ?? { by: 'measure', dir: 'desc' }) };
    if (SUM_ONLY.includes(kind)) next = { ...next, measures: next.measures.map(m => ({ ...m, aggregation: 'sum' as Aggregation })) };
  }
  if (kind === 'heatmap') {
    next = { ...next, dimensions: fields.dimensions.slice(0, 1), measures: fields.measures.slice(0, 1),
             series: fields.series ?? (fields.dimensions[1] ?? null), top_n: null, sort: null };
  }
  if (kind === 'pivot' && next.series == null && next.dimensions.length > 1) {
    next = { ...next, series: next.dimensions[next.dimensions.length - 1], dimensions: next.dimensions.slice(0, -1) };
  }
  if (kind === 'table' || kind === 'pivot') next = { ...next, top_n: null };
  if (kind === 'table') next = { ...next, dimensions: [...next.dimensions, ...(next.series != null ? [next.series] : [])], series: null };
  if (kind === 'report') next = { ...next, dimensions: [], measures: [], series: null, top_n: null, sort: null };
  return next;
}

/** The owner, 2026-11-05: "Fields doesnt come full name".  A long column name has no spaces, so it
 *  breaks anywhere rather than being cut; the mouse says it in full too. */
export const FULL_FIELD_NAME = { overflowWrap: 'anywhere' } as const;

export function fieldHoverText(c: { label: string; physical_name: string }, target: string): string {
  const name = c.physical_name !== c.label ? `${c.label} (${c.physical_name})` : c.label;
  return `${name}\nDrag onto the canvas or a visual -- or click to add it to ${target}`;
}
