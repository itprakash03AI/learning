/**
 * "Read as of" -- the consumer's as-of control on the API Explorer's request builder (2026-11-08,
 * plan docs/SNOWFLAKE_DATABRICKS_GAPS_PLAN_2026_11_08.html section 1.4 step 3).
 *
 * Drawn from the ONE server answer, read for the SELECTED view only through the consumer meta route
 * GET /api/v1/views/{slug} (time_travel_supported / _kinds / _how_listed / _unavailable_reason), under
 * the consumer's own access -- never from the list (review of 1852c1645):
 *
 *   cannot travel      -- the server's reason, in its words; no control
 *   kinds has "id"     -- a version list from GET /api/v1/views/{slug}/versions (version, time, what
 *                         it did; Databricks DESCRIBE HISTORY or an Iceberg table's snapshots), plus
 *                         "As of a time..." when "timestamp" is there too
 *   kinds = timestamp  -- a date-time (UTC); for Snowflake the window the server gives (its words and
 *                         the earliest time it keeps) -- the UI never invents the window, and a time
 *                         before it is refused by the server in words
 *
 * The choice becomes ?snapshot_id= / ?as_of_timestamp= on the request the builder shows and sends,
 * and the answer's meta.time_travel is read back in plain words ("Read as of 2026-11-08 14:02 UTC
 * -- tables: SALES").  The option words and the as-of input are the SQL page's
 * (components/common/tableVersionWords.tsx).
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, FormControl, InputLabel, MenuItem, Select, TextField, Typography,
} from '@mui/material';
import { asOfInputValue, shortTime, versionMenuItems, type TableVersionRow } from '../common/tableVersionWords';

/** The time-travel keys of GET /api/v1/views/{slug} (backend time_travel.time_travel_row) -- read for
 *  the ONE selected view, under the consumer's own access; never carried by the list (review of
 *  1852c1645: the answer costs a parse and a connection read per view, and a non-admin's list rows
 *  are redacted). */
export interface TimeTravelRow {
  time_travel_supported?: boolean | null;
  time_travel_unavailable_reason?: string | null;
  time_travel_kinds?: string[] | null;
  time_travel_how_listed?: string | null;
  time_travel_road?: string | null;
}

/** One table of GET /api/v1/views/{slug}/versions. */
export interface VersionsTable {
  table: string;
  versions?: TableVersionRow[] | null;
  kinds?: string[];
  retention_days?: number | null;
  earliest_time?: string | null;
  reason?: string | null;
  error?: string | null;
  access?: string;
  access_words?: string | null;
}
export interface VersionsAnswer { slug: string; tables: VersionsTable[] }

export type ReadAsOf =
  | { mode: 'now' }
  | { mode: 'version'; snapshotId: string }
  | { mode: 'time'; asOf: string | null };

export const READ_NOW: ReadAsOf = { mode: 'now' };
const NOW = '__now__';
export const AS_OF_TIME = '__as_of_time__';

/** What the choice adds to the request's query string. */
export function readAsOfQuery(c: ReadAsOf | null | undefined): Record<string, string> {
  if (!c || c.mode === 'now') return {};
  if (c.mode === 'version') return c.snapshotId ? { snapshot_id: c.snapshotId } : {};
  return c.asOf ? { as_of_timestamp: c.asOf } : {};
}

/** The answer's meta, in words: what was read as of when.  null when the answer carries nothing. */
export function readAsOfWords(result: any): string | null {
  const meta = result?.meta;
  if (!meta || typeof meta !== 'object') return null;
  const tt = meta.time_travel;
  if (tt && typeof tt === 'object') {
    const tables = Array.isArray(tt.tables) && tt.tables.length ? ` -- tables: ${tt.tables.join(', ')}` : '';
    if (tt.as_of) return `Read as of ${shortTime(String(tt.as_of))}${tables}`;
    if (tt.snapshot_id !== null && tt.snapshot_id !== undefined) return `Read at version ${tt.snapshot_id}${tables}`;
  }
  if (meta.snapshot_id !== null && meta.snapshot_id !== undefined) return `Read at version ${meta.snapshot_id}`;
  if (meta.as_of_timestamp_ms !== null && meta.as_of_timestamp_ms !== undefined) {
    return `Read as of ${shortTime(new Date(Number(meta.as_of_timestamp_ms)).toISOString())}`;
  }
  return null;
}

/** "2026-11-08T14:02" (the input's value, UTC) -> an ISO instant. */
function inputToIso(v: string): string | null {
  if (!v) return null;
  const d = new Date(v.endsWith('Z') ? v : `${v}${v.length === 16 ? ':00' : ''}Z`);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

interface Props {
  slug: string;
  value: ReadAsOf;
  onChange: (c: ReadAsOf) => void;
  /** reads GET /api/v1/views/{slug} -- the consumer meta route, the ONE time-travel answer (the page's
   *  safeFetch, so the session's own access applies, also to a view the person did not publish) */
  fetchMeta: (slug: string) => Promise<TimeTravelRow>;
  /** reads GET /api/v1/views/{slug}/versions (the same way) */
  fetchVersions: (slug: string) => Promise<VersionsAnswer>;
}

const ReadAsOfControl: React.FC<Props> = ({ slug, value, onChange, fetchMeta, fetchVersions }) => {
  const [view, setView] = useState<TimeTravelRow | null>(null);
  const [metaFailed, setMetaFailed] = useState<string | null>(null);
  const [answer, setAnswer] = useState<VersionsAnswer | null>(null);
  const [failed, setFailed] = useState<string | null>(null);
  const supported = view?.time_travel_supported;
  const kinds = view?.time_travel_kinds || [];
  const hasVersions = kinds.includes('id');
  const hasTime = kinds.includes('timestamp');

  // the ONE answer, for the selected view only, once
  useEffect(() => {
    let live = true;
    setView(null);
    setMetaFailed(null);
    Promise.resolve(fetchMeta(slug))
      .then((m) => { if (live) setView(m || {}); })
      .catch((e: any) => { if (live) setMetaFailed(e?.message || String(e)); });
    return () => { live = false; };
  }, [slug, fetchMeta]);

  useEffect(() => {
    let live = true;
    setAnswer(null);
    setFailed(null);
    if (supported !== true) return undefined;
    Promise.resolve(fetchVersions(slug))
      .then((a) => { if (live) setAnswer(a); })
      .catch((e: any) => { if (live) setFailed(e?.message || String(e)); });
    return () => { live = false; };
  }, [slug, supported, fetchVersions]);

  if (metaFailed) {
    return (
      <Alert severity="warning" data-testid="read-as-of-unavailable" sx={{ mb: 2 }}>
        {`Whether this API can be read as of a time could not be determined: ${metaFailed}`}
      </Alert>
    );
  }
  if (view === null) {
    return (
      <Typography variant="caption" color="text.secondary" display="block" mb={2} data-testid="read-as-of-loading">
        Checking whether this API can be read as of a time...
      </Typography>
    );
  }
  if (supported === false) {
    return (
      <Alert severity="info" data-testid="read-as-of-unavailable" sx={{ mb: 2 }}>
        {view.time_travel_unavailable_reason || 'This API cannot be read as of a time.'}
      </Alert>
    );
  }
  if (supported !== true) {
    return (
      <Alert severity="warning" data-testid="read-as-of-unavailable" sx={{ mb: 2 }}>
        {view.time_travel_unavailable_reason
          || 'Whether this API can be read as of a time could not be determined.'}
      </Alert>
    );
  }

  const tables = answer?.tables || [];
  const oneTable = tables.length === 1 ? tables[0] : null;
  const versionList = hasVersions && oneTable && Array.isArray(oneTable.versions) ? oneTable.versions : null;
  const selected = value.mode === 'now' ? NOW : value.mode === 'time' ? AS_OF_TIME : value.snapshotId;
  const query = readAsOfQuery(value);
  const requestWords = Object.keys(query).length
    ? `Adds to the request: ?${Object.entries(query).map(([k, v]) => `${k}=${v}`).join('&')}`
    : 'Nothing added: the API is read as it is now.';

  return (
    <Box mb={2} data-testid="read-as-of">
      <Typography variant="caption" color="text.secondary" display="block" mb={0.5}>
        Read as of -- the data as it was at a time{hasVersions ? ' or at a version' : ''}.
        {view.time_travel_how_listed ? ` ${view.time_travel_how_listed}.` : ''}
      </Typography>
      <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start', flexWrap: 'wrap' }}>
        <FormControl size="small" sx={{ minWidth: 320 }}>
          <InputLabel id={`read-as-of-${slug}-label`}>Read as of</InputLabel>
          <Select
            labelId={`read-as-of-${slug}-label`}
            label="Read as of"
            value={selected}
            inputProps={{ 'data-testid': 'read-as-of-select', 'aria-label': 'Read as of' }}
            onChange={(e) => {
              const v = String(e.target.value);
              if (v === NOW) onChange(READ_NOW);
              else if (v === AS_OF_TIME) onChange({ mode: 'time', asOf: null });
              else onChange({ mode: 'version', snapshotId: v });
            }}
            renderValue={(v) => (v === NOW ? 'Now (the data as it is)'
              : v === AS_OF_TIME ? (value.mode === 'time' && value.asOf ? `As of ${shortTime(value.asOf)}` : 'As of a time...')
              : `Version ${v}`)}
          >
            <MenuItem value={NOW} data-testid="read-as-of-now">Now (the data as it is)</MenuItem>
            {hasTime ? <MenuItem value={AS_OF_TIME} data-testid="read-as-of-time">As of a time...</MenuItem> : null}
            {versionList ? versionMenuItems(versionList, 'read-as-of-version') : null}
          </Select>
        </FormControl>
        {value.mode === 'time' ? (
          <TextField
            size="small" type="datetime-local" label="As of (UTC)"
            InputLabelProps={{ shrink: true }}
            defaultValue={value.asOf ? asOfInputValue(Date.parse(value.asOf)) : ''}
            inputProps={{ 'data-testid': 'read-as-of-input', 'aria-label': 'As of time (UTC)' }}
            onChange={(e) => onChange({ mode: 'time', asOf: inputToIso(e.target.value) })}
          />
        ) : null}
      </Box>
      <Typography variant="caption" color="text.secondary" display="block" data-testid="read-as-of-request">
        {requestWords}
      </Typography>
      {failed ? (
        <Typography variant="caption" color="error" display="block" data-testid="read-as-of-failed">
          {`The versions could not be read: ${failed}`}
        </Typography>
      ) : null}
      {hasVersions && tables.length > 1 ? (
        <Typography variant="caption" color="text.secondary" display="block" data-testid="read-as-of-several">
          {`This API reads ${tables.length} tables; a version number belongs to one table, so pick a time.`}
        </Typography>
      ) : null}
      {tables.map((t, i) => (
        <Box key={t.table} data-testid={`read-as-of-table-${i}`}>
          {t.earliest_time ? (
            <Typography variant="caption" color="text.secondary" display="block">
              {`Earliest time the source keeps for ${t.table}: ${shortTime(t.earliest_time)}.`}
            </Typography>
          ) : null}
          {t.error || t.reason ? (
            <Typography variant="caption" color={t.error ? 'error' : 'text.secondary'} display="block">
              {t.error || t.reason}
            </Typography>
          ) : null}
          {t.access_words ? (
            <Typography variant="caption" color="text.secondary" display="block">{t.access_words}</Typography>
          ) : null}
        </Box>
      ))}
    </Box>
  );
};

export default ReadAsOfControl;
