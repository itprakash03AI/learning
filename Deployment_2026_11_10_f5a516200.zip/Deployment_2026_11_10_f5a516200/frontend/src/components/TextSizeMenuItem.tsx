/**
 * "Text size" in the user menu (2026-11-10, the owner on UAT): Smaller / Default / Larger / Largest --
 * a multiplier on the size the screen gives (src/utils/textSize.ts, src/index.css).  The menu and every
 * rem-sized panel grow with it, so nothing wraps.
 */
import React, { useState } from 'react';
import { Box, ToggleButton, ToggleButtonGroup, Typography } from '@mui/material';
import FormatSizeIcon from '@mui/icons-material/FormatSize';
import { applyTextSize, readTextSize, TEXT_SIZES, TextSize } from '../utils/textSize';

const TextSizeMenuItem: React.FC = () => {
  const [size, setSize] = useState<TextSize>(readTextSize());
  return (
    <Box sx={{ px: 2, py: 1 }} data-testid="text-size" onClick={e => e.stopPropagation()}>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
        <FormatSizeIcon fontSize="small" sx={{ mr: 1 }} /> Text size
      </Typography>
      <ToggleButtonGroup size="small" exclusive value={size} aria-label="Text size"
        onChange={(_e, v: TextSize | null) => { if (!v) return; setSize(v); applyTextSize(v, true); }}>
        {TEXT_SIZES.map(t => (
          <ToggleButton key={t.value} value={t.value} data-testid={`text-size-${t.value}`} sx={{ textTransform: 'none', px: 1 }}>
            {t.label}
          </ToggleButton>
        ))}
      </ToggleButtonGroup>
    </Box>
  );
};

export default TextSizeMenuItem;
