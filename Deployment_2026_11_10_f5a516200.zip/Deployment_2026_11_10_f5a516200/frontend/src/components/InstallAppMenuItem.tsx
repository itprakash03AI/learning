/**
 * "Install QueryStudio" / "Install Reports" in the user menu -- shown ONLY while the browser
 * offers to install the app (desktop step one, 2026-11-08; src/installable/installPrompt.ts).
 */
import React from 'react';
import { MenuItem } from '@mui/material';
import InstallDesktopIcon from '@mui/icons-material/InstallDesktop';
import { installableAppName, useInstallPrompt } from '../installable/installPrompt';

interface Props {
  /** closes the menu around it */
  onDone?: () => void;
}

const InstallAppMenuItem: React.FC<Props> = ({ onDone }) => {
  const { prompt, install } = useInstallPrompt();
  if (!prompt) return null;
  const name = installableAppName();
  return (
    <MenuItem
      data-testid="install-app"
      onClick={async () => { onDone?.(); await install(); }}
    >
      <InstallDesktopIcon fontSize="small" sx={{ mr: 1 }} />
      Install {name}
    </MenuItem>
  );
};

export default InstallAppMenuItem;
