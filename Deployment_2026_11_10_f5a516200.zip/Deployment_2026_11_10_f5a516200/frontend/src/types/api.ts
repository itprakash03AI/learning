/**
 * Phase 117 — Shared TypeScript interfaces for API responses.
 * Replaces scattered `any` types across the codebase.
 */

// ── Connections ──────────────────────────────────────────────────────────────

export interface Connection {
  id: number;
  name: string;
  connection_type: 's3' | 'snowflake' | 'databricks' | 'trino' | 'starburst' | 'oracle' | 'athena' | 'rest_api' | 'postgresql' | 'local' | 'upload';
  config: Record<string, unknown>;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  created_by?: string;
}

// ── Tables & Files ───────────────────────────────────────────────────────────

export interface TableFile {
  key: string;
  path: string;
  name: string;
  size?: number;
  last_modified?: string;
  is_folder?: boolean;
  is_partition?: boolean;
  partition_column?: string;
  partition_value?: string;
  file_count?: number;
}

export interface Column {
  name: string;
  type: string;
  nullable?: boolean;
  description?: string;
  is_partition?: boolean;
  friendly_name?: string;
  format_pattern?: string;
  column_type?: 'dimension' | 'measure' | 'detail' | 'kpi';
  aggregation?: string;
}

// ── Query Building ───────────────────────────────────────────────────────────

export interface Filter {
  column: string;
  operator: string;
  value: string | string[];
  _partition?: boolean;
}

export interface Join {
  left_file: string;
  right_file: string;
  left_on: string[];
  right_on: string[];
  how: 'inner' | 'left' | 'right' | 'cross';
  right_suffix?: string;
}

export interface Aggregation {
  column: string;
  function: 'SUM' | 'AVG' | 'COUNT' | 'MIN' | 'MAX' | 'COUNT_DISTINCT';
  alias: string;
  distinct?: boolean;
}

export interface OrderBy {
  column: string;
  direction: 'ASC' | 'DESC';
}

export interface QueryConfig {
  connection_id: number;
  files: string[];
  columns?: string[];
  joins?: Join[];
  filters?: Filter[];
  order_by?: OrderBy[];
  limit?: number | null;
  aggregations?: Aggregation[];
  distinct?: boolean;
  filter_logic?: 'AND' | 'OR';
}

// ── Query Results ────────────────────────────────────────────────────────────

export interface QueryResult {
  execution_id: string;
  status: 'completed' | 'failed' | 'processing' | 'queued';
  columns: string[];
  rows: any[][];
  row_count: number;
  execution_time_ms: number;
  cache_hit?: boolean;
  error?: string;
}

// ── Users & Auth ─────────────────────────────────────────────────────────────

export interface User {
  username: string;
  role: 'admin' | 'analyst' | 'viewer' | 'super_admin';
  is_admin?: boolean;
  display_name?: string;
  email?: string;
  created_at?: string;
  last_login_at?: string;
}

// ── Audit ────────────────────────────────────────────────────────────────────

export interface AuditEntry {
  id: number;
  timestamp: string;
  username: string;
  action: string;
  resource_type?: string;
  resource_id?: string;
  ip_address?: string;
  details?: Record<string, unknown>;
}

// ── Cache ────────────────────────────────────────────────────────────────────

export interface CacheEntry {
  cache_key: string;
  connection_id: number;
  created_at: string;
  expires_at: string;
  row_count: number;
  size_bytes: number;
  hit_count: number;
  source_fingerprint?: string;
  is_stale?: boolean;
}

// ── Business Reports ─────────────────────────────────────────────────────────

export interface BusinessReport {
  id: number;
  name: string;
  description?: string;
  // 'dataset' and 'saved_query' are one shape (dataset-backed); the backend
  // stores 'saved_query' and reads 'dataset' as its alias (FB-46).
  // 2026-11-07 (the report framework): also any kind the registry knows (file, rest_api, a plugin's)
  data_source_type: 'dataset' | 'saved_query' | 'raw_sql' | 'published_view' | 'federation_view' | 'pivot' | (string & {});
  dataset_id?: number;
  published_view_id?: number;
  layout_config: Record<string, unknown>;
  owner: string;
  is_published?: boolean;
  created_at: string;
  updated_at: string;
}

export interface ReportParameter {
  id: number;
  report_id: number;
  param_name: string;
  param_type: 'text' | 'number' | 'date' | 'select' | 'multi_select' | 'date_range';
  default_value?: string;
  lov_source?: string;
  lov_dataset_id?: number;
  required?: boolean;
  display_order?: number;
}

// ── Pivot Config ─────────────────────────────────────────────────────────────

export interface PivotValueField {
  column_id: number;
  aggregation: string;
  alias?: string;
}

export interface PivotConfig {
  row_field_ids: number[];
  col_field_ids: number[];
  value_fields: PivotValueField[];
  show_row_totals?: boolean;
  show_col_totals?: boolean;
  show_grand_total?: boolean;
}

// ── Style Config ─────────────────────────────────────────────────────────────

export interface StyleConfig {
  header_bg?: string;
  header_fg?: string;
  row_alt_bg?: string;
  negative_color?: string;
  negative_format?: 'minus' | 'parentheses' | 'red' | 'red_parentheses';
}

// ── Published Views ──────────────────────────────────────────────────────────

export interface PublishedView {
  id: number;
  name: string;
  slug: string;
  description?: string;
  dataset_id: number;
  query_config: QueryConfig;
  param_definitions?: Record<string, unknown>[];
  cache_ttl: number;
  version: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// ── Data Quality ─────────────────────────────────────────────────────────────

export interface DataQualityRule {
  id: number;
  name: string;
  rule_type: 'freshness' | 'schema_drift' | 'null_rate' | 'row_count' | 'custom_sql';
  connection_id: number;
  table_name: string;
  config: Record<string, unknown>;
  severity: 'info' | 'warning' | 'critical';
  is_active: boolean;
  last_result?: 'pass' | 'fail' | null;
}

// ── Health ────────────────────────────────────────────────────────────────────

export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  database: { ok: boolean };
  s3: { status: string };
  disk: { free_gb: number; used_pct: number; warning: boolean };
  queries: {
    active: number;
    max_concurrent_global: number;
    per_user_limit: number;
    queue_waiting: number;
  };
}

// ── Progressive partition loading (2026-09-05) ────────────────────────────────
//
// The client-side mirror of ``api/models/query_models.py::PartitionConfigModel``
// -- the ONE typed model both backend lanes validate against.  Declared here
// for the same reason it is declared there: a field that is not declared gets
// DROPPED on the way through, the save returns 200 having stored nothing, and
// the feature is unreachable on every object that could exist.  That is
// exactly how ``partition_config`` came to have readers and no producer, and
// ``services/api/core.ts::toBackendQueryConfig`` is this side's equivalent
// choke point.
//
// Every field is optional and ABSENT MEANS "the server's default".  The UI
// never writes a default in: storing the model's dump would freeze today's
// defaults into the document, and the round-trip an author reads back would
// not be the document they sent.  Bounds are NOT restated here -- they belong
// to the server, which refuses out-of-range values with a 422 naming the key.
export interface PartitionConfig {
  /** The column to split on.  Setting it is what turns the feature ON. */
  column?: string;
  /** false turns the feature off WITHOUT losing the column. */
  enabled?: boolean;
  max_buckets?: number;
  max_concurrent?: number;
  target_rows_per_bucket?: number;
  bucket_size?: number;
  /** "auto" packs an over-cap value set to fit; "fixed" refuses instead. */
  bucket_strategy?: string;
  discovery_sql?: string;
  discovery_with_counts?: boolean;
  discovery_wrap?: boolean;
  /** Tri-state ON PURPOSE: absent => on iff discovery_sql is set. */
  preflight_count?: boolean;
  max_discovery_values?: number;
  rows_per_part?: number;
}

/** One named refusal from ``core/scan_partitions/refusals.py``.  Every field
 *  is the SERVER's text and is rendered verbatim -- a paraphrase of a refusal
 *  is a second opinion about why something did not happen. */
export interface ScanRefusal {
  code: string;
  subject: string;
  detail: string;
  remedy: string;
}

/** ``ScanPartitionPlan.to_dict()`` as it is stamped on an execution, plus the
 *  two shapes the engine stamps INSTEAD of a plan (a dataset-level conflict,
 *  and a planner that raised).  All optional: which keys are present is what
 *  distinguishes those cases, so nothing here may be defaulted. */
export interface ScanPlanVerdict {
  mode?: string;
  partition_column?: string | null;
  bucket_count?: number;
  refusal?: ScanRefusal | null;
  /** Stamped by federation_engine when the dataset's own source tables
   *  disagree -- there is no plan to refuse because none was attempted. */
  declined?: string;
  detail?: string;
  /** Planning itself raised.  An optimisation that breaks must not be the
   *  reason a report fails, so the query ran whole and this is why. */
  planner_error?: string;
  exactness_reason?: string;
  coverage_proof?: string;
  discovery_source?: string;
  counts_are_output_rows?: boolean;
  build_failed?: boolean;
  expected_total?: number | null;
  max_concurrent?: number;
}

/** ``core/scan_partitions/ledger.py::to_dict`` — the completeness ledger for
 *  a scan that actually split.  Same COMPLETE/INCOMPLETE/UNVERIFIED
 *  vocabulary as the Completeness Certificate. */
export interface ScanCompleteness {
  verdict?: string;
  verdict_reason?: string;
  rows_written?: number;
  expected_total?: number | null;
  gates?: Array<{ id?: string; name?: string; status?: string;
                  expected?: number | null; actual?: number | null;
                  detail?: string }>;
  notes?: string[];
}
