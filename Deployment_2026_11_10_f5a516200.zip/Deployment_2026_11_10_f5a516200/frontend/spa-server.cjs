#!/usr/bin/env node
/**
 * The UI image's static server (FB-47, 2026-09-20).
 *
 * Replaces `serve -s build`, whose single-page fallback answered a MISSING
 * hashed chunk with 200 text/html:
 *
 *     GET /assets/PivotReportBuilder-CvBjHnik.js  -> 200 text/html <!DOCTYPE html>
 *
 * A tab left open across a UI rebuild asks for the chunk hash it was built
 * with; the container holds the new hash; the browser receives HTML where
 * it expects an ES module and fails on whichever lazy route the user opens
 * next -- which makes it look random.  The history fallback belongs to
 * ROUTES.  Here:
 *
 *   * a path with a file extension is a FILE: served if it exists, 404 if
 *     not -- /assets/<missing>.js is a 404, never index.html;
 *   * everything else is a route and gets index.html (the SPA decides);
 *   * hashed assets under /assets/ are immutable and cached for a year;
 *     index.html, config.js/json and version.json are never cached, so a
 *     reload always sees the current deployment.
 *
 * No dependencies, no env vars, no nginx: node's http + fs, ~100 lines.
 *
 *   usage: node spa-server.cjs <build-dir> <port>
 *   (.cjs: frontend/package.json is "type": "module"; the server is plain CommonJS)
 */
'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const root = path.resolve(process.argv[2] || 'build');
const port = parseInt(process.argv[3] || process.env.PORT || '8080', 10);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.wasm': 'application/wasm',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
};

//: Never cached: the entry points a reload must re-read.
// 2026-11-08 (desktop step one): the service worker is revalidated on every start (a new build
// must replace the shell); the manifest is composed per request from config.json.
const NO_CACHE = new Set(['/index.html', '/config.js', '/config.json', '/version.json', '/sw.js', '/manifest.webmanifest']);

/** The web app manifest for THIS deployment: its name from config.json (appName, else the
 *  product's default) -- frontend/sw/build.cjs::manifestFor, shipped beside this server.  Without
 *  the builder (an image that predates it) the static file from the build is served. */
function manifestBody() {
  let cfg = {};
  try {
    cfg = JSON.parse(fs.readFileSync(path.join(root, 'config.json'), 'utf-8'));
  } catch (e) { /* the defaults */ }
  try {
    const { manifestFor } = require(path.join(__dirname, 'sw', 'build.cjs'));
    return JSON.stringify(manifestFor(cfg), null, 2) + '\n';
  } catch (e) {
    try { return fs.readFileSync(path.join(root, 'manifest.webmanifest'), 'utf-8'); } catch (e2) { return null; }
  }
}

// ── Who may put a page in an <iframe> (2026-10-02) ────────────────────────
//
// This server sent NO frame policy, so any website could frame any
// QueryStudio page -- the login form and the admin screens included
// (clickjacking).  Three kinds of page are MEANT to be framed by another
// origin, and only they are:
//
//   /embedded-business-report/<token>   a report in a partner's portal
//   /shared...                          share links (business report, query,
//                                       dashboard) a partner may also frame
//   /addin/...                          the Excel add-in task pane, which
//                                       Office loads inside its own iframe
//
// Those take `frame-ancestors` from the list an admin saves on Admin -> Embedding
// sites (read below every 30 s, so a new site needs no deployment); with nothing
// saved, from the deployment's config.json (`"frameAncestors": [...]`); absent, any
// origin may frame them (what embedding already did).  Every other page is
// same-origin only.  No env vars: config.json is the UI's one runtime file.
const FRAMEABLE = [/^\/embedded-business-report\//, /^\/shared(-[a-z-]+)?\//, /^\/addin\//];
let _ancestorsCache = { mtimeMs: -1, value: '*' };
const SITES_POLL_MS = Number(process.env.SPA_SITES_POLL_MS) || 30000;
/** The list saved by an admin, as header text; null = nothing saved / not read yet: config.json applies. */
let _savedSites = null;

const ancestorsText = list => {
  const ok = (Array.isArray(list) ? list : [])
    .filter(o => typeof o === 'string' && /^https?:\/\/[^\s;,'"]+$/.test(o));
  return ok.length ? ok.join(' ') : '*';
};

function readSavedSitesFrom(base, done) {
  let url;
  try {
    url = new URL('/api/embed-sites', base);
  } catch (e) {
    return done(false);
  }
  const req = (url.protocol === 'https:' ? https : http).get(url, { timeout: 3000 }, res => {
    let body = '';
    res.setEncoding('utf8');
    res.on('data', c => { body += c; });
    res.on('end', () => {
      try {
        if (res.statusCode !== 200) return done(false);
        const r = JSON.parse(body);
        _savedSites = r.configured ? ancestorsText(r.sites) : null;
        done(true);
      } catch (e) {
        done(false);
      }
    });
  });
  req.on('timeout', () => req.destroy());
  req.on('error', () => done(false));
}

let _sitesReadFails = 0;
/** A failed read keeps the last good list: the outcome is logged, and the admin screen compares what is sent. */
function refreshSavedSites() {
  let cfg = {};
  try {
    cfg = JSON.parse(fs.readFileSync(path.join(root, 'config.json'), 'utf-8'));
  } catch (e) { /* no addresses to try */ }
  const bases = [cfg.internalApiUrl, cfg.apiUrl].filter(Boolean);
  const next = i => {
    if (i >= bases.length) {
      if (bases.length && _sitesReadFails++ === 0) {
        console.warn(`[frame-policy] could not read /api/embed-sites from ${bases.join(' or ')}; keeping the current list`);
      }
      return;
    }
    readSavedSitesFrom(bases[i], ok => {
      if (ok) _sitesReadFails = 0;
      else next(i + 1);
    });
  };
  next(0);
}
refreshSavedSites();
setInterval(refreshSavedSites, SITES_POLL_MS).unref();

function frameAncestors() {
  if (_savedSites !== null) return _savedSites;
  const file = path.join(root, 'config.json');
  try {
    const st = fs.statSync(file);
    if (st.mtimeMs !== _ancestorsCache.mtimeMs) {
      const list = JSON.parse(fs.readFileSync(file, 'utf-8')).frameAncestors;
      _ancestorsCache = { mtimeMs: st.mtimeMs, value: ancestorsText(list) };
    }
  } catch (e) {
    _ancestorsCache = { mtimeMs: -1, value: '*' };
  }
  return _ancestorsCache.value;
}

function frameHeaders(routePath) {
  if (FRAMEABLE.some(re => re.test(routePath))) {
    return { 'Content-Security-Policy': `frame-ancestors ${frameAncestors()}` };
  }
  return { 'X-Frame-Options': 'SAMEORIGIN', 'Content-Security-Policy': "frame-ancestors 'self'" };
}

function send(res, status, headers, body) {
  res.writeHead(status, headers);
  res.end(body);
}

function serveFile(res, filePath, urlPath, method, routePath) {
  const ext = path.extname(filePath).toLowerCase();
  const type = MIME[ext] || 'application/octet-stream';
  const immutable = urlPath.startsWith('/assets/') && !NO_CACHE.has(urlPath);
  const headers = {
    'Content-Type': type,
    'Cache-Control': NO_CACHE.has(urlPath)
      ? 'no-store'
      : (immutable ? 'public, max-age=31536000, immutable' : 'public, max-age=300'),
    'X-Content-Type-Options': 'nosniff',
    ...(type.startsWith('text/html') ? frameHeaders(routePath || urlPath) : {}),
  };
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) {
      return send(res, 404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' },
                  `404 Not Found: ${urlPath}\n`);
    }
    headers['Content-Length'] = st.size;
    if (method === 'HEAD') return send(res, 200, headers, '');
    res.writeHead(200, headers);
    fs.createReadStream(filePath).pipe(res);
  });
}

const server = http.createServer((req, res) => {
  const method = req.method || 'GET';
  if (method !== 'GET' && method !== 'HEAD') {
    return send(res, 405, { 'Content-Type': 'text/plain; charset=utf-8', Allow: 'GET, HEAD' }, 'Method Not Allowed\n');
  }
  let urlPath;
  try {
    urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
  } catch (e) {
    return send(res, 400, { 'Content-Type': 'text/plain; charset=utf-8' }, 'Bad Request\n');
  }
  if (urlPath === '/') urlPath = '/index.html';
  if (urlPath === '/manifest.webmanifest') {
    const body = manifestBody();
    if (body === null) {
      return send(res, 404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }, '404 Not Found\n');
    }
    return send(res, 200, { 'Content-Type': MIME['.webmanifest'], 'Cache-Control': 'no-store',
                            'X-Content-Type-Options': 'nosniff' }, method === 'HEAD' ? '' : body);
  }
  const filePath = path.normalize(path.join(root, urlPath));
  if (!filePath.startsWith(root + path.sep) && filePath !== root) {
    return send(res, 403, { 'Content-Type': 'text/plain; charset=utf-8' }, 'Forbidden\n');
  }
  const hasExtension = path.extname(urlPath) !== '';
  if (hasExtension) {
    // A file: it exists or it is a 404.  The fallback is for routes only.
    return serveFile(res, filePath, urlPath, method);
  }
  // A route: the SPA's index.html decides what it is (including its own 404 page).
  return serveFile(res, path.join(root, 'index.html'), '/index.html', method, urlPath);
});

// 2026-09-20 -- bind BOTH stacks, not '0.0.0.0'.
//
// Measured in the running container: with an IPv4-only bind, /etc/hosts maps
// `localhost` to 127.0.0.1 AND ::1, wget tries ::1 first, and the health
// check answered "Connection refused" forever -- 66 consecutive failures
// while every page served perfectly.  `docker ps` showed the UI red, which
// is worse than showing nothing: a genuinely broken UI looks identical, and
// an orchestrator that waits on the health state never proceeds.
//
// Node's default (no host argument) listens on :: with IPv4 mapped in, so
// 127.0.0.1, ::1 and the container's routable address all answer.  Fixed
// HERE rather than in the health check, because the health check is not the
// only caller that will reach for `localhost`.
server.listen(port, () => {
  console.log(`[spa-server] serving ${root} on :${port} (dual-stack) -- files 404 when missing, routes get index.html`);
});
