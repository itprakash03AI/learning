"""Published-view SCHEMA versions and the drift notice (2026-09-27).

A published view is a contract: a consumer's client is written against the
column list ``GET /api/v1/views/{slug}`` returned on the day the key was
issued.  Three things change that list without anyone telling the consumer:

* a REPUBLISH re-snapshots ``query_config`` from the source;
* ``PUT .../query`` / ``PUT`` with a new ``query_config``;
* an AUTO-DETECT on the dataset behind a report-sourced view, which
  renames / adds / re-types the dataset's columns in place (and the view
  serves the report's columns by dataset id, so it moves with them).

WHAT EXISTED, AND WHAT IS REUSED.  ``published_views.version`` /
``query_hash`` (Phase 98-D) already bump on any query_config change; they say
THAT something changed, not WHAT.  ``api_access_log`` is the usage record
and ``api_keys.scoped_view_ids`` (empty = every view, the same rule
``_check_view_access`` applies) says WHO can call a view.  ``core/email_service``
is the one mail chokepoint.  This module adds the one missing piece -- a
recorded column list per version with the diff -- and joins the four.

THE RULES.

* ``current_columns`` answers ``None`` when it CANNOT TELL (a saved query
  with no ``selected_columns`` and no cached parquet; a federation view).
  Unknown is not empty: nothing is recorded and nothing is announced, and
  the caller's log line says so.  An empty list is a real schema.
* ``record_schema`` writes a version ONLY when the column set differs from
  the latest recorded one (names + types); a republish that changes nothing
  records nothing.  The first record (version 1) is the baseline and never
  notifies -- there is no change to announce.
* A notice goes to the OWNERS OF THE KEYS that can call the view, by email
  through ``core.email_service.send_email``.  A username is not an address:
  ``created_by`` containing '@' is used as-is; otherwise
  ``published_views.notify_email_domain`` is appended; with no domain the
  owner is recorded as UNROUTED on the version row and given an in-app
  notification instead.  Whatever happened is written to ``notified`` --
  "was anyone told" is answerable from the row.
* Every step is best-effort and fail-open: a broken mail server or a
  missing table must never be the reason a republish fails.  A failure is
  logged with its reason and recorded on the row when there is one.
"""
from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

REASONS = ("publish", "republish", "query_update", "update", "dataset_auto_detect")


# ── the column list a consumer sees ─────────────────────────────────────────

def _norm(cols: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    seen = set()
    for c in cols or []:
        if isinstance(c, dict):
            name = str(c.get("name") or c.get("columnName") or c.get("physical_name") or "").strip()
            ctype = str(c.get("type") or c.get("data_type") or "string").strip().lower()
        else:
            name, ctype = str(c or "").strip(), "string"
        if not name or name.lower() in seen:
            continue
        seen.add(name.lower())
        out.append({"name": name, "type": ctype or "string"})
    return out


def columns_hash(cols: List[Dict[str, str]]) -> str:
    canon = [(c["name"].lower(), c["type"]) for c in _norm(cols)]
    return hashlib.sha256(json.dumps(canon, sort_keys=False).encode()).hexdigest()


def current_columns(db, pv: Dict[str, Any]) -> Optional[List[Dict[str, str]]]:
    """The column list ``pv`` serves NOW, or ``None`` when it cannot be told.

    Mirrors what ``GET /api/v1/views/{slug}`` reports: ``selected_columns``
    from the frozen config first (the saved-query lane), then -- for a
    report-sourced view -- the report's dataset columns restricted to the
    report's ``column_ids`` (what the executor projects), then the cached
    parquet's schema.  A source that no longer exists is ``None``.
    """
    try:
        qc = dict(pv.get("query_config") or {})
        from api.published_views.helpers import _extract_schema_from_config
        cols = _extract_schema_from_config(qc)
        if cols:
            return _norm(cols)
        if (pv.get("source_type") or "saved_query") == "business_report":
            br = db.get_business_report(pv.get("business_report_id"))
            if not br:
                return None
            if not br.get("dataset_id"):
                # raw_sql / published_view-sourced report: no dataset columns
                # to read -- fall through to the cached parquet
                pass
            else:
                ds = db.get_dataset_full(br["dataset_id"]) or {}
                ordered = [int(x) for x in (br.get("column_ids") or []) if x is not None]
                wanted = set(ordered)
                by_id = {}
                for c in ds.get("columns") or []:
                    try:
                        by_id[int(c.get("id"))] = c
                    except (TypeError, ValueError):
                        continue
                # in the REPORT's column order -- the order the executor
                # projects and a consumer reads positionally
                chosen = ([by_id[i] for i in ordered if i in by_id] if wanted
                          else list(by_id.values()))
                out = [{"name": c.get("physical_name") or "",
                        "type": c.get("data_type") or "string"} for c in chosen]
                if out:
                    return _norm(out)
        from api.published_views.helpers import _extract_schema_from_cache
        cached = _extract_schema_from_cache(pv)
        if cached:
            return _norm(cached)
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("[pv-schema] columns of view %s could not be read: %s",
                       pv.get("id"), exc)
        return None
    return None


def diff_columns(before: List[Dict[str, str]], after: List[Dict[str, str]]) -> Dict[str, list]:
    b = {c["name"].lower(): c for c in _norm(before)}
    a = {c["name"].lower(): c for c in _norm(after)}
    added = [a[k] for k in a if k not in b]
    removed = [b[k] for k in b if k not in a]
    retyped = [{"name": a[k]["name"], "from": b[k]["type"], "to": a[k]["type"]}
               for k in a if k in b and a[k]["type"] != b[k]["type"]]
    return {"added": added, "removed": removed, "retyped": retyped}


# ── recording ───────────────────────────────────────────────────────────────

def record_schema(db, pv: Dict[str, Any], *, reason: str,
                  changed_by: Optional[str] = None,
                  columns: Optional[List[Dict[str, Any]]] = None,
                  notify: bool = True) -> Optional[Dict[str, Any]]:
    """Record the view's current schema if it differs from the last recorded
    one.  Returns the new version row, or ``None`` when nothing was recorded
    (unchanged, or the columns could not be told).  Never raises."""
    if reason not in REASONS:
        reason = "update"
    try:
        cols = _norm(columns) if columns is not None else current_columns(db, pv)
        if cols is None:
            logger.info("[pv-schema] view %s (%s): columns unknown after %s -- "
                        "nothing recorded (unknown is not empty)",
                        pv.get("id"), pv.get("slug"), reason)
            return None
        h = columns_hash(cols)
        latest = db.latest_pv_schema_version(int(pv["id"]))
        if latest and latest.get("columns_hash") == h:
            return None
        changes = diff_columns(latest.get("columns") or [], cols) if latest else None
        row = db.add_pv_schema_version(int(pv["id"]), columns=cols, columns_hash=h,
                                       changes=changes, reason=reason,
                                       changed_by=changed_by)
        if latest is None:
            return row                    # the baseline: nothing to announce
        logger.info("[pv-schema] view %s (%s): schema v%s after %s -- +%d / -%d / ~%d",
                    pv.get("id"), pv.get("slug"), row["version_no"], reason,
                    len(changes["added"]), len(changes["removed"]), len(changes["retyped"]))
        if notify:
            verdict = notify_owners(db, pv, row)
            try:
                db.set_pv_schema_version_notified(int(row["id"]), verdict)
                row["notified"] = verdict
            except Exception:                                # noqa: BLE001
                logger.debug("[pv-schema] notified verdict not stored", exc_info=True)
        return row
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("[pv-schema] recording the schema of view %s failed "
                       "(fail-open): %s", pv.get("id"), exc)
        return None


def note_dataset_columns_changed(db, dataset_id: int, *,
                                 changed_by: Optional[str] = None) -> List[Dict[str, Any]]:
    """Auto-detect moved the columns of ``dataset_id``: re-record every ACTIVE
    report-sourced view over a report on that dataset.  Returns the version
    rows recorded (empty when nothing changed for any view)."""
    out: List[Dict[str, Any]] = []
    try:
        for rid in db.list_business_report_ids_for_dataset(int(dataset_id)):
            for pv in db.list_published_views_for_report(int(rid)):
                row = record_schema(db, pv, reason="dataset_auto_detect",
                                    changed_by=changed_by)
                if row:
                    out.append(row)
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("[pv-schema] dataset %s change could not be propagated "
                       "to its views (fail-open): %s", dataset_id, exc)
    return out


# ── notification ────────────────────────────────────────────────────────────

def _address_for(username: str, domain: str) -> Optional[str]:
    u = str(username or "").strip()
    if not u:
        return None
    if "@" in u:
        return u
    d = str(domain or "").strip().lstrip("@")
    return f"{u}@{d}" if d else None


def owners_for_view(db, view_id: int) -> List[Dict[str, Any]]:
    """``[{"username", "key_name", "scope"}]`` for the keys that can call the
    view, one entry per key (an owner with two keys appears twice; the mail
    is sent once per address)."""
    out = []
    for k in db.list_api_keys_for_view(int(view_id)) or []:
        out.append({"username": k.get("created_by") or "", "key_name": k.get("name"),
                    "scope": k.get("scope", "view")})
    return out


def _render_notice(pv: Dict[str, Any], version: Dict[str, Any]) -> Dict[str, str]:
    ch = version.get("changes") or {}
    lines = []
    for c in ch.get("added") or []:
        lines.append(f"added    {c['name']} ({c['type']})")
    for c in ch.get("removed") or []:
        lines.append(f"removed  {c['name']} ({c['type']})")
    for c in ch.get("retyped") or []:
        lines.append(f"re-typed {c['name']}: {c['from']} -> {c['to']}")
    body = "\n".join(lines) or "(column set re-recorded)"
    slug = pv.get("slug") or ""
    subject = (f"[QueryStudio] Published view '{slug}' schema changed "
               f"(v{version.get('version_no')})")
    text = (f"The published view '{pv.get('name')}' ({slug}) now serves a different "
            f"column set (schema version {version.get('version_no')}, reason: "
            f"{version.get('reason')}).\n\n{body}\n\n"
            f"Columns now: " + ", ".join(c["name"] for c in version.get("columns") or [])
            + "\n\nCheck any client that reads this view by column name.")
    import html as _html
    html = ("<p>The published view <b>" + _html.escape(str(pv.get("name") or "")) +
            "</b> (<code>" + _html.escape(slug) + "</code>) now serves a different "
            "column set (schema version " + _html.escape(str(version.get("version_no"))) +
            ", reason: " + _html.escape(str(version.get("reason"))) + ").</p><pre>" +
            _html.escape(body) + "</pre><p>Columns now: " +
            _html.escape(", ".join(c["name"] for c in version.get("columns") or [])) +
            "</p><p>Check any client that reads this view by column name.</p>")
    return {"subject": subject, "text": text, "html": html}


def notify_owners(db, pv: Dict[str, Any], version: Dict[str, Any]) -> Dict[str, Any]:
    """Email every routable key owner; record the rest.  Never raises."""
    verdict: Dict[str, Any] = {"emails": [], "unrouted": [], "usernames": [],
                               "sent": False, "reason": ""}
    try:
        from core import config as _cfg
        domain = _cfg.published_views.notify_email_domain
    except Exception:                                        # noqa: BLE001
        domain = ""
    try:
        owners = owners_for_view(db, int(pv["id"]))
    except Exception as exc:                                 # noqa: BLE001
        verdict["reason"] = f"owners unreadable: {exc}"
        return verdict
    addresses: List[str] = []
    for o in owners:
        u = o.get("username") or ""
        if u and u not in verdict["usernames"]:
            verdict["usernames"].append(u)
        addr = _address_for(u, domain)
        if addr:
            if addr.lower() not in {a.lower() for a in addresses}:
                addresses.append(addr)
        elif u and u not in verdict["unrouted"]:
            verdict["unrouted"].append(u)
    # the in-app notice reaches an owner whatever the mail did
    msg = _render_notice(pv, version)
    for u in verdict["usernames"]:
        try:
            db.log_notification(event_type="published_view_schema_changed",
                                channel="in_app", recipient=u, status="unread",
                                title=msg["subject"], message=msg["text"],
                                payload={"view_id": pv.get("id"), "slug": pv.get("slug"),
                                         "version_no": version.get("version_no")})
        except Exception:                                    # noqa: BLE001
            logger.debug("[pv-schema] in-app notice for %s not logged", u, exc_info=True)
    if not owners:
        verdict["reason"] = "no api key can call this view"
        return verdict
    if not addresses:
        verdict["reason"] = ("no address derivable: set published_views.notify_email_domain "
                             "or issue keys under an address")
        return verdict
    try:
        from core import email_service
        ok = bool(email_service.send_email(addresses, msg["subject"], msg["html"],
                                           text_body=msg["text"]))
        verdict["emails"] = list(addresses)
        verdict["sent"] = ok
        if not ok:
            verdict["reason"] = email_service.last_send_failure_reason() or "send failed"
    except Exception as exc:                                 # noqa: BLE001
        verdict["emails"] = list(addresses)
        verdict["reason"] = f"send raised: {exc}"
    return verdict


__all__ = [
    "REASONS", "columns_hash", "current_columns", "diff_columns",
    "note_dataset_columns_changed", "notify_owners", "owners_for_view",
    "record_schema",
]
