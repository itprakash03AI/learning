"""Runtime resolution of ``${user.<var>}`` inside a report's OWN SQL.

2026-08-29.  Row-security policies could already reference the caller
(``${user.groups}`` in a policy's ``filter_sql``), but a report's own SQL
could not: the text went to the engine verbatim, so an author who wrote
``WHERE region IN ${user.groups}`` shipped that literal string to the
database.  This module renders those tokens at EXECUTION time, against the
principal actually running the query.

ONE RENDERER, NOT TWO.  The substitution itself is
``row_security.resolver.substitute_vars`` -- the same function, the same
quoting, the same vocabulary the policy engine uses.  A second implementation
would be a second escaping bug waiting to happen, and would let the two
surfaces drift on what ``${user.groups}`` means.

THE VOCABULARY (all resolved from the live principal):

    ${user.username}   -> 'alice'                 quoted string
    ${user.role}       -> 'analyst'               quoted string
    ${user.groups}     -> ('finance', 'audit')    ready-made IN-list
    ${user.is_admin}   -> TRUE / FALSE            bare boolean
    ${user.<attr>}     -> any key on the principal's attribute bag

WHERE IT RUNS.  ``reports_api._run_sql_report``, on the primary AND secondary
SQL, immediately before ``substitute_sql_params``.  That one function is the
chokepoint every REPORT path funnels through -- interactive, embed, share,
export, published-view-backed and scheduled -- so there is no sibling report
path to drift out of sync.  The other two SQL-executing report paths build
their SQL from a QueryConfig rather than author-written text, so no token can
appear in them.

WHERE IT DELIBERATELY DOES NOT RUN.  ``scheduler._exec_sql_query`` executes a
saved SQL query directly, never through a report.  That is a delivery job, not
somebody's session: there is no principal to resolve against.  It warns,
naming the tokens and the fix, and passes the SQL through unchanged -- see the
comment there for why it neither refuses nor invents an identity.

It deliberately does NOT live inside ``secure_sql``, which would have been one
edit covering everything: ``secure_sql`` returns early when row-security is
disabled and for every admin, so the tokens would reach the database as
literals in exactly those two cases.  Resolving principal variables is not
row-security; it must work with RLS off, and an admin running a group-scoped
report should get their own groups rather than a syntax error.

TWO FAILURE POLICIES, deliberately different:

* An UNKNOWN token (``${user.typo}``) is REFUSED.  It is an authoring error,
  deterministic, and hit on the very first execution -- never a runtime
  refusal of a report that used to work.  ``substitute_vars`` would render it
  as ``NULL``, which is correct inside a policy (the rewriter has other guards
  around it) but in a report's own WHERE clause yields a nonsense query or a
  silently empty grid.

* A NEAR-MISS spelling (``${User.groups}``, ``${user.dept.code}``) WARNS and
  passes through.  It does not refuse, and the asymmetry with the unknown
  token above is deliberate rather than accidental: an unknown token RENDERS
  -- ``substitute_vars`` turns it into ``NULL``, giving a nonsense predicate
  and a silently empty grid -- whereas a near-miss matches nothing, so the
  literal reaches the database and the query fails there, loudly, on its own.
  One produces a wrong answer; the other already fails closed.  The warning
  exists because the two are otherwise indistinguishable from the outside:
  an UNRECOGNISED spelling and a deliberate pass-through look identical.

* An EMPTY ``${user.groups}`` RUNS.  It renders as the never-match sentinel
  ``(NULL)`` -- fail-closed, zero rows, no leak -- and logs loudly.  A caller
  with no group scope is a thin configuration, not a reason to break a hybrid
  or scheduled context, and refusing there would turn a data-dependent state
  into an outage.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional, Union

from core.row_security.resolver import _VAR_RE, substitute_vars

logger = logging.getLogger(__name__)

#: Tokens resolved from first-class principal fields.  Anything else must be
#: present on the principal's ``attrs`` bag or the SQL is refused.
FIRST_CLASS_VARS = ("username", "role", "groups", "is_admin")

#: The one place the token spelling lives.  Every message that names a token
#: renders it through here, so the vocabulary cannot drift between the error
#: text an author reads and the pattern the resolver actually matches.
_VAR_PREFIX = "${user."


def _tok(name: str) -> str:
    """Render a variable name back into its ``${user.<name>}`` spelling."""
    return f"{_VAR_PREFIX}{name}}}"


#: Matches the ``${user.`` opener loosely -- any case, tolerating stray
#: whitespace -- so a spelling the strict token pattern REFUSED to match can
#: still be spotted and named.  Without this, a typo is indistinguishable from
#: text that was never meant to be a token.
_LOOSE_OPENER_RE = re.compile(r"\$\{\s*user\s*\.", re.IGNORECASE)


def malformed_user_vars(sql: Optional[str]) -> List[str]:
    """Fragments that LOOK like a ``${user.*}`` token but are not one.

    Returns the offending source text (e.g. ``${User.groups}``), not a bare
    name, because the whole point is to show the author what they actually
    typed next to what the resolver accepts.
    """
    if not sql or "${" not in sql:
        return []
    matched = [m.span() for m in _VAR_RE.finditer(sql)]
    out: List[str] = []
    for m in _LOOSE_OPENER_RE.finditer(sql):
        if any(start <= m.start() < end for start, end in matched):
            continue                      # part of a well-formed token
        close = sql.find("}", m.start())
        frag = (sql[m.start():close + 1] if 0 <= close - m.start() <= 60
                else sql[m.start():m.start() + 40])
        if frag not in out:
            out.append(frag)
    return out


def referenced_user_vars(sql: Optional[str]) -> List[str]:
    """Lower-cased ``${user.<var>}`` names referenced by ``sql``, in order.

    Cheap and side-effect free.  Returns ``[]`` for the overwhelming majority
    of SQL, which is what makes ``resolve_user_sql_vars`` safe to call on
    every SQL report: no principal is built and nothing is rewritten.
    """
    if not sql or "${" not in sql:
        return []
    out: List[str] = []
    seen = set()
    for m in _VAR_RE.finditer(sql):
        name = m.group(1).lower()
        if name not in seen:
            seen.add(name)
            out.append(name)
    return out


#: The two record vocabularies this rule must read.  A legacy ``Report`` and
#: a ``BusinessReport`` name the same concepts differently, and the instance
#: store is handed the BusinessReport shape while the report cache is handed
#: the legacy one.  Reading only one vocabulary makes the check silently
#: answer "no tokens" for every record of the other kind.
_SQL_TEXT_KEYS = ("sql_override", "secondary_sql",              # Report
                  "raw_sql", "raw_sql_override")                # BusinessReport
_SAVED_QUERY_KEYS = ("sql_saved_query_id", "raw_sql_saved_query_id")
_SQL_FILE_KEYS = ("raw_sql_file_id",)


def report_references_user_vars(report: Optional[Dict[str, Any]],
                                db: Any = None) -> bool:
    """Does this report's OWN SQL vary by who runs it?

    Every result cache in the product assumed that with row-security
    DISABLED, one caller's bytes are every caller's bytes -- true while the
    executed SQL was identical for everyone.  ``${user.*}`` breaks that
    premise precisely where row-security is off, which is the configuration
    in which these variables are the ONLY thing filtering rows.

    Three cache layers ask this one function rather than each deciding for
    itself -- the report cache key, the business-report instance signature
    and the published-view cache scope all had the same hazard, and fixing
    one of several siblings is how it survives.

    The SQL may not be on the record at all: it can live in a saved query or
    in a file on disk, and a report whose text cannot be reached is not a
    report known to be safe.

    UNKNOWN = UNSAFE -- anything that cannot be inspected counts as varying,
    so the failure mode is a cache miss, never a cross-principal serve.
    """
    if not report:
        return True
    try:
        if any(referenced_user_vars(report.get(k) or "")
               for k in _SQL_TEXT_KEYS):
            return True

        for key in _SAVED_QUERY_KEYS:
            qid = report.get(key)
            if not qid:
                continue
            if db is None:
                return True
            q = db.get_sql_query(qid) or {}
            if any(referenced_user_vars(q.get(f) or "")
                   for f in ("primary_sql", "secondary_sql")):
                return True

        for key in _SQL_FILE_KEYS:
            fid = report.get(key)
            if not fid:
                continue
            if db is None:
                return True
            if _file_references_user_vars(db, fid):
                return True
        return False
    except Exception:
        return True


#: Answers for file-backed reports, keyed by (path, mtime_ns, size).
#: A published view asks this question on EVERY data request -- including
#: cache hits -- so re-reading the file each time would put NFS I/O in front
#: of the cache it is deciding about.  The key is the file's own stat, so an
#: edit changes the key and the answer is recomputed: the memo cannot go
#: stale, which a TTL could.
_FILE_ANSWER_CACHE: Dict[Any, bool] = {}
_FILE_ANSWER_CACHE_MAX = 512


def _file_references_user_vars(db: Any, file_id: Any) -> bool:
    """Does the SQL file backing a report reference ``${user.*}``?

    Read through the same storage helper the executor uses, so this cannot
    disagree with the text that actually runs.
    """
    from core.report_framework import ports as _rf_ports
    record = db.get_sql_file(file_id) or {}
    path = _rf_ports.host().sql_files_storage_dir() / record["file_path"]
    stat = path.stat()
    key = (str(path), stat.st_mtime_ns, stat.st_size)
    hit = _FILE_ANSWER_CACHE.get(key)
    if hit is not None:
        return hit
    answer = bool(referenced_user_vars(path.read_text(encoding="utf-8")))
    if len(_FILE_ANSWER_CACHE) >= _FILE_ANSWER_CACHE_MAX:
        _FILE_ANSWER_CACHE.clear()
    _FILE_ANSWER_CACHE[key] = answer
    return answer


class ReportPrincipal:
    """The identity ONE report execution resolves ``${user.*}`` against.

    Exists so that both halves of a cross-source report see the SAME identity
    BY CONSTRUCTION.  Resolving per SQL side meant two owner lookups per
    report, and -- worse than the cost -- a transient directory failure
    between them would join a leg filtered by the owner's groups to a leg
    filtered by the fail-closed empty scope.  "Both halves see one identity"
    was true by luck; one instance per execution makes it true by structure.

    Resolution is deferred to first use, so a report whose SQL references no
    variables never pays for a lookup.
    """

    __slots__ = ("_given", "_owner", "_resolved", "_done")

    def __init__(self, user_ctx: Optional[Dict[str, Any]],
                 owner: Optional[str] = None) -> None:
        self._given = user_ctx
        self._owner = owner
        self._resolved: Optional[Dict[str, Any]] = None
        self._done = False

    def context(self, label: str = "report") -> Optional[Dict[str, Any]]:
        """The principal to render against; resolved once, then reused."""
        if not self._done:
            self._resolved = _resolve_principal(self._given, self._owner,
                                                label)
            self._done = True
        return self._resolved


def _resolve_principal(user_ctx: Optional[Dict[str, Any]],
                       owner: Optional[str],
                       label: str) -> Optional[Dict[str, Any]]:
    """The principal ``${user.*}`` resolves against.

    A live caller's context is used as-is.  When there is NONE -- a scheduled
    or background run -- the report OWNER's scope is re-resolved server-side,
    because "no caller" is not the same fact as "no groups" and rendering the
    second when you mean the first delivers an EMPTY file labelled success.

    "NO CALLER" IS ITS OWN PROPOSITION, AND IT IS NOT ``rls_unresolved``.
    This function first keyed the owner lookup on ``rls_unresolved`` alone,
    which was true of every background placeholder and of nothing else --
    until 2026-09-05, when a row-security fix stamped that same marker on
    every API-key, ``basic_noauth`` and groupless-AD principal so the
    rewriter would REFUSE governed tables for them.  Those are all REAL
    CALLERS, and the shared marker silently re-pointed their ``${user.*}``
    rendering at the report OWNER.  Measured on the api-key path:

        before  WHERE region IN (NULL)                          -- own scope
        after   WHERE region IN ('FINANCE-ALL', 'PAYROLL-EMEA') -- OWNER's

    A security fix that widens is the shape this codebase keeps paying for,
    and the cause was one symbol carrying two propositions:

        (a) this principal's GROUPS could not be resolved   -> the rewriter
        (b) there is NO CALLER to render ${user.*} against  -> here

    An API key is (a) TRUE and (b) FALSE.  A scheduled report or a feed run
    is both.  So (b) now has its own field, answered by
    ``row_security.principal.has_live_caller`` and stamped in ``api/deps.py``
    -- the only module that turns a presented credential into a principal.
    Deliberately NOT a ``username.startswith("apikey:")`` test at this reading
    site: a string prefix on a username is not the property, and this repo has
    been bitten by exactly that shape before.

    BOTH conditions are required, so this change can only ever REMOVE an owner
    lookup, never add one: a principal that renders against its own scope
    today cannot start rendering against the owner's.  A share-link or embed
    principal that carries real groups is untouched -- it fails the
    ``rls_unresolved`` half.

    And the failure mode of a background site that forgets to declare itself
    is the SAFE one: no live-caller flag plus no groups renders ``(NULL)`` --
    zero rows and a loud warning -- not the owner's scope.

    This deliberately does NOT touch the context row-security receives.  That
    placeholder's ``rls_unresolved`` flag makes the rewriter refuse governed
    tables, and widening it here would relax RLS on every scheduled report as
    a side effect of a rendering fix.

    Fail-closed throughout: ``derive_for_owner`` clamps admin away and
    degrades to viewer/no-groups, which is exactly today's behaviour.
    """
    from core.row_security.principal import has_live_caller
    if user_ctx and (has_live_caller(user_ctx)
                     or not user_ctx.get("rls_unresolved")):
        return user_ctx
    if not owner:
        return user_ctx
    try:
        from core.identity import derive_for_owner
        _ident = derive_for_owner(owner)
        # Flattened to the plain dict shape ``build_user_ctx`` consumes —
        # attrs first so the core keys below always win a name collision.
        derived = {**dict(_ident.attrs),
                   "username": _ident.username,
                   "role": _ident.role,
                   "groups": list(_ident.groups),
                   "is_admin": False}
    except Exception as exc:
        logger.warning(
            "[user-sql-vars] %s: could not resolve owner '%s' scope for "
            "${user.*} — falling back to the unresolved principal, which "
            "renders an empty scope: %s", label, owner, exc)
        return user_ctx
    logger.info(
        "[user-sql-vars] %s: no caller principal — resolved ${user.*} against "
        "report owner '%s' so the scheduled run matches what the owner sees "
        "interactively", label, owner)
    return derived


#: Regions of SQL where a ``${user.*}`` token must NOT be rendered the normal
#: way.  The renderer is textual, so without this it rewrites inside quotes and
#: comments too: ``'${user.username}'`` became ``''alice''`` -- a parse error --
#: and a group name containing ``*/`` could close a block comment early.
_LITERAL = "literal"
_COMMENT = "comment"


def _protected_regions(sql: str):
    """Spans of ``sql`` that are string literals, quoted identifiers or comments.

    A small scanner rather than a parser: the SQL here is not yet valid (it
    still holds unrendered tokens), so sqlglot cannot read it -- it raises on
    ``${``.  Handles ``''`` escaping, ``--`` to end of line, and ``/* */``.
    """
    spans = []
    i, n = 0, len(sql)
    while i < n:
        ch = sql[i]
        if ch == "'":
            # No special case for the ``''`` escape: two adjacent literals
            # cover exactly the characters one escaped literal would, so the
            # protected region is identical either way (checked over 40k
            # random inputs). A branch that cannot change the outcome reads
            # as protection while providing none.
            j = sql.find("'", i + 1)
            j = n - 1 if j < 0 else j
            spans.append((i, min(j + 1, n), _LITERAL))
            i = j + 1
        elif ch in '"`':
            j = sql.find(ch, i + 1)
            j = n - 1 if j < 0 else j
            spans.append((i, j + 1, _LITERAL))      # quoted identifier
            i = j + 1
        elif sql.startswith("--", i):
            j = sql.find("\n", i)
            j = n if j < 0 else j
            spans.append((i, j, _COMMENT))
            i = j
        elif sql.startswith("/*", i):
            j = sql.find("*/", i + 2)
            j = n if j < 0 else j + 2
            spans.append((i, j, _COMMENT))
            i = j
        else:
            i += 1
    return spans


#: ``IN (`` immediately before a token, allowing whitespace/newlines.
_IN_PAREN_RE = re.compile(r"\bIN\s*\(\s*$", re.IGNORECASE)


def _wrapped_by_in_parens(sql: str, start: int, end: int) -> bool:
    """Is this token the WHOLE contents of an ``IN ( ... )`` list?

    ``${user.groups}`` renders as a COMPLETE parenthesised list --
    ``('EMEA', 'APAC')`` -- because that is the form row-security
    policies are authored in (``region IN ${user.groups}``).  A report
    author naturally writes the parentheses themselves:

        WHERE region IN (${user.groups})

    which produced ``IN (('EMEA', 'APAC'))``.  That is not a harmless
    extra bracket: DuckDB reads the inner parens as a row constructor and
    fails with "Type VARCHAR with value 'EMEA' can't be cast", so the
    obvious spelling was a hard execution error.  Verified on the engine.

    Exactly the collision ``_LITERAL`` already resolves for quotes, and
    resolved the same way: the author supplied the syntax, so the renderer
    yields it.

    Deliberately narrow -- the opener must be the ``IN`` keyword.  A bare
    ``f(${user.groups})`` is left alone: stripping there would turn one
    tuple argument into two arguments and change what the author wrote.
    """
    if not _IN_PAREN_RE.search(sql[:start]):
        return False
    rest = sql[end:]
    return rest.lstrip().startswith(")")


def _region_of(pos: int, spans) -> Optional[str]:
    for start, end, kind in spans:
        if start <= pos < end:
            return kind
    return None


#: Engines with no boolean literal in SQL.  Oracle has BOOLEAN in PL/SQL
#: only (SQL gained it in 23ai), so ``WHERE TRUE`` is ORA-00920 -- a report
#: using ``${user.is_admin}`` would be unrunnable there while working
#: everywhere else.  Rendered as a tautology/contradiction instead, which is
#: valid on every engine in the map.
_NO_BOOLEAN_LITERAL = frozenset({"oracle"})
_BOOL_AS_PREDICATE = {"TRUE": "(1=1)", "FALSE": "(1=0)"}


def _render_token(token: str, ctx, region: Optional[str], label: str,
                  dialect: Optional[str] = None,
                  in_parens: bool = False) -> str:
    """Render ONE ``${user.*}`` token for the region it sits in.

    Delegates the actual value formatting and escaping to ``substitute_vars``
    in every case, so there is exactly one implementation of what a variable
    means and how it is quoted.
    """
    if region == _COMMENT:
        # Leave it alone. Rendering into a comment cannot help anyone, and a
        # value containing ``*/`` would close the comment early and push the
        # rest of it back into executable SQL.
        return token

    rendered = substitute_vars(token, ctx)

    if (dialect or "").lower() in _NO_BOOLEAN_LITERAL:
        rendered = _BOOL_AS_PREDICATE.get(rendered, rendered)

    if (in_parens and len(rendered) >= 2
            and rendered[0] == "(" and rendered[-1] == ")"):
        # The author supplied the IN parentheses; hand back the bare list
        # so the two do not nest.  Only ever REMOVES redundancy -- a
        # scalar like 'alice' is untouched, and ``IN ('alice')`` is valid.
        return rendered[1:-1]

    if region == _LITERAL:
        # The author already supplied the quotes. Emitting a quoted literal
        # inside them produced ''alice'' -- a syntax error. Give the escaped
        # VALUE instead, which is what the quotes were asking for.
        if len(rendered) >= 2 and rendered[0] == "'" and rendered[-1] == "'":
            return rendered[1:-1]
        # An IN-list or a bare boolean has no meaning inside quotes, and
        # silently producing '(1, 2)' would be a wrong answer rather than an
        # error. Refuse, naming the fix.
        raise ValueError(
            f"{label}: {token} renders as {rendered} and cannot go inside "
            f"quotes — remove the surrounding '' (it already renders as a "
            f"complete SQL value)")

    return rendered


def resolve_user_sql_vars(sql: Optional[str],
                          user_ctx: Union[Dict[str, Any], "ReportPrincipal",
                                          None],
                          *, label: str = "report",
                          owner: Optional[str] = None,
                          dialect: Optional[str] = None) -> Optional[str]:
    """Render every ``${user.<var>}`` in ``sql`` against ``user_ctx``.

    Returns ``sql`` UNCHANGED when it references none -- byte-identical, not a
    re-rendered equivalent -- so a report that does not use the feature cannot
    be affected by it.

    Raises ``ValueError`` when the SQL references a token this principal
    cannot resolve; report callers surface that as a 400.  See the module
    docstring for why an unknown token refuses while an empty group scope
    runs.

    MUST run BEFORE ``substitute_sql_params``.  That substituter matches
    ``{name}`` where name is ``[a-zA-Z_][a-zA-Z0-9_]*``, which cannot match
    ``{user.groups}`` (the dot), so the two are independent today -- ordering
    the general renderer first keeps them independent even if the param
    pattern is ever widened.
    """
    # Before the fast path: a near-miss spelling produces NO references, so
    # checking after the early return would never see it.
    for frag in malformed_user_vars(sql):
        logger.warning(
            "[user-sql-vars] %s: %s is not a resolvable variable and is being "
            "sent to the database unchanged. Variables are lower-case and take "
            "a single name: %s. If this text is intentional, ignore this.",
            label, frag, ", ".join(_tok(n) for n in FIRST_CLASS_VARS))

    referenced = referenced_user_vars(sql)
    if not referenced:
        return sql

    from core.row_security.api import build_user_ctx
    # Resolved AFTER the fast path above, so SQL with no tokens never pays
    # for an owner lookup.  A ReportPrincipal carries its own resolution and
    # shares it across both halves of a cross-source report; a bare dict is
    # wrapped here so single-SQL callers keep the simpler signature.
    if isinstance(user_ctx, ReportPrincipal):
        # A principal already carries its own owner.  Accepting a second one
        # here would silently discard one of the two -- the same shape as
        # reading a spec off the wrong object and never being told.  This is a
        # programming error, not a data condition, so it fails loudly.
        if owner is not None:
            raise TypeError(
                "resolve_user_sql_vars: pass owner= OR a ReportPrincipal, "
                "not both — the principal already carries its owner")
        principal = user_ctx
    else:
        principal = ReportPrincipal(user_ctx, owner)
    ctx = build_user_ctx(principal.context(label) or {})

    known = set(FIRST_CLASS_VARS) | {str(k).lower() for k in (ctx.attrs or {})}
    unknown = [name for name in referenced if name not in known]
    if unknown:
        available = list(FIRST_CLASS_VARS) + sorted(
            str(k) for k in (ctx.attrs or {}))
        raise ValueError(
            f"{label}: SQL references unresolvable "
            + ", ".join(_tok(n) for n in unknown)
            + " — available: "
            + ", ".join(_tok(n) for n in available))

    if "groups" in referenced and not ctx.groups:
        # Renders the never-match sentinel `(NULL)`: fail-closed, zero rows,
        # no leak.  Loud because "empty because your scope is empty" is
        # otherwise indistinguishable from "your filter matched nothing".
        logger.warning(
            "[user-sql-vars] %s: SQL filters on ${user.groups} but principal "
            "'%s' has NO group scope — the predicate will match nothing and "
            "the report will return zero rows. Grant the user a group, or "
            "mint the embed token with allowed_ad_groups / "
            "allowed_user_groups.", label, ctx.username)

    spans = _protected_regions(sql)
    rendered = _VAR_RE.sub(
        lambda m: _render_token(m.group(0), ctx, _region_of(m.start(), spans),
                                label, dialect,
                                _wrapped_by_in_parens(sql, m.start(), m.end())),
        sql)
    logger.info("[user-sql-vars] %s: resolved %s for principal '%s'",
                label, ", ".join(_tok(n) for n in referenced), ctx.username)
    return rendered
