"""One result contract for every business-report source type.

Design rule (2026-08-04 strategic redesign): a consumer must NEVER need to
know the source type to read a result.  Every execution path is normalised
into :class:`ReportEnvelope`; its wire form always carries the same keys:

    execution_id     str    — id the artifact / diagnostics are keyed by
    source_type      str    — informational only (never dispatch on it)
    columns          [str]  — flat column names (PV dict-columns normalised)
    total_rows       int?   — true row count when known, else null
    truncated        bool?  — True = row_limit reached (result MAY be cut),
                              False = definitely complete w.r.t. the limit,
                              null = unknown (UNKNOWN is surfaced, not hidden)
    row_limit        int?   — the cap the execution ran under
    engine           str    — server-stamped presentation-engine verdict:
                              "client" (small result — browser engine, exactly
                              today's flow) or "server" (viewer drives /cube
                              gestures; fetchAllRows must not run).  A CAP —
                              decides WHERE the work runs, never refuses it.
    output_path      str    — VERIFIED artifact path ("" when rows are inline)
    data             [dict] — materialised records   (only when materialised)
    rows             [list] — same rows, positional, aligned with ``columns``
                              (only when materialised)

``data`` (records) and ``rows`` (positional) are BOTH emitted so every
existing renderer — the token pages that index ``row[i]`` and the export
renderers that read records — consume one envelope.  When rows are NOT
materialised the keys are OMITTED entirely (never present-but-empty: an
empty list would be indistinguishable from a legitimate 0-row result, which
is exactly the inert-by-construction defect this contract removes).

Artifact verification (UNKNOWN = UNSAFE)
----------------------------------------
:func:`require_artifact` is the ONE chokepoint that decides "this execution
produced a retrievable result".  It knows both storage conventions (a
directly-claimed output path AND the data-grid result store keyed by
execution_id).  A caller that cannot obtain a verified artifact (or inline
rows) MUST NOT report success — the scheduler marking ``success`` while the
file it names does not exist was the design flaw this replaces.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

#: Keys the envelope owns on the wire.  Everything else in a raw result is
#: passed through untouched (``extras``) so no legacy consumer loses data.
_CANONICAL_KEYS = {
    "execution_id", "source_type", "columns", "total_rows", "truncated",
    "row_limit", "output_path", "data", "rows", "duration_seconds",
    "certificate", "engine",
}

# ── Presentation-engine verdict (reporting rewire Phase 3, 2026-08-09) ───────
#
# ``engine`` is stamped by the SERVER where ``total_rows`` is known — the
# viewer must never guess from what it happened to download.  It is a CAP
# (a resource decision): it chooses WHERE the banding/drill work runs, it
# never refuses work at any size.  Values:
#
#   "client" — small result: the browser fetches all rows and runs
#              useReportEngine.ts exactly as today (zero behaviour change).
#   "server" — large result: the viewer drives drill/banding/running-calc/
#              slicer gestures through POST .../results/{exec_id}/cube and
#              never calls fetchAllRows.
#
# The two engines are held to identical numbers by the parity GATE
# (backend/tests/test_report_engine_parity_2026_08_09.py matching goldens
# exported from useReportEngine.ts) — the cap decides placement, the gate
# guards correctness.

ENGINE_CLIENT = "client"
ENGINE_SERVER = "server"

#: Evidence for the default (target architecture §4): 2,072 B/row measured
#: in V8 → 50K rows ≈ 104 MB tab heap with 5-6x headroom under the measured
#: 250-300K cliff, and ~10 fetch pages to interactive.
DEFAULT_CLIENT_ENGINE_MAX_ROWS = 50_000


def client_engine_max_rows() -> int:
    """The switchover threshold — ``config.business_reports.client_engine_max_rows``.

    ``<= 0`` is the documented ROLLBACK switch: every result is stamped
    ``"client"`` and behaviour is exactly pre-rewire.  Read through
    ``config.get`` so the key works the moment an operator sets it, with the
    measured default when absent; any config hiccup falls back to the
    default rather than erroring (a cap must never take the result down).
    """
    try:
        from core import config as _cfg
        return int(_cfg.get("business_reports", "client_engine_max_rows",
                            DEFAULT_CLIENT_ENGINE_MAX_ROWS))
    except Exception:
        return DEFAULT_CLIENT_ENGINE_MAX_ROWS


def engine_for_rows(total_rows: Optional[int]) -> str:
    """The presentation-engine verdict for a result of ``total_rows`` rows.

    ONE chokepoint for the rule — :attr:`ReportEnvelope.engine` delegates
    here, and the ASYNC status / paged-results endpoints call it directly.
    Those paths do not build an envelope, and a second copy of this rule is
    exactly how the client and server engines would drift apart on which
    result each is responsible for.

    Rules (a CAP: it chooses placement, it never refuses):
      * threshold ``<= 0``       → ``"client"`` (the rollback switch);
      * ``total_rows`` unknown   → ``"client"`` — UNKNOWN must not send the
        viewer to ``/cube`` for a result that may have no artifact behind it
        (in-memory-only results 404 there).  Today's behaviour is the
        graceful degradation;
      * rows > threshold         → ``"server"``, else ``"client"``.
    """
    threshold = client_engine_max_rows()
    if threshold <= 0 or total_rows is None:
        return ENGINE_CLIENT
    try:
        return ENGINE_SERVER if int(total_rows) > threshold else ENGINE_CLIENT
    except (TypeError, ValueError):
        return ENGINE_CLIENT


# ── The ONE truncation / row-limit chokepoint (2026-08-22, CORR-2) ───────────
#
# ``0 == unlimited`` has been reintroduced in this subsystem three times because
# the same tiny rule lived in four-plus copies, each written with the ``x if x
# else`` idiom that folds an explicit ``0`` (which means UNLIMITED everywhere in
# this product) into "absent/None".  The verdict then reads UNKNOWN for a run
# that is provably COMPLETE, and the recorded row_limit is stored NULL.  These
# functions are the single home for the rule; every sibling now calls them and
# resolves by PRESENCE, never truthiness.

def resolve_cap(*caps: Any) -> Optional[int]:
    """First PRESENT cap wins (``is not None``), never first truthy.

    ``exec_meta.get("row_limit") or br.get("row_limit")`` skips an explicit
    ``0`` (unlimited) the engine stamped and falls through to a larger cap —
    the exact fold this replaces.  A present ``0`` is returned as ``0``.
    """
    for c in caps:
        if c is None:
            continue
        try:
            return int(c)
        except (TypeError, ValueError):
            continue
    return None


def normalize_row_limit(cap: Any) -> Optional[int]:
    """Normalise a row-limit for STORAGE / the wire, by PRESENCE.

    ``None`` (genuinely absent → UNKNOWN) is preserved as ``None``.  An
    explicit ``0`` (or negative) means UNLIMITED and is preserved as ``0`` —
    NEVER folded to ``None``.  ``0`` (unlimited, KNOWN) and ``None`` (unknown)
    are different facts: collapsing them is what made every serve of a
    correctly-uncapped run disclose UNKNOWN truncation.
    """
    if cap is None:
        return None
    try:
        iv = int(cap)
    except (TypeError, ValueError):
        return None
    return 0 if iv < 0 else iv


def truncation_verdict(total_rows: Optional[int],
                       row_limit: Optional[int]) -> Optional[bool]:
    """The ONE tri-state truncation rule (resolve by presence, not truthiness).

    Returns:
      * ``True``  — the cap was reached (result MAY be cut),
      * ``False`` — definitely COMPLETE w.r.t. the cap.  This INCLUDES an
                    explicit unlimited cap (``row_limit <= 0``): an unbounded
                    run cannot be truncated, so it is complete, NEVER unknown.
      * ``None``  — UNKNOWN: the cap is genuinely absent, or the row count is
                    unknown.  UNKNOWN is surfaced, never coerced to a claim.
    """
    if row_limit is None:
        return None
    try:
        rl = int(row_limit)
    except (TypeError, ValueError):
        return None
    if rl <= 0:
        return False            # unlimited ⇒ provably complete, never truncated
    if total_rows is None:
        return None
    try:
        return int(total_rows) >= rl
    except (TypeError, ValueError):
        return None


def materialize_limit(cap: Any) -> Optional[int]:
    """The READ bound for a materialisation, resolving by PRESENCE.

    An explicit ``0``/negative means UNLIMITED → ``None`` (read all); a
    genuinely absent cap is also ``None``.  Distinct from
    :func:`normalize_row_limit` (which preserves ``0`` for disclosure): here
    ``0`` and ``None`` legitimately coincide because both mean "no read
    ceiling".  Kept as its own name so the two intents never get merged.
    """
    if cap is None:
        return None
    try:
        iv = int(cap)
    except (TypeError, ValueError):
        return None
    return None if iv <= 0 else iv


class ReportArtifactError(RuntimeError):
    """An execution claims a result but no verifiable artifact exists.

    Raised by :func:`require_artifact` / :meth:`ReportEnvelope.materialize`.
    Callers must treat this as execution FAILURE — never success.
    """


def resolve_artifact(execution_id: str, claimed_path: Optional[str] = None) -> Optional[Path]:
    """Resolve the result artifact for an execution — the ONE lookup chokepoint.

    Order:
      1. the path the executor claimed to write (if it exists), then
      2. the data-grid result store keyed by ``execution_id``
         (``api.data_grid_api.find_csv_file`` — parquet preferred, csv legacy,
         DB-recorded path and S3 hydration fallbacks included).

    Returns ``None`` when no artifact can be located.  Callers that need a
    hard guarantee use :func:`require_artifact`.
    """
    if claimed_path:
        try:
            p = Path(claimed_path)
            if p.is_file():
                return p
        except (OSError, ValueError) as exc:
            logger.warning("resolve_artifact: bad claimed path %r: %s", claimed_path, exc)
    if execution_id:
        try:
            from core.report_framework import ports as _rf_ports
            fp = _rf_ports.host().find_result_file(str(execution_id))
            if fp is not None and fp.is_file():
                return fp
        except Exception as exc:
            logger.warning("resolve_artifact: result-store lookup failed for %s: %s",
                           execution_id, exc)
    return None


def require_artifact(execution_id: str, claimed_path: Optional[str] = None) -> Path:
    """Return the verified artifact path or raise :class:`ReportArtifactError`.

    Success without an artifact is impossible by construction: every headless
    execution path returns THIS verified path, so the file a run "names" is
    the file that exists.
    """
    p = resolve_artifact(execution_id, claimed_path)
    if p is None:
        raise ReportArtifactError(
            f"Execution {execution_id!r} produced no retrievable result artifact "
            f"(claimed path: {claimed_path!r}) — refusing to report success "
            "(fail-closed: a run must not claim success without the artifact it names)"
        )
    return p


def _normalize_columns(raw_columns: Any) -> List[str]:
    """Flatten column metadata to plain names (PV emits [{'name': ...}, ...])."""
    if not raw_columns:
        return []
    out: List[str] = []
    for c in raw_columns:
        if isinstance(c, dict):
            out.append(str(c.get("name") or c.get("column_name") or c))
        else:
            out.append(str(c))
    return out


@dataclass
class ReportEnvelope:
    """The single result contract — see module docstring for wire semantics."""

    execution_id: str = ""
    source_type: str = ""
    columns: List[str] = field(default_factory=list)
    total_rows: Optional[int] = None
    row_limit: Optional[int] = None
    artifact_path: Optional[str] = None
    records: Optional[List[Dict[str, Any]]] = None   # materialised rows (bounded)
    duration_seconds: Optional[float] = None
    certificate: Optional[dict] = None
    extras: Dict[str, Any] = field(default_factory=dict)

    # ── Derived ──────────────────────────────────────────────────────────────
    @property
    def truncated(self) -> Optional[bool]:
        """Tri-state: True = hit the cap (may be cut), False = under the cap,
        None = unknown.  Unknown is surfaced as null, never coerced to False —
        UNKNOWN must not masquerade as verified-complete.

        CORR-2 (2026-08-22): delegates to the ONE ``truncation_verdict``
        chokepoint so ``row_limit == 0`` (unlimited) reads COMPLETE, never
        UNKNOWN — the ``not self.row_limit`` fold this replaces treated an
        explicit unlimited cap as an absent one."""
        return truncation_verdict(self.total_rows, self.row_limit)

    @property
    def engine(self) -> str:
        """Server-stamped presentation-engine verdict — see module constants.

        Rules (a CAP: chooses placement, never refuses):
          * threshold <= 0            → ``"client"`` (rollback switch);
          * ``total_rows`` unknown    → ``"client"`` — UNKNOWN must not send
            the viewer to ``/cube`` for a result that may have no artifact
            behind it (in-memory-only results 404 there); today's behaviour
            is the graceful degradation, and the viewer additionally falls
            back to client mode on any ``/cube`` availability failure;
          * rows > threshold          → ``"server"``, else ``"client"``.
        """
        return engine_for_rows(self.total_rows)

    # ── Construction ─────────────────────────────────────────────────────────
    @classmethod
    def from_raw(cls, raw: Any, *, source_type: str,
                 row_limit: Optional[int] = None,
                 execution_id: Optional[str] = None) -> "ReportEnvelope":
        """Normalise ANY legacy execution result into the one contract.

        Accepts all three historical shapes:
          * FederationResult/raw_sql dict — ``{output_path, total_rows, columns, ...}``
          * published/federation view     — ``{data, columns, ...}``
          * anything with ``.to_dict()``
        Unknown keys are preserved in ``extras`` (no consumer loses data).
        """
        if raw is None:
            raw = {}
        if not isinstance(raw, dict):
            raw = raw.to_dict() if hasattr(raw, "to_dict") else {}

        records = raw.get("data") if isinstance(raw.get("data"), list) else None
        total = raw.get("total_rows")
        if total is None and records is not None:
            total = len(records)

        return cls(
            execution_id=str(raw.get("execution_id") or execution_id or ""),
            source_type=source_type or str(raw.get("data_source_type") or ""),
            columns=_normalize_columns(raw.get("columns")),
            total_rows=int(total) if total is not None else None,
            # CORR-2: presence-preserving — an explicit row_limit=0 (unlimited)
            # is kept as 0, not folded to None, so ``truncated`` reads COMPLETE.
            row_limit=normalize_row_limit(row_limit),
            artifact_path=(raw.get("output_path") or None),
            records=records,
            duration_seconds=raw.get("duration_seconds"),
            certificate=raw.get("certificate"),
            extras={k: v for k, v in raw.items() if k not in _CANONICAL_KEYS},
        )

    # ── Verification / materialisation ───────────────────────────────────────
    def verify(self) -> "ReportEnvelope":
        """Assert this result is retrievable: inline rows OR a verified artifact.

        Raises :class:`ReportArtifactError` otherwise.  Also canonicalises
        ``artifact_path`` to the resolved location (so the path a consumer is
        told is the path that exists).
        """
        if self.records is not None:
            return self
        self.artifact_path = str(require_artifact(self.execution_id, self.artifact_path))
        return self

    def materialize(self, max_rows: Optional[int] = None) -> "ReportEnvelope":
        """Ensure ``records`` is populated (bounded by ``max_rows``).

        Reads the artifact through the engine-pushed reader — NEVER a full
        pandas materialisation of an unbounded result.  If the result claims
        rows but neither inline records nor an artifact exist, raises
        :class:`ReportArtifactError` — a consumer must see a hard failure,
        not a silently-empty page (the old shared/embedded-page defect).
        """
        if self.records is not None:
            return self
        path = resolve_artifact(self.execution_id, self.artifact_path)
        if path is None:
            # CORR-1 (2026-08-22): ONLY a KNOWN zero (total_rows == 0) is a
            # verified-empty result.  ``not self.total_rows`` also matched
            # None (UNKNOWN) — so an unknown count with a missing artifact was
            # rendered as a positive claim of emptiness.  UNKNOWN must fail
            # closed (raise), never present itself as "the data is empty".
            if self.total_rows == 0:  # verified-empty (0 rows, nothing written)
                self.records = []
                return self
            raise ReportArtifactError(
                f"Execution {self.execution_id!r} claims {self.total_rows} rows but no "
                f"result artifact exists (claimed path: {self.artifact_path!r}) — "
                "refusing to render an empty result as if it were the data"
            )
        from core.reports.pagination import read_artifact_page
        # CORR-2: presence-based read bound — ``max_rows`` wins when supplied,
        # else the envelope's row_limit; an explicit 0 (unlimited) resolves to
        # None (read all) instead of silently falling through to the next cap.
        limit = materialize_limit(resolve_cap(max_rows, self.row_limit))
        recs, cols, total = read_artifact_page(path, offset=0, limit=limit)
        self.records = recs
        self.artifact_path = str(path)
        if not self.columns:
            self.columns = cols
        if self.total_rows is None:
            self.total_rows = total
        return self

    def locate(self) -> "ReportEnvelope":
        """Prove the result is retrievable WITHOUT reading its rows.

        2026-10-04.  The export road that streams the artifact in record
        batches (``core.reports.export_stream``) needs the same guarantee
        :meth:`materialize` gives -- a result that claims rows has an
        artifact, a missing artifact is a FAILURE unless the count is a known
        zero -- and nothing else: materialising here is what pulled a
        5M-row report into the API's heap three times over.  Inline records
        (published / federation views) are kept as they are.  An unknown
        ``total_rows`` is filled from the parquet FOOTER (no data read).
        """
        if self.records is not None:
            return self
        path = resolve_artifact(self.execution_id, self.artifact_path)
        if path is None:
            if self.total_rows == 0:          # verified-empty, as materialize
                self.records = []
                return self
            raise ReportArtifactError(
                f"Execution {self.execution_id!r} claims {self.total_rows} rows but no "
                f"result artifact exists (claimed path: {self.artifact_path!r}) — "
                "refusing to export an empty result as if it were the data"
            )
        self.artifact_path = str(path)
        if self.total_rows is None and path.suffix.lower() in (".parquet", ".pq"):
            try:
                import pyarrow.parquet as _pq
                self.total_rows = int(_pq.ParquetFile(str(path)).metadata.num_rows)
            except Exception as exc:          # unknown stays unknown
                logger.warning("locate: could not read the row count of %s: %s",
                               path, exc)
        if not self.columns:
            try:
                from core.reports.export_stream import artifact_columns
                self.columns = artifact_columns(path)
            except Exception as exc:
                logger.warning("locate: could not read the columns of %s: %s",
                               path, exc)
        return self

    # ── Wire form ────────────────────────────────────────────────────────────
    def to_wire(self) -> Dict[str, Any]:
        """Serialize to the one wire envelope (see module docstring).

        ``data``/``rows`` appear only when materialised; canonical keys always
        win over extras so no branch can drift the contract.
        """
        from core.json_utils import sanitize_for_json

        out: Dict[str, Any] = dict(self.extras)
        out.update({
            "execution_id": self.execution_id,
            "source_type": self.source_type,
            "columns": list(self.columns),
            "total_rows": self.total_rows,
            "truncated": self.truncated,
            "row_limit": self.row_limit,
            "output_path": self.artifact_path or "",
            "engine": self.engine,
        })
        if self.duration_seconds is not None:
            out["duration_seconds"] = self.duration_seconds
        if self.certificate:
            out["certificate"] = self.certificate
        if self.records is not None:
            records = sanitize_for_json(self.records)
            cols = list(self.columns) or (list(records[0].keys()) if records else [])
            out["columns"] = cols
            out["data"] = records
            out["rows"] = [[r.get(c) for c in cols] for r in records]
            if out["total_rows"] is None:
                out["total_rows"] = len(records)
        return out
