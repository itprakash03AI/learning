"""Headless business-report execution — the plugin seam, now THE framework registry.

Every headless caller (scheduler, subscription delivery, future automation)
executes a business report through ONE function — :func:`execute_headless` —
which dispatches through the REGISTRY (``core.report_framework.registry``)
instead of ``if source_type ==`` branches.  Since 2026-11-07 the registry is
the generic report framework's: a source is a declared ``ReportSource``
(QueryStudio's four live in ``core/report_framework/sources/querystudio.py``,
their executor bodies moved there unchanged), and this module keeps every
name its callers and tests use:

* ``register_source_executor(kind, fn)`` -- registers ``fn`` as the headless
  executor of ``kind`` (a framework source wrapping it, with the legacy
  executor's DECLARED capabilities);
* ``_SOURCE_EXECUTORS`` -- a live VIEW of the registry keyed by kind whose
  values are executor functions: ``get`` / ``pop`` / ``update`` / iteration
  read and write the registry itself, so there is ONE table of sources;
* ``canonical_source_type`` / ``SOURCE_TYPE_ALIASES`` / ``get_source_executor``
  / ``describe_schedulable_sources`` -- the registry's.

Contract (enforced here, not hoped for):

* UNKNOWN = UNSAFE — an unregistered ``data_source_type`` is a hard
  ``ValueError``, never a silent default.
* Success is derived from a VERIFIED artifact — every executor's claimed
  output is resolved through :func:`core.reports.contract.require_artifact`
  before this function returns.  A run that produced no retrievable file
  CANNOT report success.
* RLS — executors receive ``owner_ctx`` (the report OWNER's resolved
  principal, never role="admin") exactly as the F1 fix (commit bc5a639)
  established; a framework source that declares ``row_security: none`` is
  refused when a policy applies (rule 1), never run unfiltered.

Executor signature::

    fn(br, param_values, execution_id, output_dir, owner_ctx, db)
        -> (claimed_path | None, total_rows)
        |  (claimed_path | None, total_rows, meta_dict)

``claimed_path`` may be ``None`` when the engine writes to the shared result
store keyed by ``execution_id`` (the raw-SQL cross-source engines do) — the
verification chokepoint resolves it either way.  ``meta_dict`` (optional 3rd
element) carries ``row_limit`` (the EFFECTIVE cap), ``truncated``,
``unstable_truncation`` and the Diagnostics lists.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable, Dict, Iterator, List, Optional, Tuple

from core.report_framework import registry as _registry
from core.report_framework.contract import (
    ROW_SECURITY_BY_SOURCE, ReportSource, SourceCapabilities, SourceReadError, SourceResult, SourceRun,
)
from core.report_framework.registry import SOURCE_TYPE_ALIASES, canonical_source_type  # noqa: F401
from core.report_framework.sources.querystudio import (  # noqa: F401  (the names callers and tests use)
    EXECUTOR_SOURCE, QueryStudioSource, _exec_federation, _exec_federation_view, _exec_published_view,
    _exec_raw_sql, _finish_view_execution, _require_owner_principal, _run_coro_headless,
)
from core.report_framework.sources.builtin import register_builtin
from core.reports.contract import ReportArtifactError, require_artifact

logger = logging.getLogger(__name__)

# the file and REST sources that ship with the product, and the configuration's
# plugins (report_framework.source_plugins), on every process that runs a report
register_builtin()

SourceExecutor = Callable[..., Tuple[Optional[str], int]]


# ── a legacy executor as a declared source ───────────────────────────────────

class LegacyExecutorSource(ReportSource):
    """A source registered by ``register_source_executor(kind, fn)`` -- the
    headless executor contract of 2026-08: it runs under the owner's
    principal (the engine narrows the rows), takes parameters, may be
    scheduled, is not proven retry-safe and does not run on a query pod."""

    capabilities = SourceCapabilities(row_security=ROW_SECURITY_BY_SOURCE, filter_pushdown=True, retry_safe=False,
                                      parameters=True, subscriptions=True, query_pods=False)

    def __init__(self, kind: str, fn: Callable[..., Any]) -> None:
        self.kind = canonical_source_type(kind)
        self.label = f"A {self.kind.replace('_', ' ')} source"
        self.executor = fn

    def run(self, run: SourceRun, db: Any) -> SourceResult:
        out = self.executor(dict(run.report), dict(run.params), run.execution_id, Path(run.output_dir),
                            dict(run.principal), db)
        if not isinstance(out, (tuple, list)) or len(out) < 2:
            raise SourceReadError(f"the executor of '{self.kind}' returned {type(out).__name__}")
        meta = out[2] if len(out) > 2 and isinstance(out[2], dict) else {}
        return SourceResult(artifact_path=out[0], total_rows=int(out[1] or 0), meta=dict(meta))


def _executor_of(source: ReportSource) -> Callable[..., Any]:
    """The headless executor of a source: its own ``executor`` (QueryStudio's
    four, a legacy registration) or an adapter over ``run`` (a framework /
    plugin source) that writes inline rows to the run's parquet file so the
    road's verification sees A FILE OR A REFUSAL."""
    own = getattr(source, "executor", None) or getattr(type(source), "executor", None)
    if callable(own):
        return own
    cached = getattr(source, "_headless_executor", None)
    if cached is not None:
        return cached

    def _adapter(br, param_values, execution_id, output_dir, owner_ctx, db):
        from core.report_framework import inputs as _inputs
        from core.report_framework import ports as _ports
        from core.report_framework import rules as _rules
        _host = _ports.host()
        run_params = _inputs.prepare(
            source, br, (_host.report_parameters_for_execution(br, db, br.get("id")) if db is not None
                         else (br.get("parameters") or [])), param_values,
            strict_names=True, resolve_value=_host.resolve_param_value)
        run = SourceRun(report=dict(br), params=run_params, execution_id=str(execution_id),
                        output_dir=Path(output_dir), principal=dict(owner_ctx or {}), surface="headless",
                        row_limit=br.get("row_limit"))
        res = _rules.require_result(source.run(run, db), source, str(execution_id))
        if res.artifact_path is None and res.records is not None:
            res.artifact_path = _write_records(res, Path(output_dir) / f"{execution_id}.parquet")
        meta = dict(res.meta)
        meta.setdefault("row_limit", run.row_limit)
        return res.artifact_path, int(res.total_rows if res.total_rows is not None else len(res.records or [])), meta

    _adapter.__name__ = f"_run_{source.kind}"
    try:
        source._headless_executor = _adapter
    except Exception:                                     # a frozen source: no cache
        pass
    return _adapter


def _write_records(res: SourceResult, path: Path) -> str:
    """Inline rows as the run's parquet file (the artifact every reader expects)."""
    import pyarrow as pa
    import pyarrow.parquet as pq
    path.parent.mkdir(parents=True, exist_ok=True)
    cols = list(res.columns) or (list(res.records[0].keys()) if res.records else [])
    try:
        arrays = []
        for c in cols:
            values = [r.get(c) for r in res.records]
            try:
                arrays.append(pa.array(values))
            except OverflowError:
                # 2026-11-09: a whole number past int64 (a 20-digit key) is not a
                # kind mismatch -- it is held exactly as decimal(38,0), the type the
                # streaming writer gives such a column (core/parquet_stream_writer.py).
                arrays.append(pa.array(values, type=pa.decimal128(38, 0)))
        table = pa.Table.from_arrays(arrays, names=cols) if cols else pa.table({})
    except (pa.ArrowInvalid, pa.ArrowTypeError) as exc:
        # review 2026-11-07: a column holding numbers in some rows and text in others was a 500
        from core.report_framework.contract import SourceReadError
        raise SourceReadError(f"The source's rows could not be stored as a table: a column holds values of "
                              f"different kinds ({exc}).") from exc
    pq.write_table(table, str(path))
    return str(path)


class _ExecutorTable:
    """``_SOURCE_EXECUTORS``: a live view of the registry, kind -> executor.
    Reads and writes go to the registry (one table); tests that ``pop`` a
    kind unregister it, and ``update(dict(table))`` puts back the SAME
    declared source."""

    def get(self, kind: Any, default: Any = None) -> Any:
        src = _registry._SOURCES.get(canonical_source_type(kind))
        return _executor_of(src) if src is not None else default

    def __getitem__(self, kind: Any) -> Any:
        fn = self.get(kind)
        if fn is None:
            raise KeyError(kind)
        return fn

    def __contains__(self, kind: Any) -> bool:
        return canonical_source_type(kind) in _registry._SOURCES

    def __iter__(self) -> Iterator[str]:
        return iter(sorted(_registry._SOURCES))

    def __len__(self) -> int:
        return len(_registry._SOURCES)

    def keys(self) -> List[str]:
        return sorted(_registry._SOURCES)

    def values(self) -> List[Any]:
        return [self[k] for k in self.keys()]

    def items(self) -> List[tuple]:
        return [(k, self[k]) for k in self.keys()]

    def __setitem__(self, kind: str, fn: Callable[..., Any]) -> None:
        register_source_executor(kind, fn)

    def pop(self, kind: Any, default: Any = None) -> Any:
        fn = self.get(kind, default)
        _registry.unregister_source(kind)
        return fn

    def update(self, mapping: Any) -> None:
        for kind, fn in dict(mapping).items():
            register_source_executor(kind, fn)

    def clear(self) -> None:
        for kind in list(_registry._SOURCES):
            _registry.unregister_source(kind)

    def copy(self) -> Dict[str, Any]:
        return dict(self.items())

    def __repr__(self) -> str:
        return f"_ExecutorTable({self.keys()})"


_SOURCE_EXECUTORS = _ExecutorTable()


def register_source_executor(source_type: str, fn: SourceExecutor) -> None:
    """Register (or override) the headless executor for a source type.

    ``fn`` that is one of QueryStudio's own executors puts back its declared
    source; any other function becomes a :class:`LegacyExecutorSource`."""
    cls = EXECUTOR_SOURCE.get(fn)
    if cls is not None and canonical_source_type(source_type) == cls.kind:
        _registry.register_source(cls())
        return
    _registry.register_source(LegacyExecutorSource(source_type, fn))


def get_source_executor(source_type: str) -> Optional[SourceExecutor]:
    return _SOURCE_EXECUTORS.get(source_type)


def describe_schedulable_sources() -> str:
    """The advice a save-time refusal gives, DERIVED from the executor table
    (FB-46: a sentence spelled separately from the gate drifts exactly like a
    gate spelled separately from the runtime did).  The table is the live
    registry view; the sentence reads the MODULE attribute so a table a test
    swaps in is what the sentence describes."""
    parts: List[str] = []
    for key in sorted(_SOURCE_EXECUTORS):
        aliases = sorted(a for a, t in SOURCE_TYPE_ALIASES.items() if t == key)
        parts.append(f"{key} (also spelled {', '.join(repr(a) for a in aliases)})" if aliases else key)
    return ", ".join(parts) if parts else "(no headless executors are registered)"


# ── The one headless entry point ─────────────────────────────────────────────

def execute_headless(br: dict, param_values: dict, execution_id: str,
                     output_dir, owner_ctx: Dict[str, Any], db,
                     ) -> Tuple[str, int]:
    """Execute a business report headlessly at the OWNER's RLS scope.

    Returns ``(verified_artifact_path, total_rows)``.  The path is GUARANTEED
    to exist (verified through :func:`require_artifact`); any failure —
    including "the engine claimed success but wrote nothing retrievable" —
    raises, so callers record a real failure instead of a phantom success.
    """
    report_id = br.get("id")

    # ── Publish lifecycle (2026-08-17) — THE delivery decision ───────────────
    # A subscription / scheduled delivery ships the CURRENT PUBLISHED VERSION
    # when one exists (enterprise semantics: a consumer's inbox must never
    # receive the author's half-edited draft).  A never-published report
    # keeps delivering the draft byte-identically to before, and ANY
    # resolution failure falls open to the draft — a version-store hiccup
    # must not turn a working delivery dark.  The RLS scope is untouched:
    # owner_ctx keeps governing row security exactly as F1 established.
    served_version = None
    try:
        from core.reports.versions import resolve_headless_report
        br, served_version = resolve_headless_report(db, br)
        if served_version:
            logger.info("[br-publish] headless run of report %s executes "
                        "published v%s", report_id,
                        served_version.get("version_no"))
    except Exception as exc:
        logger.warning("[br-publish] headless version resolution failed for "
                       "report %s — executing the draft (fail-open): %s",
                       report_id, exc)

    dst = canonical_source_type(br.get("data_source_type"))
    fn = _SOURCE_EXECUTORS.get(dst)
    if fn is None:
        raise ValueError(
            f"Business report {report_id}: unknown data_source_type {dst!r} — "
            "refusing to run (UNKNOWN=UNSAFE; register an executor via "
            "core.reports.sources.register_source_executor)"
        )
    # 2026-11-07 -- rule 1 of the framework: a source that cannot narrow the
    # rows is refused when a row-security policy applies (or could not be
    # told), never run unfiltered.  QueryStudio's own sources narrow the rows
    # in their engine and are not asked.
    _source = _registry._SOURCES.get(dst)
    if _source is not None:
        from core.report_framework import rules as _rules
        _rules.check_row_security(_source, br, owner_ctx or {}, db)
    # 2026-11-02 -- a default RULE (latest value with data, ...) applies to a scheduled
    # run too, resolved for the OWNER whose scope this run reads under -- it ran with
    # no date filter at all (every date of the table delivered).  The interactive
    # routes call the same function (api.business_reports_api._fill_rule_defaults).
    from core.report_framework import ports as _rf_ports
    _fill_rule_defaults = _rf_ports.host().fill_rule_defaults
    param_values = _run_coro_headless(_fill_rule_defaults(db, br, param_values or {}, owner_ctx or None))
    try:
        out = fn(br, param_values or {}, execution_id,
                 Path(output_dir), owner_ctx, db)
    except (ValueError, ReportArtifactError):
        raise
    except Exception as exc:
        raise ValueError(f"Business report {report_id} execution failed: {exc}") from exc

    claimed_path, total_rows = out[0], out[1]
    # Optional executor meta (see module docstring) — 2-tuple executors
    # (including externally registered ones) keep working unchanged.
    exec_meta: Dict[str, Any] = (out[2] if len(out) > 2
                                 and isinstance(out[2], dict) else {})

    verified = require_artifact(execution_id, claimed_path)

    # 2026-08-05 audit: the one greppable [br-serve] line for every headless
    # run (scheduler + subscription delivery share this chokepoint).
    # 2026-08-09 (D1 follow-up, flagged in 122a8c30): prefer the EFFECTIVE
    # row_limit the engine stamped on its result over br.row_limit — the
    # br value under-reported a clamp (engine max_result_rows < br limit)
    # and reported "no cap" when the default_row_limit fill-in applied,
    # exactly the lie the contract path was cured of in 122a8c30.
    from core.reports.serve_log import log_report_serve
    # CORR-2 (2026-08-22): resolve + verdict through the ONE chokepoint.  The
    # old ``exec_meta.get("row_limit") or br.get("row_limit")`` skipped an
    # engine-stamped 0 (unlimited) and folded it into br's cap; the
    # ``int(_cap) if _cap else None`` then stored NULL for an unlimited run and
    # the verdict read UNKNOWN.  ``resolve_cap`` keeps a present 0;
    # ``truncation_verdict`` reads 0 as COMPLETE; ``normalize_row_limit`` stores
    # 0 (unlimited, known) distinct from None (absent, unknown).
    from core.reports.contract import (
        normalize_row_limit, resolve_cap, truncation_verdict,
    )
    _cap = resolve_cap(exec_meta.get("row_limit"), br.get("row_limit"))
    _stored_cap = normalize_row_limit(_cap)
    _truncated = exec_meta.get("truncated")
    if _truncated is None:
        _truncated = truncation_verdict(total_rows, _cap)
    log_report_serve(
        report_id=report_id, execution_id=execution_id,
        user=str(owner_ctx.get("username") or ""), rls="owner",
        surface="headless", fmt="artifact", rows=int(total_rows or 0),
        row_limit=_stored_cap,
        truncated=_truncated,
    )

    # Phase 2 report-instance layer (2026-08-09): headless runs PRE-WARM the
    # instance store — the 6am schedule produces the instance every 9am
    # interactive open serves for free (target architecture §5.3, the BO
    # model).  The chokepoint is fail-open + flag-gated (no-op while
    # business_reports.instance_serving_enabled is off), so a write-through
    # failure can never turn a verified successful run into a failure.
    # D1/D2 (2026-08-09 cross-feature review): persist the RUN's truncation
    # facts — the effective cap + verdict computed above for the serve log
    # are exactly what the instance must carry, or every serve of this
    # pre-warmed artifact recomputes a verdict against the BR limit and
    # resurrects the silent-truncation defect 122a8c30 killed.
    from core.reports.instances import record_report_instance
    record_report_instance(
        db, br, owner_ctx, param_values,
        execution_id=execution_id,
        artifact_path=str(verified),
        row_count=int(total_rows or 0),
        is_scheduled=True,
        row_limit=_stored_cap,
        truncated=_truncated,
        unstable_truncation=exec_meta.get("unstable_truncation"),
        iceberg_versions=exec_meta.get("iceberg_versions"),
    )

    # 2026-09-28 -- a headless run (schedule, subscription) is THE run a
    # report SLO usually counts on ("served by 07:00"): record the readiness
    # it was served under.  Fail-open: the artifact is verified and the
    # run is a success whatever this ledger write does.
    _record_headless_readiness(db, br, param_values, execution_id,
                               str(owner_ctx.get("username") or ""))

    # 2026-10-30 -- a scheduled / delivered run answers its Diagnostics panel
    # like an interactive one: the SAME recorder, with the lists the run used
    # (the dataset road hands them back in its meta; the view / raw-SQL roads
    # apply their values inside their engines, and the record says the filter
    # list was not recorded).  Never raises.
    from core.reports.diagnostics import record_report_run
    record_report_run(
        db, report=br, report_id=int(report_id), execution_id=execution_id,
        param_values=param_values or {}, combined_filters=exec_meta.get("diag_filters"),
        source_bindings=exec_meta.get("diag_bindings"),
        result=exec_meta.get("diag_result") or {"total_rows": int(total_rows or 0)},
        username=str(owner_ctx.get("username") or "") or None, surface="scheduled")

    return str(verified), int(total_rows or 0)


def _record_headless_readiness(db, br: dict, param_values: dict,
                               execution_id: str, username: str) -> None:
    try:
        from core.report_framework import ports as _rf_ports
        from core.reports.readiness import readiness_for_run, record_readiness_run
        rd = readiness_for_run(db, br, param_values or {},
                               resolve=_rf_ports.host().resolve_param_value)
        record_readiness_run(db, rd, execution_id=execution_id,
                             executed_by=username, surface="headless")
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[readiness] headless run %s of report %s: verdict not "
                       "recorded: %s", execution_id, br.get("id"), exc)
