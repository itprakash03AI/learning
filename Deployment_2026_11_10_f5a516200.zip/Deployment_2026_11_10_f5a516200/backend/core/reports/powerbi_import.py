"""A Power BI report file brought across as a canvas report (2026-11-07, the report
framework's stage 8; plan docs/REPORT_FRAMEWORK_PLAN_2026_11_04.html section 4a).

The owner: "so easy to migrate power bi report to qs".  The DESIGN lives in the report
file; the DATA stays in the source -- a person picks the dataset the report runs on,
sees a preview of what each page, visual and field becomes, fixes what did not match,
and presses Create.  Nothing in the file is run, no path from the file is ever written,
and DAX / M are read as text only.

TWO LAYOUT FORMATS exist and both are read (checked on eight real Microsoft sample
reports, 2026-11-07 -- the plan's "a .pbix is Report/Layout" was half right):

* LEGACY  -- zip entry ``Report/Layout`` (UTF-16-LE JSON): ``sections[]`` are the pages,
  each ``visualContainers[]`` with x / y / width / height, a ``config`` STRING of JSON
  (``singleVisual.visualType``, ``prototypeQuery`` with table aliases, ``projections`` per
  role) and a ``filters`` string.  The .pbit template carries the model as text in
  ``DataModelSchema`` (measures with their DAX).
* PBIR    -- Power BI's current default: ``Report/definition/report.json``,
  ``pages/pages.json``, ``pages/<id>/page.json``, ``pages/<id>/visuals/<id>/visual.json``
  (``position``, ``visual.visualType``, ``visual.query.queryState.<role>.projections[]
  .field`` as Column / Measure / Aggregation / HierarchyLevel on ``SourceRef.Entity``).
  A zipped .pbip project holds the same ``definition/`` under ``<name>.Report/`` and the
  model as text under ``<name>.SemanticModel/`` (``model.bim`` JSON or TMDL
  ``definition/tables/*.tmdl``), so ONE reader serves .pbix and .pbip.

DECIDED: the binary ``DataModel`` of a .pbix is NOT read (it would need native
decompressors on untrusted bytes and packages the offline CI lacks).  Measures are read
from text where the file carries it; a SIMPLE one (SUM / AVERAGE / MIN / MAX / COUNT /
COUNTA / DISTINCTCOUNT over one column) becomes a column with that aggregation; anything
else is LISTED with its DAX, never guessed -- a wrong translation shows a wrong number
that looks right.  For a .pbix each measure a visual uses is "definition not in this
file" until the author picks a column and an aggregation for it.

THE RULES
* A filter on a field with no match, or one whose shape cannot be applied, is REFUSED
  at preview (``refusals``) -- never dropped: dropping a filter shows MORE rows.  A filter
  that narrows nothing (a filter card with no selection) becomes a report parameter when
  its field matches and is listed otherwise.
* Every visual type is in ONE mapping table (``VISUAL_KINDS``, data); a type not in it is
  listed with the reason, never dropped in silence.  A data visual that cannot come across
  keeps its place as a table of its matched fields when it has any; otherwise its place is
  listed as left empty.  Decoration (shapes, images, buttons, navigators) gets no tile and
  is listed as such.
* Untrusted file: a size cap, an entry-count cap, a per-entry size cap, a total-read cap,
  a per-entry compression-ratio check, a declared-size check; only known entries are read,
  each in bounded chunks; an unknown layout is refused in words.

The result of ``plan(...)`` is the PREVIEW; ``create`` in ``api/powerbi_import_api.py``
saves it through the SAME report-creation route the screen uses (``create_report`` and
``batch_save_parameters``), never by a direct insert.
"""
from __future__ import annotations

import io
import json
import re
import zipfile
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple

from core.reports.canvas import (
    CHART_KINDS, GRID_COLS, MAX_GRID_ROWS, MAX_PAGES, MAX_PAGE_TITLE, MAX_SERIES_VALUES,
    MAX_TILES, SUM_ONLY, TILE_KINDS, max_points_of,
)

# ── limits on an untrusted file ─────────────────────────────────────────────

#: the whole upload (a .pbix carries its binary model; 9.7 MB in the largest sample)
MAX_FILE_BYTES = 200 * 1024 * 1024
#: entries in the zip (the samples hold 25..60; a project with many pages a few hundred)
MAX_ENTRIES = 5000
#: one entry we read, decompressed (the largest Report/Layout seen: 1.9 MB)
MAX_ENTRY_BYTES = 64 * 1024 * 1024
#: everything we read from one file, decompressed
MAX_READ_BYTES = 256 * 1024 * 1024
#: declared decompressed size of the WHOLE zip (central directory), bomb or not
MAX_DECLARED_BYTES = 4 * 1024 * 1024 * 1024
#: an entry over this many bytes that expands more than MAX_RATIO times is refused
RATIO_FLOOR_BYTES = 256 * 1024
MAX_RATIO = 400
#: visuals on one page we are willing to read
MAX_VISUALS_PER_PAGE = 400
#: the exports' row unit: a grid row is this fraction of a grid column's width
ROW_TO_COL = 0.62
#: a text box this short, at the top of a page, names the page
MAX_PAGE_TITLE_TEXT = MAX_PAGE_TITLE


class ImportRefused(ValueError):
    """The file cannot be imported; the message is for the person who chose it."""


# ── the mapping table: a Power BI visual type -> what it becomes ────────────
#
# (kind, note).  kind is a TILE_KINDS entry, or one of the WORDS below.  Everything
# not in this table is UNKNOWN: listed as "a visual QueryStudio has no equal for",
# and its data fields are still shown so the author sees what it read.

PARAMETER = "parameter"      # a slicer: becomes a report parameter the viewer picks
TEXT = "text"                # a text box: its words name the page / are listed
DECORATION = "decoration"    # a shape, image, button, navigator: no tile, listed
UNSUPPORTED = "unsupported"  # a data visual with no equal here: listed, place kept
MATRIX = "matrix"            # pivot when it has column fields, outline otherwise
CARDS = "cards"              # one number tile per value

VISUAL_KINDS: Dict[str, Tuple[str, str]] = {
    "clusteredColumnChart": ("bar", ""),
    "columnChart": ("stacked_bar", ""),
    "hundredPercentStackedColumnChart": ("stacked_bar", "drawn as stacked bars of the values, not of 100 %"),
    "clusteredBarChart": ("hbar", ""),
    "barChart": ("hbar", "Power BI stacks these sideways bars; here a split series is drawn side by side"),
    "hundredPercentStackedBarChart": ("hbar", "drawn as sideways bars of the values, not of 100 %"),
    "lineChart": ("line", ""),
    "areaChart": ("area", ""),
    "stackedAreaChart": ("stacked_area", ""),
    "lineStackedColumnComboChart": ("combo", ""),
    "lineClusteredColumnComboChart": ("combo", ""),
    "ribbonChart": ("stacked_bar", "a ribbon chart is drawn as stacked bars"),
    "pieChart": ("pie", ""),
    "donutChart": ("donut", ""),
    "treemap": ("treemap", ""),
    "funnel": ("funnel", ""),
    "waterfallChart": ("waterfall", ""),
    "scatterChart": ("scatter", ""),
    "card": (CARDS, ""),
    "cardVisual": (CARDS, "each value of the card is one number tile"),
    "multiRowCard": ("table", "a multi-row card is drawn as a table"),
    "kpi": ("number", "the KPI's trend axis and goal are not drawn"),
    "gauge": ("number", "a gauge is drawn as a number; the dial and its goal are not"),
    "tableEx": ("table", ""),
    "pivotTable": (MATRIX, ""),
    "slicer": (PARAMETER, ""),
    "advancedSlicerVisual": (PARAMETER, ""),
    "textbox": (TEXT, ""),
    "shape": (DECORATION, "a shape"),
    "basicShape": (DECORATION, "a shape"),
    "image": (DECORATION, "an image"),
    "actionButton": (DECORATION, "a button"),
    "pageNavigator": (DECORATION, "a page navigator (the report's pages are its tabs)"),
    "bookmarkNavigator": (DECORATION, "a bookmark navigator (bookmarks are not brought across)"),
    "group": (DECORATION, "a group of visuals (its visuals are read one by one)"),
    "azureMap": (UNSUPPORTED, "a map"),
    "map": (UNSUPPORTED, "a map"),
    "shapeMap": (UNSUPPORTED, "a shape map"),
    "filledMap": (UNSUPPORTED, "a filled map"),
    "esriVisual": (UNSUPPORTED, "an ArcGIS map"),
    "decompositionTreeVisual": (UNSUPPORTED, "a decomposition tree"),
    "keyDriversVisual": (UNSUPPORTED, "a key influencers visual"),
    "qnaVisual": (UNSUPPORTED, "a Q&A visual"),
    "aiNarratives": (UNSUPPORTED, "a smart narrative"),
    "scriptVisual": (UNSUPPORTED, "an R or Python visual"),
    "pythonVisual": (UNSUPPORTED, "a Python visual"),
}
#: a custom visual's type starts with one of these (its id follows)
CUSTOM_VISUAL_PREFIXES = ("PBI_CV_", "PowerApps_", "FlowVisual_")

#: Power BI's aggregation codes (QueryAggregateFunction) -> the canvas's words
#: code 5 = CountNonNull (Power BI's COUNTA): the rows with a value, the canvas's ``count_values``
AGGREGATION_CODES: Dict[int, str] = {0: "sum", 1: "avg", 2: "count", 3: "min", 4: "max", 5: "count_values"}
AGGREGATION_CODE_WORDS: Dict[int, str] = {6: "median", 7: "standard deviation", 8: "variance"}
#: the simple DAX the import translates; anything else is listed with its text
DAX_FUNCTIONS: Dict[str, str] = {"SUM": "sum", "AVERAGE": "avg", "MIN": "min", "MAX": "max",
                                 "COUNT": "count", "COUNTA": "count_values", "DISTINCTCOUNT": "count_distinct"}
_DAX_SIMPLE = re.compile(
    r"^\s*(SUM|AVERAGE|MIN|MAX|COUNT|COUNTA|DISTINCTCOUNT)\s*\(\s*"
    r"(?:'(?P<qtable>[^']+)'|(?P<table>[A-Za-z_][\w]*))?\s*\[(?P<column>[^\]]+)\]\s*\)\s*$",
    re.IGNORECASE)

#: which well a Power BI role fills
ROLE_WELLS: Dict[str, str] = {
    "Category": "dim", "Rows": "dim", "Group": "dim", "Details": "dim", "Axis": "dim", "Fields": "dim",
    "Values": "value", "Y": "value", "Y2": "value", "Value": "value", "Data": "value", "X": "value",
    "Size": "value", "Indicator": "value", "Goal": "value",
    "Series": "series", "Legend": "series", "Columns": "series",
    "Tooltips": "tooltip",
}
#: the filter shapes the report's own filter rows can carry
COMPARISON_OPS: Dict[int, str] = {0: "eq", 1: "gt", 2: "gte", 3: "lt", 4: "lte"}
#: the chart kinds that take a stored sort (the browser's rule in canvasModel.ts)
_NO_SORT_KINDS = ("line", "area", "stacked_area", "waterfall", "scatter", "bubble")


# ── the parsed shape ────────────────────────────────────────────────────────

@dataclass
class Field:
    kind: str                       # column | measure | aggregation | hierarchy_level | other
    entity: str
    prop: str
    function: Optional[int] = None  # aggregation code
    words: str = ""                 # for kind other: what it was
    active: bool = True
    display_name: str = ""

    @property
    def ref(self) -> str:
        return f"{self.entity}.{self.prop}" if self.entity else self.prop


@dataclass
class Condition:
    op: str                         # eq neq gt gte lt lte in not_in between starts_with contains
    value: Any = None
    value2: Any = None


@dataclass
class Filter:
    name: str
    scope: str                      # report | page | visual
    scope_name: str                 # page / visual display name
    field: Optional[Field]
    conditions: List[Condition] = field(default_factory=list)
    unsupported: str = ""           # a shape not translated (words)
    how_created: str = ""

    @property
    def narrows(self) -> bool:
        return bool(self.conditions) or bool(self.unsupported)


@dataclass
class Visual:
    name: str
    visual_type: str
    x: float
    y: float
    w: float
    h: float
    title: str = ""
    roles: Dict[str, List[Field]] = field(default_factory=dict)
    filters: List[Filter] = field(default_factory=list)
    sort: Optional[Tuple[Field, str]] = None
    text: str = ""                  # a text box's words
    group: Optional[str] = None     # the group container it sits in
    is_group: bool = False


@dataclass
class Page:
    name: str
    title: str
    width: float
    height: float
    visuals: List[Visual] = field(default_factory=list)
    filters: List[Filter] = field(default_factory=list)
    page_type: str = ""             # Tooltip / Drillthrough / ""
    hidden: bool = False


@dataclass
class Parsed:
    format: str                     # legacy | pbir
    pages: List[Page]
    report_filters: List[Filter]
    measures: Dict[str, str]        # "Table.Measure" -> DAX text (text models only)
    model_present: bool
    tables: Dict[str, List[str]]    # table -> column names (text models only)
    relationships: List[str]        # "From[col] -> To[col]" (text models only)
    theme: Optional[Dict[str, Any]]
    notes: List[str] = field(default_factory=list)
    custom_visuals: List[str] = field(default_factory=list)   # the custom visuals packed in the file


# ── reading the zip safely ──────────────────────────────────────────────────

class _Zip:
    """The entries of an untrusted zip, read by name within the limits."""

    def __init__(self, data: bytes, filename: str = ""):
        if len(data) > MAX_FILE_BYTES:
            raise ImportRefused(f"The file is {len(data) / 1048576:.0f} MB; a Power BI report file of up to "
                                f"{MAX_FILE_BYTES // 1048576} MB can be imported.")
        if len(data) < 4 or data[:2] != b"PK":
            raise ImportRefused("This is not a Power BI report file: a .pbix, .pbit or a zipped .pbip project "
                                "is a zip archive, and this file is not one.")
        try:
            self.z = zipfile.ZipFile(io.BytesIO(data))
            infos = self.z.infolist()
        except (zipfile.BadZipFile, ValueError, OSError, EOFError) as exc:
            raise ImportRefused(f"The file could not be opened as a zip archive ({exc}). It may be cut short or damaged.")
        if len(infos) > MAX_ENTRIES:
            raise ImportRefused(f"The file holds {len(infos):,} entries; a report file holds at most {MAX_ENTRIES:,}.")
        declared = sum(max(0, int(i.file_size)) for i in infos)
        if declared > MAX_DECLARED_BYTES:
            raise ImportRefused(f"The file says it unpacks to {declared / 1073741824:.1f} GB, which is more than a "
                                f"report file can be. It is refused.")
        self.infos = {i.filename: i for i in infos}
        self.names = [i.filename for i in infos]
        self.read_total = 0
        self.filename = filename
        #: the custom visuals packed in the file, by the type name a visual carries
        #: (``Report/CustomVisuals/<type>/package.json``; a legacy name is ``<name><digits>``)
        self.custom_visuals = sorted({n.split("CustomVisuals/", 1)[1].split("/", 1)[0]
                                      for n in self.names if "CustomVisuals/" in n and n.split("CustomVisuals/", 1)[1].count("/") >= 1})

    def has(self, name: str) -> bool:
        return name in self.infos

    def read(self, name: str) -> bytes:
        info = self.infos.get(name)
        if info is None:
            raise ImportRefused(f"The file has no entry named {name}.")
        if info.file_size > MAX_ENTRY_BYTES:
            raise ImportRefused(f"The entry {name} is {info.file_size / 1048576:.0f} MB; one part of a report file "
                                f"is read up to {MAX_ENTRY_BYTES // 1048576} MB.")
        if info.file_size > RATIO_FLOOR_BYTES and info.compress_size > 0 \
                and info.file_size / info.compress_size > MAX_RATIO:
            raise ImportRefused(f"The entry {name} expands {info.file_size // max(1, info.compress_size):,} times when "
                                f"unpacked, which no report file does. It is refused.")
        cap = MAX_ENTRY_BYTES + 1
        out = bytearray()
        try:
            with self.z.open(info) as fh:
                while True:
                    chunk = fh.read(1024 * 1024)
                    if not chunk:
                        break
                    out += chunk
                    if len(out) >= cap or self.read_total + len(out) > MAX_READ_BYTES:
                        raise ImportRefused(f"Reading {name} went past the size the file declared, or past "
                                            f"{MAX_READ_BYTES // 1048576} MB read in all. It is refused.")
        except (zipfile.BadZipFile, ValueError, OSError, EOFError, RuntimeError) as exc:
            raise ImportRefused(f"The entry {name} could not be unpacked ({exc}).")
        self.read_total += len(out)
        return bytes(out)

    def read_json(self, name: str) -> Any:
        raw = self.read(name)
        return _loads(raw, name)


def _loads(raw: bytes, name: str) -> Any:
    """JSON from bytes that may be UTF-16-LE (legacy Layout, DataModelSchema) or UTF-8 with a BOM."""
    text: Optional[str] = None
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        text = raw.decode("utf-16", errors="strict")
    elif len(raw) >= 2 and raw[1:2] == b"\x00":
        text = raw.decode("utf-16-le", errors="strict")
    else:
        text = raw.decode("utf-8-sig", errors="strict")
    try:
        return json.loads(text)
    except ValueError as exc:
        raise ImportRefused(f"The entry {name} is not readable JSON ({str(exc)[:120]}).")


# ── expressions ─────────────────────────────────────────────────────────────

def _source_entity(src: Any, aliases: Dict[str, str]) -> str:
    """``SourceRef``: ``Entity`` directly, or ``Source`` = an alias of the query's From list."""
    if not isinstance(src, dict):
        return ""
    ref = src.get("SourceRef") if isinstance(src.get("SourceRef"), dict) else src
    if not isinstance(ref, dict):
        return ""
    if ref.get("Entity"):
        return str(ref["Entity"])
    if ref.get("Source") is not None:
        return aliases.get(str(ref["Source"]), str(ref["Source"]))
    return ""


def parse_field(expr: Any, aliases: Dict[str, str]) -> Optional[Field]:
    """One query expression as a Field; None when it is nothing we read."""
    if not isinstance(expr, dict) or not expr:
        return None
    if "Column" in expr and isinstance(expr["Column"], dict):
        c = expr["Column"]
        return Field("column", _source_entity(c.get("Expression"), aliases), str(c.get("Property") or ""))
    if "Measure" in expr and isinstance(expr["Measure"], dict):
        m = expr["Measure"]
        return Field("measure", _source_entity(m.get("Expression"), aliases), str(m.get("Property") or ""))
    if "Aggregation" in expr and isinstance(expr["Aggregation"], dict):
        a = expr["Aggregation"]
        inner = parse_field(a.get("Expression"), aliases)
        fn = a.get("Function")
        if inner is None:
            return Field("other", "", "", words="an aggregation of something that is not a column")
        return Field("aggregation", inner.entity, inner.prop, function=fn if isinstance(fn, int) else None)
    if "HierarchyLevel" in expr and isinstance(expr["HierarchyLevel"], dict):
        hl = expr["HierarchyLevel"]
        level = str(hl.get("Level") or "")
        hier = (hl.get("Expression") or {}).get("Hierarchy") if isinstance(hl.get("Expression"), dict) else None
        entity, base = "", ""
        if isinstance(hier, dict):
            hx = hier.get("Expression")
            if isinstance(hx, dict) and "PropertyVariationSource" in hx:
                pvs = hx["PropertyVariationSource"]
                entity = _source_entity(pvs.get("Expression"), aliases)
                base = str(pvs.get("Property") or "")
            else:
                entity = _source_entity(hx, aliases)
        words = f"the level {level} of a hierarchy" + (f" on {base}" if base else "")
        return Field("hierarchy_level", entity, level, words=words)
    key = next(iter(expr))
    return Field("other", "", "", words=f"a {key} expression")


def _literal(v: Any) -> Any:
    """A Power BI literal: ``'text'`` (with '' as a quote), ``2014L``, ``12.5D``, true / false,
    null, ``datetime'2020-01-01T00:00:00'``."""
    if not isinstance(v, str):
        return v
    s = v.strip()
    if len(s) >= 2 and s[0] == "'" and s[-1] == "'":
        return s[1:-1].replace("''", "'")
    low = s.lower()
    if low in ("true", "false"):
        return low == "true"
    if low == "null":
        return None
    m = re.match(r"^(-?\d+)L$", s)
    if m:
        return int(m.group(1))
    m = re.match(r"^(-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?)[DMF]?$", s)
    if m:
        try:
            return float(m.group(1)) if ("." in m.group(1) or "e" in m.group(1).lower()) else int(m.group(1))
        except ValueError:
            return s
    m = re.match(r"^(?:datetime|date)'([^']+)'$", s, re.IGNORECASE)
    if m:
        t = m.group(1)
        return t[:10] if t.endswith("T00:00:00") else t
    return s


def _literal_of(expr: Any) -> Tuple[bool, Any]:
    if isinstance(expr, dict) and isinstance(expr.get("Literal"), dict):
        return True, _literal(expr["Literal"].get("Value"))
    return False, None


def _same_field(f: Field, want: Optional[Field]) -> bool:
    """Is the condition's column the card's field?  A card on a date-hierarchy LEVEL (Month) has
    its condition on Power BI's hidden date table, so a level is matched by its name alone."""
    if want is None:
        return True
    if want.kind == "hierarchy_level":
        return f.prop == want.prop
    return (f.entity, f.prop) == (want.entity, want.prop)


def parse_condition(cond: Any, aliases: Dict[str, str], want: Optional[Field]) -> Tuple[List[Condition], str]:
    """``(conditions, unsupported words)`` for one Where condition.  Several conditions are ANDed."""
    if not isinstance(cond, dict) or not cond:
        return [], "an empty condition"
    key = next(iter(cond))
    body = cond[key]
    if key == "In" and isinstance(body, dict):
        exprs = body.get("Expressions") if isinstance(body.get("Expressions"), list) else []
        if len(exprs) != 1:
            return [], "a filter on several columns at once"
        f = parse_field(exprs[0], aliases)
        if f is None or not _same_field(f, want):
            return [], "a filter whose condition is on another field than its card"
        vals = []
        for row in body.get("Values") or []:
            if not isinstance(row, list) or len(row) != 1:
                return [], "a filter of value pairs"
            ok, v = _literal_of(row[0])
            if not ok:
                return [], "a filter on a value that is not a plain literal"
            vals.append(v)
        if not vals:
            return [], "a filter with no value chosen"
        if body.get("Table") is not None:
            return [], "a filter from a table expression"
        return [Condition("in", vals)], ""
    if key == "Comparison" and isinstance(body, dict):
        kind = body.get("ComparisonKind")
        left, right = body.get("Left"), body.get("Right")
        lf, rf = parse_field(left, aliases), parse_field(right, aliases)
        lok, lv = _literal_of(left)
        rok, rv = _literal_of(right)
        if lf is not None and rok:
            col, val = lf, rv
        elif rf is not None and lok:
            col, val = rf, lv
            kind = {1: 3, 2: 4, 3: 1, 4: 2}.get(kind, kind)   # the literal on the left: flip the sense
        else:
            return [], "a comparison between two fields, or two values"
        if not _same_field(col, want):
            return [], "a filter whose condition is on another field than its card"
        op = COMPARISON_OPS.get(kind if isinstance(kind, int) else -1)
        if op is None:
            return [], f"a comparison of kind {kind}"
        return [Condition(op, val)], ""
    if key == "Not" and isinstance(body, dict):
        inner, why = parse_condition(body.get("Expression"), aliases, want)
        if why:
            return [], f"NOT ({why})"
        if len(inner) == 1 and inner[0].op == "in":
            return [Condition("not_in", inner[0].value)], ""
        if len(inner) == 1 and inner[0].op == "eq":
            return [Condition("neq", inner[0].value)], ""
        return [], "a NOT over a condition other than a list of values or an equality"
    if key == "And" and isinstance(body, dict):
        l, lw = parse_condition(body.get("Left"), aliases, want)
        r, rw = parse_condition(body.get("Right"), aliases, want)
        if lw or rw:
            return [], lw or rw
        both = l + r
        if len(both) == 2 and {both[0].op, both[1].op} == {"gte", "lte"}:
            lo = next(c for c in both if c.op == "gte")
            hi = next(c for c in both if c.op == "lte")
            return [Condition("between", lo.value, hi.value)], ""
        return both, ""
    if key == "Or":
        return [], "an OR of two conditions"
    if key in ("StartsWith", "Contains") and isinstance(body, dict):
        lf = parse_field(body.get("Left"), aliases)
        rok, rv = _literal_of(body.get("Right"))
        if lf is None or not rok:
            return [], f"a {key} on something that is not a field and a value"
        if not _same_field(lf, want):
            return [], "a filter whose condition is on another field than its card"
        return [Condition("starts_with" if key == "StartsWith" else "contains", rv)], ""
    if key == "Between" and isinstance(body, dict):
        lf = parse_field(body.get("Expression"), aliases)
        lok, lv = _literal_of(body.get("LowerBound"))
        uok, uv = _literal_of(body.get("UpperBound"))
        if lf is None or not (lok and uok):
            return [], "a range whose ends are not plain values"
        return [Condition("between", lv, uv)], ""
    if key in ("DateSpan", "RelativeDate", "TopN", "Percentile"):
        return [], {"DateSpan": "a relative date range", "RelativeDate": "a relative date",
                    "TopN": "a top N filter", "Percentile": "a percentile filter"}[key]
    return [], f"a {key} condition"


def parse_filter(raw: Any, scope: str, scope_name: str, aliases: Dict[str, str]) -> Optional[Filter]:
    """One filter card of the report, a page or a visual (either format)."""
    if not isinstance(raw, dict):
        return None
    f = parse_field(raw.get("field") if raw.get("field") is not None else raw.get("expression"), aliases)
    name = str(raw.get("name") or "Filter")
    how = raw.get("howCreated")
    how = {1: "Drillthrough", "Drillthrough": "Drillthrough"}.get(how, str(how) if how is not None else "")
    out = Filter(name=name, scope=scope, scope_name=scope_name, field=f, how_created=how)
    body = raw.get("filter")
    if isinstance(body, dict):
        local = dict(aliases)
        for fr in body.get("From") or []:
            if isinstance(fr, dict) and fr.get("Name") is not None and fr.get("Entity"):
                local[str(fr["Name"])] = str(fr["Entity"])
        # the card's field may name its table by alias too
        if f is not None and f.entity in local:
            f.entity = local[f.entity]
        conds: List[Condition] = []
        for w in body.get("Where") or []:
            c, why = parse_condition((w or {}).get("Condition") if isinstance(w, dict) else None, local, f)
            if why:
                out.unsupported = why
                out.conditions = []
                break
            conds.extend(c)
        else:
            out.conditions = conds
            if body.get("Where") and not conds:
                out.unsupported = "a condition that could not be read"
    ftype = str(raw.get("type") or "")
    if not out.narrows and ftype in ("TopN", "RelativeDate", "Tuple", "RelativeTime") and body:
        out.unsupported = f"a {ftype} filter"
    return out


def _filters_of(raw: Any, scope: str, scope_name: str, aliases: Dict[str, str]) -> List[Filter]:
    """A legacy ``filters`` string or a PBIR ``filterConfig`` / list."""
    items: Any = raw
    if isinstance(raw, str):
        raw = raw.strip()
        if not raw:
            return []
        try:
            items = json.loads(raw)
        except ValueError:
            return [Filter("Filter", scope, scope_name, None, unsupported="a filter that could not be read")]
    if isinstance(items, dict):
        items = items.get("filters")
    if not isinstance(items, list):
        return []
    out = []
    for it in items:
        f = parse_filter(it, scope, scope_name, aliases)
        if f is not None:
            out.append(f)
    return out


def _title_text(objects: Any) -> Tuple[Optional[str], bool]:
    """``(text, shown)`` of a visual's title object (``vcObjects`` / ``visualContainerObjects``)."""
    if not isinstance(objects, dict) or not isinstance(objects.get("title"), list) or not objects["title"]:
        return None, True
    props = (objects["title"][0] or {}).get("properties") if isinstance(objects["title"][0], dict) else None
    if not isinstance(props, dict):
        return None, True
    shown = True
    show = props.get("show")
    if isinstance(show, dict):
        ok, v = _literal_of(show.get("expr"))
        if ok and v is False:
            shown = False
    text = props.get("text")
    if isinstance(text, dict):
        ok, v = _literal_of(text.get("expr"))
        if ok and isinstance(v, str):
            return v, shown
    return None, shown


def _textbox_text(objects: Any) -> str:
    if not isinstance(objects, dict) or not isinstance(objects.get("general"), list):
        return ""
    parts: List[str] = []
    for g in objects["general"]:
        props = (g or {}).get("properties") if isinstance(g, dict) else None
        for para in (props or {}).get("paragraphs") or []:
            runs = [str(r.get("value") or "") for r in (para or {}).get("textRuns") or [] if isinstance(r, dict)]
            if runs:
                parts.append("".join(runs))
    return "\n".join(p for p in parts if p.strip()).strip()


# ── the LEGACY reader (Report/Layout) ───────────────────────────────────────

def _read_legacy(z: _Zip) -> Parsed:
    lay = z.read_json("Report/Layout")
    if not isinstance(lay, dict) or not isinstance(lay.get("sections"), list):
        raise ImportRefused("Report/Layout is not a Power BI layout: it has no pages (sections).")
    notes: List[str] = []
    pages: List[Page] = []
    for sec in lay["sections"]:
        if not isinstance(sec, dict):
            continue
        pname = str(sec.get("name") or f"page{len(pages) + 1}")
        ptitle = str(sec.get("displayName") or pname)
        page = Page(pname, ptitle, _num(sec.get("width"), 1280), _num(sec.get("height"), 720))
        pconf = _maybe_json(sec.get("config"))
        if isinstance(pconf, dict):
            vis = pconf.get("visibility")
            page.hidden = vis in (1, "HiddenInViewMode")
            ptype = ((pconf.get("type") if isinstance(pconf.get("type"), str) else None)
                     or ("Tooltip" if _page_is_tooltip(pconf) else ""))
            page.page_type = ptype
        page.filters = _filters_of(sec.get("filters"), "page", ptitle, {})
        containers = sec.get("visualContainers") if isinstance(sec.get("visualContainers"), list) else []
        if len(containers) > MAX_VISUALS_PER_PAGE:
            raise ImportRefused(f"Page {ptitle} holds {len(containers)} visuals; a page is read up to {MAX_VISUALS_PER_PAGE}.")
        groups: Dict[str, Tuple[float, float]] = {}
        parents: Dict[str, str] = {}
        for vc in containers:
            if not isinstance(vc, dict):
                continue
            cfg = _maybe_json(vc.get("config"))
            if not isinstance(cfg, dict):
                notes.append(f"A visual on page {ptitle} has settings that could not be read; it is left out.")
                continue
            x, y, w, h = (_num(vc.get(k)) for k in ("x", "y", "width", "height"))
            lay0 = (cfg.get("layouts") or [{}])[0] if isinstance(cfg.get("layouts"), list) and cfg["layouts"] else {}
            pos = lay0.get("position") if isinstance(lay0, dict) and isinstance(lay0.get("position"), dict) else {}
            if w <= 0 and h <= 0 and pos:
                x, y, w, h = (_num(pos.get(k)) for k in ("x", "y", "width", "height"))
            vname = str(cfg.get("name") or vc.get("id") or f"v{len(page.visuals) + 1}")
            parent = cfg.get("parentGroupName")
            if isinstance(cfg.get("singleVisualGroup"), dict):
                groups[vname] = (x, y)
                if parent:
                    parents[vname] = str(parent)
                g = Visual(vname, "group", x, y, w, h, is_group=True,
                           title=str(cfg["singleVisualGroup"].get("displayName") or ""))
                g.group = str(parent) if parent else None
                page.visuals.append(g)
                continue
            sv = cfg.get("singleVisual") if isinstance(cfg.get("singleVisual"), dict) else {}
            vtype = str(sv.get("visualType") or "")
            if not vtype:
                notes.append(f"A visual on page {ptitle} names no type; it is left out.")
                continue
            v = Visual(vname, vtype, x, y, w, h)
            v.group = str(parent) if parent else None
            pq = sv.get("prototypeQuery") if isinstance(sv.get("prototypeQuery"), dict) else {}
            aliases = {str(fr.get("Name")): str(fr.get("Entity")) for fr in pq.get("From") or []
                       if isinstance(fr, dict) and fr.get("Name") is not None and fr.get("Entity")}
            by_name: Dict[str, Field] = {}
            for sel in pq.get("Select") or []:
                if not isinstance(sel, dict):
                    continue
                f = parse_field({k: val for k, val in sel.items() if k not in ("Name", "NativeReferenceName")}, aliases)
                if f is not None:
                    f.display_name = str(sel.get("NativeReferenceName") or "")
                    by_name[str(sel.get("Name") or "")] = f
            proj = sv.get("projections") if isinstance(sv.get("projections"), dict) else {}
            for role, items in proj.items():
                fields = []
                for it in items if isinstance(items, list) else []:
                    qr = str((it or {}).get("queryRef") or "") if isinstance(it, dict) else ""
                    f = by_name.get(qr)
                    if f is None:
                        fields.append(Field("other", "", qr, words=f"a field the visual names but its query does not ({qr})"))
                        continue
                    f2 = Field(f.kind, f.entity, f.prop, f.function, f.words, bool(it.get("active", True)) if isinstance(it, dict) else True, f.display_name)
                    fields.append(f2)
                v.roles[str(role)] = fields
            if not proj and by_name:
                v.roles["Values"] = list(by_name.values())
            for ob in pq.get("OrderBy") or []:
                if isinstance(ob, dict):
                    sf = parse_field(ob.get("Expression"), aliases)
                    if sf is not None:
                        v.sort = (sf, "asc" if ob.get("Direction") == 1 else "desc")
                        break
            t, shown = _title_text(sv.get("vcObjects"))
            v.title = (t or "") if shown else ""
            if vtype == "textbox":
                v.text = _textbox_text(sv.get("objects"))
            v.filters = _filters_of(vc.get("filters"), "visual", v.title or vtype, aliases)
            page.visuals.append(v)
        _offset_groups(page, groups, parents)
        pages.append(page)
    rconf = _maybe_json(lay.get("config"))
    theme = _theme_legacy(z, rconf if isinstance(rconf, dict) else {}, lay)
    report_filters = _filters_of(lay.get("filters"), "report", "the report", {})
    measures, tables, rels, present = _model_text(z)
    return Parsed("legacy", pages, report_filters, measures, present, tables, rels, theme, notes, list(z.custom_visuals))


def _page_is_tooltip(pconf: dict) -> bool:
    objs = pconf.get("objects") if isinstance(pconf.get("objects"), dict) else {}
    for grp in ("pageInformation",):
        for row in objs.get(grp) or []:
            props = (row or {}).get("properties") if isinstance(row, dict) else {}
            tt = (props or {}).get("tooltip")
            if isinstance(tt, dict):
                ok, v = _literal_of(tt.get("expr"))
                if ok and v is True:
                    return True
    return False


def _offset_groups(page: Page, groups: Dict[str, Tuple[float, float]], parents: Dict[str, str]) -> None:
    """A visual inside a group has its position RELATIVE to the group: add the group's own
    (and its parents') offset so every tile is placed on the page."""
    def offset(gname: str, depth: int = 0) -> Tuple[float, float]:
        if gname not in groups or depth > 20:
            return 0.0, 0.0
        gx, gy = groups[gname]
        px, py = offset(parents[gname], depth + 1) if gname in parents else (0.0, 0.0)
        return gx + px, gy + py
    for v in page.visuals:
        if v.group and not v.is_group:
            dx, dy = offset(v.group)
            v.x += dx
            v.y += dy


def _theme_legacy(z: _Zip, rconf: dict, lay: dict) -> Optional[Dict[str, Any]]:
    coll = rconf.get("themeCollection") if isinstance(rconf.get("themeCollection"), dict) else {}
    cands = []
    custom = coll.get("customTheme") if isinstance(coll.get("customTheme"), dict) else None
    if custom and custom.get("name"):
        cands.append(f"Report/StaticResources/RegisteredResources/{custom['name']}")
    if isinstance(lay.get("theme"), str) and lay["theme"]:
        cands.append(f"Report/StaticResources/RegisteredResources/{lay['theme']}")
    base = coll.get("baseTheme") if isinstance(coll.get("baseTheme"), dict) else None
    if base and base.get("name"):
        cands.append(f"Report/StaticResources/SharedResources/BaseThemes/{base['name']}.json")
    return _first_theme(z, cands)


def _first_theme(z: _Zip, names: Iterable[str]) -> Optional[Dict[str, Any]]:
    for n in names:
        if z.has(n):
            try:
                t = z.read_json(n)
            except ImportRefused:
                continue
            if isinstance(t, dict) and isinstance(t.get("dataColors"), list):
                return t
    return None


# ── the PBIR reader (Report/definition) ─────────────────────────────────────

def _pbir_root(z: _Zip) -> Optional[str]:
    """The prefix before ``definition/report.json``: ``Report/`` in a .pbix, ``<name>.Report/`` in a
    zipped .pbip project (or ``definition/`` at the root)."""
    hits = sorted(n for n in z.names if n.endswith("definition/report.json") and n.count("/") <= 3)
    for n in hits:
        return n[: -len("definition/report.json")]
    return None


def _read_pbir(z: _Zip, root: str) -> Parsed:
    d = root + "definition/"
    rep = z.read_json(d + "report.json")
    if not isinstance(rep, dict):
        raise ImportRefused("report.json is not a Power BI report definition.")
    notes: List[str] = []
    order: List[str] = []
    if z.has(d + "pages/pages.json"):
        pj = z.read_json(d + "pages/pages.json")
        if isinstance(pj, dict) and isinstance(pj.get("pageOrder"), list):
            order = [str(p) for p in pj["pageOrder"]]
    page_dirs = sorted({n[len(d + "pages/"):].split("/", 1)[0] for n in z.names
                        if n.startswith(d + "pages/") and n.endswith("/page.json")})
    for p in page_dirs:
        if p not in order:
            order.append(p)
    pages: List[Page] = []
    for pid in order:
        pfile = f"{d}pages/{pid}/page.json"
        if not z.has(pfile):
            notes.append(f"The page order names a page that is not in the file ({pid}).")
            continue
        pj = z.read_json(pfile)
        if not isinstance(pj, dict):
            continue
        ptitle = str(pj.get("displayName") or pid)
        page = Page(pid, ptitle, _num(pj.get("width"), 1280), _num(pj.get("height"), 720))
        page.page_type = str(pj.get("type") or "")
        page.hidden = str(pj.get("visibility") or "") == "HiddenInViewMode"
        page.filters = _filters_of(pj.get("filterConfig"), "page", ptitle, {})
        vprefix = f"{d}pages/{pid}/visuals/"
        vfiles = sorted(n for n in z.names if n.startswith(vprefix) and n.endswith("/visual.json"))
        if len(vfiles) > MAX_VISUALS_PER_PAGE:
            raise ImportRefused(f"Page {ptitle} holds {len(vfiles)} visuals; a page is read up to {MAX_VISUALS_PER_PAGE}.")
        groups: Dict[str, Tuple[float, float]] = {}
        parents: Dict[str, str] = {}
        for vf in vfiles:
            vj = z.read_json(vf)
            if not isinstance(vj, dict):
                continue
            pos = vj.get("position") if isinstance(vj.get("position"), dict) else {}
            x, y, w, h = (_num(pos.get(k)) for k in ("x", "y", "width", "height"))
            vname = str(vj.get("name") or vf.rsplit("/", 2)[-2])
            parent = vj.get("parentGroupName")
            if isinstance(vj.get("visualGroup"), dict):
                groups[vname] = (x, y)
                if parent:
                    parents[vname] = str(parent)
                g = Visual(vname, "group", x, y, w, h, is_group=True, title=str(vj["visualGroup"].get("displayName") or ""))
                g.group = str(parent) if parent else None
                page.visuals.append(g)
                continue
            vis = vj.get("visual") if isinstance(vj.get("visual"), dict) else None
            if vis is None:
                notes.append(f"An item on page {ptitle} is neither a visual nor a group; it is left out.")
                continue
            vtype = str(vis.get("visualType") or "")
            v = Visual(vname, vtype or "unknown", x, y, w, h)
            v.group = str(parent) if parent else None
            q = vis.get("query") if isinstance(vis.get("query"), dict) else {}
            qs = q.get("queryState") if isinstance(q.get("queryState"), dict) else {}
            for role, body in qs.items():
                fields = []
                for pr in (body or {}).get("projections") or [] if isinstance(body, dict) else []:
                    if not isinstance(pr, dict):
                        continue
                    f = parse_field(pr.get("field"), {})
                    if f is None:
                        f = Field("other", "", "", words="a field that could not be read")
                    f.active = bool(pr.get("active", True))
                    f.display_name = str(pr.get("displayName") or pr.get("nativeQueryRef") or "")
                    fields.append(f)
                v.roles[str(role)] = fields
            sd = q.get("sortDefinition") if isinstance(q.get("sortDefinition"), dict) else {}
            for s in sd.get("sort") or []:
                if isinstance(s, dict):
                    sf = parse_field(s.get("field"), {})
                    if sf is not None:
                        v.sort = (sf, "asc" if str(s.get("direction") or "").lower().startswith("asc") else "desc")
                        break
            t, shown = _title_text(vis.get("visualContainerObjects"))
            v.title = (t or "") if shown else ""
            if vtype == "textbox":
                v.text = _textbox_text(vis.get("objects"))
            v.filters = _filters_of(vj.get("filterConfig"), "visual", v.title or vtype, {})
            page.visuals.append(v)
        _offset_groups(page, groups, parents)
        pages.append(page)
    if not pages:
        raise ImportRefused("The report definition has no pages.")
    theme = _theme_pbir(z, root, rep)
    report_filters = _filters_of(rep.get("filterConfig"), "report", "the report", {})
    measures, tables, rels, present = _model_text(z)
    return Parsed("pbir", pages, report_filters, measures, present, tables, rels, theme, notes, list(z.custom_visuals))


def _theme_pbir(z: _Zip, root: str, rep: dict) -> Optional[Dict[str, Any]]:
    coll = rep.get("themeCollection") if isinstance(rep.get("themeCollection"), dict) else {}
    cands = []
    custom = coll.get("customTheme") if isinstance(coll.get("customTheme"), dict) else None
    if custom and custom.get("name"):
        cands.append(f"{root}StaticResources/RegisteredResources/{custom['name']}")
    base = coll.get("baseTheme") if isinstance(coll.get("baseTheme"), dict) else None
    if base and base.get("name"):
        cands.append(f"{root}StaticResources/SharedResources/BaseThemes/{base['name']}.json")
    return _first_theme(z, cands)


# ── the model as TEXT (a .pbit's DataModelSchema, a .pbip's model.bim / TMDL) ──

def _model_text(z: _Zip) -> Tuple[Dict[str, str], Dict[str, List[str]], List[str], bool]:
    """``(measures by "Table.Name", columns by table, relationships, present)``."""
    if z.has("DataModelSchema"):
        return _model_from_bim(z.read_json("DataModelSchema")) + (True,)
    bims = sorted(n for n in z.names if n.endswith("model.bim") and n.count("/") <= 3)
    if bims:
        return _model_from_bim(z.read_json(bims[0])) + (True,)
    tmdl = sorted(n for n in z.names if ".SemanticModel/definition/tables/" in n and n.endswith(".tmdl"))
    if tmdl:
        return _model_from_tmdl(z, tmdl) + (True,)
    return {}, {}, [], False


def _model_from_bim(sch: Any) -> Tuple[Dict[str, str], Dict[str, List[str]], List[str]]:
    model = sch.get("model") if isinstance(sch, dict) and isinstance(sch.get("model"), dict) else sch
    measures: Dict[str, str] = {}
    tables: Dict[str, List[str]] = {}
    rels: List[str] = []
    if not isinstance(model, dict):
        return measures, tables, rels
    for t in model.get("tables") or []:
        if not isinstance(t, dict) or not t.get("name"):
            continue
        tname = str(t["name"])
        tables[tname] = [str(c.get("name")) for c in t.get("columns") or [] if isinstance(c, dict) and c.get("name")]
        for m in t.get("measures") or []:
            if isinstance(m, dict) and m.get("name"):
                ex = m.get("expression")
                text = "\n".join(str(x) for x in ex) if isinstance(ex, list) else str(ex if ex is not None else "")
                measures[f"{tname}.{m['name']}"] = text.strip()
    for r in model.get("relationships") or []:
        if isinstance(r, dict) and r.get("fromTable") and r.get("toTable"):
            rels.append(f"{r['fromTable']}[{r.get('fromColumn')}] -> {r['toTable']}[{r.get('toColumn')}]")
    return measures, tables, rels


_TMDL_TABLE = re.compile(r"^table\s+(?:'([^']+)'|(\S+))\s*$", re.MULTILINE)
_TMDL_MEASURE = re.compile(r"^\tmeasure\s+(?:'([^']+)'|([^\s=]+))\s*=\s*(.*?)(?=^\t(?:measure|column|partition|hierarchy|annotation|lineageTag|dataCategory)\b|^\t\w+Tag|\Z)",
                           re.MULTILINE | re.DOTALL)
_TMDL_COLUMN = re.compile(r"^\tcolumn\s+(?:'([^']+)'|(\S+))", re.MULTILINE)


def _model_from_tmdl(z: _Zip, files: List[str]) -> Tuple[Dict[str, str], Dict[str, List[str]], List[str]]:
    measures: Dict[str, str] = {}
    tables: Dict[str, List[str]] = {}
    rels: List[str] = []
    for n in files:
        text = z.read(n).decode("utf-8-sig", errors="replace").replace("\r\n", "\n")
        m = _TMDL_TABLE.search(text)
        if not m:
            continue
        tname = m.group(1) or m.group(2)
        tables[tname] = [(c.group(1) or c.group(2)) for c in _TMDL_COLUMN.finditer(text)]
        for mm in _TMDL_MEASURE.finditer(text):
            name = mm.group(1) or mm.group(2)
            body = mm.group(3).strip()
            # a multi-line expression is indented three tabs; strip the tabs and any trailing property lines
            lines = []
            for ln in body.split("\n"):
                if ln.startswith("\t\t") and not ln.startswith("\t\t\t") and lines:
                    break
                lines.append(ln.strip("\t"))
            measures[f"{tname}.{name}"] = "\n".join(lines).strip()
    rel_files = sorted(x for x in z.names if ".SemanticModel/definition/relationships.tmdl" in x)
    for n in rel_files:
        text = z.read(n).decode("utf-8-sig", errors="replace")
        for fm, to in re.findall(r"fromColumn:\s*(.+?)\s*\n\s*toColumn:\s*(.+?)\s*\n", text):
            rels.append(f"{fm.strip()} -> {to.strip()}")
    return measures, tables, rels


def translate_dax(dax: str, home_table: str) -> Tuple[Optional[Tuple[str, str, str]], str]:
    """``((table, column, aggregation), "")`` for a simple measure, else ``(None, why)``."""
    m = _DAX_SIMPLE.match(dax or "")
    if not m:
        return None, "its DAX is more than one aggregation of one column"
    fn = m.group(1).upper()
    table = m.group("qtable") or m.group("table") or home_table
    return (table, m.group("column"), DAX_FUNCTIONS[fn]), ""


# ── the one entry point for reading ─────────────────────────────────────────

def read_report(data: bytes, filename: str = "") -> Parsed:
    """The file as pages, visuals, fields, filters, measures and theme; refused in words
    when it is not a Power BI report file we know how to read."""
    z = _Zip(data, filename)
    root = _pbir_root(z)
    if root is not None:
        return _read_pbir(z, root)
    if z.has("Report/Layout"):
        return _read_legacy(z)
    if any(n.endswith(".pbix") or n.endswith(".pbit") for n in z.names):
        raise ImportRefused("This zip holds a Power BI report file inside it. Choose the .pbix or .pbit itself.")
    raise ImportRefused("This is not a report layout QueryStudio knows: it has neither Report/Layout (a Power BI "
                        "report) nor definition/report.json (a Power BI report in the PBIR format or a .pbip "
                        "project). Power BI may have changed its format; tell us which version wrote this file.")


# ── matching fields to a dataset's columns ──────────────────────────────────

def _norm(s: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(s or "").lower())


class ColumnIndex:
    """A dataset's columns by every name a person calls them, plus the author's own map."""

    def __init__(self, columns: List[dict], field_map: Optional[Dict[str, Any]] = None):
        self.cols: Dict[int, dict] = {}
        self.by_name: Dict[str, List[int]] = {}
        self.by_norm: Dict[str, List[int]] = {}
        for c in columns or []:
            try:
                cid = int(c["id"])
            except (KeyError, TypeError, ValueError):
                continue
            self.cols[cid] = c
            for k in ("physical_name", "friendly_name", "display_name"):
                n = str(c.get(k) or "").strip()
                if n:
                    self.by_name.setdefault(n.lower(), [])
                    if cid not in self.by_name[n.lower()]:
                        self.by_name[n.lower()].append(cid)
                    self.by_norm.setdefault(_norm(n), [])
                    if cid not in self.by_norm[_norm(n)]:
                        self.by_norm[_norm(n)].append(cid)
        self.field_map: Dict[str, int] = {}
        for k, v in (field_map or {}).items():
            try:
                self.field_map[str(k).strip().lower()] = int(v)
            except (TypeError, ValueError):
                continue

    def label(self, cid: int) -> str:
        c = self.cols.get(cid) or {}
        return str(c.get("friendly_name") or c.get("display_name") or c.get("physical_name") or f"column #{cid}")

    def match(self, f: Field) -> Tuple[Optional[int], str]:
        """``(column id, how)``; how is ``author`` / ``name`` / ``friendly`` / ``table and column`` /
        ``""`` (no match) / ``ambiguous: ...``."""
        for key in (f.ref.lower(), f.prop.lower()):
            if key in self.field_map:
                cid = self.field_map[key]
                if cid in self.cols:
                    return cid, "author"
                return None, f"the column you picked (#{cid}) is not in this dataset"
        cands = [f.prop]
        if f.display_name and f.display_name != f.prop:
            cands.append(f.display_name)
        for cand in cands:
            hits = self.by_name.get(cand.strip().lower(), [])
            if len(hits) == 1:
                return hits[0], "name"
            if len(hits) > 1:
                return None, f"ambiguous: {len(hits)} columns are called {cand}"
        for cand in cands + [f"{f.entity} {f.prop}", f"{f.entity}_{f.prop}", f"{f.entity}{f.prop}"]:
            hits = self.by_norm.get(_norm(cand), [])
            if len(hits) == 1:
                return hits[0], "name" if cand in cands else "table and column"
            if len(hits) > 1:
                return None, f"ambiguous: {len(hits)} columns are called {cand}"
        return None, ""

    def names(self) -> List[str]:
        return sorted({self.label(c) for c in self.cols})


# ── the plan: pages, tiles, parameters, filters, the lists ──────────────────

def _num(v: Any, default: float = 0.0) -> float:
    try:
        if isinstance(v, bool):
            return default
        return float(v)
    except (TypeError, ValueError):
        return default


def _maybe_json(v: Any) -> Any:
    if isinstance(v, str):
        try:
            return json.loads(v)
        except ValueError:
            return None
    return v


def _slug(s: str, n: int = 60) -> str:
    out = re.sub(r"[^a-z0-9]+", "_", str(s or "").lower()).strip("_")
    return (out or "field")[:n]


def _tile_id(s: str, used: set) -> str:
    base = re.sub(r"[^A-Za-z0-9_-]", "", str(s or ""))[:40] or "tile"
    tid, k = base, 1
    while tid in used:
        k += 1
        tid = f"{base}_{k}"
    used.add(tid)
    return tid


def _clean_title(s: str, n: int = 200) -> str:
    s = re.sub(r"[\x00-\x1f\x7f]+", " ", str(s or "")).strip()
    return s[:n]


class _Ctx:
    """Everything a plan needs at hand while the visuals are walked."""

    def __init__(self, parsed: Parsed, cols: ColumnIndex, measure_map: Dict[str, Any], exclude: set):
        self.parsed = parsed
        self.cols = cols
        self.measure_map: Dict[str, Dict[str, Any]] = {}
        for k, v in (measure_map or {}).items():
            if isinstance(v, dict) and v.get("column_id") is not None and v.get("aggregation"):
                try:
                    self.measure_map[str(k).strip().lower()] = {"column_id": int(v["column_id"]),
                                                                 "aggregation": str(v["aggregation"]).lower()}
                except (TypeError, ValueError):
                    continue
        self.exclude = exclude
        self.column_ids: List[int] = []
        self.listed: List[Dict[str, str]] = []
        self.refusals: List[Dict[str, str]] = []
        self.unmatched: Dict[str, Dict[str, Any]] = {}
        self.measures: Dict[str, Dict[str, Any]] = {}
        self.parameters: Dict[int, Dict[str, Any]] = {}
        self.filter_specs: List[Dict[str, Any]] = []
        self.filters_out: List[Dict[str, Any]] = []

    def use(self, cid: int) -> None:
        if cid not in self.column_ids:
            self.column_ids.append(cid)

    def say(self, what: str, why: str, where: str = "") -> None:
        self.listed.append({"what": what, "why": why, "where": where})

    def refuse(self, what: str, why: str, where: str = "", field: str = "") -> None:
        self.refusals.append({"what": what, "why": why, "where": where, "field": field})

    def note_unmatched(self, f: Field, where: str, how: str) -> None:
        d = self.unmatched.setdefault(f.ref, {"ref": f.ref, "kind": f.kind, "entity": f.entity, "property": f.prop,
                                              "used_by": [], "why": ""})
        if where not in d["used_by"]:
            d["used_by"].append(where)
        if how:
            d["why"] = how

    # a field of a visual -> what it becomes
    def resolve(self, f: Field, where: str) -> Dict[str, Any]:
        """``{ref, kind, status, column_id, label, aggregation, how, words, dax}``.
        status: column | measure | listed | unmatched."""
        out: Dict[str, Any] = {"ref": f.ref, "kind": f.kind, "status": "listed", "column_id": None, "label": None,
                               "aggregation": None, "how": "", "words": "", "dax": None}
        if f.kind == "other":
            out["words"] = f.words or "a field that could not be read"
            return out
        if f.kind in ("column", "hierarchy_level"):
            cid, how = self.cols.match(f)
            if cid is None:
                out["status"] = "unmatched"
                out["words"] = (how or ("no column of this dataset is called " + f.prop)) + \
                               (f" ({f.words})" if f.kind == "hierarchy_level" else "")
                self.note_unmatched(f, where, how)
                return out
            out.update(status="column", column_id=cid, label=self.cols.label(cid), how=how)
            return out
        if f.kind == "aggregation":
            cid, how = self.cols.match(f)
            agg = AGGREGATION_CODES.get(f.function if f.function is not None else -1)
            if agg is None:
                word = AGGREGATION_CODE_WORDS.get(f.function if f.function is not None else -1, f"code {f.function}")
                out["words"] = f"adds up as {word}, which a tile cannot do"
                return out
            if cid is None:
                out["status"] = "unmatched"
                out["words"] = how or ("no column of this dataset is called " + f.prop)
                self.note_unmatched(f, where, how)
                return out
            out.update(status="measure", column_id=cid, label=self.cols.label(cid), aggregation=agg, how=how)
            return out
        # a measure: the author's pick, the text model's DAX, or not in this file
        key = f.ref.lower()
        rec = self.measures.setdefault(f.ref, {"ref": f.ref, "table": f.entity, "name": f.prop, "dax": None,
                                                "status": "not_in_file", "column_id": None, "aggregation": None,
                                                "words": "", "used_by": []})
        if where not in rec["used_by"]:
            rec["used_by"].append(where)
        picked = self.measure_map.get(key) or self.measure_map.get(f.prop.lower())
        dax = self.parsed.measures.get(f.ref)
        if dax is None:
            for k, v in self.parsed.measures.items():
                if k.lower() == key:
                    dax = v
                    break
        rec["dax"] = dax
        if picked and picked["column_id"] in self.cols.cols:
            rec.update(status="author", column_id=picked["column_id"], aggregation=picked["aggregation"])
            out.update(status="measure", column_id=picked["column_id"], label=self.cols.label(picked["column_id"]),
                       aggregation=picked["aggregation"], how="author", dax=dax)
            return out
        if dax is not None:
            tr, why = translate_dax(dax, f.entity)
            if tr is None:
                rec.update(status="listed", words=why)
                out["words"] = f"the measure {f.prop} is listed: {why}"
                out["dax"] = dax
                return out
            table, column, agg = tr
            cid, how = self.cols.match(Field("column", table, column))
            if cid is None:
                rec.update(status="unmatched", words=f"its column {table}[{column}] has no match")
                out.update(status="unmatched", words=f"the measure {f.prop} = {dax} needs a column called {column}", dax=dax)
                self.note_unmatched(Field("column", table, column), where, how)
                return out
            rec.update(status="translated", column_id=cid, aggregation=agg)
            out.update(status="measure", column_id=cid, label=self.cols.label(cid), aggregation=agg, how="dax", dax=dax)
            return out
        if not self.parsed.model_present:
            rec.update(status="not_in_file", words="definition not in this file")
            out["status"] = "unmatched"
            out["words"] = f"the measure {f.prop}: definition not in this file -- pick a column and how to add it up"
            return out
        rec.update(status="not_in_model", words="the model in this file has no measure of this name")
        out["status"] = "unmatched"
        out["words"] = f"the measure {f.prop} is not in the file's model -- pick a column and how to add it up"
        return out


def _theme_spec(theme: Optional[Dict[str, Any]]) -> Tuple[Optional[Dict[str, Any]], str]:
    """The same mapping as the browser's ``fromPowerBiTheme`` (ThemeGallery.tsx): ``dataColors`` ->
    the palette (first 8, the default's colours fill up), ``tableAccent`` (else the first colour) ->
    the band and the grid header, ``foreground`` -> the title when it reads on white."""
    if not theme:
        return None, "The file names no theme of its own; the report takes the default look."
    from core.reports.themes import DEFAULT_THEME_NAME, SHIPPED, contrast_ratio, _is_hex
    def hex6(c: Any) -> str:
        s = str(c or "").strip().lower()
        if re.match(r"^#[0-9a-f]{3}$", s):
            s = f"#{s[1]}{s[1]}{s[2]}{s[2]}{s[3]}{s[3]}"
        return s if _is_hex(s) else ""
    colours = [hex6(c) for c in theme.get("dataColors") or []]
    colours = [c for c in colours if c]
    if not colours:
        return None, 'The file\'s theme has no "dataColors" in the form #rrggbb, so the report takes the default look.'
    accent = hex6(theme.get("tableAccent")) or colours[0]
    def text_on(bg: str) -> str:
        return "#ffffff" if contrast_ratio("#ffffff", bg) >= contrast_ratio("#111111", bg) else "#111111"
    fg = hex6(theme.get("foreground"))
    title = fg if fg and contrast_ratio(fg, "#ffffff") >= 4.5 else (accent if contrast_ratio(accent, "#ffffff") >= 4.5 else "#1f2933")
    palette = list(colours)
    for c in SHIPPED[DEFAULT_THEME_NAME]["palette"]:
        if len(palette) >= 8:
            break
        if c not in palette:
            palette.append(c)
    spec = {"band": {"bg": accent, "fg": text_on(accent), "label_fg": text_on(accent)},
            "title": {"color": title},
            "grid": {"header_bg": accent, "header_fg": text_on(accent), "subtotal": {"fg": title}, "grand": {"bg": "#f3f5f8", "fg": title}},
            "palette": palette[:8]}
    name = theme.get("name")
    who = f'"{str(name).strip()[:60]}"' if isinstance(name, str) and name.strip() else "the file's theme"
    extra = f" It has {len(colours)} chart colours; the first 8 are used." if len(colours) > 8 else ""
    return spec, f"The colours of {who} are applied: the band and grid header take its table accent, the charts its data colours.{extra}"


def _scale(v: Visual, page: Page) -> Dict[str, int]:
    """The visual's place on the page -> the canvas grid (12 columns; a row is ROW_TO_COL of a column)."""
    col = max(1.0, page.width / GRID_COLS)
    row = col * ROW_TO_COL
    x = int(round(v.x / col))
    w = max(1, int(round(v.w / col)))
    x = min(max(0, x), GRID_COLS - 1)
    w = min(w, GRID_COLS - x)
    y = max(0, int(round(v.y / row)))
    h = max(1, min(60, int(round(v.h / row))))
    return {"x": x, "y": y, "w": w, "h": h}


def _settle(tiles: List[dict]) -> None:
    """No two tiles may overlap on a page (the save refuses it): in reading order, a tile that lands
    on another moves down until it is clear -- the columns and the order down a column are kept."""
    placed: List[dict] = []
    for t in sorted(tiles, key=lambda t: (t["layout"]["y"], t["layout"]["x"])):
        lay = t["layout"]
        guard = 0
        while guard < MAX_GRID_ROWS:
            hit = next((p for p in placed if _overlap(lay, p["layout"])), None)
            if hit is None:
                break
            lay["y"] = hit["layout"]["y"] + hit["layout"]["h"]
            guard += 1
        placed.append(t)


def _overlap(a: dict, b: dict) -> bool:
    return a["x"] < b["x"] + b["w"] and b["x"] < a["x"] + a["w"] and a["y"] < b["y"] + b["h"] and b["y"] < a["y"] + a["h"]


def _wells(v: Visual, ctx: _Ctx, where: str) -> Dict[str, List[Dict[str, Any]]]:
    """The visual's fields resolved, by well: dim / value / series / tooltip / other."""
    out: Dict[str, List[Dict[str, Any]]] = {"dim": [], "value": [], "series": [], "tooltip": [], "other": []}
    for role, fields in v.roles.items():
        well = ROLE_WELLS.get(role, "other")
        for f in fields:
            r = ctx.resolve(f, where)
            r["role"] = role
            r["active"] = f.active
            out[well].append(r)
    return out


def _base_tile(tid: str, kind: str, title: str, layout: dict) -> dict:
    return {"id": tid, "kind": kind, "title": _clean_title(title), "dimensions": [], "measures": [],
            "series": None, "sort": None, "top_n": None, "layout": dict(layout)}


def _measure(r: dict) -> dict:
    m = {"column_id": r["column_id"], "aggregation": r["aggregation"]}
    label = r.get("display_label")
    if label:
        m["label"] = str(label)[:60]
    return m


def _sort_for(v: Visual, tile: dict, kind: str, ctx: _Ctx) -> Optional[dict]:
    if v.sort is None or kind not in CHART_KINDS or kind in _NO_SORT_KINDS:
        return None
    sf, direction = v.sort
    r = ctx.resolve(sf, "sort")
    if r["status"] == "measure" and any(m["column_id"] == r["column_id"] for m in tile["measures"]):
        return {"by": "measure", "dir": direction}
    if r["status"] == "column" and r["column_id"] in tile["dimensions"]:
        return {"by": r["column_id"], "dir": direction}
    return None


def _visual_tiles(v: Visual, page: Page, ctx: _Ctx, used: set) -> Tuple[List[dict], Dict[str, Any]]:
    """The tiles ONE visual becomes (0, 1 or several), and the preview record of the visual."""
    where = f"{page.title} / {v.title or v.visual_type}"
    layout = _scale(v, page)
    kind, note = VISUAL_KINDS.get(v.visual_type, (None, ""))
    rec: Dict[str, Any] = {"name": v.name, "visual_type": v.visual_type, "title": v.title, "layout": layout,
                           "becomes": None, "words": "", "fields": [], "listed": [], "excluded": False}
    if v.is_group:
        rec["becomes"] = None
        rec["words"] = "a group of visuals; each visual in it is read on its own"
        return [], rec
    if v.name in ctx.exclude:
        rec["excluded"] = True
        rec["words"] = "left out by you"
        ctx.say(f"{v.title or v.visual_type} on page {page.title}", "left out by you", where)
        wells = _wells(v, ctx, where)
        rec["fields"] = [r for w in wells.values() for r in w]
        return [], rec
    if kind is None:
        custom = v.visual_type.startswith(CUSTOM_VISUAL_PREFIXES) or v.visual_type in ctx.parsed.custom_visuals
        why = (f"a custom visual ({v.visual_type[:40]})" if custom else f"a visual of type {v.visual_type}") + " QueryStudio has no equal for"
        kind, note = UNSUPPORTED, why
    wells = _wells(v, ctx, where)
    rec["fields"] = [r for w in wells.values() for r in w]
    for r in wells["tooltip"]:
        rec["listed"].append(f"{r['ref']} is a tooltip field; tooltips are not drawn")
    for r in wells["other"]:
        rec["listed"].append(f"{r['ref']} in the {r['role']} well has no place on a tile")
    for r in [x for w in ("dim", "value", "series") for x in wells[w]]:
        if r["status"] == "listed":
            rec["listed"].append(f"{r['ref']}: {r['words']}")
        elif r["status"] == "unmatched":
            rec["listed"].append(f"{r['ref']}: {r['words']}")
    # the visual's own filters: a tile cannot carry one, so a narrowing filter REFUSES the visual
    for flt in v.filters:
        _filter_record(flt, ctx, where, on_visual=True)
    dims = [r for r in wells["dim"] if r["status"] == "column"]
    values = [r for r in wells["value"] if r["status"] == "measure"]
    bare = [r for r in wells["value"] if r["status"] == "column"]       # a column with no way to add up
    series = [r for r in wells["series"] if r["status"] == "column"]
    for r in values:
        r["display_label"] = next((f.display_name for fs in v.roles.values() for f in fs
                                   if f.ref == r["ref"] and f.display_name and f.display_name != f.prop), None)
    if kind == DECORATION:
        rec["words"] = f"not brought across ({note})"
        ctx.say(f"{v.title or note} on page {page.title}", f"not brought across (decoration: {note})", where)
        return [], rec
    if kind == TEXT:
        rec["words"] = "a text box" + (f': "{v.text[:80]}"' if v.text else "")
        rec["text"] = v.text
        return [], rec
    if kind == PARAMETER:
        picks = dims + bare
        if not picks:
            unm = [r for r in wells["dim"] + wells["value"] if r["status"] == "unmatched"]
            if unm:
                rec["words"] = f"a slicer on {unm[0]['ref']}, which has no matching column; it is listed"
                ctx.say(f"slicer {v.title or unm[0]['ref']} on page {page.title}",
                        f"its field {unm[0]['ref']} has no matching column, so no parameter is made", where)
            else:
                rec["words"] = "a slicer with no field; nothing to ask"
            return [], rec
        r = picks[0]
        ctx.parameters.setdefault(r["column_id"], {"column_id": r["column_id"], "label": r["label"], "from": []})
        ctx.parameters[r["column_id"]]["from"].append(f"slicer on page {page.title}")
        rec["becomes"] = "parameter"
        rec["words"] = f"a parameter the viewer picks: {r['label']}"
        return [], rec
    tiles: List[dict] = []
    title = v.title
    if kind == UNSUPPORTED:
        ctx.say(f"{v.title or note} on page {page.title}", f"{note}; " + (
            "its place is kept as a table of its fields" if dims or bare else "its place is left empty"), where)
        if dims or bare:
            t = _base_tile(_tile_id(v.name, used), "table", title or f"{note} (as a table)", layout)
            t["dimensions"] = _uniq([r["column_id"] for r in dims + bare])
            t["measures"] = [_measure(r) for r in values[:MAX_SERIES_VALUES]]
            for r in dims + bare + values[:MAX_SERIES_VALUES]:
                ctx.use(r["column_id"])
            tiles.append(t)
            rec["becomes"] = "table"
            rec["words"] = f"{note}: kept as a table of its fields"
        else:
            rec["words"] = f"{note}: its place is left empty"
        return tiles, rec
    if kind == CARDS:
        if not values:
            return _placeholder(v, page, ctx, used, layout, dims, bare, values, rec, "a card with no value that could be added up")
        n = len(values)
        w_each = max(1, layout["w"] // n) if n <= layout["w"] else layout["w"]
        for i, r in enumerate(values):
            lay = dict(layout)
            if n <= layout["w"]:
                lay["x"] = layout["x"] + i * w_each
                lay["w"] = w_each if i < n - 1 else layout["w"] - w_each * (n - 1)
            else:
                lay["y"] = layout["y"] + i * layout["h"]
            t = _base_tile(_tile_id(f"{v.name}_{i}" if n > 1 else v.name, used), "number",
                           title if n == 1 else (r.get("display_label") or r["label"]), lay)
            t["measures"] = [_measure(r)]
            tiles.append(t)
            ctx.use(r["column_id"])
        rec["becomes"] = "number"
        rec["words"] = f"{n} number tile{'s' if n > 1 else ''}"
        if note:
            rec["listed"].append(note)
        return tiles, rec
    if kind == MATRIX:
        if not values:
            return _placeholder(v, page, ctx, used, layout, dims, bare, values, rec, "a matrix with no value that could be added up")
        if series and dims:
            t = _base_tile(_tile_id(v.name, used), "pivot", title, layout)
            t["dimensions"] = _uniq([r["column_id"] for r in dims])
            t["series"] = series[0]["column_id"]
            t["measures"] = [_measure(r) for r in values]
            for r in series[1:]:
                rec["listed"].append(f"{r['ref']}: a pivot spreads one column field; this one is not drawn")
            rec["becomes"] = "pivot"
        elif dims:
            t = _base_tile(_tile_id(v.name, used), "outline", title, layout)
            t["levels"] = _uniq([r["column_id"] for r in dims])
            t["measures"] = [_measure(r) for r in values]
            t["totals"] = {"levels": [True] * len(t["levels"]), "grand": True}
            t["open_level"] = len(t["levels"])
            rec["becomes"] = "outline"
        else:
            t = _base_tile(_tile_id(v.name, used), "table", title, layout)
            t["dimensions"] = _uniq([r["column_id"] for r in series + bare])
            t["measures"] = [_measure(r) for r in values]
            rec["becomes"] = "table"
        tiles.append(t)
        for r in dims + series + values:
            ctx.use(r["column_id"])
        rec["words"] = {"pivot": "a pivot", "outline": "a matrix as an outline (rows with totals)", "table": "a table"}[rec["becomes"]]
        return tiles, rec
    if kind == "table":
        fields = _uniq([r["column_id"] for r in dims + bare])
        if not fields and not values:
            return _placeholder(v, page, ctx, used, layout, dims, bare, values, rec, "a table none of whose fields matched")
        t = _base_tile(_tile_id(v.name, used), "table", title, layout)
        t["dimensions"] = fields
        t["measures"] = [_measure(r) for r in values]
        tiles.append(t)
        for r in dims + bare + values:
            ctx.use(r["column_id"])
        rec["becomes"] = "table"
        rec["words"] = "a table" + (f" ({note})" if note else "")
        return tiles, rec
    if kind == "number":
        if not values:
            return _placeholder(v, page, ctx, used, layout, dims, bare, values, rec, "a visual with no value that could be added up")
        t = _base_tile(_tile_id(v.name, used), "number", title, layout)
        t["measures"] = [_measure(values[0])]
        ctx.use(values[0]["column_id"])
        tiles.append(t)
        for r in values[1:]:
            rec["listed"].append(f"{r['ref']}: a number tile shows one value; this one is not drawn")
        rec["becomes"] = "number"
        rec["words"] = "a number" + (f" ({note})" if note else "")
        return tiles, rec
    # ── charts ──
    if kind in CHART_KINDS:
        if kind in ("scatter",):
            if not dims or len(values) < 2:
                return _placeholder(v, page, ctx, used, layout, dims, bare, values, rec,
                                    "a scatter needs a field for each point and two values (x and y)")
            use_kind = "bubble" if len(values) >= 3 and any(r["role"] == "Size" for r in values) else "scatter"
            xs = [r for r in values if r["role"] == "X"] + [r for r in values if r["role"] not in ("X", "Y", "Size")]
            ys = [r for r in values if r["role"] == "Y"]
            sz = [r for r in values if r["role"] == "Size"]
            ordered = (xs[:1] + ys[:1] + sz[:1]) if xs and ys else values[:3 if use_kind == "bubble" else 2]
            t = _base_tile(_tile_id(v.name, used), use_kind, title, layout)
            t["dimensions"] = [dims[0]["column_id"]]
            t["measures"] = [_measure(r) for r in ordered[: (3 if use_kind == "bubble" else 2)]]
            t["top_n"] = max_points_of(use_kind, None)
            tiles.append(t)
            for r in dims[:1] + ordered:
                ctx.use(r["column_id"])
            rec["becomes"] = use_kind
            rec["words"] = "a scatter" if use_kind == "scatter" else "a bubble chart"
            return tiles, rec
        if not dims or not values:
            why = "a chart with no category field that matched" if not dims else "a chart with no value that could be added up"
            return _placeholder(v, page, ctx, used, layout, dims, bare, values, rec, why)
        use_kind = kind
        active = [r for r in dims if r.get("active")] or dims
        for r in dims:
            if r is not active[0]:
                rec["listed"].append(f"{r['ref']}: a drill level of the category; the chart shows {active[0]['label']}")
        measures = values
        if kind in SUM_ONLY and any(r["aggregation"] != "sum" for r in values[:1]):
            rec["listed"].append(f"{values[0]['ref']} is not added up as a sum, which a {kind} needs; drawn as bars instead")
            use_kind = "bar"
        if kind == "combo" and len(values) < 2:
            rec["listed"].append("a columns-and-lines chart needs two values; drawn as bars")
            use_kind = "bar"
        t = _base_tile(_tile_id(v.name, used), use_kind, title, layout)
        t["dimensions"] = [active[0]["column_id"]]
        if use_kind in ("pie", "donut", "treemap", "funnel", "waterfall"):
            t["measures"] = [_measure(measures[0])]
            for r in measures[1:]:
                rec["listed"].append(f"{r['ref']}: a {use_kind} draws one value; this one is not drawn")
            for r in series:
                rec["listed"].append(f"{r['ref']}: a {use_kind} cannot be split into series")
        elif use_kind == "combo":
            t["measures"] = [_measure(r) for r in measures[:MAX_SERIES_VALUES]]
            for r in series:
                rec["listed"].append(f"{r['ref']}: a columns-and-lines chart cannot be split into series")
        else:
            if series and len(measures) >= 1:
                t["measures"] = [_measure(measures[0])]
                t["series"] = series[0]["column_id"]
                for r in measures[1:]:
                    rec["listed"].append(f"{r['ref']}: a chart split by {series[0]['label']} draws one value; this one is not drawn")
                for r in series[1:]:
                    rec["listed"].append(f"{r['ref']}: one series field is drawn; this one is not")
            else:
                t["measures"] = [_measure(r) for r in measures[:MAX_SERIES_VALUES]]
                for r in measures[MAX_SERIES_VALUES:]:
                    rec["listed"].append(f"{r['ref']}: a chart draws up to {MAX_SERIES_VALUES} values; this one is not drawn")
        if t.get("series") is not None and t["series"] in t["dimensions"]:
            rec["listed"].append(f"{series[0]['ref']} is both the category and the series; drawn as the category")
            t["series"] = None
        t["top_n"] = max_points_of(use_kind, t.get("series"))
        t["sort"] = _sort_for(v, t, use_kind, ctx)
        tiles.append(t)
        for r in [active[0]] + measures:
            ctx.use(r["column_id"])
        if t.get("series") is not None:
            ctx.use(t["series"])
        rec["becomes"] = use_kind
        rec["words"] = f"a {use_kind.replace('_', ' ')} chart" + (f" ({note})" if note and use_kind == kind else "")
        return tiles, rec
    rec["words"] = f"a {kind} tile"
    return tiles, rec


def _placeholder(v: Visual, page: Page, ctx: _Ctx, used: set, layout: dict, dims, bare, values, rec, why: str):
    """A data visual that cannot come across as it was: its place is kept as a table of the
    fields that matched; with none, its place is listed as left empty."""
    where = f"{page.title} / {v.title or v.visual_type}"
    fields = _uniq([r["column_id"] for r in dims + bare])
    if fields:
        t = _base_tile(_tile_id(v.name, used), "table", v.title or f"{v.visual_type} (as a table)", layout)
        t["dimensions"] = fields
        for r in dims + bare:
            ctx.use(r["column_id"])
        rec["becomes"] = "table"
        rec["words"] = f"{why}; kept as a table of its matched fields"
        ctx.say(f"{v.title or v.visual_type} on page {page.title}", f"{why}; kept as a table of its matched fields", where)
        return [t], rec
    rec["words"] = f"{why}; its place is left empty"
    ctx.say(f"{v.title or v.visual_type} on page {page.title}", f"{why}; its place is left empty", where)
    return [], rec


def _uniq(ids: List[int]) -> List[int]:
    out: List[int] = []
    for i in ids:
        if i not in out:
            out.append(i)
    return out


def _filter_record(flt: Filter, ctx: _Ctx, where: str, on_visual: bool) -> None:
    """One filter card -> a report filter row, a parameter, a listing, or a REFUSAL."""
    rec: Dict[str, Any] = {"name": flt.name, "scope": flt.scope, "where": where, "field": flt.field.ref if flt.field else "",
                           "conditions": [{"op": c.op, "value": c.value, "value2": c.value2} for c in flt.conditions],
                           "unsupported": flt.unsupported, "status": "", "column_id": None, "words": ""}
    ctx.filters_out.append(rec)
    if flt.field is None:
        if flt.narrows:
            rec["status"] = "refused"
            rec["words"] = "a filter whose field could not be read, and it narrows the rows"
            ctx.refuse("a filter", rec["words"], where)
        else:
            rec["status"] = "listed"
            rec["words"] = "a filter card with no field and no selection; it narrows nothing"
        return
    r = ctx.resolve(flt.field, where)
    if flt.unsupported:
        rec["status"] = "refused"
        rec["words"] = (f"the filter on {flt.field.ref} is {flt.unsupported}, which a report filter cannot carry; "
                        "dropping it would show more rows than Power BI does. Change the filter in Power BI, or leave "
                        + ("this visual out." if on_visual else "the page out."))
        ctx.refuse(f"filter on {flt.field.ref}", rec["words"], where, flt.field.ref)
        return
    if not flt.conditions:
        # a card with nothing selected narrows nothing: a parameter when its field matched
        if r["status"] in ("column", "measure") and r["column_id"] is not None and not on_visual:
            rec["status"] = "parameter"
            rec["column_id"] = r["column_id"]
            ctx.parameters.setdefault(r["column_id"], {"column_id": r["column_id"], "label": r["label"], "from": []})
            ctx.parameters[r["column_id"]]["from"].append(f"{flt.scope} filter card{' (' + flt.how_created.lower() + ')' if flt.how_created else ''}")
            rec["words"] = f"a filter card with nothing selected: the viewer picks {r['label']}"
        else:
            rec["status"] = "listed"
            rec["words"] = f"a filter card with nothing selected on {flt.field.ref}; it narrows nothing" + \
                           ("" if r["status"] in ("column", "measure") else f" ({r['words']})")
            ctx.say(f"filter card on {flt.field.ref}", rec["words"], where)
        return
    if r["status"] not in ("column", "measure") or r["column_id"] is None:
        rec["status"] = "refused"
        rec["words"] = (f"the filter on {flt.field.ref} narrows the rows ({_cond_words(flt.conditions)}) and that field "
                        f"has no matching column in this dataset ({r['words']}). Pick the column it means, or leave "
                        + ("this visual out." if on_visual else "the page out."))
        ctx.refuse(f"filter on {flt.field.ref}", rec["words"], where, flt.field.ref)
        return
    if on_visual:
        rec["status"] = "refused"
        rec["words"] = (f"this visual has a filter of its own ({flt.field.ref} {_cond_words(flt.conditions)}); a tile "
                        "cannot carry a filter, and a report-wide filter would change every other tile. Leave this "
                        "visual out, or make the filter a page filter in Power BI.")
        ctx.refuse(f"filter on {flt.field.ref}", rec["words"], where, flt.field.ref)
        return
    if r["status"] == "measure":
        rec["status"] = "refused"
        rec["words"] = (f"the filter on the measure {flt.field.ref} ({_cond_words(flt.conditions)}) filters on an "
                        "added-up value, which a report filter cannot do. Leave the page out, or filter a column instead.")
        ctx.refuse(f"filter on {flt.field.ref}", rec["words"], where, flt.field.ref)
        return
    rec["status"] = "applied"
    rec["column_id"] = r["column_id"]
    rec["words"] = f"a report filter: {r['label']} {_cond_words(flt.conditions)}"
    ctx.use(r["column_id"])
    for c in flt.conditions:
        spec = {"column_id": r["column_id"], "operator": c.op, "value": c.value}
        if c.op == "between":
            spec["value2"] = c.value2
        ctx.filter_specs.append(spec)


def _cond_words(conds: List[Condition]) -> str:
    words = {"eq": "=", "neq": "is not", "gt": ">", "gte": ">=", "lt": "<", "lte": "<=", "in": "is one of",
             "not_in": "is not one of", "between": "between", "starts_with": "starts with", "contains": "contains"}
    out = []
    def show(x: Any) -> str:
        return "blank" if x is None else repr(x)
    for c in conds:
        if c.op == "between":
            out.append(f"between {show(c.value)} and {show(c.value2)}")
        elif c.op in ("in", "not_in"):
            vals = ", ".join(show(x) for x in (c.value or [])[:6]) + (" ..." if len(c.value or []) > 6 else "")
            out.append(f"{words[c.op]} {vals}")
        else:
            out.append(f"{words.get(c.op, c.op)} {show(c.value)}")
    return " and ".join(out)


def detail_grain(dataset_columns: List[dict], *, has_metrics: bool, other_report_ids: List[int]) -> Dict[str, Any]:
    """The import's ONE road to Power BI's numbers: the report runs at DETAIL grain.

    A Power BI visual aggregates the table's ROWS (COUNTA counts rows, AVERAGE averages rows); a
    QueryStudio report's rows are GROUPED as soon as a dataset column adds up (auto-detect types
    every money column as a SUM measure), and the canvas then refuses a count or an average over
    them -- rightly: the third rig run showed Opportunity ID is NOT unique (458 rows, 457 ids), so
    no substitution gives Power BI's number.  How a report selects detail rows today is the
    dataset's own setting -- a measure column with no aggregation is taken as-is and the SQL has no
    GROUP BY (business_reports_api._derive_artifact_grain) -- so the import READS THE DATASET AS-IS:
    its adding-up columns are set to no aggregation at create, the tiles aggregate detail rows through
    the cube exactly as Power BI does (COUNTA -> count_values, the rows with a value; COUNT -> count;
    AVERAGE -> avg; DISTINCTCOUNT -> count_distinct), and the plan says which columns.  It cannot when the dataset has calculated
    metrics (they force grouped rows) or when OTHER reports already read it added-up (their numbers
    would change under them) -- then it refuses in plain words.

    Returns ``{"as_is": [columns to set], "columns": the effective columns the plan is made over,
    "labels": [...], "words": "...", "refusal": None | words}``.
    """
    from core.reports.canvas import dataset_rows_are_grouped

    def _label(c: dict) -> str:
        return str(c.get("friendly_name") or c.get("display_name") or c.get("physical_name") or c.get("id"))
    adding = [c for c in (dataset_columns or []) if isinstance(c, dict) and dataset_rows_are_grouped([c], False)]
    labels = [_label(c) for c in adding]
    names = ", ".join(labels)
    others = [int(i) for i in (other_report_ids or []) if i is not None]
    if has_metrics:
        return {"as_is": [], "columns": list(dataset_columns or []), "labels": labels, "words": "",
                "refusal": ("this dataset has calculated metrics, so its reports' rows are added up and a Power BI "
                            "visual's count or average would be over groups, not rows. Import into a dataset "
                            "without calculated metrics.")}
    if not adding:
        return {"as_is": [], "columns": list(dataset_columns or []), "labels": [], "words": "", "refusal": None}
    if others:
        return {"as_is": [], "columns": list(dataset_columns or []), "labels": labels, "words": "",
                "refusal": (f"this dataset adds {names} up and {len(others)} other report"
                            f"{'s' if len(others) != 1 else ''} read it that way; reading it as-is for this import "
                            "would change their numbers. Make a dataset for this import, or set those columns to "
                            "be read as-is yourself.")}
    ids = {int(c["id"]) for c in adding if c.get("id") is not None}
    effective = [dict(c, aggregation="") if isinstance(c, dict) and c.get("id") is not None and int(c["id"]) in ids else c
                 for c in (dataset_columns or [])]
    return {"as_is": adding, "columns": effective, "labels": labels,
            "words": f"{names}: read as-is (every row, nothing added up), so the tiles add up like Power BI",
            "refusal": None}


def plan(parsed: Parsed, dataset: dict, *, dataset_columns: List[dict], file_name: str,
         field_map: Optional[Dict[str, Any]] = None, measure_map: Optional[Dict[str, Any]] = None,
         exclude_visuals: Optional[List[str]] = None, exclude_pages: Optional[List[str]] = None,
         report_name: Optional[str] = None, has_metrics: bool = True) -> Dict[str, Any]:
    """The PREVIEW: every page and visual and what it becomes, every field and its match, the
    parameters, the filters (applied / parameter / listed / REFUSED), what is not brought across,
    the measures, the theme -- and ``report`` = the body Create would save, when nothing refuses."""
    cols = ColumnIndex(dataset_columns, field_map)
    ctx = _Ctx(parsed, cols, measure_map or {}, set(exclude_visuals or []))
    excl_pages = set(exclude_pages or [])
    used_ids: set = set()
    tiles: List[dict] = []
    pages_out: List[dict] = []
    canvas_pages: List[dict] = []
    for flt in parsed.report_filters:
        _filter_record(flt, ctx, "the report", on_visual=False)
    for pg in parsed.pages:
        prec: Dict[str, Any] = {"name": pg.name, "title": pg.title, "width": pg.width, "height": pg.height,
                                "included": True, "words": "", "visuals": []}
        pages_out.append(prec)
        if pg.name in excl_pages:
            prec["included"] = False
            prec["words"] = "left out by you"
            ctx.say(f"page {pg.title}", "left out by you", pg.title)
            continue
        if pg.page_type.lower() == "tooltip":
            prec["included"] = False
            prec["words"] = "a tooltip page (shown on hover in Power BI); not brought across"
            ctx.say(f"page {pg.title}", "a tooltip page, shown on hover in Power BI; not brought across", pg.title)
            continue
        if pg.hidden and pg.page_type.lower() != "drillthrough":
            prec["words"] = "hidden in Power BI; brought across as a page"
        for flt in pg.filters:
            _filter_record(flt, ctx, f"page {pg.title}", on_visual=False)
        page_tiles: List[dict] = []
        texts: List[Visual] = []
        for v in pg.visuals:
            ts, vrec = _visual_tiles(v, pg, ctx, used_ids)
            prec["visuals"].append(vrec)
            page_tiles.extend(ts)
            if v.visual_type == "textbox" and v.text and v.name not in ctx.exclude:
                texts.append(v)
        title = _clean_title(pg.title, MAX_PAGE_TITLE) or f"Page {len(canvas_pages) + 1}"
        for tv in sorted(texts, key=lambda t: (t.y, t.x)):
            one_line = " ".join(tv.text.split())
            if len(one_line) <= MAX_PAGE_TITLE_TEXT and tv.y <= pg.height * 0.15 and title == _clean_title(pg.title, MAX_PAGE_TITLE):
                prec["words"] = (prec["words"] + " " if prec["words"] else "") + f'the text "{one_line}" at the top names the page'
                title = one_line
                ctx.say(f'text "{one_line}" on page {pg.title}', "its words name the page", pg.title)
            else:
                ctx.say(f'text "{one_line[:80]}{"..." if len(one_line) > 80 else ""}" on page {pg.title}',
                        "a text box; its words are not brought across (the report's band carries the heading)", pg.title)
        _settle(page_tiles)
        tiles.extend(page_tiles)
        canvas_pages.append({"id": _tile_id(f"page_{pg.name}", used_ids), "title": title, "tiles": [t["id"] for t in page_tiles]})
    included_pages = [p for p in canvas_pages]
    if len(included_pages) > MAX_PAGES:
        ctx.refuse("pages", f"the report has {len(included_pages)} pages to bring across; a report here holds {MAX_PAGES}. "
                   f"Leave some pages out.", "the report")
    if len(tiles) > MAX_TILES:
        ctx.refuse("tiles", f"the report's visuals make {len(tiles)} tiles; a report here holds {MAX_TILES}. "
                   f"Leave some visuals or pages out.", "the report")
    if not tiles:
        ctx.refuse("tiles", "no visual could be brought across: nothing in the file matched a column of this dataset. "
                   "Pick the dataset the report was built on, or match the fields below.", "the report")
    # parameters: one per column, named after it
    params: List[dict] = []
    seen_names: set = set()
    for cid, p in ctx.parameters.items():
        name = _slug(p["label"])
        k = 1
        while name in seen_names:
            k += 1
            name = f"{_slug(p['label'])}_{k}"
        seen_names.add(name)
        params.append({"name": name, "label": str(p["label"])[:200], "parameter_type": "multi_select",
                       "lov_column_id": cid, "is_required": False, "sort_order": len(params), "from": p["from"]})
        ctx.use(cid)
    theme_spec, theme_words = _theme_spec(parsed.theme)
    name = _clean_title(report_name or re.sub(r"\.(pbix|pbit|pbip|zip)$", "", file_name, flags=re.IGNORECASE) or "Power BI report", 200)
    canvas: Dict[str, Any] = {"version": 1, "tiles": tiles}
    if len(canvas_pages) > 1:
        canvas["pages"] = canvas_pages
    layout_config: Dict[str, Any] = {"report_type": "table", "canvas": canvas}
    if theme_spec:
        layout_config["theme"] = theme_spec
    body = {"name": name, "description": f"Imported from the Power BI report {file_name} ({parsed.format} format).",
            "dataset_id": int(dataset["id"]), "data_source_type": "dataset", "column_ids": list(ctx.column_ids),
            "filter_specs": ctx.filter_specs, "order_by": [], "layout_config": layout_config}
    # THE SAVE'S OWN RULES judge the preview (a decision made once): a tile the save would refuse -- an
    # average over rows the dataset already adds up, a pie of a value that is not a sum -- is a refusal
    # HERE, named on its visual, so the author changes the aggregation or leaves the visual out.
    if tiles:
        from core.reports.canvas import canvas_problems
        owner = {t["id"]: t for t in tiles}
        for prob in canvas_problems(canvas, dataset_columns=dataset_columns, report_column_ids=body["column_ids"],
                                    has_metrics=has_metrics):
            t = owner.get(str(prob.get("tile_id") or ""))
            where = (t or {}).get("title") or (t or {}).get("kind") or "the canvas"
            ctx.refuse(f"tile {prob.get('tile_id') or ''}".strip(),
                       f"the save would refuse this visual: {prob['message']} Change how its value is added up, or leave it out.",
                       where)
    measures = sorted(ctx.measures.values(), key=lambda m: m["ref"])
    return {
        "format": parsed.format, "file_name": file_name, "report_name": name, "dataset_id": int(dataset["id"]),
        "dataset_name": dataset.get("name"), "model_in_file": parsed.model_present,
        "relationships": list(parsed.relationships), "tables_in_model": {k: len(v) for k, v in parsed.tables.items()},
        "pages": pages_out, "tiles": len(tiles),
        "parameters": params, "filters": ctx.filters_out, "refusals": ctx.refusals,
        "not_brought_across": ctx.listed, "unmatched_fields": sorted(ctx.unmatched.values(), key=lambda u: u["ref"]),
        "measures": measures, "theme": theme_spec, "theme_words": theme_words,
        "columns": [{"id": cid, "label": cols.label(cid), "data_type": (cols.cols[cid].get("data_type") or ""),
                     "column_type": cols.cols[cid].get("column_type") or ""} for cid in sorted(cols.cols)],
        "notes": list(parsed.notes),
        "can_create": not ctx.refusals,
        "report": body if not ctx.refusals else None,
        "parameter_rows": [{k: v for k, v in p.items() if k != "from"} for p in params],
    }


def visual_types_known() -> List[str]:
    """Every visual type the mapping table names (the test asks: is every type seen in a real file here?)."""
    return sorted(VISUAL_KINDS)


def all_visual_types(parsed: Parsed) -> List[str]:
    return sorted({v.visual_type for p in parsed.pages for v in p.visuals if not v.is_group})


def is_known_visual_type(vtype: str, parsed: Optional[Parsed] = None) -> bool:
    """In the mapping table, a custom visual by its prefix, or a custom visual the FILE packs."""
    return vtype in VISUAL_KINDS or vtype.startswith(CUSTOM_VISUAL_PREFIXES)         or bool(parsed and vtype in parsed.custom_visuals)


__all__ = ["ImportRefused", "Parsed", "Page", "Visual", "Field", "Filter", "Condition", "ColumnIndex",
           "read_report", "plan", "translate_dax", "parse_field", "parse_condition", "parse_filter",
           "VISUAL_KINDS", "AGGREGATION_CODES", "DAX_FUNCTIONS", "ROLE_WELLS", "TILE_KINDS",
           "MAX_FILE_BYTES", "MAX_ENTRIES", "MAX_ENTRY_BYTES", "MAX_READ_BYTES", "MAX_DECLARED_BYTES", "MAX_RATIO",
           "RATIO_FLOOR_BYTES", "visual_types_known", "all_visual_types", "is_known_visual_type"]
