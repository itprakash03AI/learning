"""What to put in a visual: suggestions from a DATASET (2026-11-09, the owner on UAT: "smart
prediction if user select any type ... based on dataset ... you dont have to read 40 million to
suggest").  Record: docs/REPORT_DESIGNER_STEPS_PLAN_2026_11_09.html, section 4.

NO DATA IS READ.  Two signals, both cheap:
  * the column's declared role (dimension / measure / kpi), type (string / number / date) and name;
  * how the OTHER reports on the same dataset use each field (in which part of which visual).

The answer is per ROLE, not per kind of visual: ``time`` (a date to draw along), ``category`` (a
field to group by), ``measure`` (a value to add up).  The screen maps each slot ("well") of each
kind onto a role -- the slot table lives in ONE place, ``frontend/.../canvas/canvasWells.ts``.
``visuals`` are the kinds this dataset suits best, with their fields, for the Type step.

``POST /api/suggest/chart-recommendations`` is a different question (a query RESULT's columns,
with distinct estimates) and keeps its own patterns; this module is the designer's.
"""
from __future__ import annotations

import re
from collections import Counter
from typing import Any, Dict, Iterable, List, Optional

# Names are read as WHOLE WORDS (split on _ - . space; review 2026-11-09: a substring rule made
# ``updated_by`` / ``mandate_name`` a date and kept ``months_to_maturity`` from being a value).
#: the last word of a key
KEY_WORDS = {"id", "key", "uuid", "guid", "seq", "sk", "pk"}
#: a word that names a date (a string ``business_close_date``, an int ``year`` or ``cob_date``)
DATE_WORDS = {"date", "dt", "cob", "month", "year", "yr", "period", "quarter", "qtr", "week", "timestamp", "time", "day"}
#: a word that names a value to add up
VALUE_WORDS = {"amount", "amt", "balance", "bal", "value", "val", "qty", "quantity", "price", "cost", "revenue",
               "pnl", "notional", "exposure", "mtm", "fee", "fees", "total", "sum", "count", "volume", "nominal"}
#: a stored numeric type, as the screen reads it (canvasModel.ts NUMERIC): bigint, int, decimal(18,2), number(38,0)...
NUMERIC = re.compile(r"int|num|dec|float|double|real|money", re.I)
DATE_TYPE = re.compile(r"date|time", re.I)


def _words(name: str) -> List[str]:
    return [w for w in re.split(r"[_\-.\s]+", name.lower()) if w]


def is_key_like(col: Dict[str, Any]) -> bool:
    """A key: its LAST word is id / key / uuid... (``book_id``, ``trade_key``) or the name is one."""
    w = _words(str(col.get("physical_name") or col.get("friendly_name") or ""))
    return bool(w) and w[-1] in KEY_WORDS

TIME, CATEGORY, MEASURE = "time", "category", "measure"
ROLES = (TIME, CATEGORY, MEASURE)

#: kinds whose first category is drawn along a line (a date belongs there)
TIME_KINDS = {"line", "area", "stacked_area", "combo"}
#: each tile kind -> the role its dimensions take, for the usage signal
_DIM_ROLE_OF_KIND = {k: TIME for k in TIME_KINDS}


def role_of(col: Dict[str, Any]) -> Optional[str]:
    """The role a dataset column suggests itself for, or None (hidden).

    In this order (review 2026-11-09): a KEY is never a value -- auto-detect declares every numeric column a
    measure, so a ``book_id NUMBER`` was summed; it is a field to group by, ranked last when numeric
    (``rank_penalty``), and a text code like ``system_id`` ('SAPADB') is an ordinary category.  A DATE by type,
    or by a date word with no value word (``year``, an int ``cob_date``; not ``cob_balance``).  Then a declared
    measure / KPI, or a number named like a value.  Else a field to group by."""
    if col.get("is_hidden"):
        return None
    name = str(col.get("physical_name") or col.get("friendly_name") or "")
    words = set(_words(name))
    ctype = str(col.get("column_type") or "dimension").lower()
    dtype = str(col.get("data_type") or "string").lower()
    if is_key_like(col):
        return CATEGORY
    if DATE_TYPE.search(dtype) or (words & DATE_WORDS and not words & VALUE_WORDS):
        return TIME
    if ctype in ("measure", "kpi") or (NUMERIC.search(dtype) and words & VALUE_WORDS):
        return MEASURE
    return CATEGORY


def rank_penalty(col: Dict[str, Any]) -> int:
    """A numeric key groups by row-ish values: offered, but after every other category."""
    return 1 if is_key_like(col) and (NUMERIC.search(str(col.get("data_type") or "")) or
                                     str(col.get("column_type") or "").lower() in ("measure", "kpi")) else 0


def _tiles_of(layout_config: Any) -> List[Dict[str, Any]]:
    if isinstance(layout_config, str):   # a row stored as text (old SQLite rows): read it, never "no use"
        try:
            import json as _json
            layout_config = _json.loads(layout_config)
        except ValueError:
            layout_config = None
    canvas = (layout_config or {}).get("canvas") if isinstance(layout_config, dict) else None
    tiles = (canvas or {}).get("tiles") if isinstance(canvas, dict) else None
    return [t for t in (tiles or []) if isinstance(t, dict)]


def usage_from_reports(reports: Iterable[Dict[str, Any]], exclude_report_id: Optional[int] = None) -> Dict[str, Counter]:
    """How the reports use each field, per role: {role: Counter(column_id -> times)}.
    A dimension counts as ``time`` on a line-like kind, else ``category``; a series as ``category``;
    a measure as ``measure``.  The report being edited is left out (it is not another report)."""
    out = {r: Counter() for r in ROLES}
    for rep in reports:
        if exclude_report_id is not None and str(rep.get("id")) == str(exclude_report_id):
            continue
        for t in _tiles_of(rep.get("layout_config")):
            dim_role = _DIM_ROLE_OF_KIND.get(str(t.get("kind") or ""), CATEGORY)
            for d in t.get("dimensions") or []:
                out[dim_role][_int(d)] += 1
            if t.get("series") is not None:
                out[CATEGORY][_int(t.get("series"))] += 1
            for m in t.get("measures") or []:
                if isinstance(m, dict) and m.get("column_id") is not None:
                    out[MEASURE][_int(m.get("column_id"))] += 1
    for r in ROLES:
        out[r].pop(None, None)
    return out


def _int(v: Any) -> Optional[int]:
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _why(role: str, col: Dict[str, Any], used: int) -> str:
    if used:
        return f"used {used} time{'' if used == 1 else 's'} in other reports on this data"
    ctype = str(col.get("column_type") or "").lower()
    if role == MEASURE:
        return "a value of this data" if ctype in ("measure", "kpi") else "named like a value"
    if role == TIME:
        return "a date" if str(col.get("data_type") or "").lower() == "date" else "named like a date"
    return "a field to group by"


def suggest(columns: List[Dict[str, Any]], usage: Optional[Dict[str, Counter]] = None,
            *, per_role: int = 8) -> Dict[str, Any]:
    """Ranked candidates per role, and the visuals this dataset suits.  Ranking: how often other
    reports use the field IN THAT ROLE, then the dataset's own order (its author's)."""
    usage = usage or {r: Counter() for r in ROLES}
    ranked: Dict[str, List[Dict[str, Any]]] = {r: [] for r in ROLES}
    for pos, col in enumerate(columns):
        role = role_of(col)
        if role is None or col.get("id") is None:
            continue
        cid = int(col["id"])
        used = int(usage.get(role, Counter()).get(cid, 0))
        agg = str(col.get("aggregation") or "").lower() or "sum"
        ranked[role].append({"column_id": cid, "label": str(col.get("friendly_name") or col.get("physical_name") or cid),
                             **({"aggregation": agg} if role == MEASURE else {}),
                             "used": used, "why": _why(role, col, used), "_pos": pos, "_pen": rank_penalty(col)})
    for r in ROLES:
        ranked[r].sort(key=lambda c: (-c["used"], c["_pen"], c["_pos"]))
        for c in ranked[r]:
            c.pop("_pos", None)
            c.pop("_pen", None)
        ranked[r] = ranked[r][:per_role]
    return {"roles": ranked, "visuals": _visuals(ranked)}


def _visuals(r: Dict[str, List[Dict[str, Any]]]) -> List[Dict[str, Any]]:
    """The kinds this dataset suits, best first, each with its fields (ids by role)."""
    t, c, m = r[TIME], r[CATEGORY], r[MEASURE]
    out: List[Dict[str, Any]] = []
    if t and m:
        out.append({"kind": "line", "dimensions": [t[0]["column_id"]], "measures": [m[0]["column_id"]],
                    "why": f"{m[0]['label']} over {t[0]['label']}"})
    if c and m:
        out.append({"kind": "bar", "dimensions": [c[0]["column_id"]], "measures": [m[0]["column_id"]],
                    "why": f"{m[0]['label']} by {c[0]['label']}"})
    if m:
        out.append({"kind": "number", "dimensions": [], "measures": [m[0]["column_id"]], "why": f"the total {m[0]['label']}"})
    if c and m:
        out.append({"kind": "table", "dimensions": [x["column_id"] for x in c[:2]], "measures": [m[0]["column_id"]],
                    "why": f"{m[0]['label']} by {', '.join(x['label'] for x in c[:2])}"})
        out.append({"kind": "donut", "dimensions": [c[0]["column_id"]], "measures": [m[0]["column_id"]],
                    "why": f"the share of {m[0]['label']} by {c[0]['label']}"})
    if len(m) >= 2 and c:
        out.append({"kind": "scatter", "dimensions": [c[0]["column_id"]], "measures": [m[0]["column_id"], m[1]["column_id"]],
                    "why": f"{m[0]['label']} against {m[1]['label']}, one point per {c[0]['label']}"})
    return out


def suggest_for_dataset(db, dataset_id: int, *, columns: List[Dict[str, Any]], user: Optional[Dict[str, Any]] = None,
                        exclude_report_id: Optional[int] = None, max_reports: int = 500) -> Dict[str, Any]:
    """The route's answer: the dataset's columns (as the caller may see them) and the use of them by the
    other reports THE CALLER COULD SEE (``_reports_on``).  A failed usage read is said (``usage_known: false``),
    never silently empty."""
    usage_known = True
    try:
        reports = _reports_on(db, dataset_id, max_reports, user or {})
        usage = usage_from_reports(reports, exclude_report_id=exclude_report_id)
    except Exception:  # noqa: BLE001
        usage, usage_known = None, False
    out = suggest(columns, usage)
    out["usage_known"] = usage_known
    return out


#: lifecycle states whose reports are no guide to what people chart now
_RETIRED = ("archived", "deprecated")


def _reports_on(db, dataset_id: int, limit: int, user: Dict[str, Any]) -> List[Dict[str, Any]]:
    """The reports on the dataset whose use may inform THIS caller (review 2026-11-09: "used N times in other
    reports" must not reveal another person's private draft): switched on, not a sample, not archived /
    deprecated, and either the caller's own or PUBLISHED to a role list that is empty or holds the caller's
    role.  Newest first, so the cap keeps the current ones."""
    from core.db.models import BusinessReport
    from core.config_active import active_clause
    me = str(user.get("username") or "").lower()
    role = str(user.get("role") or "").lower()
    with db.get_session(read_only=True) as session:
        rows = (session.query(BusinessReport.id, BusinessReport.layout_config, BusinessReport.owner,
                              BusinessReport.is_published, BusinessReport.role_whitelist,
                              BusinessReport.lifecycle_status, BusinessReport.is_sample)
                .filter(BusinessReport.dataset_id == int(dataset_id), active_clause(BusinessReport))
                .order_by(BusinessReport.id.desc()).limit(int(limit)).all())
    out = []
    for rid, lc, owner, published, roles, status, sample in rows:
        if sample or str(status or "").lower() in _RETIRED:
            continue
        mine = bool(me) and str(owner or "").lower() == me
        allowed = [str(r).lower() for r in (roles or []) if r] if isinstance(roles, list) else []
        if mine or (published and (not allowed or role in allowed)):
            out.append({"id": rid, "layout_config": lc})
    return out
