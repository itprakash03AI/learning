"""core.reports.export_stream -- a report export read from its ARTIFACT in
record batches, never materialised whole (2026-10-04).

Measured live on the Docker rig (real Snowflake, a 4,988,801-row detail
report, ``row_limit`` 0):

* ``download-csv``  -> 1,000,000 rows in 226 s, cut by
  ``business_reports.export_materialize_cap`` -- though the route calls CSV
  "the documented escape hatch for large results";
* ``download-excel`` -> 1,000,002 rows on one sheet in 309 s;
* ``download-pdf``  -> the API container OOM-KILLED (see ``pdf_engine``).

The export routes pulled every row into Python THREE times before writing a
byte: ``ReportEnvelope.materialize`` (a DuckDB -> pandas -> list-of-dicts
read), ``to_wire`` (``sanitize_for_json`` copied every record AND built a
positional ``rows`` list beside it, on the event loop), then the renderer.
Measured on the dev box for 1M rows x 5 columns: ~1.1 GB resident and ~10 s
before the CSV writer even started -- on a 2 GB container that is the whole
pod, and the event loop sat blocked inside ``to_wire`` meanwhile.

This module is the other road: a parquet artifact is read with
``pyarrow.parquet.ParquetFile.iter_batches`` and every batch is converted
COLUMN-WISE to the values the in-memory path produced, then handed to a
writer and dropped.  Peak memory is one batch whatever the result size.

THE VALUE CONVENTION IS THE OLD ONE.  :func:`export_cell_values` reproduces
what ``read_artifact_page`` (DuckDB -> pandas) followed by
``sanitize_for_json`` yields, as verified in the production image
(Python 3.11, pandas 2.1.3, DuckDB 1.5.3) and on the dev box:

=================  =========================================
artifact type      exported value
=================  =========================================
integer / string   the value itself
bool               ``True`` / ``False``
float              the float; NaN / +-inf -> empty
decimal            float when it has <= 15 significant digits,
                   else its exact string (``sanitize_for_json``'s rule)
date               ``YYYY-MM-DDT00:00:00`` (pandas gave a Timestamp)
timestamp          ``datetime.isoformat()``
time               ``time.isoformat()``
duration           seconds as a float
binary             hex
anything else      ``sanitize_for_json`` of the Python value
=================  =========================================

Synchronous by design -- callers run it on a worker thread (the export
routes use the worker pool's EXPORT slot), never on the event loop.
"""
from __future__ import annotations

import csv
import datetime as _dt
import logging
import math
from pathlib import Path
from typing import Any, Iterable, Iterator, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)

#: Rows per record batch.  32k rows of a typical 5-column report row is
#: ~25 MB of Python objects at the conversion step (measured: a 64k batch
#: peaked at 48 MB under tracemalloc, however many rows followed) -- small
#: against any pod, large enough that the per-batch overhead is noise.
EXPORT_BATCH_ROWS = 32_768


class ExportSourceError(RuntimeError):
    """The artifact cannot be read as the export asked (missing file, an
    unreadable format).  A FAILURE -- never an empty file presented as the
    data."""


# ── The value convention ─────────────────────────────────────────────────────

def _float_values(values: list) -> list:
    # 2026-11-08 -- a whole number prints as a whole number (core.csv_numbers, THE rule every
    # CSV road shares): a SUM over an integer column reaches the artifact as DOUBLE 1000.0
    from core.csv_numbers import whole_number
    return [None if (v is None or math.isnan(v) or math.isinf(v)) else whole_number(v)
            for v in values]


def _decimal_value(v):
    # sanitize_for_json's rule, verbatim (BF-560): precision beyond what a
    # binary64 holds is kept as the exact string.
    if v is None:
        return None
    try:
        if len(v.as_tuple().digits) > 15:
            return str(v)
        from core.csv_numbers import whole_number
        return whole_number(float(v))                     # 2026-11-08: 100.00 -> 100, 12.34 stays
    except (ValueError, OverflowError, TypeError):
        return str(v)


def _decimal_values(arr, values: list) -> list:
    """``_decimal_value`` over a column, without ``as_tuple`` per value where
    the TYPE already answers it.  ``float(Decimal)`` is correctly rounded;
    Arrow's decimal -> double cast is NOT (measured: 13% of DECIMAL(18,2)
    values differ in the last bit), so the float always comes from Python.
    """
    import pyarrow as pa
    import pyarrow.compute as pc

    t = arr.type
    # 2026-11-08 -- a whole number prints as a whole number (core.csv_numbers): DuckDB's HUGEINT
    # sum arrives as decimal(38, 0) and used to print 1000.0.  No scale-0 shortcut is needed: a
    # value a float could distort is above 2**53 and so above 10**15, which the wide-value rule
    # below already keeps as its exact string (a mutation sweep proved the shortcut unobservable).
    from core.csv_numbers import whole_number
    if t.precision <= 15:
        # Every value has <= 15 significant digits: always a float -- and a whole one prints
        # as a whole number (2026-11-08), as the in-memory renderer prints the same value.
        return [None if v is None else whole_number(float(v)) for v in values]
    # A value keeps its exact string when its UNSCALED integer has more than
    # 15 digits, i.e. |v| >= 10**15 / 10**scale -- decided by Arrow's exact
    # decimal comparison, then only those values pay for str().
    import decimal as _decimal
    try:
        threshold = pa.scalar(_decimal.Decimal(10 ** 15).scaleb(-t.scale), type=t)
        wide = pc.greater_equal(pc.abs(arr), threshold).to_pylist()
    except (pa.ArrowException, ValueError, TypeError):
        # A type the threshold cannot be expressed in (negative scale):
        # the per-value rule.
        return [_decimal_value(v) for v in values]
    return [None if v is None else (str(v) if w else whole_number(float(v)))
            for v, w in zip(values, wide)]


def _date_values(values: list) -> list:
    # Dates repeat heavily in report data; one isoformat per distinct day.
    memo: dict = {}
    out = []
    for v in values:
        if v is None:
            out.append(None)
            continue
        s = memo.get(v)
        if s is None:
            s = memo[v] = _dt.datetime(v.year, v.month, v.day).isoformat()
        out.append(s)
    return out


def _iso_value(v):
    if v is None:
        return None
    try:
        return v.isoformat()
    except (ValueError, OverflowError):
        return str(v)


def _duration_value(v):
    return None if v is None else v.total_seconds()


def _binary_value(v):
    return None if v is None else bytes(v).hex()


def export_cell_values(arr) -> list:
    """One Arrow column -> the Python values an export writes for it.

    See the module docstring for the convention; it is the in-memory
    path's, so a streamed file and a materialised one carry the same text.
    ``arr`` is a ``pyarrow.Array`` or ``ChunkedArray``.
    """
    import pyarrow.types as pat

    t = arr.type
    if pat.is_dictionary(t):
        arr = arr.cast(t.value_type)
        t = arr.type
    values = arr.to_pylist()
    if (pat.is_integer(t) or pat.is_string(t) or pat.is_large_string(t)
            or pat.is_boolean(t) or pat.is_null(t)):
        return values
    if pat.is_floating(t):
        return _float_values(values)
    if pat.is_decimal(t):
        return _decimal_values(arr, values)
    if pat.is_date(t):
        return _date_values(values)
    if pat.is_timestamp(t) or pat.is_time(t):
        return [_iso_value(v) for v in values]
    if pat.is_duration(t):
        return [_duration_value(v) for v in values]
    if pat.is_binary(t) or pat.is_large_binary(t) or pat.is_fixed_size_binary(t):
        return [_binary_value(v) for v in values]
    # Nested / exotic types: the in-memory path's own sanitiser.
    from core.json_utils import sanitize_for_json
    return [sanitize_for_json(v) for v in values]


# ── Reading an artifact in batches ───────────────────────────────────────────

def artifact_columns(path) -> List[str]:
    """Column names of an artifact (parquet schema, or a CSV header)."""
    p = Path(path)
    if p.suffix.lower() in (".parquet", ".pq"):
        import pyarrow.parquet as pq
        return list(pq.ParquetFile(str(p)).schema_arrow.names)
    with open(p, "r", encoding="utf-8", newline="") as fh:
        return next(csv.reader(fh), [])


def _open_batches(path: Path, columns: Sequence[str], batch_rows: int):
    """Yield ``pyarrow.RecordBatch`` objects carrying ``columns`` (those the
    artifact has).  Parquet reads only the requested columns."""
    suffix = path.suffix.lower()
    if suffix in (".parquet", ".pq"):
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(str(path))
        yield from pf.iter_batches(batch_size=batch_rows,
                                   columns=list(columns) or None)
        return
    if suffix == ".csv":
        # Legacy CSV artifacts: Arrow's streaming CSV reader (one block at a
        # time), every column read as text -- a CSV has no types to keep.
        import pyarrow as pa
        import pyarrow.csv as pacsv
        names = artifact_columns(path)
        reader = pacsv.open_csv(
            str(path),
            convert_options=pacsv.ConvertOptions(
                column_types={n: pa.string() for n in names},
                include_columns=list(columns) or None,
                strings_can_be_null=True))
        for batch in reader:
            yield batch
        return
    raise ExportSourceError(f"cannot export from an artifact of type {suffix!r}")


def native_cell_values(arr) -> list:
    """One Arrow column -> TYPED Python values for a spreadsheet: dates and
    timestamps stay dates (an Excel cell can sort and filter them), NaN /
    +-inf become empty, and a zone-aware timestamp becomes its naive UTC
    time (an xlsx cell cannot carry a zone -- pandas' ``to_excel`` refused
    such a column outright)."""
    import pyarrow.types as pat
    t = arr.type
    if pat.is_dictionary(t):
        arr = arr.cast(t.value_type)
        t = arr.type
    values = arr.to_pylist()
    if pat.is_floating(t):
        return _float_values(values)
    if pat.is_timestamp(t) and t.tz is not None:
        return [None if v is None else
                v.astimezone(_dt.timezone.utc).replace(tzinfo=None)
                for v in values]
    if pat.is_duration(t):
        return [_duration_value(v) for v in values]
    if pat.is_binary(t) or pat.is_large_binary(t) or pat.is_fixed_size_binary(t):
        return [_binary_value(v) for v in values]
    if (pat.is_nested(t) or pat.is_map(t)):
        return [None if v is None else str(v) for v in values]
    return values


def iter_artifact_rows(path, columns: Sequence[str], *,
                       limit: Optional[int] = None,
                       batch_rows: int = EXPORT_BATCH_ROWS,
                       native: bool = False
                       ) -> Iterator[List[Tuple[Any, ...]]]:
    """Yield the artifact's rows as LISTS OF TUPLES, one list per batch,
    each tuple in ``columns`` order, values per :func:`export_cell_values`
    (``native=True``: :func:`native_cell_values`, for a spreadsheet that
    keeps typed cells).

    A column the artifact does not carry yields ``None`` in every row -- the
    in-memory path's ``DictWriter(restval="")`` parity -- and is logged once,
    because it is never expected.  ``limit`` (``None`` / ``<= 0`` = all)
    stops the read after that many rows.
    """
    p = Path(path)
    if not p.is_file():
        raise ExportSourceError(f"export artifact is missing: {p}")
    present = set(artifact_columns(p))
    wanted = list(columns)
    missing = [c for c in wanted if c not in present]
    if missing:
        logger.warning("[export-stream] artifact %s lacks column(s) %s -- they "
                       "export empty (the in-memory path's behaviour)",
                       p.name, missing)
    read_cols = [c for c in wanted if c in present]
    convert = native_cell_values if native else export_cell_values
    for batch in _bounded(_open_batches(p, read_cols, batch_rows), limit):
        n = batch.num_rows
        by_name = {name: convert(batch.column(i))
                   for i, name in enumerate(batch.schema.names)}
        none_col = [None] * n
        cols_out = [by_name.get(c, none_col) for c in wanted]
        yield list(zip(*cols_out)) if cols_out else [()] * n


def _bounded(batches, limit: Optional[int]):
    """Non-empty batches, stopping after ``limit`` rows (``None`` / ``<= 0``
    = all)."""
    remaining = int(limit) if (limit is not None and int(limit) > 0) else None
    for batch in batches:
        if remaining is not None:
            if remaining <= 0:
                return
            if batch.num_rows > remaining:
                batch = batch.slice(0, remaining)
            remaining -= batch.num_rows
        if batch.num_rows:
            yield batch


def iter_record_rows(records: Iterable[Any], columns: Sequence[str],
                     batch_rows: int = EXPORT_BATCH_ROWS
                     ) -> Iterator[List[Tuple[Any, ...]]]:
    """The same batch shape over rows already in memory (inline published /
    federation view results, running-calculation output).  A non-dict row
    contributes empty values -- ``_render_csv_bytes``' behaviour."""
    from core.csv_numbers import whole_number      # 2026-11-08: the one rule, on in-memory rows too
    wanted = list(columns)
    chunk: List[Tuple[Any, ...]] = []
    for r in records:
        if isinstance(r, dict):
            chunk.append(tuple(whole_number(r.get(c)) for c in wanted))
        else:
            chunk.append(tuple(None for _ in wanted))
        if len(chunk) >= batch_rows:
            yield chunk
            chunk = []
    if chunk:
        yield chunk


# ── Writers ──────────────────────────────────────────────────────────────────

def write_csv(out_path, columns: Sequence[str],
              row_batches: Iterable[List[Tuple[Any, ...]]]) -> Tuple[int, int]:
    """Write a CSV in the business-report convention -- UTF-8 with BOM, the
    ``excel`` dialect (CRLF, minimal quoting), header = ``columns`` -- the
    exact bytes ``_render_csv_bytes`` produces for the same rows.  ``None``
    is written as empty.

    Returns ``(data_rows, bytes_written)``; the byte count is the WRITER's
    own (its position after the final flush), so a caller can verify the
    file on disk is the file that was written before registering it.
    """
    n = 0
    with open(out_path, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(list(columns))
        for chunk in row_batches:
            w.writerows(chunk)
            n += len(chunk)
        fh.flush()
        nbytes = fh.buffer.tell()
    return n, int(nbytes)
