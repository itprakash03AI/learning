"""THE rule every CSV road shares: a whole number prints as a whole number (2026-11-08).

The UAT guides of 2026-11-06 / 07 listed it: "A summed whole number in a CSV downloads as
1000.0".  A SUM over an integer column comes back from DuckDB as HUGEINT (written to the result
artifact as DOUBLE, or read as decimal(38, 0)) or from pandas as float64, and every CSV writer
printed the float's text -- ``1000.0``.

ONE rule, in one place, used by every road that writes CSV for a report (the report download,
the scheduled / subscription file, the burst slice, the results grid's download, the published
API's ``format=csv`` and the share-link / embed CSV, the canvas action's detail file):

* a float that holds a whole number (``1000.0``) is written as the integer ``1000`` -- when it is
  EXACTLY representable, |v| < 2**53 (:data:`EXACT_WHOLE_BOUND`); a whole float beyond that bound
  (``1e19``, ``1.5e300``) is NOT an exact integer and keeps its float text, as it printed before
  (review 2026-11-08: ``astype("Int64")`` raised on |v| >= 2**63 and a mixed column would have
  printed ``1e300`` as a 301-digit integer);
* a float with a real fraction keeps it (``1000.5`` stays ``1000.5``) -- nothing is rounded;
* a decimal of scale 0 (an integer type) is written as the exact integer, never through a float
  (a HUGEINT sum past 2**53 keeps every digit);
* a decimal WITH a scale keeps its scale -- ``Decimal('1000.00')`` is not a whole-number float
  and is left to the road's own decimal convention;
* NaN / infinities and non-numbers are left exactly as they came.

Two shapes of the same rule: :func:`whole_number` for a value (the ``csv`` module roads) and
:func:`whole_number_columns` for a DataFrame (the ``to_csv`` roads) -- a float column whose
values are all whole becomes pandas' nullable integer so ``1000`` / empty print consistently.
"""
from __future__ import annotations

import decimal as _decimal
import math
from typing import Any

__all__ = ["EXACT_WHOLE_BOUND", "is_whole_float", "whole_number", "whole_number_columns"]

#: the largest magnitude at which every whole float is an exact integer (a double has a 53-bit
#: significand); beyond it a float is a rounded value and its integer text would claim digits
#: the number never had
EXACT_WHOLE_BOUND = 2 ** 53


def is_whole_float(v: Any) -> bool:
    """A finite float (or numpy float) that holds an integer value EXACTLY (|v| < 2**53)."""
    if isinstance(v, bool):
        return False
    if isinstance(v, float):
        return math.isfinite(v) and v.is_integer() and abs(v) < EXACT_WHOLE_BOUND
    kind = type(v).__name__
    if kind.startswith("float"):                       # numpy float32 / float64
        try:
            f = float(v)
        except (TypeError, ValueError):
            return False
        return math.isfinite(f) and f.is_integer() and abs(f) < EXACT_WHOLE_BOUND
    return False


def whole_number(v: Any) -> Any:
    """The value a CSV cell is written from: a whole-number float as ``int``, a scale-0
    decimal as ``int``, everything else unchanged."""
    if is_whole_float(v):
        return int(float(v))
    if isinstance(v, _decimal.Decimal):
        if not v.is_finite():
            return v
        if v.as_tuple().exponent >= 0:                 # scale 0: an integer type
            return int(v)
        return v                                       # a scaled decimal keeps its scale
    return v


def whole_number_columns(df):
    """A copy of ``df`` whose float columns print as :func:`whole_number` prints each value:
    a column that holds only exact whole numbers (nulls allowed) becomes pandas' nullable
    ``Int64`` (``1000`` and empty, never ``1000.0``); a column that mixes whole numbers and
    fractions -- or whole numbers beyond the exact-integer bound -- is written value by value
    (``1`` beside ``2.25`` beside ``1e+19``) -- the same text the ``csv``-module roads write, so a
    number reads the same in every CSV.  NaN-only or infinite columns are left.  Never raises:
    a value the rule does not convert is written as it came."""
    import pandas as pd
    out = df
    for col in df.columns:
        s = df[col]
        if not pd.api.types.is_float_dtype(s.dtype):
            continue
        present = s.dropna()
        if present.empty:
            continue
        arr = present.to_numpy(dtype="float64", copy=False)
        if not (math.isfinite(float(arr.min())) and math.isfinite(float(arr.max()))):
            continue
        whole = ((arr % 1) == 0) & (abs(arr) < EXACT_WHOLE_BOUND)
        if not bool(whole.any()):
            continue
        if out is df:
            out = df.copy()
        if bool(whole.all()):
            out[col] = s.astype("Int64")
        else:
            # an explicit object Series: pandas would infer float64 again from ints beside floats
            out[col] = pd.Series([None if (v is None or (isinstance(v, float) and math.isnan(v))) else whole_number(v)
                                  for v in s.tolist()], index=s.index, dtype=object)
    return out
