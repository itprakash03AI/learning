"""Large queries in the background -- ONE model (2026-11-08; the owner's asks of 2026-11-04).

The EXPECTED rows of a run = the Iceberg manifests' ``record_count`` over the data files kept
after partition pruning: known before a byte of data is read (``core/limit_early_stop.py`` and
the completeness certificate already read these counts; the reader stamps the same sum as
``island_rows``), an UPPER BOUND on the rows to read -- before a WHERE on a non-partition column,
before GROUP BY, before LIMIT.  It is never the answer's size and is never shown as one:
"up to 2,400,000 rows to read".  Unknown is "not known", never 0, and is never routed.  ONE
rule for unknown: ANY missing count (a NULL in the manifests, a table the plan cannot count --
plain parquet, Hive, a Trino side, the second connection of a cross-source run) makes the WHOLE
run "not known".

From that number and ONE threshold (``features.background_rows_threshold``, 0 = off):
  * the SQL road: as the S3 read plan is made (``core/duckdb_views``), ``note_plan`` stamps the
    count on the execution (``files_metadata.expected_rows``) and, above the threshold, marks it
    ``background``, writes the PENDING notice and tells the screen (WS ``execution_background``);
  * the report road: the federation reader's plan stamps the count on the run
    (``note_report_plan`` -> the per-execution diagnostic store -> the envelope, the Diagnostics
    panel's facts); BEFORE a run, ``report_preflight`` reads the last recorded run of the same
    report by the SAME person with the same values -- above the threshold, and only when the
    caller said it can show the words (``allow_background``), the route starts the async job,
    marks the PENDING notice and answers 202 in words;
  * when the result is ready, ``on_result_ready`` registers it in the Download Centre, turns the
    pending notice into "Your result is ready" (the app's ONE bell: ``notification_log``, the
    WebSocket), and sends the e-mail the person asked for (``request_email``: to the person's OWN
    address, derived as every notice address is -- ``published_views.notify_email_domain``);
  * when a routed run FAILS or is CANCELLED, ``on_result_ended`` closes its notice (failed -> a
    "did not finish" notice with the reason; cancelled -> withdrawn) and cancels the e-mail wish.
The notices ARE the bookkeeping -- the pending row, the e-mail wish, the ready / did-not-finish
rows all live in ``notification_log`` (never a parallel store).  A cap must throttle and say so:
a routed run is never cut.
"""
from __future__ import annotations

import contextvars
import json
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)

EVENT_PENDING = "result_pending"          # the run went to the background (status pending -> sent)
EVENT_READY = "result_ready"              # the result is ready (status sent)
EVENT_FAILED = "result_failed"            # the run did not finish (status sent)
EVENT_EMAIL = "result_email_requested"    # the e-mail wish (channel email, pending -> sent / failed / cancelled)
WS_BACKGROUND = "execution_background"    # the screen is told to stop waiting
BASIS_MANIFEST = "iceberg_manifest"
BASIS_LAST_RUN = "last_run_plan"
SOURCE_KIND_QUERY = "background_result"
SOURCE_KIND_REPORT = "background_report"
NOT_KNOWN = "not known"
STORE_KEY = "expected_rows"               # the key in files_metadata / the diagnostic store / the run facts
#: files_metadata keys that are NOT a table's file stats
_RESERVED_FM_KEYS = {STORE_KEY, "background", "__engine_meta__", "stage_history", "latency_breakdown",
                     "iceberg_versions", "agent_suggestion", "cross_source", "join_health", "join_health_detail"}

__all__ = ["expected_rows_words", "expected_from_counts", "threshold", "routes_to_background",
           "background_words", "note_plan", "note_report_plan", "expected_rows_keys", "gate_entry",
           "report_preflight", "expected_rows_for_sql", "mark_pending", "unmark_pending", "requester_email",
           "request_email", "email_wish_check", "on_result_ready", "on_result_ended", "status_fields",
           "tables_in_plan_of", "tables_of_dataset", "move_pending", "run_will_retry", "TABLES_UNKNOWN",
           "current_job_id", "set_current_job_id", "reset_current_job_id", "move_pending_for_job", "job_lookups_armed",
           "EVENT_PENDING", "EVENT_READY", "EVENT_FAILED", "EVENT_EMAIL", "WS_BACKGROUND", "NOT_KNOWN",
           "SOURCE_KIND_QUERY", "SOURCE_KIND_REPORT", "STORE_KEY"]


# ── the number and its words ────────────────────────────────────────────────

def expected_rows_words(expected: Optional[int]) -> str:
    """Plain words for the screen: an upper bound, or 'not known' -- never 0 for unknown."""
    if expected is None:
        return NOT_KNOWN
    try:
        n = int(expected)
    except (TypeError, ValueError):
        return NOT_KNOWN
    return f"up to {n:,} rows to read"


def expected_from_counts(record_counts: Optional[Iterable[Any]], pos_delete_records: int = 0) -> Optional[int]:
    """Σ record_count of the kept files (minus exact position deletes); None when any count is
    missing -- unknown is not a number (core/completeness_control.compute_expected_rows)."""
    from core.completeness_control import compute_expected_rows
    counts = None if record_counts is None else list(record_counts)
    if counts is None or any(c is None for c in counts):
        return None
    out = compute_expected_rows(counts, pos_delete_records or 0)
    if out.get("record_count_missing") or out.get("record_count_partial"):
        return None
    return out.get("expected_rows")


def threshold() -> int:
    """``features.background_rows_threshold``; 0 = off."""
    try:
        from core.config import features as _features
        return int(getattr(_features, "background_rows_threshold", 0) or 0)
    except Exception:  # noqa: BLE001
        return 0


def routes_to_background(expected: Optional[int], thr: Optional[int] = None) -> bool:
    """Above the threshold, and only for a KNOWN count (unknown is never routed)."""
    t = threshold() if thr is None else int(thr or 0)
    if t <= 0 or expected is None:
        return False
    try:
        return int(expected) > t
    except (TypeError, ValueError):
        return False


def background_words(expected: Optional[int], thr: Optional[int] = None, what: str = "query") -> str:
    t = threshold() if thr is None else int(thr or 0)
    n = f"{int(expected):,}" if expected is not None else "an unknown number of"
    return (f"This {what} reads up to {n} rows (more than {t:,}), so it runs in the background. "
            f"You can leave this page: the result will be in the Download Centre, and you will get a "
            f"notice here when it is ready.")


def _bare(name: Any) -> str:
    return str(name or "").strip().lower().rsplit(".", 1)[-1].strip('"')


def _entry(by_table: Dict[str, Any], tables_read: Optional[Sequence[Any]] = None) -> Dict[str, Any]:
    """The run's expected-rows record.  ``tables_read`` = EVERY table the run reads (names); a
    table without a known count -- never planned as Iceberg, or a missing manifest count -- makes
    the total unknown.  ONE rule: any missing count = unknown."""
    vals = [v.get("expected_rows") for v in by_table.values()]
    total = None if (not vals or any(v is None for v in vals)) else int(sum(vals))
    known = {_bare(k) for k in by_table}
    read = [str(t) for t in (tables_read or []) if str(t or "").strip()]
    partial = bool(read) and any(_bare(t) not in known for t in read)
    if partial:
        total = None
    return {"by_table": by_table, "total": total, "words": expected_rows_words(total),
            "basis": BASIS_MANIFEST, "upper_bound": True,
            "tables_read": sorted({str(t) for t in read}) if read else None, "partial": partial}


def gate_entry(entry: Any, tables_read: Optional[Sequence[Any]]) -> Optional[Dict[str, Any]]:
    """An entry re-gated on the FULL list of tables a run reads (a dataset's source tables, the
    file stats at completion): any table without a known count -> the total is not known."""
    if not isinstance(entry, dict):
        return None
    out = dict(entry)
    by_table = dict(entry.get("by_table") or {})
    known = {_bare(k) for k in by_table}
    read = [str(t) for t in (tables_read or []) if str(t or "").strip()]
    partial = bool(entry.get("partial")) or (bool(read) and any(_bare(t) not in known for t in read))
    total = entry.get("total")
    if partial or total is None:
        total = None
    out.update({"total": total, "words": expected_rows_words(total), "partial": partial,
                "tables_read": sorted({str(t) for t in read}) if read else entry.get("tables_read")})
    return out


def tables_in_plan_of(registered: Optional[Sequence[Any]], referenced: Optional[Iterable[Any]]) -> List[str]:
    """The registered tables a statement READS: the connection's registered list narrowed to the
    names the statement references (re-review A: the full registered list made every single-table
    query on a connection with several tables 'partial' -> never known, never routed).  No
    referenced list = the plan reads them all (the planner's own rule)."""
    refs = {str(r).strip().lower() for r in (referenced or []) if str(r or "").strip()}
    out: List[str] = []
    for t in registered or []:
        name = t.get("name") if isinstance(t, dict) else t
        if not name:
            continue
        if refs and str(name).lower() not in refs:
            continue
        out.append(str(name))
    return out


#: "the tables could not be told" -- a name no plan ever counts, so the gate reads NOT KNOWN
#: (final review C: an empty list means "no gate" and let an unparseable dataset keep a known count)
TABLES_UNKNOWN: List[str] = ["?could-not-tell?"]


def tables_of_dataset(ds: Any) -> List[str]:
    """Every table a dataset reads: its declared ``source_tables``, else (a SQL-mode dataset has
    none, re-review C) the tables its ``base_query`` names.  When that cannot be told -- no dataset,
    no SQL, SQL that names no table or does not parse -- :data:`TABLES_UNKNOWN`, which gates the
    count to NOT KNOWN; never an empty list, which would mean "nothing to gate on"."""
    if not isinstance(ds, dict):
        return list(TABLES_UNKNOWN)
    names = [st.get("table") for st in (ds.get("source_tables") or []) if isinstance(st, dict) and st.get("table")]
    if names:
        return [str(n) for n in names]
    sql = str(ds.get("base_query") or ds.get("custom_sql") or "")
    if not sql.strip():
        return list(TABLES_UNKNOWN)
    try:
        from core.sql_table_extractor import extract_table_names
        found = sorted(str(n) for n in (extract_table_names(sql) or []))
    except Exception:  # noqa: BLE001
        found = []
    return found or list(TABLES_UNKNOWN)


# ── the SQL road: the plan hook (the S3 read plan knows the kept files and their counts) ──

def _files_metadata(db, execution_id: str) -> Optional[Dict[str, Any]]:
    try:
        ex = db.get_execution(execution_id)
    except Exception as exc:  # noqa: BLE001
        logger.info("[background] execution %s unreadable: %s", execution_id, exc)
        return None
    if not ex:
        return None
    fm = ex.get("files_metadata")
    if isinstance(fm, str):
        try:
            fm = json.loads(fm)
        except Exception:  # noqa: BLE001
            fm = {}
    fm = dict(fm or {})
    fm["_executed_by"] = ex.get("executed_by") or ""
    return fm


#: one note at a time per process (see note_plan)
_NOTE_LOCK = __import__("threading").Lock()


def note_plan(db, execution_id: Optional[str], table: str, record_counts: Optional[Iterable[Any]], *,
              pos_delete_records: int = 0, files: Optional[int] = None,
              tables_in_plan: Optional[Sequence[Any]] = None,
              link: Optional[str] = None, what: str = "query") -> Dict[str, Any]:
    """Stamp a table's expected rows on the execution (``files_metadata.expected_rows``), total
    them over EVERY table the plan reads (``tables_in_plan``: a plain-parquet or Hive table has no
    count -> the total is not known), and above the threshold mark the run ``background``, write
    the PENDING notice and tell the screen.  Returns what it recorded; never raises into the plan."""
    out: Dict[str, Any] = {"table": table, "expected_rows": None, "total": None, "background": False}
    if not execution_id or db is None:
        return out
    try:
        n = expected_from_counts(record_counts, pos_delete_records)
        out["expected_rows"] = n
        # 2026-11-09 (review): the multi-worker road notes its tables from PARALLEL threads, and
        # update_execution merges files_metadata only at the top level -- read, rebuild, write by two
        # threads at once lost a table (a two-table JOIN read "not known", never routed).  One lock
        # per process around the read-modify-write, and only the keys this note OWNS are written
        # (a whole read-back would also put stale values of every other key back).
        with _NOTE_LOCK:
            fm = _files_metadata(db, execution_id)
            if fm is None:
                return out
            user = fm.pop("_executed_by", "")
            prev = fm.get(STORE_KEY) or {}
            by_table = dict(prev.get("by_table") or {})
            by_table[str(table)] = {"expected_rows": n, "files": files, "basis": BASIS_MANIFEST if n is not None else None}
            read = list(tables_in_plan or prev.get("tables_read") or [])
            entry = _entry(by_table, read)
            if fm.get("cross_source_plan") or fm.get("cross_source"):
                # re-review B: a cross-source run reads a SECOND connection this plan never counts --
                # the total is not known and the run is never routed (its completion road announces nothing)
                entry.update({"total": None, "words": NOT_KNOWN, "partial": True, "cross_source": True})
            write: Dict[str, Any] = {STORE_KEY: entry}
            total = entry["total"]
            out["total"] = total
            thr = threshold()
            if routes_to_background(total, thr) and not fm.get("background"):
                words = background_words(total, thr, what)
                write["background"] = {"threshold": thr, "expected_rows": total, "words": words,
                                       "since": datetime.now(timezone.utc).isoformat(), "what": what}
                out["background"] = True
                out["words"] = words
                db.update_execution(execution_id, files_metadata=write)
                mark_pending(db, execution_id, user=user, link=link or f"/downloads?execution={execution_id}",
                             words=words, what=what, expected_rows=total)
                logger.info("[background] execution %s routed to the background: %s rows expected (threshold %d)",
                            execution_id, total, thr)
            else:
                db.update_execution(execution_id, files_metadata=write)
    except Exception as exc:  # noqa: BLE001
        logger.warning("[background] expected rows of %s not recorded: %s", execution_id, exc)
    return out


def mark_pending(db, execution_id: str, *, user: str, link: str, words: str, what: str,
                 expected_rows: Optional[int] = None, ws=None) -> Optional[Dict[str, Any]]:
    """The run goes to the background: the PENDING notice (the bell's store) and the word to the
    screen (WS ``execution_background``, addressed to the person)."""
    row = None
    if user:
        # ONE notice per routed request: a continuation whose notice was moved here already has one
        already = [r for r in _rows_for(db, execution_id) if r.get("event_type") == EVENT_PENDING and r.get("status") == "pending"]
        row = already[-1] if already else db.log_notification(
            event_type=EVENT_PENDING, channel="websocket", recipient=user, status="pending",
            title=f"Your {what} runs in the background", message=words,
            payload={"link": link, "what": what, "expected_rows": expected_rows}, execution_id=execution_id)
    _tell(ws, user, {"type": WS_BACKGROUND, "execution_id": execution_id, "username": user or "",
                     "words": words, "expected_rows": expected_rows, "link": link, "what": what})
    return row


def _close_pending(db, rows: List[Dict[str, Any]]) -> int:
    """PENDING rows become read history (sent + read).  Returns how many."""
    n = 0
    upd = getattr(db, "update_notification_status", None)
    mark_read = getattr(db, "mark_notification_read", None)
    for row in rows:
        try:
            if callable(upd):
                upd(int(row["id"]), "sent")
            if callable(mark_read):
                mark_read(int(row["id"]))
            n += 1
        except Exception:  # noqa: BLE001
            pass
    return n


#: the job the CURRENT submit runs for -- set by the job queue's bridge around the submit body
#: (core/jobqueue/execute_bridge._submit_with_reservation), read by execute_api when it CREATES the
#: execution row, so the row carries its job id from birth (the ``job_id`` column).  None = an inline run.
_CURRENT_JOB_ID: contextvars.ContextVar = contextvars.ContextVar("qs_background_current_job_id", default=None)


def set_current_job_id(job_id: Optional[str]):
    return _CURRENT_JOB_ID.set(str(job_id) if job_id else None)


def reset_current_job_id(token) -> None:
    try:
        _CURRENT_JOB_ID.reset(token)
    except Exception:  # noqa: BLE001
        _CURRENT_JOB_ID.set(None)


def current_job_id() -> Optional[str]:
    return _CURRENT_JOB_ID.get()


def _job_id_of_execution(db, execution_id: str) -> Optional[str]:
    try:
        ex = db.get_execution(execution_id) or {}
        jid = ex.get("job_id")
        return str(jid) if jid else None
    except Exception:  # noqa: BLE001
        return None


def job_lookups_armed(db) -> bool:
    """Whether a job could have a ROUTED run at all -- the gate on every by-job lookup the queue and
    the bridge make (``executions_for_job``): the feature on (``threshold() > 0``), or a pending
    notice still open (a run routed while it was on, ``notification_log`` is small).  Off and
    nothing open = zero extra queries per job transition / retry."""
    try:
        if threshold() > 0:
            return True
        fn = getattr(db, "has_pending_background_notices", None)
        return bool(fn()) if callable(fn) else False
    except Exception:  # noqa: BLE001
        return False


def run_will_retry(db, execution_id: str) -> bool:
    """THE one answer to "is this run over?" for a run the job queue owns: the queue's own state.
    The execution row carries its job id from CREATION (the indexed ``job_id`` column, the bridge's
    ContextVar): that job live with attempts left = the reaper will requeue it (the pod may have died
    before the bridge stamped the run on the job -- the link was there first); terminal or exhausted
    = over.  A row without a job id (an inline run, or one made before the link) falls back to the
    job's handles: a live ``result_handle`` with attempts left, or a live ``previous_result_handle``
    (the continuation under way).  No job = over."""
    if not execution_id or db is None:
        return False
    try:
        from sqlalchemy import text
        jid = _job_id_of_execution(db, execution_id)
        if jid:
            with db.get_session(read_only=True) as session:
                row = session.execute(text(
                    "SELECT status, attempts, max_attempts FROM query_jobs WHERE id = :j"), {"j": jid}).fetchone()
            if row is None:
                return False
            status, attempts, max_attempts = row
            return (str(status or "").lower() in ("queued", "leased", "running")
                    and int(attempts or 0) < int(max_attempts or 1))
        with db.get_session(read_only=True) as session:
            rows = session.execute(text(
                "SELECT status, attempts, max_attempts, result_handle, previous_result_handle FROM query_jobs "
                "WHERE result_handle = :e OR previous_result_handle = :e"), {"e": str(execution_id)}).fetchall()
        live = {"queued", "leased", "running"}
        for status, attempts, max_attempts, handle, previous in rows:
            st = str(status or "").lower()
            if st not in live:
                continue
            if str(handle or "") == str(execution_id) and int(attempts or 0) < int(max_attempts or 1):
                return True          # the reaper will requeue it
            if str(previous or "") == str(execution_id):
                return True          # the continuation is under way
        # A run no job references is OVER (the 8f6101c71 rule).  Known follow-up (recorded in qs-platform):
        # a pod that dies between the run's start and the bridge stamping result_handle leaves a run no
        # job references, so its notice says "did not finish" although the retry completes; the proof
        # the queue lacks is the execution -> job link (store the job id on the execution row at
        # creation and look the job up by id here).  A guess by person was tried and removed: any fresh
        # queued job of the person matched, deferred an unrelated run, and nothing ever closed it.
        return False
    except Exception as exc:  # noqa: BLE001
        logger.debug("[background] retry state of %s unknown (%s): treated as over", execution_id, exc)
        return False


def move_pending_for_job(db, job_id: str, new_execution_id: str) -> int:
    """Every earlier execution of this JOB (linked by id at creation) hands its pending notice and
    e-mail wish to the run that continues it -- the bridge's ``previous_result_handle`` move covers a
    run that was stamped; this covers one that was not (the pod died before the stamp)."""
    if not job_id or not new_execution_id:
        return 0
    if not job_lookups_armed(db):
        return 0                      # nothing could be routed: no lookup at all
    finder = getattr(db, "executions_for_job", None)
    if not callable(finder):
        return 0
    moved = 0
    try:
        for old in finder(job_id):
            if str(old) != str(new_execution_id):
                moved += move_pending(db, str(old), str(new_execution_id))
    except Exception as exc:  # noqa: BLE001
        logger.info("[background] notices of job %s not moved to %s: %s", job_id, new_execution_id, exc)
    return moved


def move_pending(db, old_execution_id: str, new_execution_id: str) -> int:
    """A run CONTINUED on another pod (the job queue's ``_point_previous_run_here``) is not ended:
    its PENDING notice and e-mail wish move to the continuation's execution id, so the old id's
    "failed / continued as" write closes nothing and the continuation's completion announces
    (re-review D).  A continuation that already FINISHED before the move settles the moved rows
    at once from its own row (final review D).  Returns how many rows moved."""
    if not old_execution_id or not new_execution_id or old_execution_id == new_execution_id:
        return 0
    mover = getattr(db, "move_notifications", None)
    if not callable(mover):
        return 0
    try:
        n = int(mover(old_execution_id, new_execution_id, event_types=(EVENT_PENDING, EVENT_EMAIL)) or 0)
    except Exception as exc:  # noqa: BLE001
        logger.info("[background] notices of %s not moved to %s: %s", old_execution_id, new_execution_id, exc)
        return 0
    if n:
        try:
            ex = db.get_execution(new_execution_id) or {}
            st = str(ex.get("status") or "").lower()
            if st == "completed":
                on_result_ready(db, None, new_execution_id, username=str(ex.get("executed_by") or ""),
                                link=f"/downloads?execution={new_execution_id}", title="Your query result is ready",
                                words="The query that ran in the background has finished; its result is in the Download Centre.",
                                output_file=ex.get("output_file"), rows=ex.get("total_rows"))
            elif st in ("failed", "cancelled"):
                on_result_ended(db, None, new_execution_id, status=st, reason=ex.get("error_message"))
        except Exception as exc:  # noqa: BLE001
            logger.info("[background] moved notices of %s not settled: %s", new_execution_id, exc)
    return n


def unmark_pending(db, execution_id: str) -> int:
    """The start answered at once (an instance served it) or the run was cancelled: the run is NOT
    in the background -- its PENDING notice becomes read history so the bell never says so."""
    return _close_pending(db, [r for r in _rows_for(db, execution_id)
                               if r.get("event_type") == EVENT_PENDING and r.get("status") == "pending"])


def _tell(ws, username: str, payload: Dict[str, Any]) -> None:
    """One UI event to the person: the wired manager when the caller has one (from a worker
    thread, ``broadcast_to_user_sync``), else the EXISTING cross-pod queue
    (``core.notification_queue.emit_ws_event``).  Never raises."""
    try:
        if ws is not None and callable(getattr(ws, "broadcast_to_user_sync", None)) and username:
            ws.broadcast_to_user_sync(username, payload)
            return
        from core.notification_queue import emit_ws_event
        emit_ws_event(payload)
    except Exception as exc:  # noqa: BLE001
        logger.info("[background] the screen could not be told (%s): %s", payload.get("type"), exc)


# ── the report road ─────────────────────────────────────────────────────────

def note_report_plan(table: str, island_rows: Any, files: Any, execution_id: Optional[str] = None,
                     missing_counts: Any = 0) -> Optional[int]:
    """The federation reader planned one Iceberg table: its kept files' rows (``island_rows``)
    on the run's diagnostic store, so the envelope, the Diagnostics facts and the completion read
    ONE number.  A file whose manifest carries no count (``missing_counts`` > 0), or 0 rows with
    files kept, = unknown -- the same rule as the SQL road."""
    try:
        from core.query_diagnostic_store import get_current_execution_id, get_pruning, record_pruning
        eid = execution_id or get_current_execution_id()
        if not eid:
            return None
        n: Optional[int]
        try:
            n = int(island_rows) if island_rows is not None else None
        except (TypeError, ValueError):
            n = None
        try:
            nf = int(files or 0)
        except (TypeError, ValueError):
            nf = 0
        try:
            miss = int(missing_counts or 0)
        except (TypeError, ValueError):
            miss = 1
        if (n == 0 and nf > 0) or miss > 0:
            n = None
        prev = (get_pruning(eid) or {}).get(STORE_KEY) or {}
        by_table = dict(prev.get("by_table") or {})
        by_table[str(table)] = {"expected_rows": n, "files": nf, "basis": BASIS_MANIFEST if n is not None else None,
                                "missing_counts": miss}
        record_pruning(eid, {STORE_KEY: _entry(by_table, prev.get("tables_read"))})
        return n
    except Exception as exc:  # noqa: BLE001
        logger.info("[background] report plan of %s not noted: %s", table, exc)
        return None


def expected_rows_keys(execution_id: Optional[str], tables_read: Optional[Sequence[Any]] = None) -> Dict[str, Any]:
    """What a report envelope / status carries: ``expected_rows`` (an upper bound or None) and
    ``expected_rows_words``.  ``tables_read`` = every table the report's dataset reads: one the
    plan could not count makes it not known.  Nothing recorded = not known."""
    total = None
    try:
        from core.query_diagnostic_store import get_pruning
        er = (get_pruning(execution_id) or {}).get(STORE_KEY) if execution_id else None
        gated = gate_entry(er, tables_read)
        total = gated.get("total") if gated else None
    except Exception:  # noqa: BLE001
        total = None
    return {"expected_rows": total, "expected_rows_words": expected_rows_words(total)}


def _same_values(a: Any, b: Any) -> bool:
    try:
        return json.dumps(a or {}, sort_keys=True, default=str) == json.dumps(b or {}, sort_keys=True, default=str)
    except Exception:  # noqa: BLE001
        return False


def report_preflight(db, report_id: int, param_values: Optional[Dict[str, Any]], *, username: Optional[str] = None,
                     thr: Optional[int] = None, lookback: int = 50) -> Dict[str, Any]:
    """Before a report runs: the expected rows of its LAST recorded run with the SAME values BY
    THE SAME PERSON (``report_run_diagnostics.facts.expected_rows``; another person's run may have
    read under another row-security scope, so it says nothing about this one), and whether that
    routes this run to the background.  No such run = not known = runs as today (never routed)."""
    out: Dict[str, Any] = {"expected_rows": None, "expected_rows_words": NOT_KNOWN, "basis": None,
                           "background": False, "words": None, "threshold": threshold() if thr is None else int(thr or 0)}
    if db is None or not report_id:
        return out
    try:
        from core.db.models import ReportRunDiagnostic
        with db.get_session(read_only=True) as session:
            q = (session.query(ReportRunDiagnostic.facts, ReportRunDiagnostic.executed_by)
                 .filter(ReportRunDiagnostic.report_id == int(report_id)))
            rows = q.order_by(ReportRunDiagnostic.recorded_at.desc()).limit(int(lookback)).all()
        want = str(username or "").strip().lower()
        for facts, by in rows:
            if not isinstance(facts, dict):
                continue
            if str(by or "").strip().lower() != want:
                continue
            er = facts.get(STORE_KEY)
            if not isinstance(er, dict) or er.get("total") is None:
                continue
            if not _same_values(facts.get("parameter_values"), param_values):
                continue
            total = int(er["total"])
            out.update({"expected_rows": total, "expected_rows_words": expected_rows_words(total),
                        "basis": BASIS_LAST_RUN})
            if routes_to_background(total, out["threshold"]):
                out["background"] = True
                out["words"] = background_words(total, out["threshold"], "report")
            break
    except Exception as exc:  # noqa: BLE001
        logger.info("[background] report %s pre-flight not possible: %s", report_id, exc)
    return out


# ── the SQL editor's pre-flight (the Iceberg manifest cache) ────────────────

def _partition_columns_of(db, connection_id: Any, tbl: Dict[str, Any]) -> List[str]:
    """The table's partition columns as the SQL road finds them: its own declaration, else the
    one resolver (``core/iceberg_partition_resolver``, no S3 client: the admin / DB / cache
    tiers), else the recorded schema.  Empty = unknown."""
    cols = [str(c) for c in (tbl.get("partition_columns") or []) if c]
    if cols:
        return cols
    try:
        from core.iceberg_partition_resolver import resolve_with_diagnostics
        res = resolve_with_diagnostics(registered_table=tbl, db_manager=db, connection_id=connection_id,
                                       table_name=tbl.get("name"), s3_client=None, bucket=None,
                                       table_prefix=tbl.get("s3_prefix"))
        cols = [str(c) for c in (getattr(res, "cols", None) or []) if c]
    except Exception:  # noqa: BLE001
        cols = []
    if cols:
        return cols
    try:
        sc = db.get_schema_cache(int(connection_id), tbl.get("name")) or {}
        data = sc.get("schema_data", sc) if isinstance(sc, dict) else {}
        return [str(c) for c in ((data or {}).get("partition_columns") or []) if c]
    except Exception:  # noqa: BLE001
        return []


def _sql_plan_keys(db, connection_id: Any, conn_cfg: Dict[str, Any], raw_sql: str):
    """For each registered Iceberg table the statement names: (name, the read-plan cache key under
    the statement's own partition filters or None, the unfiltered key, those filters) -- derived
    EXACTLY as the run derives them.  None when a named table is not a registered Iceberg table (not known)."""
    from core.duckdb_views import _compute_table_filters
    from core.iceberg_cache import ice_cache_key
    from core.sql_partition_extractor import extract_combined_filters_and_or_groups_for_iceberg
    from core.sql_table_extractor import extract_table_names
    registered = [t for t in (conn_cfg or {}).get("registered_tables") or [] if isinstance(t, dict)]
    reg = {str(t.get("name") or "").lower(): t for t in registered
           if str(t.get("format") or "").lower() == "iceberg"}
    named = [str(n) for n in (extract_table_names(raw_sql or "") or [])]
    names = [n for n in named if n.lower() in reg]
    if not names or len(names) != len(named):
        return None
    pc_map = {reg[str(n).lower()]["name"]: _partition_columns_of(db, connection_id, reg[str(n).lower()]) for n in names}
    pc_map = {k: v for k, v in pc_map.items() if v}
    combined, or_groups = (extract_combined_filters_and_or_groups_for_iceberg(raw_sql, pc_map, dialect="duckdb")
                           if pc_map else (None, None))
    all_names = [str(t.get("name")) for t in registered if t.get("name")]
    out = []
    for name in names:
        tname = reg[str(name).lower()]["name"]
        pf = _compute_table_filters(combined, tname, True, all_table_names=all_names, raw_sql=raw_sql) if combined else None
        fkey = ice_cache_key(connection_id, tname, pf or None, or_groups=or_groups or None) if pf else None
        out.append((tname, fkey, ice_cache_key(connection_id, tname, None), list(pf or [])))
    return out


def _entry_count(entry: Dict[str, Any]) -> Optional[int]:
    counts = entry.get("file_record_counts")
    rc = entry.get("record_count")
    return expected_from_counts(counts) if counts else (int(rc) if rc is not None else None)


#: the counts the multi-worker raw-SQL road read, per read-plan key (that road fills no
#: ``core/iceberg_cache`` entry).  Per process, bounded, and trusted for exactly the life the
#: read-plan cache gives the entries the pre-flight reads beside it -- older = not known.
_PLAN_MEMO: "Dict[Any, Tuple[float, int]]" = {}
_PLAN_MEMO_MAX = 512
_PLAN_MEMO_LOCK = __import__("threading").Lock()


def _memo_ttl_s() -> float:
    from core.iceberg_cache import ICE_FILE_CACHE_TTL
    return float(ICE_FILE_CACHE_TTL)


def _memo_key(key: Any) -> Any:
    """The read-plan key with the connection id as text (a route passes an int, the engine may not)."""
    return (str(key[0]),) + tuple(key[1:])


def _memo_count(key: Any) -> Optional[int]:
    import time as _t
    with _PLAN_MEMO_LOCK:
        hit = _PLAN_MEMO.get(_memo_key(key))
    if not hit or (_t.monotonic() - hit[0]) > _memo_ttl_s():
        return None
    return hit[1]


#: a statement that reads a PINNED version (time travel; the run's rewrite leaves this marker or
#: the clause itself): its count is another snapshot's, and the read-plan key has no snapshot
_PINNED_RE = __import__("re").compile(
    r"qs-version|\bFOR\s+(?:VERSION|TIMESTAMP|SYSTEM_TIME|SYSTEM_VERSION)\s+AS\s+OF\b", __import__("re").I)


def remember_sql_plan(db, connection_id: Any, conn_cfg: Dict[str, Any], raw_sql: str, table: str,
                      record_counts: Optional[Iterable[Any]], *,
                      road_filters: Optional[Sequence[Any]] = None, narrowed_beyond_sql: bool = False) -> Optional[int]:
    """A road that reads its own file list (the multi-worker raw-SQL road) leaves its count where
    the editor's pre-flight (:func:`expected_rows_for_sql`) looks, under the key the pre-flight
    derives from the same statement.  Never raises.  NOT remembered (2026-11-09 review) -- the
    pre-flight then says "not known", never a number that is not an upper bound for the key:
      * an unknown count;
      * a pinned / time-travel read (``_PINNED_RE``): another snapshot's count under the latest key;
      * files narrowed by MORE than the key's partition filters: a join-derived filter
        (``narrowed_beyond_sql``) or a road filter whose column the key does not carry (column-stat
        pruning on a non-partition column, a row-security predicate the key cannot see) -- the
        count would be smaller than what the same statement reads for someone else."""
    import time as _t
    try:
        n = expected_from_counts(record_counts)
        if n is None or narrowed_beyond_sql or _PINNED_RE.search(raw_sql or ""):
            return None
        keys = _sql_plan_keys(db, connection_id, conn_cfg, raw_sql) or []
        for tname, fkey, ukey, pf in keys:
            if str(tname).lower() != str(table or "").lower():
                continue
            key_cols = {str(f.get("col") or "").lower() for f in pf if isinstance(f, dict)}
            road_cols = {str(f.get("col") or "").lower() for f in (road_filters or []) if isinstance(f, dict)}
            if any(not isinstance(f, dict) for f in (road_filters or [])) or not road_cols <= key_cols:
                return None
            key = _memo_key(fkey or ukey)
            with _PLAN_MEMO_LOCK:
                if len(_PLAN_MEMO) >= _PLAN_MEMO_MAX and key not in _PLAN_MEMO:
                    _PLAN_MEMO.pop(next(iter(_PLAN_MEMO)))
                _PLAN_MEMO[key] = (_t.monotonic(), n)
            return n
    except Exception as exc:  # noqa: BLE001
        logger.info("[background] plan count of %s not remembered: %s", table, exc)
    return None


def expected_rows_for_sql(db, connection_id: Any, conn_cfg: Dict[str, Any], raw_sql: str) -> Dict[str, Any]:
    """Before a SQL run on an S3 connection: Σ record_count of the files the cached read plan
    kept for the registered Iceberg tables the statement names, under the statement's own
    partition filters derived EXACTLY as the run derives them (the same extractor, the same
    per-table attribution, the same cache key -- ``core/iceberg_cache``); the unfiltered entry
    when no filtered one is cached (the whole table, still an upper bound, ``pruned: false``).
    A statement that also names a table the plan cannot count (plain parquet, an unregistered
    name) is not known; any table without an entry = not known."""
    out: Dict[str, Any] = {"expected_rows": None, "expected_rows_words": NOT_KNOWN, "expected_rows_pruned": None}
    try:
        from core.iceberg_cache import ice_cache_get
        keys = _sql_plan_keys(db, connection_id, conn_cfg, raw_sql)
        if not keys:
            return out                                   # a table without a count -> not known
        total, pruned_all = 0, True
        for tname, fkey, ukey, _pf in keys:
            entry = ice_cache_get(fkey) if fkey else None
            n = _entry_count(entry) if entry else None
            if n is None and fkey:
                # 2026-11-09 -- the multi-worker raw-SQL road fills no read-plan cache; it leaves
                # its count under the SAME key (remember_sql_plan)
                n = _memo_count(fkey)
            pruned = n is not None
            if n is None:
                entry = ice_cache_get(ukey)
                n = _entry_count(entry) if entry else None
            if n is None:
                n = _memo_count(ukey)
            if n is None:
                return out
            total += n
            pruned_all = pruned_all and pruned
        out.update({"expected_rows": total, "expected_rows_words": expected_rows_words(total),
                    "expected_rows_pruned": pruned_all})
    except Exception as exc:  # noqa: BLE001
        logger.info("[background] SQL pre-flight not possible: %s", exc)
    return out


# ── the e-mail wish and the ready result ────────────────────────────────────

def requester_email(user: Any) -> Optional[str]:
    """The person's OWN address, derived as every notice address in this app is
    (``core/published_view_schema._address_for`` + ``published_views.notify_email_domain``): a
    username that is already an address, else username@domain; None when no domain is set."""
    try:
        from core import config as _c
        from core.published_view_schema import _address_for
        username = user.get("username") if isinstance(user, dict) else user
        return _address_for(str(username or ""), _c.published_views.notify_email_domain)
    except Exception:  # noqa: BLE001
        return None


def email_wish_check(db, execution_id: str) -> Tuple[bool, str]:
    """Whether an e-mail wish on this run can ever be honoured: the run must be in the background
    and not finished.  Returns (ok, words) -- the words say what would happen instead."""
    rows = _rows_for(db, execution_id)
    pending = [r for r in rows if r.get("event_type") == EVENT_PENDING]
    if not pending:
        return False, ("This run is not in the background: it runs on screen, and its result will be shown "
                       "there when it is ready. No e-mail will be sent.")
    if all(r.get("status") != "pending" for r in pending):
        if any(r.get("event_type") == EVENT_READY for r in rows):
            return False, "This run has already finished: its result is in the Download Centre. No e-mail will be sent."
        return False, "This run has already ended without a result. No e-mail will be sent."
    return True, ""


def request_email(db, execution_id: str, *, user: Any, address: Optional[str] = None) -> Dict[str, Any]:
    """The person asked for an e-mail when this run's result is ready.  The address is ALWAYS
    the person's own (``requester_email``); an address given in the request must be that one.
    One wish per (run, person): a second request returns the first (``already: true``)."""
    username = str((user.get("username") if isinstance(user, dict) else user) or "").strip()
    own = requester_email(user)
    if not own:
        raise ValueError("Your account has no e-mail address on file: notices go to <your user name>@<the "
                         "company domain>, and no domain is configured (published_views.notify_email_domain). "
                         "Ask an admin to set it.")
    given = str(address or "").strip()
    if given and given.lower() != own.lower():
        raise ValueError(f"Notices go only to your own address on file, {own}.")
    for row in _rows_for(db, execution_id):
        if (row.get("event_type") == EVENT_EMAIL and str(row.get("recipient") or "").lower() == username.lower()
                and row.get("status") == "pending"):
            return {**row, "already": True}
    row = db.log_notification(event_type=EVENT_EMAIL, channel="email", recipient=username, status="pending",
                              title="E-mail when the result is ready", message=own,
                              payload={"address": own}, execution_id=execution_id)
    return {**row, "already": False}


def _rows_for(db, execution_id: str) -> List[Dict[str, Any]]:
    fn = getattr(db, "notifications_for_execution", None)
    return list(fn(execution_id) or []) if callable(fn) else []


def _settle_wishes(db, notices: List[Dict[str, Any]], *, send: Optional[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    """Every pending e-mail wish of the run: sent (``send`` = title, message, link) through the
    one mail road, or cancelled with the reason when ``send`` is None.  Never raises."""
    out: List[Dict[str, Any]] = []
    upd = getattr(db, "update_notification_status", None)
    for req in [n for n in notices if n.get("event_type") == EVENT_EMAIL and n.get("status") == "pending"]:
        addr = str((req.get("payload") or {}).get("address") or req.get("message") or "").strip()
        ok, err, status = False, None, "cancelled"
        if send is not None:
            title, msg, link = send
            try:
                from core.email_service import send_email
                html = f"<p>{title}.</p><p>{msg}</p><p>Open it here: {link}</p>"
                ok = bool(send_email([addr], title, html, text_body=f"{title}. {msg} Open it here: {link}"))
                err = None if ok else "the mail server did not accept the message"
            except Exception as exc:  # noqa: BLE001
                err = str(exc)[:500]
            status = "sent" if ok else "failed"
        else:
            err = "the run did not finish, so no result could be sent"
        if callable(upd):
            try:
                upd(int(req["id"]), status, err)
            except Exception:  # noqa: BLE001
                pass
        out.append({"address": addr, "sent": ok, "status": status, "error": err})
    return out


def on_result_ready(db, ws, execution_id: str, *, username: str, link: str, title: str, words: str,
                    output_file: Optional[str] = None, rows: Optional[int] = None,
                    source_kind: str = SOURCE_KIND_QUERY, filename: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """For a run that went to the background: the Download Centre row, the ready notice (the
    bell + the WebSocket), the e-mail if asked.  None for a run that was not routed."""
    notices = _rows_for(db, execution_id)
    pending = [n for n in notices if n.get("event_type") == EVENT_PENDING and n.get("status") == "pending"]
    if not pending:
        return None
    result: Dict[str, Any] = {"execution_id": execution_id, "download": None, "notice": None, "emails": []}
    # 1. the Download Centre row (the result file; previewed by its file id or execution id)
    try:
        if output_file and os.path.exists(str(output_file)):
            file_id = str(uuid.uuid4())
            db.create_download_file(file_id=file_id, execution_id=execution_id,
                                    filename=filename or f"result_{execution_id[:8]}.parquet",
                                    file_path=str(output_file), file_size_bytes=int(os.path.getsize(str(output_file))),
                                    created_by=username, source_kind=source_kind)
            result["download"] = file_id
    except Exception as exc:  # noqa: BLE001
        logger.warning("[background] Download Centre row for %s not written: %s", execution_id, exc)
    # 2. the ready notice -- the pending one becomes read history, the new one rings the bell
    msg = words if rows is None else f"{words} {int(rows):,} rows."
    notice = db.log_notification(event_type=EVENT_READY, channel="websocket", recipient=username, status="sent",
                                 title=title, message=msg,
                                 payload={"link": link, "execution_id": execution_id,
                                          "download_file_id": result["download"]},
                                 execution_id=execution_id)
    result["notice"] = notice.get("id") if isinstance(notice, dict) else None
    _close_pending(db, pending)
    _tell(ws, username, {"type": EVENT_READY, "event_type": EVENT_READY, "username": username, "title": title,
                         "message": msg, "link": link, "execution_id": execution_id,
                         "download_file_id": result["download"],
                         "timestamp": datetime.now(timezone.utc).isoformat()})
    # 3. the e-mail the person asked for
    result["emails"] = _settle_wishes(db, notices, send=(title, msg, link))
    return result


def on_result_ended(db, ws, execution_id: str, *, status: str, reason: Optional[str] = None,
                    what: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """A run that went to the background did NOT produce a result: failed -> a "did not finish"
    notice with the reason (the pending one becomes history); cancelled -> the pending notice is
    withdrawn.  Either way the e-mail wish is cancelled, nothing is mailed.  None for a run that
    was not routed (or was already closed)."""
    notices = _rows_for(db, execution_id)
    pending = [n for n in notices if n.get("event_type") == EVENT_PENDING and n.get("status") == "pending"]
    if not pending:
        return None
    if run_will_retry(db, execution_id):
        # final review D: a sweep failed the dead pod's run, but the job queue will retry it -- the
        # run is NOT over; its notice and wish stay pending and follow the continuation (move_pending)
        logger.info("[background] %s is %s but its job will be retried: notice kept", execution_id, status)
        return {"execution_id": execution_id, "status": str(status or "").lower(), "deferred": True}
    username = str(pending[-1].get("recipient") or "")
    kind = what or str((pending[-1].get("payload") or {}).get("what") or "run")
    st = str(status or "").lower()
    result: Dict[str, Any] = {"execution_id": execution_id, "status": st, "notice": None, "emails": []}
    _close_pending(db, pending)
    if st == "failed":
        why = str(reason or "").strip() or "the run stopped with an error"
        msg = f"Your {kind} that ran in the background did not finish: {why}"
        notice = db.log_notification(event_type=EVENT_FAILED, channel="websocket", recipient=username, status="sent",
                                     title=f"Your {kind} did not finish", message=msg,
                                     payload={"execution_id": execution_id, "reason": why},
                                     execution_id=execution_id)
        result["notice"] = notice.get("id") if isinstance(notice, dict) else None
        _tell(ws, username, {"type": EVENT_FAILED, "event_type": EVENT_FAILED, "username": username,
                             "title": f"Your {kind} did not finish", "message": msg, "execution_id": execution_id,
                             "timestamp": datetime.now(timezone.utc).isoformat()})
    result["emails"] = _settle_wishes(db, notices, send=None)
    return result


def status_fields(files_metadata: Any) -> Dict[str, Any]:
    """What ``/api/executions/{id}/status`` adds: the expected rows (an upper bound, words) and
    whether the run went to the background.  Re-gated on what the run READ: a table in the file
    stats the plan did not count (plain parquet, Hive), or a cross-source run (its second
    connection is never counted), is not known."""
    fm = files_metadata
    if isinstance(fm, str):
        try:
            fm = json.loads(fm)
        except Exception:  # noqa: BLE001
            fm = {}
    fm = fm if isinstance(fm, dict) else {}
    er = fm.get(STORE_KEY) if isinstance(fm.get(STORE_KEY), dict) else None
    read = [k for k, v in fm.items() if k not in _RESERVED_FM_KEYS and isinstance(v, dict)
            and ("after_pruning" in v or "format" in v)]
    gated = gate_entry(er, read) if er else None
    total = gated.get("total") if gated else None
    if fm.get("cross_source"):
        total = None
    bg = fm.get("background") if isinstance(fm.get("background"), dict) else None
    return {"expected_rows": total, "expected_rows_words": expected_rows_words(total),
            "expected_rows_basis": (er or {}).get("basis") if total is not None else None,
            "expected_rows_upper_bound": True,
            "background": bool(bg), "background_words": (bg or {}).get("words")}
