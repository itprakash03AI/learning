"""
Dynamic date expression resolver for query filters.

Supports template expressions embedded in filter values so that saved queries
and scheduled jobs always operate on a *relative* date window without manual
editing.

Syntax  (case-insensitive, inside ${...}):
  ${today}           → today's date             2024-01-15
  ${yesterday}       → today - 1 day            2024-01-14
  ${tomorrow}        → today + 1 day            2024-01-16
  ${weekStart}       → Monday of current week   2024-01-13
  ${monthStart}      → 1st of current month     2024-01-01
  ${monthEnd}        → last day of current month 2024-01-31
  ${yearStart}       → Jan 1 of current year    2024-01-01
  ${yearEnd}         → Dec 31 of current year   2024-12-31
  ${today-7d}        → 7 days ago               2024-01-08
  ${today+30d}       → 30 days from now         2024-02-14
  ${today-1m}        → 1 calendar month ago     2023-12-15
  ${today+1m}        → 1 calendar month from now 2024-02-15
  ${today-1y}        → 1 year ago               2023-01-15
  ${now}             → current UTC datetime     2024-01-15T10:30:00
  ${now-2h}          → 2 hours ago              2024-01-15T08:30:00

All date results are ISO-8601 strings (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS).
Expressions that cannot be parsed are returned unchanged.

Usage:
    from core.date_resolver import resolve_filter_dates

    filters_json = '[{"col":"business_date","op":"equals","val":"${today}"}]'
    resolved = resolve_filter_dates(filters_json)
    # → '[{"col":"business_date","op":"equals","val":"2024-01-15"}]'

    # Or resolve a plain string value:
    from core.date_resolver import resolve_value
    resolve_value("${today-7d}")   # → "2024-01-08"
"""
from __future__ import annotations

import json
import re
import logging
from calendar import monthrange
from datetime import date, datetime, timedelta, timezone
from typing import Any

logger = logging.getLogger(__name__)

# 2026-09-28 -- business-calendar tokens (${prev_business_day:LDN},
# @BUSINESS_MONTH_END, bare business_day_n:3) resolve through THE shared
# resolver, in all three spellings this module accepts.  A token that cannot
# be rendered raises CalendarTokenRefused (re-exported here so an API site
# can name it beside the resolver it calls) -- never a silent literal.
from core.business_calendar_tokens import (  # noqa: F401 -- re-exported
    CalendarTokenRefused, resolve_if_calendar_token,
)

# Regex that matches ${...} expressions anywhere in a string
_EXPR_RE = re.compile(r"\$\{([^}]+)\}", re.IGNORECASE)

# Relative-offset pattern: today+7d  today-1m  now-2h
_OFFSET_RE = re.compile(
    r"^(today|now)([+-])(\d+)([dDhHmMwWyY])$", re.IGNORECASE
)


def _clock_now() -> datetime:
    """The wall clock, server-local -- the one thing a test freezes."""
    return datetime.now()


def business_today() -> date:
    """THE "today" every date vocabulary resolves against (2026-11-09).

    Review of e59a13033: this module said today in UTC while a report's
    ``@TODAY`` (``api.business_reports_api``) and a saved query's bare
    ``today`` (``core.parameters``) said it server-local -- two answers near
    midnight.  ONE answer now, the report's: the server-local calendar date
    (no business timezone is configured in core/config; when one is, it
    goes HERE and nowhere else).  ``_today()`` below is this.
    """
    return _clock_now().date()


def _today() -> date:
    return business_today()


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


def _resolve_expr(expr: str) -> str:
    """Resolve a single expression (without the surrounding ${}) to a string."""
    key = expr.strip().lower()

    # ── Business-calendar tokens (checked FIRST: the calendar part keeps
    #    its case, and a malformed one must refuse, not fall through) ──────
    calendar_iso = resolve_if_calendar_token(expr, today=_today())
    if calendar_iso is not None:
        return calendar_iso

    # ── Absolute keywords ─────────────────────────────────────────────────────
    if key == "today":
        return str(_today())
    if key == "yesterday":
        return str(_today() - timedelta(days=1))
    if key == "tomorrow":
        return str(_today() + timedelta(days=1))
    if key == "now":
        return _now().isoformat()

    t = _today()
    if key == "weekstart":
        return str(t - timedelta(days=t.weekday()))
    if key == "monthstart":
        return str(t.replace(day=1))
    if key == "monthend":
        last_day = monthrange(t.year, t.month)[1]
        return str(t.replace(day=last_day))
    if key == "yearstart":
        return str(t.replace(month=1, day=1))
    if key == "yearend":
        return str(t.replace(month=12, day=31))

    # ── Relative offsets: today±Nd, today±Nm, today±Ny, now±Nh ───────────────
    m = _OFFSET_RE.match(expr.strip())
    if m:
        base_key, op, num_str, unit = m.group(1).lower(), m.group(2), m.group(3), m.group(4).lower()
        num = int(num_str)
        sign = 1 if op == "+" else -1

        if base_key == "now":
            base_dt = _now()
            if unit == "h":
                result_dt = base_dt + timedelta(hours=sign * num)
            elif unit == "m":
                result_dt = base_dt + timedelta(minutes=sign * num)
            elif unit == "d":
                result_dt = base_dt + timedelta(days=sign * num)
            else:
                return f"${{{expr}}}"      # unsupported unit for datetime
            return result_dt.isoformat()

        # base_key == "today"
        base_d = _today()
        if unit == "d":
            return str(base_d + timedelta(days=sign * num))
        if unit == "w":
            return str(base_d + timedelta(weeks=sign * num))
        if unit == "m":
            # Calendar-month arithmetic (clamped to last valid day)
            month = base_d.month + sign * num
            year  = base_d.year + (month - 1) // 12
            month = (month - 1) % 12 + 1
            last_day = monthrange(year, month)[1]
            return str(base_d.replace(year=year, month=month, day=min(base_d.day, last_day)))
        if unit == "y":
            try:
                return str(base_d.replace(year=base_d.year + sign * num))
            except ValueError:
                # Feb 29 → Feb 28 on non-leap years
                return str(base_d.replace(year=base_d.year + sign * num, day=28))

    # Unknown expression — return unchanged so it surfaces in logs/errors
    return f"${{{expr}}}"


def resolve_value(value: Any) -> Any:
    """Replace all ${...} tokens in *value* (string only; other types pass through)."""
    if not isinstance(value, str) or "${" not in value:
        return value
    def _replacer(m: re.Match) -> str:
        try:
            return _resolve_expr(m.group(1))
        except CalendarTokenRefused:
            # A calendar token that cannot be rendered REFUSES the whole
            # value (2026-09-28).  Keeping the original here would hand the
            # literal text '${prev_business_day:NOPE}' to a filter, which
            # matches nothing and returns zero rows as success.
            raise
        except Exception as exc:
            logger.warning("[date_resolver] Failed to resolve '%s': %s", m.group(0), exc)
            return m.group(0)   # keep original on error
    return _EXPR_RE.sub(_replacer, value)


def resolve_filter_list(filters: list) -> list:
    """Walk a filter list (adv_filters conditions or legacy filter dicts) and
    resolve date expressions in 'val'/'value' fields in-place (returns a copy)."""
    if not filters:
        return filters
    resolved = []
    for f in filters:
        if not isinstance(f, dict):
            resolved.append(f)
            continue
        fc = dict(f)
        # adv_filters format: {"col": ..., "op": ..., "val": "..."}
        if "val" in fc:
            fc["val"] = resolve_value(fc["val"])
        # legacy format: {"column": ..., "operator": ..., "value": "..."}
        if "value" in fc:
            fc["value"] = resolve_value(fc["value"])
        resolved.append(fc)
    return resolved


def resolve_adv_filters(adv_filters_json: str | None) -> str | None:
    """Parse adv_filters JSON, resolve date expressions, re-serialise."""
    if not adv_filters_json or "${" not in adv_filters_json:
        return adv_filters_json
    try:
        af = json.loads(adv_filters_json)
        if isinstance(af, dict) and "conditions" in af:
            af["conditions"] = resolve_filter_list(af["conditions"])
        return json.dumps(af)
    except CalendarTokenRefused:
        raise            # a filter that cannot be rendered refuses (2026-09-28)
    except Exception as exc:
        logger.warning("[date_resolver] adv_filters parse error: %s", exc)
        return adv_filters_json


def resolve_filter_dates(obj: Any) -> Any:
    """Recursively resolve date expressions in a query_config-style dict/list.

    Handles:
      - list of legacy filter dicts  (query_config["filters"])
      - adv_filters JSON string
      - any nested dict/list
    """
    if isinstance(obj, str):
        return resolve_value(obj)
    if isinstance(obj, list):
        return [resolve_filter_dates(item) for item in obj]
    if isinstance(obj, dict):
        return {k: resolve_filter_dates(v) for k, v in obj.items()}
    # 2026-09-28 -- a Pydantic model (the request's FilterModel) was returned
    # UNTOUCHED, so four call sites that pass ``query_config.filters`` resolved
    # nothing: ``${today}`` reached the WHERE clause as a literal and a saved
    # query returned zero rows as a success.  Resolve its fields and rebuild it
    # through validation (nested models stay models).
    if hasattr(obj, "model_dump") and hasattr(type(obj), "model_validate"):
        return type(obj).model_validate(resolve_filter_dates(obj.model_dump()))
    return obj


# ── Phase 134-P — unified date-token resolver for PV/Feed/Recon wrap ─
#
# Three token syntaxes have been in use across the platform for the
# same intent ("resolve a date relative to today, at run time"):
#
#   1. ``${today}`` / ``${today-7d}`` / ``${monthStart}``  — date_resolver
#                                                             (this module)
#   2. ``@TODAY`` / ``@MONTH_END`` / ``@YESTERDAY``         — BR @-syntax
#                                                             (business_reports_api)
#   3. bare ``today`` / ``yesterday`` / ``-7d`` / ``+1d``   — feed/parameters
#                                                             (core.parameters)
#
# Publishers picked their syntax based on where they came from (BR vs
# saved query vs feed); the resulting Dynamic default value carries
# the original syntax into ``_where_clauses_mapping``.  Phase 134-M
# wrapped these defaults INTO raw_sql as literal SQL strings — so an
# un-resolved ``'@TODAY'`` predicate caused either a SQL error or
# silently-wrong rows.
#
# This helper normalises all three forms before the wrap.  Each
# string value is tried against each resolver in turn; the first one
# that produces a different output wins.  Non-string values
# (numbers, lists, dicts) pass through their elements recursively.

_BARE_DATE_TOKENS = frozenset({
    "today", "yesterday", "tomorrow",
    "week_start", "week_end",
    "last_week_start", "last_week_end",
    "month_start", "month_end",
    "last_month_start", "last_month_end",
    "year_start", "year_end",
    "last_year_start", "last_year_end",
})

_RELATIVE_BARE_RE = re.compile(r"^\s*([+-])(\d+)d\s*$", re.IGNORECASE)


def month_end_of(today: date) -> str:
    next_month_first = (today.replace(day=1) + timedelta(days=32)).replace(day=1)
    return (next_month_first - timedelta(days=1)).isoformat()


def quarter_start_of(today: date) -> str:
    q_month = ((today.month - 1) // 3) * 3 + 1
    return today.replace(month=q_month, day=1).isoformat()


def quarter_end_of(today: date) -> str:
    q_month = ((today.month - 1) // 3) * 3 + 3
    next_q = (today.replace(month=q_month, day=1) + timedelta(days=32)).replace(day=1)
    return (next_q - timedelta(days=1)).isoformat()


#: THE ``@``-token vocabulary, each as a function of the day it is resolved
#: on (2026-11-09).  It was two copies: ``api.business_reports_api.
#: _RELATIVE_DATE_MAP`` (what a report accepts) and a hand-written chain here
#: (what a filter / the published API's door accepted) -- and the chain
#: lacked @THIS_MONTH_END, @LAST_WEEK_START, @LAST_WEEK_END, @THIS_WEEK_START,
#: so the API refused tokens the report took.  The report's map is now built
#: FROM this one; a token added here reaches both.
RELATIVE_DATE_MAP: dict = {
    "@TODAY":           lambda t: t.isoformat(),
    "@YESTERDAY":       lambda t: (t - timedelta(days=1)).isoformat(),
    "@TOMORROW":        lambda t: (t + timedelta(days=1)).isoformat(),
    "@MONTH_START":     lambda t: t.replace(day=1).isoformat(),
    "@MONTH_END":       month_end_of,
    "@YEAR_START":      lambda t: t.replace(month=1, day=1).isoformat(),
    "@YEAR_END":        lambda t: t.replace(month=12, day=31).isoformat(),
    "@LAST_7_DAYS":     lambda t: (t - timedelta(days=7)).isoformat(),
    "@LAST_30_DAYS":    lambda t: (t - timedelta(days=30)).isoformat(),
    "@LAST_90_DAYS":    lambda t: (t - timedelta(days=90)).isoformat(),
    # Phase 83F -- additional macros
    "@QUARTER_START":   quarter_start_of,
    "@QUARTER_END":     quarter_end_of,
    "@LAST_WEEK_START": lambda t: (t - timedelta(days=t.weekday() + 7)).isoformat(),
    "@LAST_WEEK_END":   lambda t: (t - timedelta(days=t.weekday() + 1)).isoformat(),
    "@THIS_WEEK_START": lambda t: (t - timedelta(days=t.weekday())).isoformat(),
    "@THIS_MONTH_END":  month_end_of,  # alias
}


def _resolve_at_prefixed(val: str) -> str:
    """``@TODAY`` / ``@MONTH_END`` etc. -- uppercase + @-prefixed, through
    ``RELATIVE_DATE_MAP`` (the report's vocabulary, one copy) on
    ``business_today()``; then the business-calendar tokens."""
    if not isinstance(val, str) or not val.startswith("@"):
        return val
    today = _today()
    fn = RELATIVE_DATE_MAP.get(val.upper())
    if fn is not None:
        return fn(today)
    # @PREV_BUSINESS_DAY[:CAL] and friends -- the shared calendar resolver;
    # refuses when the token cannot be rendered.
    calendar_iso = resolve_if_calendar_token(val, today=today)
    if calendar_iso is not None:
        return calendar_iso
    # Unknown @-token — leave unchanged so an admin sees it surface
    # in logs rather than silently mapping to today.
    return val


def _resolve_bare_token(val: str) -> str:
    """Bare lowercase shortcut tokens — ``today``, ``yesterday``,
    ``month_end``, ``-7d``, ``+1d``, etc.  Mirrors the syntax
    ``core.parameters.resolve_business_dates`` accepts.

    Only triggers when the whole value matches a known shortcut — a
    free-form string like ``'today is friday'`` passes through
    unchanged to avoid corrupting real text content.
    """
    if not isinstance(val, str):
        return val
    norm = val.strip().lower()
    if norm in _BARE_DATE_TOKENS:
        # Delegate to date_resolver's existing shortcut implementation
        # by wrapping in ``${...}`` syntax + calling resolve_value.
        # date_resolver's tokens use camelCase (monthStart) while bare
        # tokens use snake_case (month_start) — translate.
        translated = {
            "today":              "today",
            "yesterday":          "yesterday",
            "tomorrow":           "tomorrow",
            "week_start":         "weekStart",
            "week_end":           "weekEnd",
            "month_start":        "monthStart",
            "month_end":          "monthEnd",
            "year_start":         "yearStart",
            "year_end":           "yearEnd",
            "last_week_start":    "lastWeekStart",
            "last_week_end":      "lastWeekEnd",
            "last_month_start":   "lastMonthStart",
            "last_month_end":     "lastMonthEnd",
            "last_year_start":    "lastYearStart",
            "last_year_end":      "lastYearEnd",
        }.get(norm, norm)
        return resolve_value(f"${{{translated}}}")
    # Relative bare offset: -7d, +14d
    m = _RELATIVE_BARE_RE.match(val)
    if m:
        sign = 1 if m.group(1) == "+" else -1
        days = int(m.group(2))
        return (_today() + timedelta(days=sign * days)).isoformat()
    # Bare business-calendar token (prev_business_day:LDN, business_day_n:3)
    # -- the shared resolver; refuses when it cannot be rendered.
    calendar_iso = resolve_if_calendar_token(val, today=_today())
    if calendar_iso is not None:
        return calendar_iso
    return val


#: The spellings a date VALUE takes besides YYYY-MM-DD, in the words a refusal
#: and the published API's OpenAPI document use (api/published_views/helpers.py
#: ``_date_param_value``, core/published_api/openapi_doc.py).
DATE_PARAM_FORMS = ("YYYY-MM-DD", "@TODAY / @YESTERDAY / @MONTH_END", "today / yesterday / month_end",
                    "-1d / +7d", "prev_business_day[:CALENDAR] / prev_business_month_end[:CALENDAR]",
                    "${today} / ${monthStart}")


def resolve_date_token(value: Any) -> Any:
    """ONE value through the whole date vocabulary -- the three-stage chain
    ``resolve_filter_tokens`` walks a filter list with, for a single value.

    2026-11-09 (the owner: "Published api csv doesnt accept dynamic
    paramters"): a published API's ``date`` parameter was checked with
    ``date.fromisoformat`` alone, so the dynamic values every report and
    saved query accept (``@TODAY``, ``@PREV_BUSINESS_DAY:LDN``, ``today``,
    ``-1d``, ``${monthEnd}``) were a 400 "invalid value for type 'date'" on
    every format.  The API's parameter reader now calls THIS, so the API and
    the report it is built on read one vocabulary.

    A string that is no token comes back unchanged (the caller decides what
    an unresolved value means); a calendar token that cannot be rendered
    REFUSES (``CalendarTokenRefused``), never falls back.  Lists and dicts
    are walked; other types pass through.

    Resolver chain -- first one to change the value wins:
      1. date_resolver's ``${...}`` substitution
      2. BR ``@``-prefixed token (uppercase)
      3. bare lowercase shortcut OR ``-7d`` / ``+14d`` offset
    """
    if isinstance(value, str):
        # Stage 1 -- ${...} tokens (early-out if no $ in string).
        r1 = resolve_value(value) if "${" in value else value
        if r1 != value:
            return r1
        # Stage 2 -- @-prefixed (uppercase, early-out if no @).
        if value.startswith("@"):
            r2 = _resolve_at_prefixed(value)
            if r2 != value:
                return r2
        # Stage 3 -- bare token or relative offset.
        return _resolve_bare_token(value)
    if isinstance(value, list):
        return [resolve_date_token(x) for x in value]
    if isinstance(value, dict):
        return {k: resolve_date_token(v) for k, v in value.items()}
    return value


def resolve_filter_tokens(filters: Any) -> Any:
    """Resolve every supported date-token form in a filter list.

    Phase 134-P — used by PV / Feed / Recon wrap paths BEFORE the
    raw_sql wrap so date tokens become concrete date strings inside
    the wrapped SQL.  Without this, a publisher Dynamic-row default
    of ``@TODAY`` (or ``${today}`` or bare ``today``) would land as
    a literal ``'@TODAY'`` SQL string and either fail to parse or
    return 0 rows.

    Walks filters AND each filter's value (including list values for
    IN / BETWEEN).  Strings get the full three-resolver chain; non-
    strings pass through their elements recursively.

    Resolver chain — first one to change the value wins:
      1. date_resolver's ``${...}`` substitution
      2. BR ``@``-prefixed token (uppercase)
      3. bare lowercase shortcut OR ``-7d`` / ``+14d`` offset
    """
    _one = resolve_date_token          # one chain, one value at a time

    if not filters:
        return filters
    out = []
    for f in filters:
        if isinstance(f, dict):
            ff = dict(f)
            if "value" in ff:
                ff["value"] = _one(ff["value"])
            if "val" in ff:
                ff["val"] = _one(ff["val"])
            out.append(ff)
        else:
            out.append(f)
    return out
