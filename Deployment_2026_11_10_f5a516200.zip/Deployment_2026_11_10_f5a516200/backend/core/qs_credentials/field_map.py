"""ONE rule for a System Account whose Vault entry uses its OWN field names (2026-11-08).

The owner's real Vault entries do not spell their fields the way QueryStudio's readers do:
a Snowflake account whose kv entry carried "access key" / "secret key" (2026-11-04), a Jira
login that will come from Vault KV.  ``_payload_to_creds`` (kv_secrets) handed the kv dict
through as it came, and every reader took its own fixed keys -- the Jira client only
``username`` / ``password``, Databricks ``token``, Snowflake ``private_key`` / ``password`` --
so a mismatch sent an EMPTY secret to the source.

``vault_field_map`` on the System Account says which Vault field holds each canonical value:
``{"username": "access key", "password": "secret key"}``.  It is applied ONCE, in
``_payload_to_creds``, so every road (Jira, Databricks, Snowflake, Oracle, S3, SFTP,
Starburst ...) receives the canonical keys.  Absent or empty = today's behaviour exactly.
A mapped field the Vault entry does not hold REFUSES in words naming the field (and the
entry's field NAMES, never a value): the account's Test and every login say the same thing.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Optional

__all__ = ["CANONICAL_FIELDS", "FIELD_WORDS", "VaultFieldMapError", "validate_field_map",
           "apply_field_map", "field_names_report"]

#: the names the readers take (core/connectors/__init__.py::apply_system_account and the
#: connectors behind it, core/feed/jira_client.py, the feed destinations)
CANONICAL_FIELDS = ("username", "password", "token", "private_key", "private_key_passphrase",
                    "access_key", "secret_key", "session_token", "tns_alias")

#: plain words for the screen and the refusals
FIELD_WORDS: Dict[str, str] = {
    "username":               "the login name",
    "password":               "the password (a Jira API token or a Databricks token sent as the password is one too)",
    "token":                  "a token (a Databricks personal access token)",
    "private_key":            "the private key (a Snowflake key-pair login)",
    "private_key_passphrase": "the private key's passphrase",
    "access_key":             "the access key (S3, Athena)",
    "secret_key":             "the secret key (S3, Athena)",
    "session_token":          "a session token (S3, Athena)",
    "tns_alias":              "the Oracle TNS alias",
}

#: keys the resolver itself adds to a kv payload -- never Vault fields
_META_KEYS = frozenset({"id", "vault_id", "account_type", "via"})


class VaultFieldMapError(ValueError):
    """The map, or the Vault entry it points at, cannot give a reader its value -- said in words."""


def validate_field_map(raw: Any) -> Dict[str, str]:
    """A map as saved: canonical names only, each naming a non-blank Vault field.  ``None`` /
    ``{}`` -> ``{}`` (no map).  Raises :class:`VaultFieldMapError` in words otherwise."""
    if raw is None:
        return {}
    if not isinstance(raw, Mapping):
        raise VaultFieldMapError("The Vault field names must be given as a list of 'value: field in Vault' pairs.")
    out: Dict[str, str] = {}
    for key, field in raw.items():
        canonical = str(key or "").strip()
        vault_field = str(field or "").strip() if field is not None else ""
        if not canonical:
            continue
        if canonical not in CANONICAL_FIELDS:
            raise VaultFieldMapError(
                f"'{canonical}' is not a value QueryStudio reads from a Vault entry. "
                f"The values are: {', '.join(CANONICAL_FIELDS)}.")
        if not vault_field:
            continue                                   # a blank entry = not mapped
        out[canonical] = vault_field
    return out


def apply_field_map(payload: Mapping[str, Any], field_map: Any, *, account_name: Any = None) -> Dict[str, Any]:
    """The Vault kv entry with the canonical keys the readers take, filled from the fields the
    map names.  No map = the entry as it came.  A mapped field the entry does not hold (or holds
    blank) refuses, naming the missing field and the entry's field NAMES -- never a value."""
    out: Dict[str, Any] = dict(payload)
    mapping = validate_field_map(field_map)
    if not mapping:
        return out
    missing: List[str] = [vf for vf in mapping.values() if not str(payload.get(vf) or "").strip()]
    if missing:
        present = sorted(str(k) for k in payload if k not in _META_KEYS)
        who = f"System Account '{account_name}'" if account_name else "this System Account"
        wants = ", ".join(f"'{vf}' (for {FIELD_WORDS.get(c, c)})" for c, vf in mapping.items() if vf in missing)
        raise VaultFieldMapError(
            f"The Vault entry of {who} has no field named {wants}. "
            f"The entry's fields are: {present or 'none'}. Fix the Vault field names on the account, "
            f"or add the field to the Vault entry.")
    for canonical, vault_field in mapping.items():
        out[canonical] = payload[vault_field]
    return out


def field_names_report(creds: Mapping[str, Any], field_map: Any) -> Dict[str, Any]:
    """What the account Test tells a person: the field NAMES the resolved entry carries and
    which Vault field each canonical value came from.  Names only, never a value."""
    mapping = validate_field_map(field_map)
    found = sorted(str(k) for k in creds if k not in _META_KEYS and str(creds.get(k) or "").strip())
    return {"fields_found": found, "from_vault_fields": dict(mapping)}


def words_for_test(creds: Mapping[str, Any], field_map: Any) -> str:
    rep = field_names_report(creds, field_map)
    text = "Fields found: " + (", ".join(rep["fields_found"]) or "none")
    if rep["from_vault_fields"]:
        text += " (" + ", ".join(f"{c} from '{vf}'" for c, vf in rep["from_vault_fields"].items()) + ")"
    return text + "."
