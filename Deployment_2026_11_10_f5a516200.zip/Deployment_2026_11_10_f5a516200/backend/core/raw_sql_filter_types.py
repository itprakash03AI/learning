"""The TYPE of each column a raw-SQL statement OUTPUTS, so a consumer's filter
value is rendered as a literal of that type (2026-10-05).

WHY
---
A published view whose source is SQL text (a SQL-page saved query, a ``.sql``
file, a raw-SQL report, a raw-SQL federation side) applies the consumer's
``?dt=1995-03-15`` by wrapping the statement
(``core.sql_filter_wrapper.wrap_sql_with_filters`` -- THE renderer).  The
wrapper renders a typed literal when it is TOLD the column's type, and on this
path nobody told it: the only type it ever received was a publisher's
``_where_clauses_mapping.data_type``, which a view published with
``allowed_filters`` does not have.  So every filter on a DATE / TIMESTAMP
column became ``dt = '1995-03-15'`` and Trino/Starburst answered
``Cannot apply operator: date = varchar(10)`` -- a 500 for every date filter,
while the report-sourced view over the same table (typed dataset columns,
``federation_engine._filter_to_sql``) answered 200.

THE ORDER (``filter_column_types``)
-----------------------------------
1. the filter row's own ``data_type`` and the publisher's declared mapping
   type (the caller passes them as ``declared``) -- someone SAID;
2. the view's RECORDED schema (``published_view_schema_versions``, written at
   publish / republish by ``core.published_view_schema``) -- a non-string
   type only: "string" is also what that record writes when it did not know;
3. the SOURCE's own description of the statement's output -- a zero-row
   ``SELECT * FROM (<sql>) qs_describe WHERE 1 = 0`` through the SAME
   connector construction the execution uses, cached per (connection,
   statement) for ``_TTL_SECONDS``;
4. otherwise UNKNOWN -- the column is absent from the answer and its value is
   rendered exactly as before (a quoted string).  Never a guess, and never a
   refusal: an unknown type must not turn a working string filter into a 400.

Only SQL connectors are described.  A DuckDB-run source (s3 / local) coerces
a string literal to the column's type itself, so describing it buys nothing
the recorded schema does not.

Fail-open throughout: a describe that fails, times out or returns nothing is
UNKNOWN (and remembered as such for ``_NEG_TTL_SECONDS``, so a source that
cannot describe is not asked on every request).
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import threading
import time
from typing import Any, Dict, Iterable, List, Optional, Tuple

logger = logging.getLogger(__name__)

#: A described statement's types are reused this long.  The key includes the
#: statement's hash, so a republished view with new SQL is described afresh;
#: the TTL bounds how long an ALTER TABLE under unchanged SQL goes unseen.
_TTL_SECONDS = 300
#: A describe that FAILED is not retried for this long (unknown is cached
#: too, or a source that cannot describe costs a round trip per request).
_NEG_TTL_SECONDS = 60
_MAX_ENTRIES = 512
#: A describe is metadata work; past this the filter renders as before.
DESCRIBE_TIMEOUT_S = 20.0

_lock = threading.Lock()
#: (connection_id, sha256(sql)) -> (expires_at, {column_lower: type} | None, [exact spellings])
#: The types stay keyed by LOWER name (every reader's contract); the source's own spelling of
#: each output column is kept BESIDE them (2026-11-08, O5) for ``output_column_spellings``.
_cache: Dict[Tuple[Any, str], Tuple[float, Optional[Dict[str, str]], List[str]]] = {}


def clear_cache() -> None:
    """Forget every described statement (tests, connection edits)."""
    with _lock:
        _cache.clear()


def _key(connection_id: Any, sql: str) -> Tuple[Any, str]:
    return (connection_id, hashlib.sha256(sql.encode("utf-8")).hexdigest())


def _cached(key) -> Tuple[bool, Optional[Dict[str, str]]]:
    now = time.time()
    with _lock:
        hit = _cache.get(key)
        if hit and hit[0] > now:
            return True, hit[1]
    return False, None


def _cached_spellings(key) -> List[str]:
    """The exact output-column names the describe under ``key`` reported; [] = unknown."""
    now = time.time()
    with _lock:
        hit = _cache.get(key)
        if hit and hit[0] > now:
            return list(hit[2])
    return []


def _remember(key, types: Optional[Dict[str, str]], spellings: Optional[List[str]] = None) -> None:
    ttl = _TTL_SECONDS if types else _NEG_TTL_SECONDS
    with _lock:
        if len(_cache) >= _MAX_ENTRIES:
            _cache.clear()
        _cache[key] = (time.time() + ttl, types, list(spellings or []))


def describe_sql(sql: str) -> str:
    """The zero-row statement that asks the source for ``sql``'s output
    columns and types.  ``qs_describe`` starts with a letter and takes no
    ``AS``, so Oracle accepts it as well as Trino, Snowflake, Databricks,
    Athena and DuckDB."""
    inner = str(sql).rstrip()
    while inner.endswith(";"):
        inner = inner[:-1].rstrip()
    return f"SELECT * FROM (\n{inner}\n) qs_describe WHERE 1 = 0"


def describe_statement_types(connector: Any, sql: str, *,
                             connection_id: Any = None
                             ) -> Optional[Dict[str, str]]:
    """``{column_lower: engine type name}`` of ``sql``'s output, by asking
    ``connector``; None when it cannot be told.  Cached."""
    if connector is None or not sql or not str(sql).strip():
        return None
    key = _key(connection_id, str(sql))
    hit, types = _cached(key)
    if hit:
        return types
    types = None
    try:
        res = connector.execute_query(describe_sql(sql), limit=None) or {}
        cols = res.get("columns") or []
        found: Dict[str, str] = {}
        spellings: List[str] = []
        for c in cols:
            name = str((c or {}).get("name") or "").strip()
            ctype = str((c or {}).get("type") or "").strip()
            if name and ctype:
                found.setdefault(name.lower(), ctype)
                # 2026-11-08 (the REAL Snowflake account, proof O5): the column's EXACT spelling
                # as the source reports it -- USER_ID for an unquoted Snowflake column, "Desk" for
                # a quoted one -- kept beside the types for ``output_column_spellings``, which the
                # filter wrapper renders a filter column by.
                if name not in spellings:
                    spellings.append(name)
        types = found or None
    except Exception as exc:                                 # noqa: BLE001
        logger.info("[filter-types] describing the statement on connection "
                    "%s failed (types unknown, filters render as before): %s",
                    connection_id, exc)
        types, spellings = None, []
    _remember(key, types, spellings)
    return types


def _bare(col: Any) -> str:
    from core.sql_filter_wrapper import _bare_column
    return _bare_column(str(col or "")).lower()


async def output_column_spellings(sql: Optional[str], filters: Optional[Iterable[Any]] = None, *,
                                  connection_id: Any = None, db: Any = None,
                                  recorded: Optional[Iterable[Dict[str, Any]]] = None) -> List[str]:
    """The statement's output columns AS THE SOURCE SPELLS THEM -- the ``output_columns`` argument
    of ``wrap_sql_with_filters`` (2026-11-08, the real Snowflake account, proof O5).

    The same order as ``filter_column_types``: the view's RECORDED schema answers when it names
    EVERY filtered column (case-insensitively) -- no round trip; else the source's own description
    of the statement (the cached describe the types already paid for; the spellings sit beside the
    types in that cache); else whatever the recorded schema knows.  [] = unknown, and the wrapper
    then renders the consumer's name exactly as it did before.

    The recorded schema is NOT trusted on its own: it can be stale (recorded from an earlier cache
    of the view, or before the SQL was edited) -- the first route-level run of this rule found a
    view recorded as ID / AMT whose statement served Desk / region / AMT / USER_ID.
    """
    names = [str(c.get("name") or "").strip() for c in (recorded or []) if isinstance(c, dict)]
    names = [n for n in names if n]
    wanted = {_bare(_filter_column(f)[0]) for f in (filters or [])} - {""}
    lower = {n.lower() for n in names}
    if names and wanted <= lower:
        return names
    if sql and connection_id:
        await describe_for_connection(str(sql), connection_id, db)
        described = _cached_spellings(_key(connection_id, str(sql)))
        if described:
            return described
    return names


def _filter_column(f: Any) -> Tuple[str, str]:
    if isinstance(f, dict):
        return (str(f.get("column") or ""),
                str(f.get("data_type") or f.get("type") or ""))
    return (str(getattr(f, "column", "") or ""),
            str(getattr(f, "data_type", "") or ""))


def _typed(type_name: Any) -> bool:
    from core.sql_filter_wrapper import filter_value_kind
    return bool(filter_value_kind(type_name))


async def describe_for_connection(sql: str, connection_id: Any, db: Any
                                  ) -> Dict[str, str]:
    """The source's own types for ``sql`` on ``connection_id``; {} = unknown.

    The connector is built exactly as the published-view execution builds
    it (``core.connectors.get_connector`` over the stored connection), so the
    describe runs under the same credentials as the query it types.
    """
    if not sql or not connection_id or db is None:
        return {}
    key = _key(connection_id, str(sql))
    hit, types = _cached(key)
    if hit:
        return dict(types or {})
    try:
        from core.db_async import adb
        conn = await adb(db.get_connection_raw, connection_id)
    except Exception as exc:                                 # noqa: BLE001
        logger.info("[filter-types] connection %s unreadable: %s", connection_id, exc)
        return {}
    if not conn:
        return {}
    ctype = str(conn.get("connection_type") or "").strip().lower()
    try:
        from core.connectors import SQL_CONNECTOR_TYPES, get_connector
    except Exception:                                        # noqa: BLE001
        return {}
    if ctype not in SQL_CONNECTOR_TYPES or ctype == "rest_api":
        return {}
    text = str(sql)
    if "__logical__:" in text.lower():
        # The execution resolves logical tables later; the describe must ask
        # about the same physical tables or the source cannot answer.
        try:
            from core.logical_table_service import get_service
            text = get_service().rewrite_sql(text, connection_id)
        except Exception:                                    # noqa: BLE001
            return {}

    def _run() -> Optional[Dict[str, str]]:
        connector = get_connector(ctype, conn.get("config") or {}, connection_id,
                                  conn.get("name", ""))
        try:
            return describe_statement_types(connector, text,
                                            connection_id=connection_id)
        finally:
            try:
                connector.close()
            except Exception:                                # noqa: BLE001
                pass

    try:
        found = await asyncio.wait_for(asyncio.to_thread(_run),
                                       timeout=DESCRIBE_TIMEOUT_S)
    except Exception as exc:                                 # noqa: BLE001
        logger.info("[filter-types] describe on connection %s did not answer "
                    "(types unknown): %s", connection_id, exc)
        _remember(key, None)
        return {}
    if found is not None and text != sql:
        _remember(key, found, _cached_spellings(_key(connection_id, text)))
    return dict(found or {})


def recorded_view_types(db: Any, view_id: Any) -> List[Dict[str, Any]]:
    """The columns the view's latest RECORDED schema version lists; [] when
    none was recorded (a sql_query view publishes with no column list -- it
    is recorded only once something could tell)."""
    if db is None or not view_id or not hasattr(db, "latest_pv_schema_version"):
        return []
    try:
        latest = db.latest_pv_schema_version(int(view_id)) or {}
        return list(latest.get("columns") or [])
    except Exception as exc:                                 # noqa: BLE001
        logger.info("[filter-types] recorded schema of view %s unreadable: %s",
                    view_id, exc)
        return []


async def filter_column_types(sql: Optional[str], filters: Optional[Iterable[Any]],
                              *, connection_id: Any = None, db: Any = None,
                              recorded: Optional[Iterable[Dict[str, Any]]] = None,
                              declared: Optional[Dict[str, str]] = None
                              ) -> Dict[str, str]:
    """``{column: type}`` for the filtered columns of a raw-SQL statement --
    the ``column_types`` argument of ``wrap_sql_with_filters``.

    See the module docstring for the order.  A column that no source could
    type is ABSENT (unknown), never guessed.  The source is described only
    when a filtered column is still untyped after the declared and recorded
    types, so a view whose types were recorded costs no round trip.
    """
    out: Dict[str, str] = {}
    for k, v in (declared or {}).items():
        if k and v:
            out[str(k)] = str(v)
    known = {str(k).lower() for k in out}
    wanted: List[str] = []
    for f in filters or []:
        col, own_type = _filter_column(f)
        bare = _bare(col)
        if bare and not own_type and bare not in known and bare not in wanted:
            wanted.append(bare)
    if not wanted:
        return out
    for c in recorded or []:
        if not isinstance(c, dict):
            continue
        name = str(c.get("name") or "").strip().lower()
        ctype = c.get("type") or c.get("data_type")
        if name in wanted and _typed(ctype):
            out[name] = str(ctype)
            wanted.remove(name)
    if not wanted or not sql or not connection_id:
        return out
    described = await describe_for_connection(str(sql), connection_id, db)
    for name in wanted:
        if name in described:
            out[name] = described[name]
    return out
