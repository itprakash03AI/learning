"""Listing a SQL source's table VERSIONS, and the refusals its engine words
(2026-11-01, core/connectors/version_capability.py is the DECLARATION; this
is the read).

* Trino / Starburst / Athena: ``SELECT ... FROM "<schema>"."<table>$snapshots"``
  -- the same columns the storage listing shows (snapshot_id, committed_at,
  operation, summary), newest first.
* Databricks: ``DESCRIBE HISTORY <table>`` -- Delta versions (version,
  timestamp, operation).
* Snowflake: no list -- Time Travel reads ANY time inside the table's
  retention window; the window is READ (``SHOW PARAMETERS LIKE
  'DATA_RETENTION_TIME_IN_DAYS' IN TABLE <t>``) and a time before it is
  refused up front with that sentence, not by Snowflake's own error after
  the statement ran.
* Oracle: Flashback -- no list; the engine's ORA-01555 / ORA-08180 /
  ORA-01031 answers are rendered in plain words (``oracle_flashback_refusal``,
  read by ``core/error_sanitizer._refusal_sentence``).
* Databricks' and Snowflake's own refusals of a pinned read -- MEASURED on
  the real accounts on 2026-11-08 (``DELTA_VERSION_NOT_FOUND``,
  ``DELTA_TIMESTAMP_EARLIER_THAN_COMMIT_RETENTION``, ``UNSUPPORTED_FEATURE.
  TIME_TRAVEL`` on a view, ``EXPECT_TABLE_NOT_VIEW`` from DESCRIBE HISTORY;
  Snowflake ``000707 (02000): Time travel data is not available for table
  X``) -- in plain words too (``delta_time_travel_refusal``,
  ``snowflake_time_travel_refusal``; ``time_travel_refusal`` tries every
  engine, and is what the sanitizer and the published API read).

Every identifier is quoted by ONE helper; nothing from the table name
reaches SQL unquoted.
"""
from __future__ import annotations

import datetime as _dt
import re
from typing import Any, Dict, List, Optional

from core.iceberg_versions import IcebergVersionRefusal, qident

#: Days of history a Snowflake table keeps when the parameter cannot be read.
SNOWFLAKE_RETENTION_UNKNOWN = None


def _bident(name: str) -> str:
    """Databricks (Spark SQL) quotes an identifier with BACKTICKS; a double-quoted
    name is a string there.  Measured on the real warehouse 2026-11-08:
    ``DESCRIBE HISTORY "a"."b"."t"`` -> PARSE_SYNTAX_ERROR; backticks and bare
    names both answer."""
    return "`" + str(name).replace("`", "``") + "`"


def _qualified(table: str, connection_type: str = "") -> str:
    """``db.schema.table`` -> each part quoted the way THIS engine quotes
    (``qident`` double quotes; Databricks backticks)."""
    parts = [p for p in re.split(r"\.(?=(?:[^\"`]*[\"`][^\"`]*[\"`])*[^\"`]*$)", table.strip()) if p]
    q = _bident if str(connection_type or "").lower() == "databricks" else qident
    return ".".join(q(p.strip().strip('"').strip("`")) for p in parts)


def listing_sql(connection_type: str, table: str) -> Optional[str]:
    """The statement that lists ``table``'s versions on this engine, or None
    when the engine keeps no list (Snowflake, Oracle) or none is declared."""
    t = str(connection_type or "").lower()
    parts = [p for p in re.split(r"\.(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", table.strip()) if p]
    if t in ("trino", "starburst", "starburst_galaxy", "galaxy", "presto", "athena"):
        if not parts:
            return None
        last = parts[-1].strip().strip('"') + "$snapshots"
        q = ".".join(qident(p.strip().strip('"')) for p in parts[:-1] + [last])
        return (f"SELECT snapshot_id, committed_at, parent_id, operation, manifest_list, summary "
                f"FROM {q} ORDER BY committed_at DESC")
    if t == "databricks":
        return f"DESCRIBE HISTORY {_qualified(table, 'databricks')}"
    return None


def retention_sql(connection_type: str, table: str) -> Optional[str]:
    if str(connection_type or "").lower() == "snowflake":
        return f"SHOW PARAMETERS LIKE 'DATA_RETENTION_TIME_IN_DAYS' IN TABLE {_qualified(table)}"
    return None


def _ms(v: Any) -> Optional[int]:
    if v is None:
        return None
    if isinstance(v, _dt.datetime):
        d = v if v.tzinfo else v.replace(tzinfo=_dt.timezone.utc)
        return int(d.timestamp() * 1000)
    try:
        d = _dt.datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        d = d if d.tzinfo else d.replace(tzinfo=_dt.timezone.utc)
        return int(d.timestamp() * 1000)
    except ValueError:
        return None


def rows_to_versions(connection_type: str, columns: List[str], rows: List[Any]) -> List[Dict[str, Any]]:
    """The engine's answer as the ONE listing shape the panel shows
    (snapshot_id, committed_at, operation, summary, is_current)."""
    cols = [str(c).lower() for c in columns or []]
    out: List[Dict[str, Any]] = []
    t = str(connection_type or "").lower()
    for r in rows or []:
        rec = dict(zip(cols, r)) if not isinstance(r, dict) else {str(k).lower(): v for k, v in r.items()}
        if t == "databricks":
            sid, ts, op = rec.get("version"), rec.get("timestamp"), rec.get("operation")
            summ = rec.get("operationparameters") or rec.get("operationmetrics") or {}
        else:
            sid, ts, op = rec.get("snapshot_id"), rec.get("committed_at"), rec.get("operation")
            summ = rec.get("summary") or {}
        if sid is None:
            continue
        ms = _ms(ts)
        out.append({"snapshot_id": str(sid), "committed_at_ms": ms,
                    "committed_at": (_dt.datetime.fromtimestamp(ms / 1000, tz=_dt.timezone.utc)
                                     .isoformat(timespec="milliseconds").replace("+00:00", "Z") if ms else None),
                    "operation": str(op) if op is not None else None,
                    "summary": {str(k): str(v) for k, v in dict(summ).items()} if isinstance(summ, dict) else {},
                    "parent_id": (str(rec["parent_id"]) if rec.get("parent_id") is not None else None),
                    "is_current": False})
    out.sort(key=lambda x: x["committed_at_ms"] or 0, reverse=True)
    if out:
        out[0]["is_current"] = True
    return out


def list_versions(connector, connection_type: str, table: str) -> Dict[str, Any]:
    """Versions of ``table`` through an OPEN connector (``execute_query``
    returning ``{columns, rows}`` or ``(columns, rows)``).  A listing failure
    is the engine's sentence under ``error``, never an empty list."""
    sql = listing_sql(connection_type, table)
    if sql is None:
        return {"versions": None, "sql": None,
                "reason": "this source keeps no list of versions; pick a time instead"}
    try:
        res = connector.execute_query(sql)
        if res is None:
            raise RuntimeError("the source answered nothing")
        cols, rows = _split(res)
        return {"versions": rows_to_versions(connection_type, cols, rows), "sql": sql}
    except Exception as exc:                                   # noqa: BLE001
        # the sanitizer's sentence; the driver's own text goes to the log only
        # (security review of 5f04142e9)
        from core.table_version_access import failure_words
        return {"versions": None, "sql": sql, "error": failure_words(table, exc, verb="listed")}


def _split(res: Any):
    if isinstance(res, dict):
        return list(res.get("columns") or []), list(res.get("rows") or res.get("data") or [])
    if isinstance(res, tuple) and len(res) == 2:
        return list(res[0]), list(res[1])
    return [], list(res or [])


def snowflake_retention_days(connector, table: str) -> Optional[int]:
    """``DATA_RETENTION_TIME_IN_DAYS`` of ``table`` (SHOW PARAMETERS ... IN
    TABLE), or None when it could not be read -- unknown is not a window."""
    try:
        res = connector.execute_query(retention_sql("snowflake", table))
        cols, rows = _split(res)
        lc = [str(c).lower() for c in cols]
        for r in rows:
            rec = dict(zip(lc, r)) if not isinstance(r, dict) else {str(k).lower(): v for k, v in r.items()}
            if str(rec.get("key") or "").upper() == "DATA_RETENTION_TIME_IN_DAYS":
                return int(str(rec.get("value")).strip())
        if rows and len(rows[0]) >= 2 and not isinstance(rows[0], dict):
            return int(str(rows[0][1]).strip())
    except Exception:                                          # noqa: BLE001
        return SNOWFLAKE_RETENTION_UNKNOWN
    return SNOWFLAKE_RETENTION_UNKNOWN


def refuse_outside_snowflake_retention(table: str, as_of_ms: int, retention_days: Optional[int],
                                       now_ms: Optional[int] = None) -> None:
    """A time before the table's retention window is REFUSED here, with the
    window named, before any statement runs.  An unknown window refuses
    nothing (Snowflake answers then, with its own sentence)."""
    if retention_days is None:
        return
    import time as _time
    now = int(now_ms if now_ms is not None else _time.time() * 1000)
    floor = now - int(retention_days) * 86_400_000
    if int(as_of_ms) < floor:
        when = _dt.datetime.fromtimestamp(int(as_of_ms) / 1000, tz=_dt.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        raise IcebergVersionRefusal(
            f"{table} keeps {int(retention_days)} day(s) of history (Snowflake "
            f"DATA_RETENTION_TIME_IN_DAYS), so it cannot be read as of {when}. Pick a time "
            f"inside the last {int(retention_days)} day(s), or remove FOR TIMESTAMP AS OF to read it as it is now.")


_ORA_FLASHBACK = {
    "ORA-01555": "Oracle no longer holds the undo data for that time (ORA-01555: snapshot too old)",
    "ORA-08180": "Oracle has no data for that time (ORA-08180: no snapshot found based on specified time)",
    "ORA-08181": "the time is not inside Oracle's flashback window (ORA-08181)",
    "ORA-01031": "the login lacks the FLASHBACK privilege on the table (ORA-01031: insufficient privileges)",
    "ORA-08189": "the table does not allow flashback (ORA-08189: row movement is not enabled)",
}


def oracle_flashback_refusal(text: str) -> Optional[str]:
    """The plain sentence for an Oracle Flashback (``AS OF TIMESTAMP``)
    refusal in ``text``, or None when it is none of them."""
    s = str(text or "")
    for code, words in _ORA_FLASHBACK.items():
        if code in s.upper():
            return (f"The table could not be read as of that time: {words}. Pick a more recent "
                    f"time (inside the database's undo retention), ask for the FLASHBACK privilege, "
                    f"or remove FOR TIMESTAMP AS OF to read it as it is now.")
    return None


#: Databricks' error classes for a pinned read, as the real warehouse spelled them
#: (2026-11-08): the class in brackets, then what to do.
_DELTA_TIME_TRAVEL = (
    ("DELTA_VERSION_NOT_FOUND",
     "the table has no such version number"),
    ("DELTA_TIMESTAMP_EARLIER_THAN_COMMIT_RETENTION",
     "the time is before the earliest version the table still keeps (Delta's commit retention)"),
    ("DELTA_CANNOT_TIME_TRAVEL",
     "the time or version is outside what the table still keeps"),
    ("UNSUPPORTED_FEATURE.TIME_TRAVEL",
     "it is a view or not a Delta table, and only a Delta TABLE keeps versions"),
    ("EXPECT_TABLE_NOT_VIEW",
     "it is a view, and only a Delta TABLE keeps versions"),
    ("DELTA_TIMESTAMP_GREATER_THAN_COMMIT",
     "the time is after the table's latest version"),
)

_DELTA_AVAILABLE_RE = re.compile(r"Available versions:\s*\[([^\]]*)\]")
_DELTA_AFTER_RE = re.compile(r"Please use a timestamp after ([0-9:\- .]+)")


def delta_time_travel_refusal(text: str) -> Optional[str]:
    """The plain sentence for a Databricks (Delta) refusal of ``VERSION AS OF``
    / ``TIMESTAMP AS OF`` / ``DESCRIBE HISTORY`` in ``text``, or None."""
    s = str(text or "")
    up = s.upper()
    for code, words in _DELTA_TIME_TRAVEL:
        if code in up:
            hint = ""
            m = _DELTA_AVAILABLE_RE.search(s)
            if m:
                hint = f" The table keeps versions {m.group(1).strip()}."
            m2 = _DELTA_AFTER_RE.search(s)
            if m2:
                hint = f" Pick a time after {m2.group(1).strip().rstrip('.')} UTC."
            return (f"The table could not be read at that version: {words}.{hint} Pick a version "
                    f"or time the table keeps (GET .../versions lists them), or read it as it is now.")
    return None


def snowflake_time_travel_refusal(text: str) -> Optional[str]:
    """The plain sentence for Snowflake's own Time Travel refusal (``000707
    (02000): Time travel data is not available for table X ...``, errno 707)
    in ``text``, or None."""
    s = str(text or "")
    if "000707" not in s and "time travel data is not available" not in s.lower():
        return None
    m = re.search(r"not available for table\s+([A-Za-z0-9_.\"$]+)", s)
    table = m.group(1).rstrip(".") if m else "the table"
    return (f"{table} could not be read as of that time: Snowflake no longer keeps that time "
            f"(it is before the table's retention window, DATA_RETENTION_TIME_IN_DAYS, or before "
            f"the table was created). Pick a more recent time, or read the table as it is now.")


def time_travel_refusal(text: str) -> Optional[str]:
    """ONE question for every engine: is ``text`` a source's refusal of a
    pinned read?  The plain sentence, or None."""
    return (oracle_flashback_refusal(text) or delta_time_travel_refusal(text)
            or snowflake_time_travel_refusal(text))
