"""The contract between a report and the source that holds its data.

A source DECLARES what it can do (:class:`SourceCapabilities`: nothing here has
a default -- a capability nobody declared is a capability nobody has), is asked
for its columns, checks a report at save time, and RUNS a report into a
:class:`SourceResult`: a verified file, or inline rows, or an error.  It never
answers "no rows" for "could not read" (CLAUDE.md section 4: unknown is not
empty).

Vocabulary, in plain words for the screen:

* ``row_security`` -- who narrows the rows: the source itself (``by_source``,
  QueryStudio's engine rewrites the query), the framework after the read
  (``by_framework``), or nobody (``none``: such a source is refused when a
  row-security policy applies to the report, never served unfiltered);
* ``filter_pushdown`` -- a filter runs inside the source's read; otherwise the
  framework applies it to the result, and refuses what it cannot apply;
* ``retry_safe`` -- the read may run twice (a dead pod's job re-queued);
  unknown = False = once;
* ``parameters`` / ``subscriptions`` / ``query_pods`` -- the source takes
  report parameters, may be delivered on a subscription, may run on the
  query-pod lane.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

ROW_SECURITY_BY_SOURCE = "by_source"
ROW_SECURITY_BY_FRAMEWORK = "by_framework"
ROW_SECURITY_NONE = "none"
ROW_SECURITY_KINDS = (ROW_SECURITY_BY_SOURCE, ROW_SECURITY_BY_FRAMEWORK, ROW_SECURITY_NONE)

#: where a run is asked for
SURFACE_INTERACTIVE = "interactive"
SURFACE_HEADLESS = "headless"
SURFACE_PUBLISHED_API = "published_api"
SURFACES = (SURFACE_INTERACTIVE, SURFACE_HEADLESS, SURFACE_PUBLISHED_API)

#: the words a capability is shown with (the source picker, the as-built doc)
CAPABILITY_WORDS = {
    "row_security": "who narrows the rows to what the reader may see",
    "filter_pushdown": "filters run inside the source's own read",
    "retry_safe": "a read may run a second time on another pod",
    "parameters": "report parameters",
    "subscriptions": "delivery on a subscription or a schedule",
    "query_pods": "may run on a query pod",
}


class ReportFrameworkError(ValueError):
    """Every refusal the framework makes.  The text is a plain sentence."""


class UnknownSourceError(ReportFrameworkError):
    """A report names a source kind nobody registered.  Refused, never defaulted."""


class SourceRefused(ReportFrameworkError):
    """A source refused a report (a bad save, a run it cannot do)."""


class RowSecurityRefused(ReportFrameworkError):
    """A row-security policy applies and this source cannot narrow the rows."""


class FilterRefused(ReportFrameworkError):
    """A filter the framework could not apply to the result -- refused, never dropped."""


class SourceReadError(ReportFrameworkError):
    """The source could not read.  Distinct from "read nothing"."""


@dataclass(frozen=True)
class SourceCapabilities:
    """DECLARED, every field.  No default: a source that does not say is
    refused at registration, not guessed."""
    row_security: str
    filter_pushdown: bool
    retry_safe: bool
    parameters: bool
    subscriptions: bool
    query_pods: bool

    def __post_init__(self) -> None:
        if self.row_security not in ROW_SECURITY_KINDS:
            raise ReportFrameworkError(
                f"row_security must be one of {', '.join(ROW_SECURITY_KINDS)}, not {self.row_security!r}")
        for name in ("filter_pushdown", "retry_safe", "parameters", "subscriptions", "query_pods"):
            if not isinstance(getattr(self, name), bool):
                raise ReportFrameworkError(f"{name} must be declared True or False, not {getattr(self, name)!r}")

    def to_dict(self) -> Dict[str, Any]:
        return {"row_security": self.row_security, "filter_pushdown": self.filter_pushdown,
                "retry_safe": self.retry_safe, "parameters": self.parameters,
                "subscriptions": self.subscriptions, "query_pods": self.query_pods}


@dataclass(frozen=True)
class ColumnInfo:
    name: str
    data_type: str = "string"
    label: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "data_type": self.data_type, "label": self.label or self.name}


@dataclass(frozen=True)
class SourceRun:
    """One run of one report, as the source sees it."""
    report: Mapping[str, Any]
    params: Mapping[str, Any]
    execution_id: str
    output_dir: Path
    principal: Mapping[str, Any]        # who it runs as; the owner for a scheduled run
    surface: str                        # interactive | headless | published_api
    row_limit: Optional[int] = None     # None = not given; 0 = every row
    filters: List[Dict[str, Any]] = field(default_factory=list)   # {column, op, value[, value2]}

    def __post_init__(self) -> None:
        if self.surface not in SURFACES:
            raise ReportFrameworkError(f"surface must be one of {', '.join(SURFACES)}, not {self.surface!r}")


@dataclass
class SourceResult:
    """What a run produced.  EITHER a file (``artifact_path``, verified by the
    framework before anyone reads it) OR inline ``records``.  A source that
    could not read raises :class:`SourceReadError` instead of returning this
    with nothing in it."""
    artifact_path: Optional[str] = None
    records: Optional[List[Dict[str, Any]]] = None
    columns: List[str] = field(default_factory=list)
    total_rows: Optional[int] = None
    meta: Dict[str, Any] = field(default_factory=dict)      # row_limit, truncated, engine, ...

    def is_empty_claim(self) -> bool:
        """Nothing to serve and no count of zero: an unknown, not an empty result."""
        return self.artifact_path is None and self.records is None and self.total_rows != 0


class ReportSource:
    """One kind of report source.  Subclass it; declare ``kind``, ``label``
    and ``capabilities``; implement ``run``.  ``validate`` and ``columns`` have
    honest defaults (accept nothing special; no columns known)."""

    kind: str = ""
    label: str = ""
    description: str = ""
    capabilities: Optional[SourceCapabilities] = None

    def validate(self, report: Mapping[str, Any], db: Any) -> None:
        """Raise :class:`SourceRefused` on a report this source cannot run."""
        return None

    def connection_ids(self, report: Mapping[str, Any]) -> List[Any]:
        """The QueryStudio connections this report's data is read through: the
        host checks the person saving the report may use each (review
        2026-11-07).  A source reading through one must declare it."""
        return []

    def columns(self, report: Mapping[str, Any], principal: Mapping[str, Any], db: Any) -> List[ColumnInfo]:
        """The columns a run would produce, when the source can say without running."""
        return []

    def run(self, run: SourceRun, db: Any) -> SourceResult:
        raise SourceRefused(f"The source '{self.kind}' cannot run a report here.")

    def describe(self) -> Dict[str, Any]:
        return {"kind": self.kind, "label": self.label or self.kind, "description": self.description,
                "capabilities": self.capabilities.to_dict() if self.capabilities else None}


__all__ = [
    "CAPABILITY_WORDS", "ColumnInfo", "FilterRefused", "ROW_SECURITY_BY_FRAMEWORK", "ROW_SECURITY_BY_SOURCE",
    "ROW_SECURITY_KINDS", "ROW_SECURITY_NONE", "ReportFrameworkError", "ReportSource", "RowSecurityRefused",
    "SURFACE_HEADLESS", "SURFACE_INTERACTIVE", "SURFACE_PUBLISHED_API", "SURFACES", "SourceCapabilities",
    "SourceReadError", "SourceRefused", "SourceResult", "SourceRun", "UnknownSourceError",
]
