"""The three ports a HOST gives the framework, and the host's own helpers by name.

The framework never imports the host.  At start-up the host installs:

* :class:`PolicyPort`    -- do row-security policies apply to this report, for
                            this person?  ``True`` / ``False`` / ``None`` (could
                            not tell; the rule treats it as applying);
* :class:`ArtifactPort`  -- where a result file lives and which file is the run's;
* :class:`ReadinessPort` -- is this report's data ready: ``ready`` / ``not_ready``
                            / ``unknown`` with a sentence.  No provider = "not
                            known here", never "ready";
* the HOST helpers (:func:`host`), the host's own functions the report modules
  used to import from ``api.*`` -- resolved by name, installed once.

A process that never ran the host's start-up (a worker, a test) gets the
DEFAULT host by module name (:data:`DEFAULT_HOST_MODULE`, a string: this
module imports nothing of it).  A name the host did not install is
:class:`HostNotInstalled` -- "not known here" -- never a guess.
"""
from __future__ import annotations

import importlib
import logging
import threading
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional, Protocol

from core.report_framework.contract import ReportFrameworkError

logger = logging.getLogger(__name__)

#: QueryStudio's host module, by NAME.  It installs the ports when imported.
DEFAULT_HOST_MODULE = "api.report_framework_host"

READY = "ready"
NOT_READY = "not_ready"
UNKNOWN = "unknown"


class HostNotInstalled(ReportFrameworkError):
    """The host never installed this port or helper: the answer is not known here."""


class PolicyPort(Protocol):
    def policies_apply(self, report: Mapping[str, Any], principal: Mapping[str, Any],
                       governed_refs: list, db: Any) -> Optional[bool]: ...


class ArtifactPort(Protocol):
    def result_dir(self) -> Path: ...
    def resolve(self, execution_id: str, claimed_path: Optional[str]) -> Optional[Path]: ...


class ReadinessPort(Protocol):
    def evaluate(self, report: Mapping[str, Any], params: Mapping[str, Any], db: Any) -> Dict[str, Any]: ...


class DependencyPort(Protocol):
    """What the report readiness and SLO modules need of a DEPENDENCY engine
    (QueryStudio's is the feed engine's: its gate, its arrival ledger, its
    clocks, its business calendars, its Netcool sender).  Without one, a
    readiness is ``unknown`` and a promise ``could_not_evaluate`` -- never
    ready, never met."""
    netcool: Any                                            # build_event, enqueue_event, resolution_for, ...

    def gate_states(self) -> Dict[str, str]: ...            # MET / NOT_MET / NOT_EXPECTED / UNKNOWN
    def evaluate_gate_over_rows(self, db: Any, rows: Any, business_date: Any) -> Any: ...
    def compute_clocks(self, **kwargs: Any) -> Any: ...
    def arrival_profile(self, db: Any, name: str, *, now: Any) -> Any: ...
    def calendar_is_business_day(self, db: Any, calendar_name: str, business_date: Any) -> tuple: ...
    def resolve_zone(self, name: Any) -> Any: ...
    def breach_severity(self) -> Any: ...


class _Host:
    """The host's helpers by name.  ``host().name`` -> the callable, or HostNotInstalled."""

    def __init__(self) -> None:
        self._fns: Dict[str, Callable[..., Any]] = {}

    def install(self, **fns: Callable[..., Any]) -> None:
        for k, v in fns.items():
            if not callable(v):
                raise ReportFrameworkError(f"host helper {k!r} is not callable")
            self._fns[k] = v

    def has(self, name: str) -> bool:
        return name in self._fns

    def names(self) -> list:
        return sorted(self._fns)

    def __getattr__(self, name: str) -> Callable[..., Any]:
        if name.startswith("_"):
            raise AttributeError(name)
        fn = self._fns.get(name)
        if fn is None:
            raise HostNotInstalled(
                f"The host did not provide '{name}', so this is not known here "
                f"(helpers installed: {', '.join(self.names()) or 'none'}).")
        return fn


_LOCK = threading.RLock()
_POLICY: Optional[PolicyPort] = None
_ARTIFACT: Optional[ArtifactPort] = None
_READINESS: Optional[ReadinessPort] = None
_DEPENDENCY: Optional[DependencyPort] = None
_HOST = _Host()
_HOST_LOADED = [False]


def install_policy_port(port: PolicyPort) -> None:
    global _POLICY
    with _LOCK:
        _POLICY = port


def install_artifact_port(port: ArtifactPort) -> None:
    global _ARTIFACT
    with _LOCK:
        _ARTIFACT = port


def install_readiness_port(port: ReadinessPort) -> None:
    global _READINESS
    with _LOCK:
        _READINESS = port


def install_dependency_port(port: DependencyPort) -> None:
    global _DEPENDENCY
    with _LOCK:
        _DEPENDENCY = port


def install_host(**fns: Callable[..., Any]) -> None:
    with _LOCK:
        _HOST.install(**fns)
        _HOST_LOADED[0] = True


def ensure_host() -> bool:
    """Load the default host once, by name.  False when it could not be
    imported (a process without the host: the ports stay empty, every answer
    is 'not known here')."""
    with _LOCK:
        if _HOST_LOADED[0]:
            return True
        try:
            mod = importlib.import_module(DEFAULT_HOST_MODULE)
            # an already-imported host whose installs were reset (a test, a
            # re-initialised process) installs again: importing it a second
            # time runs nothing
            if not _HOST_LOADED[0] and callable(getattr(mod, "install", None)):
                mod.install()
        except Exception as exc:                          # noqa: BLE001
            logger.warning("[report-framework] the host module %s could not be loaded: %s",
                           DEFAULT_HOST_MODULE, exc)
            return False
        _HOST_LOADED[0] = True
        return True


def host() -> _Host:
    ensure_host()
    return _HOST


def policy() -> Optional[PolicyPort]:
    ensure_host()
    return _POLICY


def artifact() -> Optional[ArtifactPort]:
    ensure_host()
    return _ARTIFACT


def readiness() -> Optional[ReadinessPort]:
    ensure_host()
    return _READINESS


def dependency() -> Optional[DependencyPort]:
    ensure_host()
    return _DEPENDENCY


def dependency_or_raise() -> DependencyPort:
    """The dependency engine, or HostNotInstalled: 'not known here', never a guess."""
    port = dependency()
    if port is None:
        raise HostNotInstalled("No dependency engine is installed here, so whether a report's data is ready "
                               "is not known here.")
    return port


def readiness_of(report: Mapping[str, Any], params: Mapping[str, Any], db: Any) -> Dict[str, Any]:
    """``{state, sentence}``; with no provider the state is UNKNOWN ("not known here")."""
    port = readiness()
    if port is None:
        return {"state": UNKNOWN, "sentence": "Whether this report's data is ready is not known here."}
    try:
        out = port.evaluate(report, params, db) or {}
    except Exception as exc:                              # noqa: BLE001
        return {"state": UNKNOWN, "sentence": f"Whether the data is ready could not be told: {exc}"}
    state = out.get("state")
    if state not in (READY, NOT_READY, UNKNOWN):
        return {"state": UNKNOWN, "sentence": f"The readiness provider answered {state!r}, which is not an answer."}
    return {"state": state, "sentence": str(out.get("sentence") or "")}


def _reset_for_tests(*, keep_host: bool = False) -> None:
    global _POLICY, _ARTIFACT, _READINESS, _DEPENDENCY, _HOST
    with _LOCK:
        _POLICY = _ARTIFACT = _READINESS = _DEPENDENCY = None
        if not keep_host:
            _HOST = _Host()
            _HOST_LOADED[0] = False


__all__ = [
    "ArtifactPort", "DEFAULT_HOST_MODULE", "DependencyPort", "HostNotInstalled", "NOT_READY", "PolicyPort", "READY",
    "ReadinessPort", "UNKNOWN", "artifact", "dependency", "dependency_or_raise", "ensure_host", "host",
    "install_artifact_port", "install_dependency_port", "install_host", "install_policy_port",
    "install_readiness_port", "policy", "readiness", "readiness_of",
]
