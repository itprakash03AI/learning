"""A third party's report source, loaded by module path.

Config key ``report_framework.source_plugins`` (a list; CONFIG FILE ONLY --
it runs code, so it is never a screen setting): each entry is
``"package.module"`` (the module exposes ``SOURCE``, a ReportSource, or
``register(registry)``) or ``"package.module:attribute"``.  An entry that
cannot be loaded is recorded with its sentence (``plugin_problems``, shown on
the source list) and the kind it would have added stays unknown -- refused at
run, never guessed.
"""
from __future__ import annotations

import importlib
import logging
import threading
from typing import Any, Dict, List, Optional

from core.report_framework import registry
from core.report_framework.contract import ReportFrameworkError, ReportSource

logger = logging.getLogger(__name__)

_LOCK = threading.RLock()
_PROBLEMS: List[Dict[str, str]] = []
_LOADED: List[str] = []


def _load_one(entry: str) -> List[str]:
    """Register what one entry names; returns the kinds it added."""
    text = str(entry or "").strip()
    if not text:
        raise ReportFrameworkError("an empty plugin entry")
    mod_name, _, attr = text.partition(":")
    module = importlib.import_module(mod_name.strip())
    if attr:
        obj = getattr(module, attr.strip(), None)
        if obj is None:
            raise ReportFrameworkError(f"{mod_name} has no attribute {attr!r}")
    elif hasattr(module, "SOURCE"):
        obj = module.SOURCE
    elif callable(getattr(module, "register", None)):
        before = {s.kind for s in registry.list_sources()}
        module.register(registry)
        return sorted({s.kind for s in registry.list_sources()} - before)
    else:
        raise ReportFrameworkError(f"{mod_name} exposes neither SOURCE nor register(registry)")
    if isinstance(obj, type):
        obj = obj()
    if not isinstance(obj, ReportSource):
        raise ReportFrameworkError(f"{text} is a {type(obj).__name__}, not a ReportSource")
    registry.register_source(obj)
    return [obj.kind]


def load_source_plugins(entries: Optional[List[str]]) -> Dict[str, Any]:
    """Load every entry; never raises: ``{loaded: [kinds], problems: [{entry, problem}]}``."""
    loaded: List[str] = []
    problems: List[Dict[str, str]] = []
    for entry in entries or []:
        try:
            kinds = _load_one(entry)
            loaded.extend(kinds)
            logger.info("[report-framework] source plugin %s registered %s", entry, kinds)
        except Exception as exc:                          # noqa: BLE001
            problem = f"{type(exc).__name__}: {exc}"
            problems.append({"entry": str(entry), "problem": problem})
            logger.error("[report-framework] source plugin %r could not be loaded: %s", entry, problem)
    with _LOCK:
        _LOADED.extend(loaded)
        _PROBLEMS.extend(problems)
    return {"loaded": loaded, "problems": problems}


def load_from_config() -> Dict[str, Any]:
    """The entries the configuration names (``report_framework.source_plugins``)."""
    try:
        from core import config as _cfg
        entries = list(_cfg.report_framework.source_plugins or [])
    except Exception as exc:                              # noqa: BLE001
        logger.warning("[report-framework] source_plugins could not be read from the configuration: %s", exc)
        entries = []
    return load_source_plugins(entries)


def plugin_problems() -> List[Dict[str, str]]:
    with _LOCK:
        return list(_PROBLEMS)


def loaded_plugin_kinds() -> List[str]:
    with _LOCK:
        return list(_LOADED)


def _reset_for_tests() -> None:
    with _LOCK:
        _PROBLEMS.clear()
        _LOADED.clear()


__all__ = ["load_from_config", "load_source_plugins", "loaded_plugin_kinds", "plugin_problems"]
