"""The generic report framework (2026-11-07; plan docs/REPORT_FRAMEWORK_PLAN_2026_11_04.html).

A report asks ONE declared contract for its data (:mod:`contract`), the
registry answers which source holds it (:mod:`registry`), the five rules every
run is held to live in :mod:`rules`, the host's three ports (who may see which
rows, where a result file lives, is the data ready) in :mod:`ports`, and a
third party's source is loaded by module path from the config key
``report_framework.source_plugins`` (:mod:`plugins`).

Layers (the import guard, ``tests/test_report_framework_guards_2026_11_07.py``):

* this package (the FRAMEWORK) imports the standard library, a few pure
  third-party libraries and ``core.reports.contract`` -- never ``api.*``,
  ``core.feed``, ``core.dataflow``, ``core.clockwork`` nor an engine;
* ``core/report_framework/sources/`` (the SOURCES) may import what each
  wraps: QueryStudio's four import the engine and the host's route helpers;
* ``api/*`` (the HOST) may import anything; it installs the ports and attaches
  its own screen roads to the sources it knows.
"""
from core.report_framework.contract import (  # noqa: F401
    ColumnInfo, FilterRefused, ReportFrameworkError, ReportSource, RowSecurityRefused,
    SourceCapabilities, SourceReadError, SourceRefused, SourceResult, SourceRun,
    UnknownSourceError,
)
from core.report_framework.registry import (  # noqa: F401
    canonical_source_type, is_registered, list_sources, register_source, source_for,
)
