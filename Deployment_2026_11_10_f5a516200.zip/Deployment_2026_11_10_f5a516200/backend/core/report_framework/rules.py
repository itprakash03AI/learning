"""The five rules every run is held to (plan section 3), each a function the
host roads call and a test plants a source against.

1. **Row security refuses, never drops** (:func:`check_row_security`): a
   policy applies and the source says ``row_security: none`` -> refused in a
   sentence.  "Could not tell" counts as applying.
2. **Retry is a declaration** (:func:`attempts_for`): ``retry_safe`` True ->
   the configured attempts; anything else -> one.
3. **Unknown is not empty** (:func:`require_result`): a result with no file,
   no rows and no known count of zero is refused; the registry refuses an
   unknown kind; the readiness port with no provider says "not known here".
4. **A file or a refusal** (:func:`verify_result`): a file result goes through
   ``core.reports.contract.require_artifact`` before anyone reads it.
5. **A filter it cannot apply is a refusal** (:func:`apply_filters`): with
   ``filter_pushdown`` False the framework filters the result itself; a
   filter on a column the result lacks, or with an operator it does not
   know, refuses -- a dropped filter would return MORE rows.
"""
from __future__ import annotations

import logging
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, List, Mapping, Optional

from core.report_framework import ports
from core.report_framework.contract import (
    ROW_SECURITY_NONE, FilterRefused, ReportSource, RowSecurityRefused, SourceReadError, SourceResult,
)

logger = logging.getLogger(__name__)

FILTER_OPS = ("eq", "ne", "in", "not_in", "gt", "gte", "lt", "lte", "between", "is_null", "is_not_null")
_OP_ALIASES = {"=": "eq", "==": "eq", "!=": "ne", "<>": "ne", ">": "gt", ">=": "gte", "<": "lt", "<=": "lte",
               "not in": "not_in", "is null": "is_null", "is not null": "is_not_null", "equals": "eq"}


# ── 1 · row security ─────────────────────────────────────────────────────────

def governed_refs_of(source: ReportSource, report: Mapping[str, Any]) -> List[str]:
    """The names a source's data goes by, for a policy to match (a source may
    declare ``governed_refs(report)``; else the report's own name)."""
    fn = getattr(source, "governed_refs", None)
    if callable(fn):
        try:
            refs = fn(report)
            return [str(r) for r in (refs or []) if str(r).strip()]
        except Exception as exc:                          # noqa: BLE001
            logger.warning("[report-framework] %s.governed_refs failed: %s", source.kind, exc)
            return []
    return [f"report:{report.get('id')}"] if isinstance(report, Mapping) and report.get("id") else []


def check_row_security(source: ReportSource, report: Mapping[str, Any], principal: Mapping[str, Any],
                       db: Any) -> Optional[bool]:
    """Rule 1.  Returns the port's answer (True / False / None) for the record;
    raises :class:`RowSecurityRefused` when a policy applies (or could not be
    told) and the source cannot narrow the rows."""
    caps = source.capabilities
    if caps is None or caps.row_security != ROW_SECURITY_NONE:
        return None             # the source narrows the rows itself, or the framework does
    port = ports.policy()
    if port is None:
        raise RowSecurityRefused(
            "This report cannot run: whether row-security policies apply to it is not known here, "
            f"and its source ('{source.kind}') cannot narrow the rows to what you may see.")
    try:
        applies = port.policies_apply(report, principal, governed_refs_of(source, report), db)
    except Exception as exc:                              # noqa: BLE001
        raise RowSecurityRefused(
            f"This report cannot run: whether row-security policies apply could not be told ({exc}), "
            f"and its source ('{source.kind}') cannot narrow the rows.") from exc
    if applies is None or applies:
        raise RowSecurityRefused(
            "This report cannot run: a row-security policy applies to its data"
            + ("" if applies else " (or could not be told)")
            + f", and its source ('{source.kind}') cannot narrow the rows to what you may see. "
              "It is refused rather than shown unfiltered.")
    return False


# ── 2 · retry ────────────────────────────────────────────────────────────────

def attempts_for(source: Optional[ReportSource], read_attempts: int) -> tuple:
    """Rule 2.  ``(max_attempts, why)``: a DECLARED ``retry_safe`` gets the
    configured attempts; an unknown source or an undeclared one gets ONE."""
    if source is None or source.capabilities is None:
        return 1, "the source is not known (unknown = once)"
    if source.capabilities.retry_safe:
        return max(1, int(read_attempts)), f"the source '{source.kind}' declares its read retry-safe"
    return 1, f"the source '{source.kind}' does not declare its read retry-safe (once)"


# ── 3 + 4 · a file or a refusal, never an empty claim ────────────────────────

def require_result(result: Any, source: ReportSource, execution_id: str) -> SourceResult:
    """Rule 3.  The run must have produced a SourceResult that says something."""
    if not isinstance(result, SourceResult):
        raise SourceReadError(
            f"The source '{source.kind}' returned {type(result).__name__} for run {execution_id}, "
            "not a result. Refused rather than shown as empty.")
    if result.is_empty_claim():
        raise SourceReadError(
            f"The source '{source.kind}' produced neither a file nor rows for run {execution_id} "
            "and did not say the result is empty. Refused rather than shown as empty.")
    return result


def verify_result(result: SourceResult, execution_id: str) -> SourceResult:
    """Rule 4.  A file result is verified (it exists, it is the run's) before anyone reads it."""
    if result.records is not None:
        return result
    from core.reports.contract import require_artifact
    verified = require_artifact(execution_id, result.artifact_path)
    result.artifact_path = str(verified)
    return result


# ── 5 · a filter it cannot apply ─────────────────────────────────────────────

def _norm_op(op: Any) -> str:
    o = str(op or "eq").strip().lower()
    o = _OP_ALIASES.get(o, o)
    if o not in FILTER_OPS:
        raise FilterRefused(f"The filter operator '{op}' is not one this source's result can take "
                            f"({', '.join(FILTER_OPS)}). The filter was not dropped: the run is refused.")
    return o


def _as_number(v: Any) -> Optional[Decimal]:
    if v is None or isinstance(v, bool):
        return None
    try:
        return Decimal(str(v))
    except (InvalidOperation, ValueError):
        return None


def _as_bool(v: Any) -> Optional[bool]:
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    return {"true": True, "1": True, "yes": True, "false": False, "0": False, "no": False}.get(s)


def _as_moment(v: Any) -> Optional[datetime]:
    if isinstance(v, datetime):
        return v
    if isinstance(v, date):
        return datetime(v.year, v.month, v.day)
    try:
        return datetime.fromisoformat(str(v).strip().replace("Z", "+00:00"))
    except ValueError:
        return None


def _typed(cell: Any, value: Any, column: str) -> tuple:
    """``(cell, value)`` as ONE type, the COLUMN's: a number column compares as
    numbers, a date / time column as moments, a true/false column as true/false,
    a text column as text (so ``"007"`` is not ``7``).  A value that cannot be
    read as the column's type REFUSES -- never a quiet mismatch that drops or
    keeps rows."""
    if isinstance(cell, bool):
        b = _as_bool(value)
        if b is None:
            raise FilterRefused(f"The filter on '{column}' compares a true/false column with '{value}'. "
                                "Refused rather than guessed.")
        return cell, b
    if isinstance(cell, (int, float, Decimal)):
        b = _as_number(value)
        if b is None:
            raise FilterRefused(f"The filter on '{column}' compares a number column with '{value}'. "
                                "Refused rather than guessed.")
        return Decimal(str(cell)), b
    if isinstance(cell, (datetime, date)):
        a, b = _as_moment(cell), _as_moment(value)
        if b is None:
            raise FilterRefused(f"The filter on '{column}' compares a date column with '{value}', which is "
                                "not a date. Refused rather than guessed.")
        if (a.tzinfo is None) != (b.tzinfo is None):
            raise FilterRefused(f"The filter on '{column}' compares a time with a time zone and one without. "
                                "Refused rather than guessed.")
        return a, b
    return str(cell), str(value)


def _compare(cell: Any, op: str, value: Any, value2: Any = None, column: str = "") -> bool:
    if op == "is_null":
        return cell is None
    if op == "is_not_null":
        return cell is not None
    if cell is None:
        return False                    # as SQL: a missing value matches no comparison
    if op in ("in", "not_in"):
        values = value if isinstance(value, (list, tuple, set)) else [value]
        hit = any(_same(cell, v, column) for v in values)
        return hit if op == "in" else not hit
    if op == "eq":
        return _same(cell, value, column)
    if op == "ne":
        return not _same(cell, value, column)
    a, b = _typed(cell, value, column)
    if op == "between":
        _, c = _typed(cell, value2, column)
        return b <= a <= c
    return {"gt": a > b, "gte": a >= b, "lt": a < b, "lte": a <= b}[op]


def _same(cell: Any, value: Any, column: str = "") -> bool:
    a, b = _typed(cell, value, column)
    return a == b


def _filter_value(f: Mapping[str, Any], op: str, column: str) -> Any:
    """The filter's value; a list filter may carry its list under ``values``.
    A list filter with no list REFUSES (an empty NOT IN would keep every row)."""
    value = f.get("value")
    if op in ("in", "not_in"):
        if value is None:
            value = f.get("values")
        if value is None or (isinstance(value, (list, tuple, set)) and not value):
            raise FilterRefused(f"The list filter on '{column}' has no values. Refused rather than dropped.")
    return value


def apply_filters(result: SourceResult, filters: List[Dict[str, Any]], source: ReportSource) -> SourceResult:
    """Rule 5.  With ``filter_pushdown`` the source already applied them (and
    is trusted to have REFUSED what it could not).  Otherwise the framework
    applies each filter to the result's rows; a column the result lacks or an
    operator it does not know REFUSES the run."""
    if not filters:
        return result
    caps = source.capabilities
    if caps is not None and caps.filter_pushdown:
        return result
    if result.records is None:
        if result.artifact_path:
            result.records = _read_artifact_records(result.artifact_path)
        else:
            raise FilterRefused(
                f"A filter was asked of this report, but its source ('{source.kind}') gave no rows the "
                "framework could filter. Refused rather than returning every row.")
    cols = set(result.columns) if result.columns else (set(result.records[0]) if result.records else set())
    rows = result.records
    for f in filters:
        if not isinstance(f, Mapping):
            raise FilterRefused("A filter was not readable (not an object). Refused rather than dropped.")
        column = str(f.get("column") or f.get("name") or "").strip()
        if not column or (cols and column not in cols):
            raise FilterRefused(
                f"The filter on '{column or '?'}' names a column this report's result does not have "
                f"({', '.join(sorted(cols)) or 'no columns known'}). Refused rather than dropped.")
        op = _norm_op(f.get("op") or f.get("operator"))
        value, value2 = _filter_value(f, op, column), f.get("value2", f.get("value_to"))
        if op == "between" and (value is None or value2 is None):
            raise FilterRefused(f"The range filter on '{column}' needs both ends. Refused rather than dropped.")
        rows = [r for r in rows if _compare(r.get(column), op, value, value2, column)]
    result.records = rows
    result.total_rows = len(rows)
    result.meta["filtered_by_framework"] = len(filters)
    return result


def apply_row_limit(result: SourceResult, row_limit: Optional[int], source: ReportSource) -> SourceResult:
    """A source that pushes filters down applied its cap itself.  For one that
    does not, the framework filtered the rows (rule 5) and caps them AFTER --
    a cap before the filter would return fewer rows than the truth.  0 / None
    = every row."""
    caps = source.capabilities
    if caps is not None and caps.filter_pushdown:
        return result
    if result.records is None or row_limit is None or int(row_limit) <= 0:
        return result
    limit = int(row_limit)
    if len(result.records) > limit:
        result.meta["row_limit"] = limit
        result.meta["truncated"] = True
        result.records = result.records[:limit]
        result.total_rows = limit
    else:
        result.meta.setdefault("row_limit", limit)
        result.meta.setdefault("truncated", False)
    return result


def _read_artifact_records(path: str) -> List[Dict[str, Any]]:
    import pyarrow.parquet as pq
    try:
        return pq.read_table(path).to_pylist()
    except Exception as exc:                              # noqa: BLE001
        raise FilterRefused(f"The result file could not be read to apply the filter ({exc}). "
                            "Refused rather than returning every row.") from exc


__all__ = ["FILTER_OPS", "apply_filters", "apply_row_limit", "attempts_for", "check_row_security",
           "governed_refs_of", "require_result", "verify_result"]
