"""A report on a REST API answering JSON -- the second source written only
against the contract (stage 5, 2026-11-07).

Where the data is, on the report::

    layout_config.source = {"connection_id": <a REST API connection>, "path": "/v1/trades?book={book}",
                            "records_path": "data.items"}      # optional: where the list is in the answer

The connection (type ``rest_api``, authored by an admin) holds the base URL,
the login, the proxy and SSL rules; the report adds only the path.  The read
goes through the SAME rules the REST connector applies (``core.url_safety``:
no private or loopback address; the response size cap; no redirects; the
connector's headers and rate limit).  ``{name}`` in the path is a report
parameter's value, URL-encoded.  The rows are the JSON list at
``records_path`` (or the answer itself when it is a list); nested values are
kept as JSON text (a column still exists; nothing is dropped).  The source
cannot filter, so the FRAMEWORK filters the rows (rule 5) and refuses what it
cannot apply.  Row security: ``none`` -- a policy naming ``rest:<host>/<path>``
refuses the run (rule 1).
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Mapping, Tuple
from urllib.parse import quote, urlparse

from core.report_framework.contract import (
    ROW_SECURITY_NONE, ReportSource, SourceCapabilities, SourceReadError, SourceRefused, SourceResult, SourceRun,
)

logger = logging.getLogger(__name__)

KIND = "rest_api"


def _source_of(report: Mapping[str, Any]) -> Dict[str, Any]:
    lc = report.get("layout_config") if isinstance(report, Mapping) else None
    src = (lc or {}).get("source") if isinstance(lc, Mapping) else None
    return dict(src) if isinstance(src, Mapping) else {}


def _connection(db: Any, connection_id: Any) -> Dict[str, Any]:
    try:
        cid = int(connection_id)
    except (TypeError, ValueError):
        raise SourceRefused("This REST report needs a connection: pick the REST API connection it reads.")
    if db is None or not hasattr(db, "get_connection_raw"):
        raise SourceReadError("The connection of this REST report could not be read here (no database).")
    conn = db.get_connection_raw(cid)
    if not conn:
        raise SourceRefused(f"The connection #{cid} of this REST report does not exist any more.")
    if str(conn.get("connection_type") or "").lower() != "rest_api":
        raise SourceRefused(
            f"The connection '{conn.get('name')}' is a {conn.get('connection_type')} connection; a REST report "
            "reads a REST API connection.")
    return conn


def _fill_path(path: str, params: Mapping[str, Any]) -> str:
    """``{name}`` -> the parameter's value, URL-encoded; a name with no value refuses."""
    out = path
    import re
    for name in re.findall(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", path):
        if name not in params or params.get(name) in (None, ""):
            raise SourceRefused(f"The REST report's path needs a value for '{name}' and none was given.")
        out = out.replace("{" + name + "}", quote(str(params[name]), safe=""))
    return out


def resolve_url(db: Any, report: Mapping[str, Any], params: Mapping[str, Any]) -> Tuple[Dict[str, Any], str]:
    """The connection and the full URL, checked by the connector's own rule (core.url_safety)."""
    src = _source_of(report)
    path = str(src.get("path") or "").strip()
    if not path:
        raise SourceRefused("This REST report needs the path to read on its connection (for example /v1/trades).")
    if "://" in path:
        raise SourceRefused("The REST report's path is a path on its connection, not a whole address.")
    conn = _connection(db, src.get("connection_id"))
    base = str((conn.get("config") or {}).get("base_url") or "").rstrip("/")
    if not base:
        raise SourceRefused(f"The connection '{conn.get('name')}' has no base URL.")
    url = base + ("" if path.startswith("/") else "/") + _fill_path(path, params or {})
    from core.url_safety import validate_url_safety
    try:
        validate_url_safety(url)
    except Exception as exc:                              # noqa: BLE001  (its own words)
        raise SourceRefused(f"This address cannot be read from here: {exc}") from exc
    return conn, url


def _records_at(answer: Any, records_path: str) -> List[Dict[str, Any]]:
    node = answer
    for part in [p for p in str(records_path or "").split(".") if p]:
        if isinstance(node, Mapping) and part in node:
            node = node[part]
        else:
            raise SourceReadError(f"The answer has nothing at '{records_path}'.")
    if isinstance(node, Mapping):
        node = [node]
    if not isinstance(node, list):
        raise SourceReadError("The answer is not a list of records" + (f" at '{records_path}'" if records_path else "") + ".")
    rows: List[Dict[str, Any]] = []
    for item in node:
        if not isinstance(item, Mapping):
            raise SourceReadError("An item of the answer is not an object with fields; the rows cannot be read.")
        rows.append({str(k): (v if isinstance(v, (str, int, float, bool)) or v is None else json.dumps(v, default=str))
                     for k, v in item.items()})
    return rows


class RestApiSource(ReportSource):
    kind = KIND
    label = "A REST API (JSON)"
    description = "The report reads the JSON list a REST API connection answers at a path."
    capabilities = SourceCapabilities(row_security=ROW_SECURITY_NONE, filter_pushdown=False, retry_safe=False,
                                      parameters=True, subscriptions=True, query_pods=False)

    def connection_ids(self, report: Mapping[str, Any]) -> List[Any]:
        return [_source_of(report).get("connection_id")]

    def governed_refs(self, report: Mapping[str, Any]) -> List[str]:
        src = _source_of(report)
        return [f"rest:{src.get('connection_id')}/{str(src.get('path') or '').lstrip('/')}"]

    def validate(self, report: Mapping[str, Any], db: Any) -> None:
        src = _source_of(report)
        path = str(src.get("path") or "")
        import re
        probe = {name: "x" for name in re.findall(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", path)}
        resolve_url(db, report, probe)

    def run(self, run: SourceRun, db: Any) -> SourceResult:
        conn, url = resolve_url(db, run.report, run.params)
        from core.connectors.rest_api_connector import RestApiConnector, _enforce_response_size
        import requests
        connector = RestApiConnector(dict(conn.get("config") or {}))
        try:
            connector._validate_url_safety(url)
            connector._rate_limit()
            resp = connector._session.get(url, headers=connector._build_headers(), timeout=connector.timeout,
                                          allow_redirects=False)
            _enforce_response_size(resp, url)
            if resp.status_code >= 300:
                raise SourceReadError(f"The API answered HTTP {resp.status_code} for {urlparse(url).path}.")
            try:
                answer = resp.json()
            except ValueError as exc:
                raise SourceReadError("The API's answer is not JSON.") from exc
        except SourceReadError:
            raise
        except requests.RequestException as exc:
            raise SourceReadError(f"The API could not be reached: {exc}") from exc
        finally:
            try:
                connector.close()
            except Exception:                             # noqa: BLE001
                pass
        rows = _records_at(answer, str(_source_of(run.report).get("records_path") or ""))
        columns: List[str] = []
        for r in rows:
            for k in r:
                if k not in columns:
                    columns.append(k)
        return SourceResult(records=rows, columns=columns, total_rows=len(rows),
                            meta={"read_by": f"the REST API connection '{conn.get('name')}'", "engine_name": "rest",
                                  "url_path": urlparse(url).path, "row_limit": run.row_limit})


SOURCE = RestApiSource()

__all__ = ["KIND", "RestApiSource", "SOURCE", "resolve_url"]
