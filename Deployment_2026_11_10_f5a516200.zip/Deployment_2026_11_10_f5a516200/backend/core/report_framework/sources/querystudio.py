"""QueryStudio's four report sources, wrapped as framework sources (stage 2, 2026-11-07).

The executor bodies MOVED here from ``core/reports/sources.py`` unchanged in what
they do (that module keeps every name and re-exports these); each is now the
``executor`` of a :class:`ReportSource` whose capabilities are DECLARED.  The
headless signature stays::

    fn(br, param_values, execution_id, output_dir, owner_ctx, db)
        -> (claimed_path | None, total_rows[, meta_dict])

Two defects the stage-0 baseline found in these roads are fixed HERE, where
every road now passes: a pod that never mounted the view routers (the
job-worker, the scheduler) binds them their database before a view runs
(:func:`_bind_view_routers`); and a published-view report under the product's
unlimited row limit (0) asks the view for "as much as allowed" through THE
view's own rule (``effective_page_limit``) instead of sending ``limit=0``,
which the view engine read as zero rows.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

from core.report_framework.contract import (
    ROW_SECURITY_BY_SOURCE, ReportSource, SourceCapabilities, SourceReadError, SourceResult, SourceRun,
)
from core.report_framework.registry import register_source
from core.reports.contract import ReportArtifactError

logger = logging.getLogger(__name__)


# ── the roads' plumbing on a pod that never mounted the routers ──────────────

def _bind_view_routers(db: Any) -> None:
    """The job-worker and the scheduler pod never mount the published-view and
    federation-view routers, so main.py never gave them their database: a
    scheduled published_view report died with ``'NoneType' object has no
    attribute 'get_connection_raw'`` (the stage-0 baseline).  Same answer as
    ``core.reports.from_sql._bind_routes``: give them the database this run
    was handed, only when they have none."""
    if db is None:
        return
    try:
        import api.published_views_api as pva
        if pva._db_manager is None:
            pva._db_manager = db
        if getattr(pva, "_pv_cfg", None) is None:
            from core.config import published_views as _pv_cfg
            pva._pv_cfg = _pv_cfg
    except Exception as exc:                              # noqa: BLE001
        logger.warning("[report-framework] published-view router not bound: %s", exc)
    try:
        import api.federation_views_api as fva
        if fva._db_manager is None:
            fva._db_manager = db
    except Exception as exc:                              # noqa: BLE001
        logger.warning("[report-framework] federation-view router not bound: %s", exc)
    # the published-view engine runs its SQL side through the EXECUTE router's
    # background runner (api.execute_api), whose database and paths main.py
    # sets: on the job-worker they were None ("'NoneType' object has no
    # attribute 'downloads_dir'", the stage-4 Docker compare)
    try:
        import api.execute_api as exa
        from core import config as _cfg
        if exa._db_manager is None:
            exa._db_manager = db
        if getattr(exa, "_paths", None) is None:
            exa._paths = _cfg.paths
        if getattr(exa, "_ws_manager", None) is None:
            # the execute router tells the browser about its run over a websocket; a
            # pod with no browser (the job-worker) gets a manager that says nothing
            exa._ws_manager = _NoBrowser()
        for name, value in (("_qe_cfg", getattr(_cfg, "query_engine", None)),
                            ("_limits_cfg", getattr(_cfg, "limits", None)),
                            ("_s3_config", getattr(_cfg, "s3", None))):
            if getattr(exa, name, None) is None and value is not None:
                setattr(exa, name, value)
    except Exception as exc:                              # noqa: BLE001
        logger.warning("[report-framework] execute router not bound: %s", exc)


class _NoBrowser:
    """A websocket manager for a pod no browser is attached to: every call is an
    async no-op (``broadcast_to_user``, ``broadcast``, ... -- whatever the
    execute router asks for)."""

    def __getattr__(self, name: str):
        if name.endswith("_sync"):
            return lambda *_a, **_k: None

        async def _nothing(*_a, **_k):
            return None
        return _nothing


def _pv_limit(pv: dict, row_limit: Optional[int]) -> int:
    """The limit a published-view report asks the view for: the VIEW's rule
    (``effective_page_limit``: 0 = as much as the view allows, unlimited when
    the view's max is unlimited) -- ``limit=0`` sent straight to the engine
    read as zero rows (the stage-0 baseline)."""
    from api.published_views.helpers import effective_page_limit
    return int(effective_page_limit(pv, row_limit))


# ── Built-in executors (moved from core/reports/sources.py) ──────────────────

def _exec_raw_sql(br: dict, param_values: dict, execution_id: str,
                  output_dir: Path, owner_ctx: Dict[str, Any], db,
                  ) -> Tuple[Optional[str], int]:
    """raw_sql source — the raw_sql engines (api.reports_api) via _as_legacy_report.

    The parquet engine writes the file we name; the SQL/cross-source engines
    write into the data-grid result store keyed by ``execution_id`` — we
    return ``None`` and let the verification chokepoint resolve the REAL
    location (previously callers were handed a phantom path that never
    existed for this branch).

    2026-09-07 — ``db=db`` IS FORWARDED.  Both engine entry points take an
    optional ``db`` and fall back to ``api.reports_api._db_manager``, a
    module global that only ``main.py``'s API startup sets.  This registry
    is the HEADLESS seam: it is reached from the scheduler worker and from
    subscription delivery, i.e. from processes that may never have run that
    startup — and it is handed a live ``db`` in its own signature, which it
    was then throwing away to fall back on a global that could be ``None``.
    """
    from api.reports_api import _run_parquet_report, _run_sql_report
    from api.business_reports_api import _as_legacy_report
    from core.parameters import (resolve_business_dates, seed_parameter_defaults,
                                 validate_param_values)

    legacy = _as_legacy_report(br)
    # 2026-09-26 (FB-60): this seam ran with NO default seeding and NO
    # validation -- a required parameter with a default (which the preflight
    # had approved) reached the SQL as an unsubstituted placeholder.  Same
    # rule as the interactive run and the preflight; a missing required
    # value is refused BY NAME so the schedule/subscription records why.
    schema = legacy.get("parameters") or []
    param_values = resolve_business_dates(
        seed_parameter_defaults(schema, param_values))
    errors = validate_param_values(schema, param_values)
    if errors:
        raise ValueError("Parameter validation failed: " + "; ".join(errors))
    noop_emit = lambda _msg: None  # noqa: E731
    if legacy["saved_query_id"]:
        output_path = str(Path(output_dir) / f"{execution_id}.parquet")
        total = _run_parquet_report(legacy, param_values, None, output_path,
                                    noop_emit, user_ctx=owner_ctx, db=db)
        return output_path, int(total or 0)
    if legacy["sql_saved_query_id"] or legacy.get("sql_override"):
        total = _run_sql_report(legacy, param_values, None, execution_id,
                                noop_emit, user_ctx=owner_ctx, db=db)
        return None, int(total or 0)   # artifact lives in the result store
    raise ValueError(f"Business report {br.get('id')} (raw_sql) has no source configured")


def _exec_federation(br: dict, param_values: dict, execution_id: str,
                     output_dir: Path, owner_ctx: Dict[str, Any], db,
                     ) -> Tuple[Optional[str], int]:
    """saved_query / federation_view / published_view — FederationEngine path."""
    from api.business_reports_api import (
        _build_report_filters, _build_source_bindings, _require_federation, _run_report_query,
    )
    fed = _require_federation()
    combined_filters = _build_report_filters(br, param_values, db, br["id"])
    # 2026-10-29 -- the report's SOURCE parameters (filter at the source), as
    # the engine's own argument, never inside the filter list
    source_bindings = _build_source_bindings(br, param_values, db, br["id"])
    # 2026-08-05 audit: parity with the interactive path — /execute caps at
    # business_reports.default_row_limit (500K) when the report sets no
    # row_limit, while this hardcoded 50000 silently made the SCHEDULED
    # file 10x shorter than the same report run interactively.
    from core import config as _cfg
    # 2026-08-13 -- through the SHARED resolver, not another ``or`` chain.
    # The 2026-08-05 note above fixed a hardcoded 50000 that made scheduled
    # files 10x shorter than interactive; the replacement kept the ``or``
    # idiom, which folds an explicit ``row_limit: 0`` (UNLIMITED) back into
    # the 500K default -- the same silent clipping in a new spelling, and
    # the scheduled path is where nobody is watching the row count.
    from api.business_reports_api import _resolve_report_row_limit
    row_limit = _resolve_report_row_limit(None, br, _cfg)
    result = _run_report_query(
        fed, br, combined_filters, row_limit, execution_id,
        owner_ctx.get("role") or "viewer", user_ctx=owner_ctx,
        source_bindings=source_bindings,
    )
    res = result.to_dict() if hasattr(result, "to_dict") else result
    # 2026-08-09 (D1 follow-up): surface the engine-stamped EFFECTIVE
    # row_limit + truncation verdict (FederationResult.to_dict emits them
    # only when stamped).  Fall back to the limit we REQUESTED — still
    # strictly better than br.row_limit alone, which is None whenever the
    # default_row_limit fill-in above applied.
    meta = {
        "row_limit": res.get("row_limit") or row_limit,
        "truncated": res.get("truncated"),
        # D1/D2 (2026-08-09 cross-feature review): the no-ORDER-BY-cut
        # disclosure must survive into the recorded instance, or every
        # serve of a pre-warmed artifact silently drops it.
        "unstable_truncation": res.get("unstable_truncation"),
        # 2026-10-30 -- what the run USED, for its Diagnostics record
        # (execute_headless -> diagnostics.record_report_run)
        "diag_filters": combined_filters,
        "diag_bindings": source_bindings,
        "diag_result": res,
    }
    return (res.get("output_path") or None), int(res.get("total_rows") or 0), meta


# ── PV / FV headless executors (2026-08-30) ─────────────────────────────────
#
# These two source types were registered to an honest refusal ("cannot run
# headlessly … interactive-only") because their engines are ASYNC page-
# envelope producers.  The capability always existed — the interactive path
# in api.business_reports_api executes both — so this is the bridge, not a
# new engine: same engines, same artifact helper, dispatched through this
# registry so scheduler and subscription delivery pick them up with zero
# edits and identical RLS scope.

def _run_coro_headless(coro):
    """Bridge an ASYNC view engine into the SYNC headless worker context.

    Every production headless caller (core.scheduler worker thread,
    core.delivery_engine via run_business_report_to_df) runs in a plain
    thread with NO event loop, so ``asyncio.run`` is the correct bridge —
    it creates a fresh loop, sets it as the thread's current loop for the
    duration (matching the manual ``new_event_loop``/``set_event_loop``
    pattern federation_views_api's materializer already uses) and tears it
    down.

    Defensive branch: if a future caller invokes execute_headless ON a
    thread whose loop is RUNNING (a sync call made from coroutine context),
    ``asyncio.run`` would raise "cannot be called from a running event
    loop" — instead the coroutine runs to completion on a private worker
    thread with its own loop.  That blocks the calling thread exactly as
    any sync call from a loop thread already does; it never nests or
    re-enters the caller's loop.
    """
    import asyncio
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    import concurrent.futures
    with concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="br-headless-bridge") as pool:
        return pool.submit(asyncio.run, coro).result()


def _require_owner_principal(br: dict, owner_ctx: Dict[str, Any]) -> Dict[str, Any]:
    """SECURITY — refuse a headless view run with no resolved principal.

    Both view engines have a FALLBACK principal for missing identities, and
    the PV one is WIDER than a refusal: ``_execute_view`` with an empty
    consumer ctx falls back to a synthetic ``pv:<slug>`` principal carrying
    ``groups=allowed_ad_groups`` and NO ``rls_unresolved`` marker — in this
    GRANT-shaped RLS engine an unmarked principal that matches no policy
    binding reads governed tables UNFILTERED (the escalation shape this
    codebase has shipped twice).  A username-less owner_ctx therefore
    REFUSES here, before any engine sees it.  A ctx that carries a username
    plus ``rls_unresolved=True`` is passed through untouched — the
    row-security rewriter turns that marker into a per-governed-table
    refusal, which is the intended fail-closed degradation.
    """
    if not isinstance(owner_ctx, dict) or not str(owner_ctx.get("username") or "").strip():
        raise ValueError(
            f"Business report {br.get('id')}: headless view execution refused "
            "— no resolved owner principal (owner_ctx carries no username). "
            "Running anyway would fall back to an unscoped engine principal "
            "and bypass row security (fail-closed)."
        )
    return owner_ctx


def _finish_view_execution(db, br: dict, result: Any,
                           owner_ctx: Dict[str, Any], execution_id: str,
                           row_limit: Optional[int],
                           ) -> Tuple[str, int, Dict[str, Any]]:
    """Shared PV/FV tail: verified artifact + truncation meta (fail-CLOSED).

    The interactive path persists the inline result through
    ``business_reports_api._persist_inline_result_artifact`` fail-OPEN (the
    artifact is additive there — the inline rows still reach the viewer).
    Headless has NO inline consumer: the artifact IS the deliverable, so a
    persist failure here is a run failure, never a silent success.
    """
    from api.business_reports_api import _persist_inline_result_artifact
    from core.reports.contract import resolve_cap

    res = result if isinstance(result, dict) else {}
    artifact_path = _persist_inline_result_artifact(
        db, br, res, str(owner_ctx.get("username") or ""), execution_id)
    if not artifact_path:
        raise ReportArtifactError(
            f"Business report {br.get('id')} ({br.get('data_source_type')}) "
            f"execution {execution_id} produced no persistable result artifact "
            "— the view engine returned no materialised rows or the artifact "
            "write failed (see the preceding warning log). Refusing to report "
            "success without the file delivery would ship."
        )
    meta = {
        # resolve_cap: first PRESENT cap wins — an engine-stamped 0
        # (unlimited) must not be folded into the requested cap by ``or``.
        "row_limit": resolve_cap(res.get("row_limit"), row_limit),
        "truncated": res.get("truncated"),
        "unstable_truncation": res.get("unstable_truncation"),
    }
    return artifact_path, int(res.get("total_rows") or 0), meta


def _exec_federation_view(br: dict, param_values: dict, execution_id: str,
                          output_dir: Path, owner_ctx: Dict[str, Any], db,
                          ) -> Tuple[Optional[str], int, Dict[str, Any]]:
    """federation_view source — the SAME engine the interactive path uses.

    Mirrors api.business_reports_api.execute_report's FV branch:
    ``execute_federation_view`` with the shared row-limit resolver, then the
    shared inline→parquet artifact helper (here fail-closed — see
    :func:`_finish_view_execution`).  ``param_values`` are deliberately not
    threaded: the interactive FV branch does not map report parameters into
    the view either, and headless must not silently mean something different
    from interactive.  IDENTITY: ``owner_ctx`` is passed as ``user_ctx``,
    which ``federation_views_api._fv_principal`` uses AS-IS on every side —
    the owner's username/role/groups (and any ``rls_unresolved`` marker)
    reach the row-security rewriter exactly as on the other headless paths.
    """
    from api.business_reports_api import _resolve_report_row_limit
    from api.federation_views_api import execute_federation_view
    from core import config as _cfg

    _require_owner_principal(br, owner_ctx)
    _bind_view_routers(db)
    fv_id = br.get("federation_view_id")
    if not fv_id:
        raise ValueError(
            f"Business report {br.get('id')} has data_source_type="
            "'federation_view' but no federation_view_id — it cannot run "
            "headlessly (or interactively) until the view reference is "
            "configured."
        )
    fv = db.get_federation_view(fv_id)
    if not fv:
        raise ValueError(
            f"Business report {br.get('id')}: federation view {fv_id} not found"
        )
    row_limit = _resolve_report_row_limit(None, br, _cfg)
    result = _run_coro_headless(execute_federation_view(
        fv, limit=row_limit,
        username=str(owner_ctx.get("username") or ""),
        user_ctx=owner_ctx,
    ))
    return _finish_view_execution(db, br, result, owner_ctx, execution_id,
                                  row_limit)


def _exec_published_view(br: dict, param_values: dict, execution_id: str,
                         output_dir: Path, owner_ctx: Dict[str, Any], db,
                         ) -> Tuple[Optional[str], int, Dict[str, Any]]:
    """published_view source — the SAME handler the interactive path uses.

    Mirrors api.business_reports_api.execute_report's PV branch: the
    config gate, the active check, ``_map_report_params_to_pv`` for report
    parameters, ``_execute_view`` for execution, the shared artifact helper
    (fail-closed here).  IDENTITY: ``owner_ctx`` is passed as
    ``consumer_user`` — the report OWNER's resolved principal, exactly the
    RLS identity every other headless source runs under; the PV handlers
    stash it as ``_consumer_user_ctx`` and thread it into ``secure_sql`` /
    the engine's SQL-build site, where an ``rls_unresolved`` marker refuses
    governed tables instead of reading them unfiltered.
    """
    from api.business_reports_api import (
        _map_report_params_to_pv, _resolve_report_row_limit,
    )
    from api.published_views_api import _execute_view
    from core import config as _cfg

    _require_owner_principal(br, owner_ctx)
    _bind_view_routers(db)
    pv_id = br.get("published_view_id")
    if not pv_id:
        raise ValueError(
            f"Business report {br.get('id')} has data_source_type="
            "'published_view' but no published_view_id — it cannot run "
            "headlessly (or interactively) until the view reference is "
            "configured."
        )
    if not _cfg.business_reports.enable_published_view_source:
        raise ValueError(
            f"Business report {br.get('id')}: Published View data source is "
            "disabled by configuration (business_reports."
            "enable_published_view_source)"
        )
    pv = db.get_published_view(pv_id)
    if not pv:
        raise ValueError(
            f"Business report {br.get('id')}: published view {pv_id} not found"
        )
    if not pv.get("is_active"):
        raise ValueError(
            f"Business report {br.get('id')}: published view {pv_id} is inactive"
        )
    pv_params = _map_report_params_to_pv(br, param_values or {}, db, br.get("id"))
    row_limit = _resolve_report_row_limit(None, br, _cfg)
    result = _run_coro_headless(_execute_view(
        pv=pv, filters=[], columns=None,
        sort_column=None, sort_dir="asc",
        limit=_pv_limit(pv, row_limit), offset=0, params=pv_params,
        consumer_user=owner_ctx,
    ))
    return _finish_view_execution(db, br, result, owner_ctx, execution_id,
                                  row_limit)


# ── the four sources ─────────────────────────────────────────────────────────

def _result_of_executor(out: Any) -> SourceResult:
    """The executor's ``(path, total[, meta])`` as a SourceResult."""
    if not isinstance(out, (tuple, list)) or len(out) < 2:
        raise SourceReadError(f"the executor returned {type(out).__name__}, not (path, total_rows[, meta])")
    meta = out[2] if len(out) > 2 and isinstance(out[2], dict) else {}
    return SourceResult(artifact_path=out[0], total_rows=int(out[1] or 0), meta=dict(meta))


class QueryStudioSource(ReportSource):
    """A source whose read is one of QueryStudio's executors."""

    executor: Any = None

    def run(self, run: SourceRun, db: Any) -> SourceResult:
        fn = type(self).executor
        if fn is None:
            raise SourceReadError(f"the source '{self.kind}' has no executor")
        return _result_of_executor(fn(dict(run.report), dict(run.params), run.execution_id,
                                      Path(run.output_dir), dict(run.principal), db))

    def governed_refs(self, report: Mapping[str, Any]) -> List[str]:
        return [f"report:{report.get('id')}"]


class DatasetSource(QueryStudioSource):
    kind = "saved_query"
    label = "A dataset"
    description = "The report reads a QueryStudio dataset through its own engine."
    capabilities = SourceCapabilities(row_security=ROW_SECURITY_BY_SOURCE, filter_pushdown=True, retry_safe=False,
                                      parameters=True, subscriptions=True, query_pods=True)
    executor = staticmethod(_exec_federation)


class RawSqlSource(QueryStudioSource):
    kind = "raw_sql"
    label = "Your own SQL"
    description = "The report runs a saved SQL query or a SQL file on its connection."
    capabilities = SourceCapabilities(row_security=ROW_SECURITY_BY_SOURCE, filter_pushdown=True, retry_safe=False,
                                      parameters=True, subscriptions=True, query_pods=True)
    executor = staticmethod(_exec_raw_sql)


class PublishedViewSource(QueryStudioSource):
    kind = "published_view"
    label = "A published API"
    description = "The report reads a published API's rows."
    capabilities = SourceCapabilities(row_security=ROW_SECURITY_BY_SOURCE, filter_pushdown=True, retry_safe=False,
                                      parameters=True, subscriptions=True, query_pods=False)
    executor = staticmethod(_exec_published_view)


class FederationViewSource(QueryStudioSource):
    kind = "federation_view"
    label = "A cross-connection view"
    description = "The report reads a view that joins or unions two connections."
    capabilities = SourceCapabilities(row_security=ROW_SECURITY_BY_SOURCE, filter_pushdown=False, retry_safe=False,
                                      parameters=False, subscriptions=True, query_pods=False)
    executor = staticmethod(_exec_federation_view)


QUERYSTUDIO_SOURCES = (DatasetSource, RawSqlSource, PublishedViewSource, FederationViewSource)

#: executor function -> the source it belongs to (so a table restored from
#: ``dict(_SOURCE_EXECUTORS)`` puts back the SAME declared source)
EXECUTOR_SOURCE: Dict[Any, type] = {cls.executor: cls for cls in QUERYSTUDIO_SOURCES}


def register_all() -> None:
    """Register (or re-register) QueryStudio's four sources."""
    for cls in QUERYSTUDIO_SOURCES:
        register_source(cls())


register_all()

__all__ = [
    "DatasetSource", "EXECUTOR_SOURCE", "FederationViewSource", "PublishedViewSource", "QUERYSTUDIO_SOURCES",
    "QueryStudioSource", "RawSqlSource", "register_all", "_bind_view_routers", "_exec_federation",
    "_exec_federation_view", "_exec_published_view", "_exec_raw_sql", "_finish_view_execution", "_pv_limit",
    "_require_owner_principal", "_run_coro_headless",
]
