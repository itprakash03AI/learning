"""The sources every QueryStudio process registers, and the third party's.

ONE road for both: the built-in modules are loaded by the same loader a
plugin is (``plugins.load_source_plugins``), then the configuration's
``report_framework.source_plugins``.  Called by ``core.reports.sources`` at
import (every process that runs a report: the API, the pods, the job-worker,
the scheduler) and by the host's ``install()``; idempotent.
"""
from __future__ import annotations

import logging
import threading
from typing import Any, Dict

from core.report_framework import plugins

logger = logging.getLogger(__name__)

#: the sources that ship with the product, by module path (each exposes SOURCE)
BUILTIN_SOURCE_MODULES = (
    "core.report_framework.sources.file_source",
    "core.report_framework.sources.rest_source",
)

_LOCK = threading.RLock()
_DONE: Dict[str, Any] = {}


def register_builtin(*, with_config: bool = True) -> Dict[str, Any]:
    """Register the built-in sources (once) and the configured plugins (once).
    Returns what was loaded and what could not be."""
    with _LOCK:
        if "builtin" not in _DONE:
            _DONE["builtin"] = plugins.load_source_plugins(list(BUILTIN_SOURCE_MODULES))
            for problem in _DONE["builtin"].get("problems") or []:
                logger.error("[report-framework] a built-in source did not load: %s", problem)
        if with_config and "config" not in _DONE:
            _DONE["config"] = plugins.load_from_config()
        return {"builtin": _DONE.get("builtin"), "config": _DONE.get("config")}


def _reset_for_tests() -> None:
    with _LOCK:
        _DONE.clear()


__all__ = ["BUILTIN_SOURCE_MODULES", "register_builtin"]
