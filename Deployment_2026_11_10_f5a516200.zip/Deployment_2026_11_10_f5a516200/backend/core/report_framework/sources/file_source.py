"""A report on a FILE (CSV or Parquet), read by DuckDB -- the first source
written only against the contract (stage 5, 2026-11-07), nothing of
QueryStudio's engine on its path.

Where the data is, on the report::

    layout_config.source = {"connection_id": <a LOCAL connection>, "path": "folder/file.csv"}

The path is RELATIVE to the connection's ``base_path`` and must stay inside it
(a path that climbs out is refused at save and at run); the format is the
file's extension through ``core.file_formats`` (CSV, Parquet).  Filters are
pushed into DuckDB's WHERE (rule 5 inside the source: an operator this source
does not know REFUSES); the row limit is DuckDB's LIMIT; the result is the
run's parquet file.  Row security: ``none`` -- a row-security policy naming
this file (``file:<connection>/<path>``) refuses the run (rule 1).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

from core.report_framework.contract import (
    ROW_SECURITY_NONE, ColumnInfo, FilterRefused, ReportSource, SourceCapabilities, SourceReadError,
    SourceRefused, SourceResult, SourceRun,
)

logger = logging.getLogger(__name__)

KIND = "file"
FORMATS = {".csv", ".parquet", ".pq"}
_OPS = {"eq": "=", "ne": "<>", "gt": ">", "gte": ">=", "lt": "<", "lte": "<="}
_OP_ALIASES = {"=": "eq", "==": "eq", "!=": "ne", "<>": "ne", ">": "gt", ">=": "gte", "<": "lt", "<=": "lte",
               "not in": "not_in", "is null": "is_null", "is not null": "is_not_null", "equals": "eq"}


def _source_of(report: Mapping[str, Any]) -> Dict[str, Any]:
    lc = report.get("layout_config") if isinstance(report, Mapping) else None
    src = (lc or {}).get("source") if isinstance(lc, Mapping) else None
    return dict(src) if isinstance(src, Mapping) else {}


def _connection(db: Any, connection_id: Any) -> Dict[str, Any]:
    try:
        cid = int(connection_id)
    except (TypeError, ValueError):
        raise SourceRefused("This file report needs a connection: pick the folder connection that holds the file.")
    if db is None or not hasattr(db, "get_connection_raw"):
        raise SourceReadError("The connection of this file report could not be read here (no database).")
    conn = db.get_connection_raw(cid)
    if not conn:
        raise SourceRefused(f"The connection #{cid} of this file report does not exist any more.")
    if str(conn.get("connection_type") or "").lower() != "local":
        raise SourceRefused(
            f"The connection '{conn.get('name')}' is a {conn.get('connection_type')} connection; a file report "
            "reads a FOLDER connection (type: local).")
    return conn


def resolve_file(db: Any, report: Mapping[str, Any]) -> Tuple[Dict[str, Any], Path]:
    """The connection and the absolute file path, both checked: inside the
    folder, a known format, present."""
    src = _source_of(report)
    rel = str(src.get("path") or "").strip().replace("\\", "/")
    if not rel:
        raise SourceRefused("This file report needs the file's path inside its folder connection (for example data/sales.csv).")
    conn = _connection(db, src.get("connection_id"))
    raw_base = str((conn.get("config") or {}).get("base_path") or "").strip()
    # review 2026-11-07: Path("").resolve() is the SERVER's working directory, so an
    # empty base folder must be refused BEFORE it is resolved
    if not raw_base:
        raise SourceRefused(f"The connection '{conn.get('name')}' has no base folder (base_path), so a file "
                            "report cannot read from it. Set its folder first.")
    base = Path(raw_base).resolve()
    full = (base / rel).resolve()
    try:
        full.relative_to(base)
    except ValueError:
        raise SourceRefused(f"The path '{rel}' leaves the folder of connection '{conn.get('name')}'. Refused.")
    if full.suffix.lower() not in FORMATS:
        raise SourceRefused(f"'{rel}' is not a CSV or Parquet file; a file report reads one of: {', '.join(sorted(FORMATS))}.")
    if not full.is_file():
        raise SourceRefused(f"The file '{rel}' was not found in the folder of connection '{conn.get('name')}'.")
    return conn, full


def _read_expr(path: Path) -> str:
    from core.file_formats import get_format_adapter
    return get_format_adapter(str(path)).duckdb_read_expr(path.as_posix())


def _where(filters: List[Dict[str, Any]], columns: List[str]) -> Tuple[str, list]:
    """The filters as ONE DuckDB WHERE with bound parameters; what cannot be
    rendered refuses (a dropped filter would return more rows)."""
    clauses: List[str] = []
    params: list = []
    known = {c.lower(): c for c in columns}
    for f in filters or []:
        if not isinstance(f, Mapping):
            raise FilterRefused("A filter was not readable (not an object). Refused rather than dropped.")
        column = str(f.get("column") or f.get("name") or "").strip()
        if column.lower() not in known:
            raise FilterRefused(f"The filter on '{column or '?'}' names a column the file does not have "
                                f"({', '.join(columns)}). Refused rather than dropped.")
        col = '"' + known[column.lower()].replace('"', '""') + '"'
        op = str(f.get("op") or f.get("operator") or "eq").strip().lower()
        op = _OP_ALIASES.get(op, op)
        value, value2 = f.get("value"), f.get("value2", f.get("value_to"))
        if op in _OPS:
            clauses.append(f"{col} {_OPS[op]} ?")
            params.append(value)
        elif op in ("in", "not_in"):
            if value is None:
                value = f.get("values")
            values = list(value) if isinstance(value, (list, tuple, set)) else ([] if value is None else [value])
            if not values:
                raise FilterRefused(f"The list filter on '{column}' has no values. Refused rather than dropped.")
            clauses.append(f"{col} {'NOT ' if op == 'not_in' else ''}IN ({', '.join('?' for _ in values)})")
            params.extend(values)
        elif op == "between":
            if value is None or value2 is None:
                raise FilterRefused(f"The range filter on '{column}' needs both ends. Refused rather than dropped.")
            clauses.append(f"{col} BETWEEN ? AND ?")
            params.extend([value, value2])
        elif op == "is_null":
            clauses.append(f"{col} IS NULL")
        elif op == "is_not_null":
            clauses.append(f"{col} IS NOT NULL")
        else:
            raise FilterRefused(f"The filter operator '{f.get('op')}' is not one a file report can apply. "
                                "Refused rather than dropped.")
    return (" WHERE " + " AND ".join(clauses)) if clauses else "", params


class FileSource(ReportSource):
    kind = KIND
    label = "A file (CSV or Parquet)"
    description = "The report reads one CSV or Parquet file from a folder connection."
    capabilities = SourceCapabilities(row_security=ROW_SECURITY_NONE, filter_pushdown=True, retry_safe=True,
                                      parameters=False, subscriptions=True, query_pods=False)

    def connection_ids(self, report: Mapping[str, Any]) -> List[Any]:
        return [_source_of(report).get("connection_id")]

    def governed_refs(self, report: Mapping[str, Any]) -> List[str]:
        src = _source_of(report)
        return [f"file:{src.get('connection_id')}/{str(src.get('path') or '').replace(chr(92), '/')}"]

    def validate(self, report: Mapping[str, Any], db: Any) -> None:
        resolve_file(db, report)

    def columns(self, report: Mapping[str, Any], principal: Mapping[str, Any], db: Any) -> List[ColumnInfo]:
        _, path = resolve_file(db, report)
        import duckdb
        con = duckdb.connect()
        try:
            rows = con.execute(f"DESCRIBE SELECT * FROM {_read_expr(path)}").fetchall()
        finally:
            con.close()
        return [ColumnInfo(name=str(r[0]), data_type=str(r[1]).lower()) for r in rows]

    def run(self, run: SourceRun, db: Any) -> SourceResult:
        conn, path = resolve_file(db, run.report)
        import duckdb
        out = Path(run.output_dir) / f"{run.execution_id}.parquet"
        out.parent.mkdir(parents=True, exist_ok=True)
        con = duckdb.connect()
        try:
            expr = _read_expr(path)
            cols = [str(r[0]) for r in con.execute(f"DESCRIBE SELECT * FROM {expr}").fetchall()]
            where, params = _where(list(run.filters or []), cols)
            limit = int(run.row_limit or 0)
            total = con.execute(f"SELECT count(*) FROM {expr}{where}", params).fetchone()[0]
            sql = f"COPY (SELECT * FROM {expr}{where}{' LIMIT ' + str(limit) if limit > 0 else ''}) TO '{out.as_posix()}' (FORMAT PARQUET)"
            con.execute(sql, params)
        except FilterRefused:
            raise
        except duckdb.Error as exc:
            raise SourceReadError(f"The file '{path.name}' could not be read: {exc}") from exc
        finally:
            con.close()
        written = min(total, limit) if limit > 0 else total
        return SourceResult(artifact_path=str(out), columns=cols, total_rows=int(written),
                            meta={"row_limit": limit, "truncated": bool(limit > 0 and total > limit),
                                  "read_by": "DuckDB on the file", "engine_name": "duckdb",
                                  "file": path.name, "connection": conn.get("name")})


SOURCE = FileSource()

__all__ = ["FORMATS", "KIND", "FileSource", "SOURCE", "resolve_file"]
