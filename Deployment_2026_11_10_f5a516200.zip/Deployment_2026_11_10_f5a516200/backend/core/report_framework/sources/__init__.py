"""The SOURCES layer of the report framework: each module wraps what it reads
and may import it (QueryStudio's four import the engine and the host's route
helpers; a file source imports DuckDB; a REST source the connector rules).
Not the framework layer: the import guard skips this package by name.
"""
