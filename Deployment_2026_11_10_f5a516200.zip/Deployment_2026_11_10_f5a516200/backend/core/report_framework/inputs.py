"""What a run of a framework source may be GIVEN: its parameters and its filters,
decided once for every road (on screen, async, share / embed / export, a
schedule, the published API).  Review of 2026-11-07, before merge.

Before this module the generic road handed the viewer's raw
``parameter_values`` to the source and ignored the report's saved filters:

* a hidden parameter (the author's scope, ``visible: false``) could be
  overridden by any viewer who sent a value for it -- the bypass the
  2026-11-01 security review closed for dataset reports;
* a name the report does not declare reached the source (a REST path token
  the author never offered could be filled by a caller);
* a saved filter, or a parameter bound to a result column, was simply not
  applied, and the run returned MORE rows than the report means.

The rules here are the dataset roads' own (``core.reports.param_contract``):
``run_value`` (a parameter that is not shown runs with its default and a
sent value is ignored), ``validation_problems``, and an unknown name
refused.  What a framework source cannot apply is REFUSED, never dropped.
"""
from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from core.report_framework.contract import FilterRefused, ReportSource, SourceRefused

#: a parameter target a framework source can be handed (a path / SQL token, or no target)
_PASSABLE_TARGETS = ("token", "api")


def saved_filter_problem(report: Mapping[str, Any]) -> Optional[str]:
    """A sentence when the report carries saved filters a framework source
    cannot apply (they name dataset columns), else None."""
    specs = report.get("filter_specs") if isinstance(report, Mapping) else None
    if isinstance(specs, (list, tuple)) and any(s for s in specs):
        return ("This report has saved filters, and its source cannot apply them: they would be ignored "
                "and the report would show more rows than it should. Remove the saved filters, or filter "
                "in the source itself.")
    return None


def bound_parameter_problems(params: Sequence[Mapping[str, Any]]) -> List[str]:
    """One sentence per parameter bound to a result column or a source condition
    (a framework source has neither)."""
    from core.reports.param_contract import targets_of
    out: List[str] = []
    for p in params or []:
        if not isinstance(p, Mapping):
            continue
        bad = [t for t in targets_of(dict(p)) if str(t.get("to") or "") not in _PASSABLE_TARGETS]
        if bad:
            who = str(p.get("label") or p.get("name") or "?")
            out.append(f"The parameter '{who}' filters a column, and this report's source cannot apply that "
                       "filter: it would be ignored and the report would show more rows than it should.")
    return out


def definition_problems(source: ReportSource, report: Mapping[str, Any],
                        params: Sequence[Mapping[str, Any]]) -> List[str]:
    """Everything about a saved report a framework source could not honour."""
    out: List[str] = []
    p = saved_filter_problem(report)
    if p:
        out.append(p)
    out.extend(bound_parameter_problems(params))
    return out


def prepare(source: ReportSource, report: Mapping[str, Any], declared: Sequence[Mapping[str, Any]],
            sent: Optional[Mapping[str, Any]], *, strict_names: bool,
            resolve_value=None) -> Dict[str, Any]:
    """The parameter values the source is handed, by the dataset roads' rules.

    ``declared``: the report's parameters as the run reads them.  ``sent``:
    what the caller sent.  ``strict_names``: refuse a name the report does
    not declare (on screen, share / embed / export, a schedule); a published
    API passes its VIEW's vocabulary, so there an undeclared name is ignored
    -- and never handed on.  Raises :class:`SourceRefused` /
    :class:`FilterRefused` in plain words."""
    from core.reports.param_contract import run_value, validation_problems
    declared = [dict(p) for p in (declared or []) if isinstance(p, Mapping) and p.get("name")]
    problems = definition_problems(source, report, declared)
    if problems:
        raise FilterRefused(" ".join(problems))
    sent = dict(sent or {})
    names = {str(p["name"]) for p in declared}
    if strict_names:
        unknown = sorted(str(k) for k in sent if str(k) not in names)
        if unknown:
            raise SourceRefused(
                f"Unknown parameter(s): {', '.join(u[:60] for u in unknown[:10])}. Valid parameters for this "
                f"report: {', '.join(sorted(names)) or '(this report declares no parameters)'}.")
    out: Dict[str, Any] = {}
    for p in declared:
        value = run_value(p, sent, declared)
        bad = validation_problems(p, value, sent)
        if bad:
            raise SourceRefused(" ".join(bad))
        if value is None or value == "":
            if p.get("is_required"):
                raise SourceRefused(f"{p.get('label') or p['name']} needs a value.")
            continue
        out[str(p["name"])] = resolve_value(value) if callable(resolve_value) else value
    return out


def passable_filters(filters: Any) -> List[Dict[str, Any]]:
    """The run-time filters as a list, or a refusal when they are not readable."""
    if filters is None:
        return []
    if not isinstance(filters, (list, tuple)):
        raise FilterRefused("The filters of this run were not readable. Refused rather than dropped.")
    return [dict(f) if isinstance(f, Mapping) else f for f in filters]


__all__ = ["bound_parameter_problems", "definition_problems", "passable_filters", "prepare",
           "saved_filter_problem"]
