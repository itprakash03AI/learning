"""The ONE answer to "which source holds this report's data".

Every reader of ``data_source_type`` that decides anything goes through here:
the screen, the headless runner, the published API, the subscription gate, the
retry declaration.  An unregistered kind is refused with a sentence that names
the kinds that exist (never a silent default).

Roads.  A source runs through the framework's generic road (``run`` into a
``SourceResult``).  A HOST may attach its own road for a source on a surface
(``attach_road``) -- QueryStudio's route module attaches the on-screen bodies
of its four sources, moved there unchanged -- and the route asks ``road_for``
first.  The decision "which source" is still made here, once.
"""
from __future__ import annotations

import logging
import threading
from typing import Any, Callable, Dict, List, Optional

from core.report_framework.contract import (
    ReportFrameworkError, ReportSource, SourceCapabilities, UnknownSourceError,
)

logger = logging.getLogger(__name__)

#: second spellings of a registered kind (FB-46: ``dataset`` is the builder's
#: word for a dataset-backed report; the stored canonical spelling is saved_query)
SOURCE_TYPE_ALIASES: Dict[str, str] = {"dataset": "saved_query"}
DEFAULT_KIND = "saved_query"

_SOURCES: Dict[str, ReportSource] = {}
_ROADS: Dict[tuple, Callable[..., Any]] = {}
_LOCK = threading.RLock()


def canonical_source_type(source_type: Optional[str]) -> str:
    """The registry's spelling of ``source_type`` (empty -> saved_query)."""
    dst = str(source_type or DEFAULT_KIND).strip().lower() or DEFAULT_KIND
    return SOURCE_TYPE_ALIASES.get(dst, dst)


def register_source(source: ReportSource, *, replace: bool = True) -> ReportSource:
    """Register a source.  Its kind, label and capabilities must be DECLARED."""
    kind = str(getattr(source, "kind", "") or "").strip().lower()
    if not kind or kind != canonical_source_type(kind):
        raise ReportFrameworkError(
            f"A report source needs a kind (lower case, not an alias); got {getattr(source, 'kind', None)!r}.")
    if not str(getattr(source, "label", "") or "").strip():
        raise ReportFrameworkError(f"The source '{kind}' needs a label in plain words.")
    caps = getattr(source, "capabilities", None)
    if not isinstance(caps, SourceCapabilities):
        raise ReportFrameworkError(
            f"The source '{kind}' must declare its capabilities (SourceCapabilities), it declared {caps!r}.")
    if not callable(getattr(source, "run", None)):
        raise ReportFrameworkError(f"The source '{kind}' has no run().")
    with _LOCK:
        if kind in _SOURCES and not replace:
            raise ReportFrameworkError(f"A source '{kind}' is already registered.")
        _SOURCES[kind] = source
    return source


def unregister_source(kind: str) -> None:
    """Forget a source.  The HOST's roads for the kind stay: they are the
    host's wiring for that kind, not the source object's, and a source
    registered again under the kind (a test restoring the table, a plugin
    reloaded) runs on them again; ``road_for`` refuses while no source holds
    the kind."""
    with _LOCK:
        _SOURCES.pop(canonical_source_type(kind), None)


def is_registered(kind: Optional[str]) -> bool:
    return canonical_source_type(kind) in _SOURCES


def source_for(kind: Optional[str]) -> ReportSource:
    """The source for a kind, or :class:`UnknownSourceError` naming the kinds that exist."""
    dst = canonical_source_type(kind)
    src = _SOURCES.get(dst)
    if src is None:
        raise UnknownSourceError(
            f"This report's source '{dst}' is not known here, so it cannot run. "
            f"Sources known: {describe_sources()}.")
    return src


def source_of_report(report: Any) -> ReportSource:
    """The source of a report dict (``data_source_type``) -- the ONE reader."""
    dst = report.get("data_source_type") if isinstance(report, dict) else getattr(report, "data_source_type", None)
    return source_for(dst)


def list_sources() -> List[ReportSource]:
    with _LOCK:
        return [_SOURCES[k] for k in sorted(_SOURCES)]


def describe_sources() -> str:
    """The sentence a refusal gives, DERIVED from the registry, aliases beside their kind."""
    parts: List[str] = []
    for key in sorted(_SOURCES):
        aliases = sorted(a for a, t in SOURCE_TYPE_ALIASES.items() if t == key)
        parts.append(f"{key} (also spelled {', '.join(repr(a) for a in aliases)})" if aliases else key)
    return ", ".join(parts) if parts else "(no report sources are registered)"


# ── host roads ───────────────────────────────────────────────────────────────

def attach_road(kind: str, surface: str, fn: Callable[..., Any]) -> None:
    """A host's own way to run ``kind`` on ``surface`` (the moved route bodies)."""
    dst = canonical_source_type(kind)
    if dst not in _SOURCES:
        raise UnknownSourceError(f"No source '{dst}' is registered to attach a road to.")
    with _LOCK:
        _ROADS[(dst, str(surface))] = fn


def road_for(kind: Optional[str], surface: str) -> Optional[Callable[..., Any]]:
    """The host's road for this kind on this surface, or None = the generic road.
    An unknown kind is refused here too (the decision is made once)."""
    src = source_for(kind)
    return _ROADS.get((src.kind, str(surface)))


def _reset_for_tests() -> None:
    with _LOCK:
        _SOURCES.clear()
        _ROADS.clear()


__all__ = [
    "DEFAULT_KIND", "SOURCE_TYPE_ALIASES", "attach_road", "canonical_source_type", "describe_sources",
    "is_registered", "list_sources", "register_source", "road_for", "source_for", "source_of_report",
    "unregister_source",
]
