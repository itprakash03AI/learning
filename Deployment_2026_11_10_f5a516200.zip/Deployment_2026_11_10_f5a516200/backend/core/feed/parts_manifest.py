"""The parts manifest moved to ``core/artifacts/parts_manifest.py`` (2026-11-07,
the report framework's stage 4): it is a RESULT-ARTIFACT shape, read by reports,
published APIs and feeds alike, and the report modules must not import the feed
engine.  This path re-exports every name so no importer changes."""
from core.artifacts.parts_manifest import (  # noqa: F401  (every name, BY NAME: a star import is invisible
    # to tests/test_imported_names_exist_2026_09_01.py, which then reports every feed importer as broken)
    MANIFEST_NAME, PARTIAL_MANIFEST_NAME, PartInfo, PartsManifest, PartsManifestError, __all__,
    _pad_batch_to_schema, _part_disagreement, _schema_from_b64, _schema_to_b64, is_parts_dir,
    iter_manifest_batches, load_manifest, read_result_table, sql_sha256, verify_local_parts,
)
