"""
Shared parameter helpers for report execution.

Phase 111-A: extracted from api/reports_api.py so scheduler, embed, pdf_export,
and business_reports can all use them without importing from a router file.

Functions:
  substitute_sql_params()       — {param_name} → type-safe values in SQL text
  substitute_filter_params()    — {param_name} → values in parquet filter dicts
  auto_append_sql_where()       — inject WHERE for unhandled partition params
  resolve_business_dates()      — today / month_start / -7d → ISO date strings
  validate_param_values()       — check required params are present
  looks_like_date()             — heuristic: is this column name a date?
  cast_scalar()                 — int → float → str for PyArrow compatibility
  normalise_cols()              — normalize column dicts from various sources
  get_parquet_schema_columns()  — column list from saved query file references
"""
from __future__ import annotations

import logging
import re
from datetime import date as _date, timedelta
from pathlib import Path
from typing import Dict, List, Set

logger = logging.getLogger(__name__)

# ── Regex for {param_name} placeholders ──────────────────────────────────────

PARAM_RE = re.compile(r'\{([a-zA-Z_][a-zA-Z0-9_]*)\}')

# ── THE parameter-type vocabulary (2026-09-17, FB-14) ────────────────────
#
# One list, because there were two and they disagreed about numbers in the
# worst possible way.  Measured:
#
#     number    -> WHERE amt > 100.0    numeric
#     integer   -> WHERE amt > '100'    QUOTED
#     float     -> WHERE amt > '100'    QUOTED
#
# ``integer`` and ``float`` are the only numeric spellings a published
# view's validator ACCEPTED; ``number`` is the only one this module treated
# as a number.  For numeric parameters the two vocabularies had an EMPTY
# intersection, so every numeric parameter on a published view was compared
# as a string -- a type error on Trino, and on an engine with implicit
# coercion a LEXICAL comparison where '9' > '100'.  Neither fails in a way
# that names the cause.
#
# api/published_views/models.py builds its pattern from PARAM_TYPES rather
# than re-spelling it, so the two cannot drift apart again.
INTEGER_PARAM_TYPES = frozenset({"integer", "int"})
FLOAT_PARAM_TYPES = frozenset({"number", "float", "decimal", "numeric"})
NUMERIC_PARAM_TYPES = INTEGER_PARAM_TYPES | FLOAT_PARAM_TYPES
BOOLEAN_PARAM_TYPES = frozenset({"boolean", "bool"})
#: Everything else renders as a quoted literal -- that is the safe default
#: and the historical behaviour, so an unrecognised type degrades to a
#: string rather than to an unquoted injection.
PARAM_TYPES = frozenset(
    {"string", "date", "datetime", "select", "multiselect"}
) | NUMERIC_PARAM_TYPES | BOOLEAN_PARAM_TYPES

# ── Date heuristic ───────────────────────────────────────────────────────────

_DATE_LIKE_NAMES = frozenset({
    "date", "dt", "day", "month", "year", "business_date", "trade_date",
    "report_date", "event_date", "created_date", "load_date", "partition_date",
    "snapshot_date", "as_of_date", "effective_date",
})


def looks_like_date(col_name: str) -> bool:
    """Heuristic: does this column name look like a date partition?"""
    norm = col_name.lower().replace("-", "_")
    if norm in _DATE_LIKE_NAMES:
        return True
    return any(norm.endswith(f"_{s}") or norm.startswith(f"{s}_") for s in ("date", "dt", "day"))


# ── SQL parameter substitution ───────────────────────────────────────────────

def _quoted_spans(sql: str) -> list:
    """``[(open, close)]`` index pairs of every single-quoted SQL literal
    ('' inside a literal is an escaped quote, not its end).  An unclosed
    literal runs to the end of the text."""
    spans, i, n = [], 0, len(sql)
    while i < n:
        if sql[i] == "'":
            j = i + 1
            while j < n:
                if sql[j] == "'":
                    if j + 1 < n and sql[j + 1] == "'":
                        j += 2
                        continue
                    break
                j += 1
            spans.append((i, j))
            i = j + 1
        else:
            i += 1
    return spans


def substitute_sql_params(sql: str, param_values: dict, param_schema: list) -> str:
    """
    Replace {param_name} placeholders in SQL with type-safe values.

    - string / date  → wrapped in single quotes, single-quotes in value escaped
    - number         → cast to float, inserted raw (validates it's numeric)
    - boolean        → TRUE / FALSE
    - select         → treated as string
    - list/tuple     → 'v1','v2','v3' for IN clauses
    Unknown params are left as-is (no substitution).
    """
    schema_map = {p["name"]: p for p in (param_schema or [])}
    quoted = _quoted_spans(sql or "")

    def _replace(m: re.Match) -> str:
        name = m.group(1)
        val = param_values.get(name)
        if val is None:
            return m.group(0)  # leave placeholder untouched
        # 2026-10-11 -- the placeholder sits INSIDE the author's own quotes
        # (the OG token style the owner's queries use: CODE='{SYSTEM_ENTITY}',
        # CAST('{BUSINESSDATE}' AS DATE)).  Wrapping the value in quotes again
        # rendered CODE=''E1'' -- broken SQL in a report, while the SAME text
        # ran as a feed (core/feed/sql_tokens.py).  Inside a literal the value
        # is pasted with its quotes doubled, and nothing is added.
        if any(a < m.start() and m.end() <= z for a, z in quoted):
            if isinstance(val, (list, tuple)):
                return "','".join(str(v).replace("'", "''") for v in val)
            return str(val).replace("'", "''")
        p = schema_map.get(name, {})
        ptype = p.get("type", "string")

        # Multi-select: list/array → 'v1','v2','v3' for IN clauses
        if isinstance(val, (list, tuple)):
            if not val:
                return "''"  # empty → no match
            safe_parts = [str(v).replace("'", "''") for v in val]
            return "'" + "','".join(safe_parts) + "'"

        _pt = str(ptype or "string").strip().lower()
        if _pt in INTEGER_PARAM_TYPES:
            # 2026-09-17 -- rendered as '100' before, so `amt > '100'`.
            # An integer parameter renders as an INTEGER: 100, not 100.0,
            # because a partition or id column compared against 100.0 can
            # defeat partition pruning on engines that will not match the
            # literal to an integer partition value.
            try:
                _f = float(val)
            except (ValueError, TypeError):
                raise ValueError(
                    f"Parameter '{name}' must be an integer, got: {val!r}")
            if _f != int(_f):
                raise ValueError(
                    f"Parameter '{name}' is declared integer but got "
                    f"{val!r}. Refusing rather than truncating it -- a "
                    f"silently rounded bound returns the wrong rows.")
            return str(int(_f))
        if _pt in FLOAT_PARAM_TYPES:
            try:
                return str(float(val))
            except (ValueError, TypeError):
                raise ValueError(f"Parameter '{name}' must be a number, got: {val!r}")
        elif _pt in BOOLEAN_PARAM_TYPES:
            return "TRUE" if str(val).lower() in ("true", "1", "yes") else "FALSE"
        else:
            # string, date, select, multiselect (single value) — wrap in quotes
            safe = str(val).replace("'", "''")
            return f"'{safe}'"

    return PARAM_RE.sub(_replace, sql)


# ── Parquet filter parameter substitution ────────────────────────────────────

def unresolved_filter_params(filters) -> list:
    """Names of ``{param}`` placeholders still standing as a WHOLE filter value.

    2026-09-24 (driven by real clicks): a saved query built for a report keeps
    ``{p_status}`` in its filter values; run directly (a dashboard widget, the
    Saved Queries Run button) nothing filled them, the engine compared the
    column to the literal text "{p_status}", and the run "completed" with 0
    rows -- an empty result indistinguishable from real emptiness.  A caller
    refuses with these names instead.  Filters may be dicts or models.
    """
    out = []
    for f in filters or []:
        val = f.get("value") if isinstance(f, dict) else getattr(f, "value", None)
        m = PARAM_RE.fullmatch(str(val)) if isinstance(val, str) else None
        if m and m.group(1) not in out:
            out.append(m.group(1))
    return out


def substitute_filter_params(filters: list, param_values: dict) -> list:
    """Replace {param_name} in parquet filter values with actual param values."""
    if not filters or not param_values:
        return filters
    result = []
    for f in filters:
        new_f = dict(f)
        val_str = str(f.get("value", ""))
        m = PARAM_RE.fullmatch(val_str)
        if m:
            param_name = m.group(1)
            if param_name in param_values:
                substituted = param_values[param_name]
                # Empty list/tuple → drop this filter entirely so ALL rows are
                # returned (multiselect with nothing selected = no restriction).
                if isinstance(substituted, (list, tuple)) and len(substituted) == 0:
                    continue
                new_f["value"] = substituted
                # When the substituted value is a non-empty list, upgrade
                # eq → in so the parquet engine can evaluate it correctly.
                if isinstance(substituted, (list, tuple)) and new_f.get("operator") in ("eq", "=", None, ""):
                    new_f["operator"] = "in"
        result.append(new_f)
    return result


# ── Auto-append WHERE for partition params not in SQL ────────────────────────

def auto_append_sql_where(sql: str, param_schema: list, param_values: dict,
                          referenced_params: Set[str]) -> str:
    """Auto-append WHERE conditions for partition params not already in the SQL.

    If the user selected param values but didn't wire them as {param_name}
    placeholders, we inject WHERE conditions so partition filtering is automatic.
    Skips params already handled by {placeholder} substitution.
    """
    conditions: List[str] = []
    for p in param_schema:
        name = p["name"]
        if name in referenced_params:
            continue  # already handled via {param_name} substitution
        val = param_values.get(name)
        if val is None or val == "":
            continue

        col = name  # column name = param name (partition columns)
        if isinstance(val, (list, tuple)):
            if len(val) == 0:
                continue
            safe_parts = [str(v).replace("'", "''") for v in val]
            in_list = ", ".join(f"'{v}'" for v in safe_parts)
            conditions.append(f'"{col}" IN ({in_list})')
        else:
            ptype = p.get("type", "string")
            if ptype == "number":
                try:
                    conditions.append(f'"{col}" = {float(val)}')
                except (ValueError, TypeError):
                    safe = str(val).replace("'", "''")
                    conditions.append(f'"{col}" = \'{safe}\'')
            elif ptype == "boolean":
                bval = "TRUE" if str(val).lower() in ("true", "1", "yes") else "FALSE"
                conditions.append(f'"{col}" = {bval}')
            else:
                safe = str(val).replace("'", "''")
                conditions.append(f'"{col}" = \'{safe}\'')

    if not conditions:
        return sql

    extra_where = " AND ".join(conditions)
    stripped = sql.strip().rstrip(";")
    return f"SELECT * FROM ({stripped}) _auto_filtered WHERE {extra_where}"


# ── Parameter validation ─────────────────────────────────────────────────────

def describe_parameter(p: dict) -> str:
    """How a refusal names a parameter: by the NAME the API accepts.

    AQD-05 (2026-09-23): refusals named the LABEL. Report 22's parameter is
    ``name=p_region, label=Region``; the product said "Required parameter(s)
    missing: Region", and a caller who then sent ``Region`` was refused as an
    unknown parameter -- following the message verbatim was guaranteed to
    fail. The name comes first because it is what must be sent; the label
    follows in quotes when it differs, because it is what a person recognises.
    """
    name = str(p.get("name") or "")
    label = str(p.get("label") or "").strip()
    if label and label != name:
        return f"{name} (\"{label}\")"
    return name or label or "?"


def validate_param_values(param_schema: list | None, param_values: dict) -> List[str]:
    """Return list of validation error messages (empty = valid)."""
    if not param_schema:
        return []
    errors = []
    for p in param_schema:
        name = p["name"]
        val = param_values.get(name)
        if p.get("required") and (val is None or str(val).strip() == ""):
            errors.append(f"Required parameter {describe_parameter(p)} is missing")
    return errors


def seed_parameter_defaults(param_schema: list | None, param_values: dict | None) -> dict:
    """The schema's ``default_value`` for every parameter the caller did not
    supply; a supplied value always wins.

    ONE rule, three readers (2026-09-26, FB-60): the interactive raw_sql
    run (``business_reports_api._execute_raw_sql_report``), the headless
    run behind schedules / subscriptions / bursts
    (``core.reports.sources._exec_raw_sql``) and the save-time preflight
    (``core.reports.subscription_preflight``).  The preflight used to mirror
    the LEGACY scheduled runner's seeding while neither successor seam
    seeded at all -- so a required parameter WITH a default passed the
    save-time gate and then failed (interactive: 400) or ran with an
    unsubstituted placeholder (headless) at 3 AM.  The rule this module
    guards is that save time and run time cannot disagree; they read the
    same function now.  ``None`` and the empty string are not defaults.
    """
    effective: dict = {}
    for p in (param_schema or []):
        if not isinstance(p, dict) or not p.get("name"):
            continue
        dv = p.get("default_value")
        if dv is not None and str(dv).strip() != "":
            effective[p["name"]] = dv
    for k, v in (param_values or {}).items():
        if v is None or (isinstance(v, str) and v.strip() == ""):
            continue   # an empty supplied value does not erase a default
        effective[k] = v
    return effective


# ── Business date resolver ───────────────────────────────────────────────────

_RELATIVE_RE = re.compile(r'^([+-])(\d+)d$', re.IGNORECASE)

BUSINESS_DATE_SHORTCUTS = [
    "today", "yesterday", "tomorrow",
    "week_start", "week_end",
    "last_week_start", "last_week_end",
    "month_start", "month_end",
    "last_month_start", "last_month_end",
    "year_start", "year_end",
    "last_year_start", "last_year_end",
]


def resolve_business_dates(param_values: dict, *, db=None) -> dict:
    """
    Expand business date shortcuts in param_values before substitution.
    Shortcuts are case-insensitive and resolved to YYYY-MM-DD strings.

    Supported shortcuts:
      today, yesterday, tomorrow
      week_start / week_end          — Mon/Sun of current ISO week
      last_week_start / last_week_end
      month_start / month_end
      last_month_start / last_month_end
      year_start / year_end
      last_year_start / last_year_end
      -Nd / +Nd                       — relative days (e.g. -7d = 7 days ago)

    Business-CALENDAR tokens (2026-09-28), resolved by the ONE resolver every
    date vocabulary shares (``core.business_calendar_tokens``):
      prev_business_day[:CAL], next_business_day[:CAL],
      business_month_end[:CAL], prev_business_month_end[:CAL],
      business_day_n:N[:CAL]
    also spelled ``@PREV_BUSINESS_DAY:CAL`` / ``${prev_business_day:CAL}``.
    No calendar named -> ``feed_generation.default_calendar``.  A token that
    cannot be rendered (unknown calendar, no default declared, beyond the
    calendar's horizon) raises ``CalendarTokenRefused`` (a ValueError, 400
    at the API) -- it never falls back to plain calendar days.  ``db`` is
    the calendar store; the process-wide DatabaseManager when omitted.
    """
    from core.business_calendar_tokens import resolve_if_calendar_token
    from core.date_resolver import business_today
    today = business_today()                 # 2026-11-09: THE one "today"

    def _first(d):
        return d.replace(day=1)

    def _last(d):
        m2 = d.month % 12 + 1
        y2 = d.year + (1 if d.month == 12 else 0)
        return _date(y2, m2, 1) - timedelta(days=1)

    last_month_last = _first(today) - timedelta(days=1)
    shortcuts = {
        "today":             today,
        "yesterday":         today - timedelta(days=1),
        "tomorrow":          today + timedelta(days=1),
        "week_start":        today - timedelta(days=today.weekday()),
        "week_end":          today + timedelta(days=6 - today.weekday()),
        "last_week_start":   today - timedelta(days=today.weekday() + 7),
        "last_week_end":     today - timedelta(days=today.weekday() + 1),
        "month_start":       _first(today),
        "month_end":         _last(today),
        "last_month_start":  _first(last_month_last),
        "last_month_end":    last_month_last,
        "year_start":        _date(today.year, 1, 1),
        "year_end":          _date(today.year, 12, 31),
        "last_year_start":   _date(today.year - 1, 1, 1),
        "last_year_end":     _date(today.year - 1, 12, 31),
    }

    result = {}
    if not param_values:
        return result
    for key, val in param_values.items():
        if not isinstance(val, str):
            result[key] = val
            continue
        norm = val.strip().lower()
        if norm in shortcuts:
            result[key] = shortcuts[norm].isoformat()
        else:
            m = _RELATIVE_RE.match(val.strip())
            if m:
                sign = 1 if m.group(1) == "+" else -1
                result[key] = (today + timedelta(days=sign * int(m.group(2)))).isoformat()
            else:
                # A business-calendar token, or the literal it always was.
                # None = not a calendar token; a token that cannot be
                # rendered REFUSES here rather than passing through as text.
                calendar_iso = resolve_if_calendar_token(val, today=today, db=db)
                result[key] = calendar_iso if calendar_iso is not None else val
    return result


# ── Scalar casting for PyArrow ───────────────────────────────────────────────

def cast_scalar(v):
    """Try int → float → str so PyArrow type-matching works on numeric columns."""
    s = str(v).strip()
    try:
        return int(s)
    except (ValueError, TypeError):
        pass
    try:
        return float(s)
    except (ValueError, TypeError):
        pass
    return s


# ── Column normalisation ────────────────────────────────────────────────────

def normalise_cols(raw: list) -> List[Dict[str, str]]:
    """Normalise column dicts from various sources into {name, type} dicts."""
    out: List[Dict[str, str]] = []
    for c in (raw or []):
        if isinstance(c, dict):
            name = c.get("name") or c.get("column_name") or ""
            ctype = c.get("type") or c.get("column_type") or "unknown"
        else:
            name, ctype = str(c), "unknown"
        if name:
            out.append({"name": name, "type": ctype})
    return out


# ── Parquet schema column reader ─────────────────────────────────────────────

def get_parquet_schema_columns(files: list, db=None) -> List[Dict[str, str]]:
    """
    Return all columns from the first readable source in ``files``.

    Handles all path prefixes used by QueryStudio:
      __local__:name          — LocalTable (schema_json from DB)
      __materialized__:name   — MaterializedView parquet storage
      __registered__:name     — S3 registered table (schema cache / materialized copy)
      s3://...                — direct S3 (skipped — needs live credentials)
      <filename>              — local parquet (DuckDB DESCRIBE + PyArrow fallback)
    """
    _log = logging.getLogger(__name__)
    try:
        from core.config import paths as _param_paths, materialized_views as _mv_cfg
        data_dir = Path(str(_param_paths.parquet_dir))
        mv_storage = Path(_mv_cfg.storage_dir)
    except Exception:
        data_dir = Path("/usr/local/querystudioapi/nfs/data/parquet")
        mv_storage = None

    for fname in (files or [])[:10]:
        fname = str(fname)

        # ── Local table ────────────────────────────────────────────────
        if fname.startswith("__local__:"):
            lt_name = fname[len("__local__:"):]
            if db:
                try:
                    lt = db.get_local_table_by_name(lt_name)
                    if lt and lt.get("schema_json"):
                        cols = normalise_cols(lt["schema_json"])
                        if cols:
                            return cols
                    if lt and lt.get("storage_path"):
                        import glob as _gm
                        pqs = sorted(_gm.glob(str(Path(lt["storage_path"]) / "*.parquet")))
                        if pqs:
                            r = get_parquet_schema_columns([pqs[0]])
                            if r:
                                return r
                except Exception as exc:
                    _log.debug("__local__ schema %s: %s", lt_name, exc)
            continue

        # ── Materialized view ──────────────────────────────────────────
        if fname.startswith("__materialized__:"):
            mv_name = fname[len("__materialized__:"):]
            if db and mv_storage:
                try:
                    mv = db.get_materialized_view_by_name(mv_name)
                    if mv:
                        import glob as _gm
                        pqs = sorted(_gm.glob(str(mv_storage / str(mv["id"]) / "*.parquet")))
                        if pqs:
                            r = get_parquet_schema_columns([pqs[0]])
                            if r:
                                return r
                except Exception as exc:
                    _log.debug("__materialized__ schema %s: %s", mv_name, exc)
            continue

        # ── Registered S3 table ────────────────────────────────────────
        if fname.startswith("__registered__:"):
            reg_name = fname[len("__registered__:"):]
            if db:
                try:
                    schema = db.get_registered_table_schema(reg_name)
                    if schema:
                        cols = normalise_cols(schema)
                        if cols:
                            return cols
                except Exception as exc:
                    _log.debug("__registered__ schema %s: %s", reg_name, exc)
            continue

        # ── Direct S3 path — skip (needs live creds) ──────────────────
        if fname.startswith("s3://"):
            continue

        # ── Local parquet file (DuckDB DESCRIBE + PyArrow fallback) ───
        full_path = data_dir / fname if not Path(fname).is_absolute() else Path(fname)
        if full_path.suffix.lower() not in (".parquet", ".pq"):
            continue
        if not full_path.exists():
            continue

        # Try DuckDB DESCRIBE first
        try:
            from core.duckdb_factory import duckdb_connection
            with duckdb_connection() as con:
                rows = con.execute(f"DESCRIBE SELECT * FROM '{full_path}'").fetchall()
                cols = [{"name": r[0], "type": r[1]} for r in rows if r[0]]
                if cols:
                    return cols
        except Exception:
            pass

        # PyArrow fallback
        try:
            import pyarrow.parquet as pq
            schema = pq.read_schema(str(full_path))
            cols = [{"name": f.name, "type": str(f.type)} for f in schema]
            if cols:
                return cols
        except Exception as exc:
            _log.debug("PyArrow schema read failed for %s: %s", full_path, exc)

    return []
