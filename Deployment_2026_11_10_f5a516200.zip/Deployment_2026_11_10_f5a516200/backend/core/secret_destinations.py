"""Where a connection's secret GOES -- the fields that name the place a saved
credential is sent to, how it is sent, and where its rights write output.
ONE vocabulary, applied at ANY depth of a config, for every type.

Two routes inject a STORED secret into a config the caller wrote (a ``"***"``
in a sensitive field means "use the saved one"):

* ``POST /api/connections/test`` with ``connection_id`` (edit-and-test);
* ``POST /api/connections/{id}/clone`` with ``overrides`` (2026-11-09, the
  clone form: "Keep the saved password / keys from <source>").

Each must refuse when the caller ALSO moved where that secret goes --
otherwise "keep my password, and send it to attacker.example" is one request
(SECURITY AUDIT 2026-08-03 S2; FB-62).  Before 2026-11-09 the test route held
its own flat list (``_TARGET_KEYS``) and the clone route had no host field at
all; the clone form needs the rule, and a decision made twice is a bug, so
the list lives here and both routes read it.

THE LIST IS DERIVED FROM WHAT THE CONNECTORS READ, not from the forms
(security review 2026-11-09, finding 1): ``core/s3_access.py``,
``credential_resolver.py`` and ``local_parquet_road.py`` read
``endpoint_url or endpoint``, so a config carrying only ``endpoint`` reached
the old per-type list as "no change".  Every alias is listed, the set applies
at every nested dict (a Trino connection's ``unload_s3_access`` block has its
own keys and its own endpoint), and ``tests/test_connection_clone_2026_09_23.py``
greps the connector and resolver sources for every host-like config key they
read and fails when one is neither declared here nor waived with a reason
(``NOT_DESTINATIONS``), so a new alias cannot bypass the rule silently.

What counts, in three groups (``DESTINATION_KEYS``):

* **where the login is sent** -- host / hostname / server / server_hostname,
  port, endpoint / endpoint_url, base_url / url / jdbc_url, dsn / tns_alias,
  account (Snowflake), http_path (Databricks), token_url / auth_url /
  authenticator (an OAuth or Okta URL receives the password), proxy / proxy_url,
  the AWS portal base / JWT / credential URL, bootstrap_servers;
* **where output is written with the login's rights** -- ``s3_staging_dir``
  (Athena writes every result there: a copy pointing it at an attacker's
  bucket writes the victim's data out with the victim's principal --
  finding 4), ``output_location``, ``unload_s3_location`` (Trino unloads);
* **how it is sent** (finding 3) -- scheme (``http_scheme`` / ``protocol`` /
  ``scheme``, and the scheme of every URL above), and TLS: ``verify_ssl`` /
  ``ssl_verify`` / ``use_ssl`` / ``ssl`` / ``tls`` / ``ssl_mode`` and the CA
  (``ca_cert_pem`` / ``ca_bundle``) -- a copy that keeps the password and
  turns verification off, or installs its own CA, hands the password to
  whoever sits in the middle.  ANY change to these counts, not only a
  weakening: a judgement about which direction is "safer" is one more thing
  to get wrong.

NOT destinations, deliberately: a bucket, prefix, registered table, region,
catalog, schema, database, Snowflake warehouse and Athena workgroup are names
INSIDE the account the login already reaches (the old test-route list also
held ``warehouse`` / ``workgroup``; they were dropped on purpose, see
``NOT_DESTINATIONS``).  AWS keys belong to a PARTITION, so a REAL S3 endpoint
of the same partition is the same place (finding 2: only a host that
fullmatches the S3 endpoint patterns ``s3.amazonaws.com``,
``s3.<region>.amazonaws.com``, ``s3-<region>.amazonaws.com``,
``s3.dualstack.<region>.amazonaws.com`` and their ``.cn`` forms -- never "any
``*.amazonaws.com``", which includes EC2 and API Gateway hosts; a URL with
userinfo, a query or a fragment is malformed and always a change).

Comparison (:func:`changed_destinations`): at every dict level of the
SUBMITTED config, every key above is compared with the stored value at the
same path.  A key the caller did not send is not a change (the form sends
what it has).  A key sent EMPTY where a value was stored IS a change
(finding 8: an emptied MinIO endpoint silently falls back to AWS).  A dict or
list where a scalar was expected is a change (unknown is unsafe).  Hosts and
URLs compare case-insensitively, trailing slash ignored, ports as text, URLs
by scheme + host + port + path.
"""
from __future__ import annotations

import re
from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Tuple
from urllib.parse import urlsplit

#: Every config key, at any depth and for every type, whose change moves
#: where a kept secret goes, how it travels, or where its rights write.
DESTINATION_KEYS: FrozenSet[str] = frozenset({
    # where the login is sent
    "host", "hostname", "server", "server_hostname", "port",
    "endpoint", "endpoint_url", "base_url", "url", "jdbc_url",
    "dsn", "tns_alias", "account", "http_path",
    "token_url", "auth_url", "authenticator",
    "proxy", "proxy_url", "portal_base_url", "jwt_token_url", "jwt_url", "credential_url",
    "bootstrap_servers",
    # where output is written with the login's rights
    "s3_staging_dir", "output_location", "unload_s3_location",
    # how it is sent: scheme and TLS
    "http_scheme", "protocol", "scheme",
    "verify_ssl", "ssl_verify", "use_ssl", "ssl", "tls", "ssl_mode",
    "ca_cert_pem", "ca_bundle",
})

#: Host-like config keys the connectors / resolvers READ that are NOT where a
#: secret goes -- each with the reason, so the guard test can hold the line.
NOT_DESTINATIONS: Dict[str, str] = {
    "api_key_location": "header-or-query placement of the API key, not a place",
    "wallet_location": "a directory on the pod holding the Oracle wallet, not a network place",
    "kerberos_config": "a krb5.conf path on the pod",
    "cert": "a client certificate FILE on the pod (Trino mTLS)",
    "key": "a client key FILE on the pod (Trino mTLS)",
    "path_style": "URL style (bucket.host vs host/bucket) of the same host",
    "addressing_style": "URL style of the same host",
    "s3_access_mode": "presigned vs native reads of the same store",
    "endpoint_path": "a REST query definition's path ON the connection's base host "
                     "(held there by RestAPIConnector._build_url, 2026-11-09)",
    "response_json_path": "a JSON pointer into the response body",
    "unload_scratch_catalog": "a catalog NAME in the same Trino",
    "unload_scratch_schema": "a schema NAME in the same Trino",
    "region": "AWS region: keys belong to the partition, not a region",
    "region_name": "AWS region: keys belong to the partition, not a region",
    "warehouse": "a Snowflake compute NAME inside the account the login reaches "
                 "(dropped from the old test-route list on purpose)",
    "workgroup": "an Athena workgroup NAME inside the account "
                 "(dropped from the old test-route list on purpose)",
    "kerberos_service_name": "the Kerberos service principal name, not a host",
    "kerberos_principal": "the client's own Kerberos principal",
    "bucket": "a bucket NAME inside the partition the keys reach",
    "bucket_name": "a bucket NAME inside the partition the keys reach",
    "root_prefix": "a prefix inside the bucket",
    "iceberg_warehouse_path": "a prefix inside the bucket",
    "s3_prefix": "a registered table's prefix inside the bucket",
    "base_path": "a folder on the pod (local / upload connections)",
    "portal_username": "the login's NAME, not where it goes",
    "sso_username": "the login's NAME, not where it goes",
    "username": "the login's NAME, not where it goes",
    "user": "the login's NAME, not where it goes",
    "role_arn": "an IAM role inside the account the keys reach",
    "role_session_name": "a session label",
    "external_id": "an assume-role condition value inside the account",
    "role": "a role NAME inside the server the login reaches (Trino system role, Snowflake role)",
    "role_name": "the IAM role NAME the portal mints keys for, inside the account",
    "roles": "the portal's list of role names (a response field, not a config key)",
    "iam_role": "a role NAME inside the account",
    "account_id": "the AWS account NUMBER the portal returns a role in (inside the login's own estate)",
    "account_type": "a System Account row's kind, not a connection config key",
    "catalog_roles": "Trino catalog role NAMES",
    "system_account": "a reference to a System Account: not a secret, not a place",
    "system_account_id": "a reference to a System Account: not a secret, not a place",
    "system_account_name": "a reference to a System Account: not a secret, not a place",
    "portal_password": "a SECRET (core/crypto SENSITIVE_FIELDS), not a place",
    "creds_url_base": "derived from portal_base_url inside aws_portal_auth (a resolved dict, not a config key)",
    "roles_url": "derived from portal_base_url inside aws_portal_auth (a resolved dict, not a config key)",
    "endpoints": "the REST connector's table-name list, not a config key",
    "json_path": "a JSON pointer into a response body",
    "path": "a file path inside a listing / response, not a network place",
    "user_data": "the portal login's profile blob",
}
# the DuckDB settings core/s3_access.py derives (it alone spells them; imported, never re-typed here)
from core.s3_access import DUCKDB_S3_SETTINGS as _DUCKDB_S3_SETTINGS  # noqa: E402
NOT_DESTINATIONS.update({_k: "a DuckDB setting DERIVED from the connection's config by core/s3_access.py (not a config key)"
                         for _k in _DUCKDB_S3_SETTINGS})

#: The name pattern the guard test uses to find host-like keys in source.
HOST_LIKE_KEY = re.compile(
    r"(host|url|endpoint|server|dsn|account|port|path|proxy|staging|location|"
    r"scheme|protocol|ssl|tls|cert|bootstrap|alias|bucket|prefix|region|"
    r"warehouse|workgroup|kerberos|^user|role|external_id|^key$)")

#: A REAL S3 endpoint host of a partition -- and nothing else on amazonaws.com.
_S3_HOST = re.compile(
    r"s3(?:\.dualstack)?(?:[.-][a-z]{2}(?:-gov)?-[a-z]+-\d)?\.amazonaws\.com(?:\.cn)?")


def _norm(value: Any) -> str:
    return str(value if value is not None else "").strip().rstrip("/").lower()


def _aws_partition(host: str) -> Optional[str]:
    """``aws`` / ``aws-cn`` / ``aws-us-gov`` when ``host`` is a REAL S3
    endpoint of that partition, else None."""
    if not _S3_HOST.fullmatch(host):
        return None
    if host.endswith(".amazonaws.com.cn"):
        return "aws-cn"
    if "-gov-" in host:
        return "aws-us-gov"
    return "aws"


def _partition_of_region(region: Any) -> str:
    r = _norm(region)
    if r.startswith("cn-"):
        return "aws-cn"
    if r.startswith("us-gov-"):
        return "aws-us-gov"
    return "aws"


def _url_place(raw: Any, *, empty_region: Any = None) -> Optional[Tuple[str, str, str]]:
    """``(scheme, host-or-partition[:port], path)`` of a URL as botocore / DuckDB
    would dial it (``urlsplit``), or None when it cannot be one place: a URL
    with userinfo, a query or a fragment (``https://evil.example?.amazonaws.com``
    parses to host evil.example -- and a secret must not ride a trick).

    An EMPTY endpoint is AWS over https in the partition ``empty_region``
    names; a real S3 host of a partition is that partition (keys belong to
    it); any other host is itself, lower-cased, default port dropped."""
    text = str(raw if raw is not None else "").strip()
    if not text:
        return ("https", _partition_of_region(empty_region), "")
    if "://" not in text:
        text = "https://" + text
    try:
        parts = urlsplit(text)
    except ValueError:
        return None
    if parts.username is not None or parts.password is not None or parts.query or parts.fragment:
        return None
    scheme = (parts.scheme or "https").lower()
    try:
        host = (parts.hostname or "").lower().rstrip(".")
        port = parts.port
    except ValueError:
        return None
    if not host or "@" in parts.netloc:
        return None
    partition = _aws_partition(host)
    if partition:
        return (scheme, partition, "")
    if port is not None and (scheme, port) not in (("https", 443), ("http", 80)):
        host = f"{host}:{port}"
    return (scheme, host, parts.path.rstrip("/").lower())


_URL_KEYS = frozenset({"endpoint", "endpoint_url", "base_url", "url", "jdbc_url",
                       "token_url", "auth_url", "proxy", "proxy_url", "portal_base_url",
                       "jwt_token_url", "jwt_url", "credential_url"})
_S3_ENDPOINT_KEYS = frozenset({"endpoint", "endpoint_url"})


def _same(key: str, old: Any, new: Any, old_dict: dict, new_dict: dict) -> bool:
    """Is the submitted value of ``key`` the same place / way as the stored one?"""
    if isinstance(new, (dict, list)) or isinstance(old, (dict, list)):
        return False                                      # unknown is a change
    if key in _S3_ENDPOINT_KEYS:
        region_old = old_dict.get("region_name") or old_dict.get("region")
        region_new = new_dict.get("region_name") or new_dict.get("region")
        p_old = _url_place(old, empty_region=region_old)
        p_new = _url_place(new, empty_region=region_new)
        return p_old is not None and p_old == p_new
    if key in _URL_KEYS:
        if _norm(new) == "" and _norm(old) == "":
            return True
        if _norm(new) == "" or _norm(old) == "":
            return False                                  # emptied, or newly set
        p_old, p_new = _url_place(old), _url_place(new)
        return p_new is not None and p_old == p_new
    return _norm(new) == _norm(old)


#: What EVERY reader takes for a destination key the stored config does not hold
#: (2026-11-10).  TLS verification is ON when ``verify_ssl`` / ``ssl_verify`` is
#: absent -- every connector and S3 road reads ``.get(<key>, True)``.  A connection
#: saved without the key (through the API, from SQL, by an older form) and a form
#: that sends its default ``true`` are the SAME way of sending the secret; reading
#: the absence as "" refused every keep-the-keys clone and edit of it ("The ssl
#: verify changed").  Only a default every reader shares belongs here.
ABSENT_READS_AS: Dict[str, Any] = {"verify_ssl": True, "ssl_verify": True}


def _stored_value(stored_d: dict, key: str) -> Any:
    if key in stored_d:
        return stored_d[key]
    return ABSENT_READS_AS.get(key)


def _walk(stored: Any, submitted: Any, path: str, out: List[str]) -> None:
    if isinstance(submitted, dict):
        stored_d = stored if isinstance(stored, dict) else {}
        for k, v in submitted.items():
            p = f"{path}.{k}" if path else str(k)
            if k in DESTINATION_KEYS:
                if v is None and k not in stored_d:
                    continue                          # not sent = not a change
                if not _same(k, _stored_value(stored_d, k), v, stored_d, submitted):
                    out.append(p)
            elif isinstance(v, (dict, list)):
                _walk(stored_d.get(k), v, p, out)
    elif isinstance(submitted, list):
        stored_l = stored if isinstance(stored, list) else []
        for i, v in enumerate(submitted):
            if isinstance(v, (dict, list)):
                _walk(stored_l[i] if i < len(stored_l) else None, v, f"{path}[{i}]", out)


def changed_destinations(connection_type: Any, stored: Any, submitted: Any) -> List[str]:
    """The destination fields (dotted paths, any depth) the caller CHANGED
    against the stored config -- the ones a kept secret would be sent to, or
    through, somewhere new.  Empty = the same places, the same way."""
    out: List[str] = []
    _walk(stored if isinstance(stored, dict) else {},
          submitted if isinstance(submitted, dict) else {}, "", out)
    return out


def kept_secret_refusal(changed: Iterable[str]) -> str:
    """The sentence the clone form shows when it keeps a secret and moved it."""
    named = ", ".join(_plain(f) for f in changed) or "host"
    return (f"The {named} changed, so the saved password / keys are not copied -- "
            f"type them for the new place, or untick 'Keep the saved password / keys'.")


def repoint_refusal(changed: Iterable[str]) -> str:
    """The sentence an EDIT (PUT) gets when it keeps a typed secret ("***")
    and moves where it goes (security review 2026-11-09, finding 7)."""
    named = ", ".join(_plain(f) for f in changed) or "host"
    return (f"The {named} changed, so the saved password / keys are not used -- "
            f"type them for the new place.")


def value_at(config: Any, path: str) -> Any:
    """The value at a dotted path with ``[i]`` steps (``sides[0].host``)."""
    cur = config
    for step in re.findall(r"[^.\[\]]+|\[\d+\]", path):
        if step.startswith("["):
            i = int(step[1:-1])
            cur = cur[i] if isinstance(cur, list) and i < len(cur) else None
        else:
            cur = cur.get(step) if isinstance(cur, dict) else None
    return cur


def repoint_record(changed: Iterable[str], stored: Any, submitted: Any) -> Dict[str, Dict[str, Any]]:
    """``{path: {"from": old, "to": new}}`` for the audit -- destination
    fields are NAMES of places, never secrets."""
    return {p: {"from": value_at(stored, p), "to": value_at(submitted, p)} for p in changed}


def _plain(path: str) -> str:
    """``unload_s3_access.endpoint_url`` -> ``unload s3 access endpoint url``."""
    return re.sub(r"\[\d+\]", "", path).replace(".", " ").replace("_", " ")


def test_route_mismatch(field: str) -> str:
    """The test route's sentence, unchanged since 2026-08-03."""
    return (f"'{field}' does not match the saved connection — re-enter the "
            f"credential to test against a different target.")
