"""QueryStudio as the HOST of the report framework (stage 4, 2026-11-07).

``core/report_framework/ports.py`` names this module (``DEFAULT_HOST_MODULE``)
and imports it by name once; importing it installs, for every process that
runs reports (the API, the reports pod, the published-API pod, the job-worker,
the scheduler, a test):

* the PolicyPort  -- do row-security policies apply to a report's data
                     (QueryStudio's row policies by table pattern);
* the ArtifactPort -- the result directory and the one artifact lookup;
* the ReadinessPort -- ``core.reports.readiness`` as ready / not ready / unknown;
* the DependencyPort -- the FEED engine's gate, ledger, clocks, calendars and
                     Netcool sender, which the readiness and SLO modules used to
                     import from ``core.feed`` themselves;
* the host helpers by name -- the functions ``core/reports/*`` used to import
  from ``api.*`` (``_resolve_param_value``, ``_derive_artifact_grain``, ...),
  each resolved lazily so importing this module imports no route module.

Every name installed here is one a ``core/reports`` module asks for through
``ports.host().<name>``; ``tests/test_report_framework_host_2026_11_07.py``
reads those names out of the source and checks each is installed.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

from core.report_framework import ports

logger = logging.getLogger(__name__)


# ── the host helpers, by name, resolved lazily ──────────────────────────────

def _br():
    import api.business_reports_api as m
    return m


def derive_artifact_grain(db, report):
    return _br()._derive_artifact_grain(db, report)


def find_result_file(execution_id: str):
    from api.data_grid_api import find_csv_file
    return find_csv_file(str(execution_id))


def report_parameters_for_execution(report, db, report_id):
    return _br()._report_parameters_for_execution(report, db, report_id)


def resolve_param_value(value):
    return _br()._resolve_param_value(value)


def dataset_sql_dialect(ds) -> Optional[str]:
    """The dialect the federation engine would use for a dataset's SQL, or None without an engine."""
    engine = getattr(_br(), "_federation_engine", None)
    return engine.dataset_sql_dialect(ds) if engine is not None else None


async def fill_rule_defaults(db, report, param_values, user):
    return await _br()._fill_rule_defaults(db, report, param_values, user)


def resolve_lov_dataset_id(report, db):
    return _br()._resolve_lov_dataset_id(report, db)


async def refuse_unreadable_value_tables(db, items, user):
    return await _br()._refuse_unreadable_value_tables(db, items, user)


async def connection_visible_to(conn, user):
    from api.connections_api import _connection_visible_to
    return await _connection_visible_to(conn, user)


async def registered_table_partition_values(conn_id: int, table: str):
    from api.connections_api import registered_table_partition_values as _rtpv
    return await _rtpv(int(conn_id), table)


async def dataset_partition_detection(ds, user):
    from api.datasets_api import dataset_partition_detection as _dpd
    return await _dpd(ds, user)


def sql_files_storage_dir() -> Path:
    from api.sql_files_api import _get_storage_dir
    return _get_storage_dir()


def register_switch_on(table: str, fn) -> None:
    from api.config_active_api import ON_SWITCH_ON
    ON_SWITCH_ON[table] = fn


class _PartsDatasets:
    """The parts-dataset helpers of the published-API bulk reader (``open`` /
    ``describe`` / ``verify_version`` / ``close``)."""

    @staticmethod
    def open(parts_dir, *, allow_partial: bool = True):
        from api.published_views import bulk
        return bulk.open_dataset(parts_dir, allow_partial=allow_partial)

    @staticmethod
    def describe(parts_dir, *, cache_key: str = "", pf=None):
        from api.published_views import bulk
        return bulk.describe_dataset(parts_dir, cache_key=cache_key, pf=pf)

    @staticmethod
    def verify_version(pin, ref, *, source: str):
        from api.published_views import bulk
        return bulk.verify_dataset_version(pin, ref, source=source)

    @staticmethod
    def close(pf):
        from api.published_views import bulk
        return bulk.close_dataset(pf)


def parts_datasets() -> _PartsDatasets:
    return _PartsDatasets()


# ── the ports ───────────────────────────────────────────────────────────────

class QueryStudioPolicyPort:
    """Do QueryStudio's row-security policies apply to a report's data?  A
    source names what its data goes by (``governed_refs``); an ENABLED, active
    row policy whose table pattern matches one of them applies.  True / False,
    or None when the policies could not be read (the rule treats None as
    applying)."""

    def policies_apply(self, report: Mapping[str, Any], principal: Mapping[str, Any],
                       governed_refs: list, db: Any) -> Optional[bool]:
        if db is None or not hasattr(db, "list_row_policies"):
            return None
        try:
            from core.row_security.resolver import table_matches_pattern
            policies = db.list_row_policies(enabled_only=True) or []
        except Exception as exc:                          # noqa: BLE001
            logger.warning("[report-framework] row policies could not be read: %s", exc)
            return None
        if not policies:
            return False
        refs = [str(r) for r in (governed_refs or []) if str(r).strip()]
        for pol in policies:
            pattern = str(pol.get("table_pattern") or "").strip()
            if not pattern:
                continue
            if pattern == "*":
                return True
            for ref in refs:
                try:
                    if table_matches_pattern(ref, pattern):
                        return True
                except Exception:                         # noqa: BLE001
                    return None
        return False


class QueryStudioArtifactPort:
    def result_dir(self) -> Path:
        from core.config import paths as _paths
        return Path(str(_paths.downloads_dir))

    def resolve(self, execution_id: str, claimed_path: Optional[str]):
        from core.reports.contract import resolve_artifact
        return resolve_artifact(execution_id, claimed_path)


class QueryStudioReadinessPort:
    """``core.reports.readiness`` as the framework's three states."""

    def evaluate(self, report: Mapping[str, Any], params: Mapping[str, Any], db: Any) -> Dict[str, Any]:
        from core.reports.readiness import readiness_for_run
        rd = readiness_for_run(db, dict(report), dict(params or {}), resolve=resolve_param_value)
        state = {"complete": ports.READY, "partial": ports.NOT_READY}.get(str(rd.state), ports.UNKNOWN)
        return {"state": state, "sentence": str(getattr(rd, "summary", "") or rd.state)}


class QueryStudioDependencyPort:
    """The feed engine's facilities the readiness and SLO modules use."""

    @property
    def netcool(self):
        from core.feed import netcool
        return netcool

    def gate_states(self) -> Dict[str, str]:
        from core.feed.dependency_gate import MET, NOT_EXPECTED, NOT_MET, UNKNOWN
        return {"MET": MET, "NOT_MET": NOT_MET, "NOT_EXPECTED": NOT_EXPECTED, "UNKNOWN": UNKNOWN}

    def evaluate_gate_over_rows(self, db, rows, business_date):
        from core.feed.etl_dependency import evaluate_gate_over_rows
        return evaluate_gate_over_rows(db, rows, business_date)

    def compute_clocks(self, **kwargs):
        from core.feed.acting_time import compute_clocks
        return compute_clocks(**kwargs)

    def arrival_profile(self, db, name: str, *, now):
        from core.feed.ledger import arrival_profile
        return arrival_profile(db, name, None, now=now)

    def calendar_is_business_day(self, db, calendar_name: str, business_date) -> tuple:
        from core.feed.calendar import BusinessCalendar, BusinessCalendarRepo
        spec = BusinessCalendarRepo(db).get(str(calendar_name))
        if spec is None:
            return None, f"calendar {calendar_name!r} is not an active business calendar"
        return bool(BusinessCalendar(spec).is_business_day(business_date)), None

    def resolve_zone(self, name):
        from core.feed.acting_time import _resolve_zone
        return _resolve_zone(name)

    def breach_severity(self):
        from core.feed.acting_time import STAGE_BREACHED, STAGE_SEVERITY
        return STAGE_SEVERITY[STAGE_BREACHED]


def install() -> None:
    from core.report_framework.sources.builtin import register_builtin
    register_builtin()
    ports.install_policy_port(QueryStudioPolicyPort())
    ports.install_artifact_port(QueryStudioArtifactPort())
    ports.install_readiness_port(QueryStudioReadinessPort())
    ports.install_dependency_port(QueryStudioDependencyPort())
    ports.install_host(
        derive_artifact_grain=derive_artifact_grain,
        find_result_file=find_result_file,
        report_parameters_for_execution=report_parameters_for_execution,
        resolve_param_value=resolve_param_value,
        dataset_sql_dialect=dataset_sql_dialect,
        fill_rule_defaults=fill_rule_defaults,
        resolve_lov_dataset_id=resolve_lov_dataset_id,
        refuse_unreadable_value_tables=refuse_unreadable_value_tables,
        connection_visible_to=connection_visible_to,
        registered_table_partition_values=registered_table_partition_values,
        dataset_partition_detection=dataset_partition_detection,
        sql_files_storage_dir=sql_files_storage_dir,
        register_switch_on=register_switch_on,
        parts_datasets=parts_datasets,
    )


install()

__all__ = ["QueryStudioArtifactPort", "QueryStudioDependencyPort", "QueryStudioPolicyPort",
           "QueryStudioReadinessPort", "install"]
