"""Import a Power BI report file as a canvas report (2026-11-07, the report framework's
stage 8; the parser and the mapping are ``core/reports/powerbi_import.py``).

Two routes, both ``reports.create``:

``POST /api/powerbi-import/preview``   multipart: ``file`` (.pbix / .pbit / zipped .pbip),
    ``dataset_id``, ``options`` (JSON: ``field_map`` {"Table.Column": column id},
    ``measure_map`` {"Table.Measure": {column_id, aggregation}}, ``exclude_visuals`` [names],
    ``exclude_pages`` [names], ``name``).  Reads the file in memory, SAVES NOTHING, and answers
    the preview: pages, visuals and what each becomes, every field and its match, the parameters,
    the filters (applied / parameter / listed / REFUSED), what is not brought across, the
    measures, the theme, and ``report`` = the body Create would save when nothing refuses.
``POST /api/powerbi-import/create``    the same body; refuses (422) while the preview holds a
    refusal, else saves THROUGH THE SCREEN'S OWN ROUTE (``business_reports_api.create_report``,
    then ``batch_save_parameters``) so every rule of a save holds -- never a direct insert.

The upload is bounded before it is read (Content-Length, then the bytes as they arrive);
nothing from the file is written to disk and nothing in it is run.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile

from api.deps import require_capability
from core.reports import powerbi_import as pbi

logger = logging.getLogger(__name__)
router = APIRouter()

#: the file-name endings a person may choose
ACCEPTED_ENDINGS = (".pbix", ".pbit", ".pbip", ".zip")


def _db():
    import api.business_reports_api as bra
    return bra._require_db()


async def _read_upload(request: Request, file: UploadFile) -> bytes:
    """The upload's bytes, refused in words before the cap is crossed."""
    cl = request.headers.get("content-length")
    try:
        if cl is not None and int(cl) > pbi.MAX_FILE_BYTES + 1024 * 1024:
            raise HTTPException(status_code=413, detail=f"The file is larger than {pbi.MAX_FILE_BYTES // 1048576} MB, "
                                                        "the most a Power BI report file can be here.")
    except ValueError:
        pass
    out = bytearray()
    while True:
        chunk = await file.read(1024 * 1024)
        if not chunk:
            break
        out += chunk
        if len(out) > pbi.MAX_FILE_BYTES:
            raise HTTPException(status_code=413, detail=f"The file is larger than {pbi.MAX_FILE_BYTES // 1048576} MB, "
                                                        "the most a Power BI report file can be here.")
    if not out:
        raise HTTPException(status_code=400, detail="The file is empty.")
    return bytes(out)


def _options(raw: Optional[str]) -> Dict[str, Any]:
    if not raw or not str(raw).strip():
        return {}
    try:
        opts = json.loads(raw)
    except ValueError:
        raise HTTPException(status_code=400, detail="The import options are not readable JSON.")
    if not isinstance(opts, dict):
        raise HTTPException(status_code=400, detail="The import options must be a JSON object.")
    for key in ("field_map", "measure_map"):
        if key in opts and opts[key] is not None and not isinstance(opts[key], dict):
            raise HTTPException(status_code=400, detail=f"'{key}' must be an object.")
    for key in ("exclude_visuals", "exclude_pages"):
        if key in opts and opts[key] is not None and not (isinstance(opts[key], list) and all(isinstance(x, str) for x in opts[key])):
            raise HTTPException(status_code=400, detail=f"'{key}' must be a list of names.")
    if "name" in opts and opts["name"] is not None and not isinstance(opts["name"], str):
        raise HTTPException(status_code=400, detail="'name' must be text.")
    return opts


async def _dataset_for(dataset_id: int, user: dict) -> dict:
    """The dataset as the person may see it -- through the datasets route's own rules."""
    import api.datasets_api as dsa
    ds = await dsa.get_dataset(int(dataset_id), user)
    if not isinstance(ds, dict):
        raise HTTPException(status_code=404, detail="Dataset not found")
    return ds


def _has_metrics(dataset_id: int) -> bool:
    """The save's own reading (``business_reports_api._validate_canvas``): any calculated metric
    means the stored rows are grouped; unknown = the stricter rule."""
    try:
        m = _db().list_calculated_metrics(dataset_id, active_only=False)
        return bool(m) if isinstance(m, (list, tuple)) else False
    except Exception:                                    # noqa: BLE001
        return True


def _other_report_ids(dataset_id: int) -> List[int]:
    """The reports that read this dataset today; unknown = the stricter rule (one unnamed report)."""
    try:
        ids = _db().list_business_report_ids_for_dataset(int(dataset_id))
        return [int(i) for i in (ids or [])]
    except Exception:                                    # noqa: BLE001
        return [-1]


def _safe_name(filename: Optional[str]) -> str:
    """The file's own name, for words and the report's name -- never a path."""
    name = str(filename or "report").replace("\\", "/").rsplit("/", 1)[-1].strip() or "report"
    return name[:200]


async def _preview(request: Request, file: UploadFile, dataset_id: int, options: Optional[str], user: dict) -> Dict[str, Any]:
    name = _safe_name(file.filename)
    if not name.lower().endswith(ACCEPTED_ENDINGS):
        raise HTTPException(status_code=400, detail=f"Choose a Power BI report file: .pbix, .pbit, or a .pbip project "
                                                    f"zipped (.zip). '{name}' is none of these.")
    opts = _options(options)
    data = await _read_upload(request, file)
    ds = await _dataset_for(dataset_id, user)
    has_metrics = await asyncio.to_thread(_has_metrics, int(dataset_id))
    # 2026-11-08 -- the report runs at DETAIL grain (core.reports.powerbi_import.detail_grain): the plan
    # is made over the dataset's columns read as-is, and create sets them so before the save
    _others = await asyncio.to_thread(_other_report_ids, int(dataset_id))
    _dg = pbi.detail_grain(list(ds.get("columns") or []), has_metrics=has_metrics, other_report_ids=_others)
    try:
        parsed = await asyncio.to_thread(pbi.read_report, data, name)
        out = await asyncio.to_thread(
            pbi.plan, parsed, ds, dataset_columns=list(_dg["columns"]), file_name=name,
            field_map=opts.get("field_map"), measure_map=opts.get("measure_map"),
            exclude_visuals=opts.get("exclude_visuals"), exclude_pages=opts.get("exclude_pages"),
            report_name=opts.get("name"), has_metrics=has_metrics)
    except pbi.ImportRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    out["detail_rows"] = {"columns": [int(c["id"]) for c in _dg["as_is"]], "labels": list(_dg["labels"]),
                          "words": _dg["words"]}
    if _dg["refusal"]:
        out["refusals"] = list(out.get("refusals") or []) + [
            {"what": "the dataset", "why": _dg["refusal"], "where": str(ds.get("name") or ""), "field": ""}]
        out["can_create"] = False
    return out


@router.post("/api/powerbi-import/preview")
async def powerbi_import_preview(request: Request, file: UploadFile = File(...), dataset_id: int = Form(...),
                                 options: Optional[str] = Form(None),
                                 user: dict = Depends(require_capability("reports.create"))):
    """What the file would become on this dataset.  Saves nothing."""
    return await _preview(request, file, dataset_id, options, user)


@router.post("/api/powerbi-import/create")
async def powerbi_import_create(request: Request, file: UploadFile = File(...), dataset_id: int = Form(...),
                                options: Optional[str] = Form(None),
                                user: dict = Depends(require_capability("reports.create"))):
    """The preview, then the report saved through the screen's own creation route."""
    import api.business_reports_api as bra
    out = await _preview(request, file, dataset_id, options, user)
    if out.get("refusals") or not out.get("report"):
        raise HTTPException(status_code=422, detail={
            "message": "The report cannot be created yet: " + "; ".join(
                f"{r['where']}: {r['why']}" for r in (out.get("refusals") or [])[:5]),
            "refusals": out.get("refusals") or [],
        })
    body: Dict[str, Any] = dict(out["report"])
    # the dataset's adding-up columns are read as-is from here on: the report's rows are the rows
    for _cid in (out.get("detail_rows") or {}).get("columns") or []:
        await asyncio.to_thread(_db().update_dataset_column, int(_cid), aggregation="")
    try:
        made = await bra.create_report(bra.ReportCreate(**body), user)
    except HTTPException as exc:
        # a save rule refused (a canvas problem, a theme problem): said in the preview's words
        detail = exc.detail
        if isinstance(detail, dict):
            words = detail.get("message") or json.dumps(detail)[:800]
            problems = detail.get("problems")
            if isinstance(problems, list):
                words = (words or "The canvas was refused") + ": " + "; ".join(
                    str(p.get("message") if isinstance(p, dict) else p) for p in problems[:8])
        else:
            words = str(detail)
        raise HTTPException(status_code=exc.status_code if exc.status_code < 500 else 422,
                            detail=f"The report could not be saved: {words}")
    rid = int(made["id"])
    rows: List[dict] = list(out.get("parameter_rows") or [])
    if rows:
        try:
            await bra.batch_save_parameters(rid, bra.BatchParameterRequest(parameters=rows), user)
        except HTTPException as exc:
            logger.warning("[powerbi-import] report %s saved; its parameters were refused: %s", rid, exc.detail)
            out["parameters_problem"] = f"The report was saved, but its parameters were refused: {exc.detail}"
    saved = await asyncio.to_thread(_db().get_business_report, rid)
    return {"report": saved or made, "report_id": rid, "slug": (saved or {}).get("slug"),
            "tiles": out.get("tiles"), "parameters": len(rows), "not_brought_across": out.get("not_brought_across"),
            "measures": out.get("measures"), "theme_words": out.get("theme_words"),
            "detail_rows": out.get("detail_rows"), "parameters_problem": out.get("parameters_problem")}


__all__ = ["router", "ACCEPTED_ENDINGS"]
