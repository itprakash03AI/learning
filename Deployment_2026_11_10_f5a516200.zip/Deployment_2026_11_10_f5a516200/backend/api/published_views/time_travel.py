"""FB-38 (2026-09-19) -- Iceberg time travel is a CAPABILITY a view declares,
asked ONCE, before a request that depends on it is answered.

Every published lane advertises ``?snapshot_id=`` / ``?as_of_timestamp=``,
and only the saved_query handler implements them -- the business_report and
federation handlers accepted both and returned CURRENT data with HTTP 200.
Measured on the rig: the travelled and the ignored answer differed by
138,033,109.63 in sum(amt); the response shape, columns and status were
identical.  A mistyped snapshot id silently changed the answer instead of
failing.  The limitation lived in a Python comment ("time travel:
saved_query-only ... unused") and nothing reached the caller.

Even the saved_query lane travels only when the frozen query reads an
ICEBERG table: an S3 parquet file, a local file or a SQL-connector saved
query (no ``FOR VERSION AS OF`` is emitted anywhere in this codebase) has no
snapshot to travel to, and the parameter was stashed into ``query_config``
and consumed by nothing.

This module answers "can THIS view travel?" once.  The dispatcher and the
three handlers refuse from it; ``GET /api/v1/views/{slug}`` reports it as
``time_travel_supported`` so a consumer can ask before it pulls -- the same
shape as ``/api/feeds/backend-options`` (available + detail), Clockwork
(routable + reason) and row-security (``materialize_views_available`` +
``_unavailable_reason``).

The answer is tri-state.  ``None`` means "could not tell" (the connection
that would say whether a registered table is Iceberg could not be read) and
the caller refuses as a 503, never as "no".  Unknown is not empty.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple

#: Source types whose handler implements ``snapshot_id`` / ``as_of_timestamp``.
#: A plugin that registers a new source type in ``_SOURCE_HANDLERS`` and
#: implements time travel adds itself here; otherwise its views refuse.
#: 2026-11-08 -- ``sql_query`` / ``sql_file`` (a saved SQL on ONE connection)
#: run through the saved_query handler and travel on the SQL road below.
TIME_TRAVEL_SOURCE_TYPES = frozenset({"saved_query", "sql_query", "sql_file"})

#: The two roads a view travels on.  ``iceberg`` = QueryStudio reads the
#: table's own metadata (an S3 / storage connection); ``sql`` = the SQL
#: source reads its own history and the statement is rewritten so EVERY
#: table it reads carries the source's clause (``core.iceberg_versions.
#: pin_every_table``).
ROAD_ICEBERG = "iceberg"
ROAD_SQL = "sql"


@dataclass(frozen=True)
class TimeTravelAnswer:
    """ONE answer to "can this view travel, and how?" -- what the meta route
    reports, what the data routes refuse from, what ``/versions`` lists by.

    ``supported`` is True / False / None (could not tell); ``reason`` is for
    the consumer and None only when supported; ``kinds`` are the pins the
    road can read (``id`` = a version number, ``timestamp`` = a time);
    ``how_listed`` says where a consumer finds the versions it may ask for;
    ``road`` is ``iceberg`` / ``sql`` / None."""
    supported: Optional[bool]
    reason: Optional[str] = None
    kinds: Tuple[str, ...] = ()
    how_listed: Optional[str] = None
    road: Optional[str] = None
    connection_type: Optional[str] = None

    @property
    def pair(self) -> Tuple[Optional[bool], Optional[str]]:
        return self.supported, self.reason

    def kind_refusal(self, snapshot_id: Any, as_of_timestamp_ms: Any) -> Optional[str]:
        """The sentence when the request asks a KIND this road cannot read
        (a version number of a Snowflake table), or None when it can."""
        if not self.supported:
            return None
        if snapshot_id is not None and "id" not in self.kinds:
            return (f"This view's {self.connection_type or 'source'} source keeps no version "
                    f"numbers, so ?snapshot_id= cannot be read on it. Ask for a time instead "
                    f"(?as_of_timestamp=). {self.how_listed or ''}").strip()
        if as_of_timestamp_ms is not None and "timestamp" not in self.kinds:
            return (f"This view's {self.connection_type or 'source'} source cannot be read as of "
                    f"a time; ask for a version number (?snapshot_id=). "
                    f"{self.how_listed or ''}").strip()
        return None

_ICEBERG_PREFIX = "__iceberg__:"
_REGISTERED_PREFIX = "__registered__:"


def _ref_path(ref: Any) -> str:
    if isinstance(ref, str):
        return ref
    if isinstance(ref, dict):
        return str(ref.get("path") or ref.get("name") or "")
    return ""


def _registered_iceberg_names(connection_config: Optional[Dict[str, Any]]) -> Dict[str, str]:
    """{lower_name: name} of the connection's registered tables whose
    ``format`` is iceberg (the marker ``core.duckdb_views`` branches on)."""
    out: Dict[str, str] = {}
    for tbl in (connection_config or {}).get("registered_tables") or []:
        if not isinstance(tbl, dict):
            continue
        name = tbl.get("name")
        if name and str(tbl.get("format") or "parquet").lower() == "iceberg":
            out[str(name).lower()] = str(name)
    return out


def iceberg_table_refs(query_config: Dict[str, Any],
                       connection_config: Optional[Dict[str, Any]] = None) -> List[str]:
    """The Iceberg tables a frozen ``query_config`` reads: ``__iceberg__:x``
    refs, ``__registered__:x`` / bare refs whose registered table is
    iceberg, and -- for a raw_sql query with no ``files`` -- registered
    iceberg names that appear in the SQL text."""
    registered = _registered_iceberg_names(connection_config)
    names: List[str] = []
    refs: Iterable[Any] = (query_config or {}).get("files") or []
    for ref in refs:
        path = _ref_path(ref).strip()
        if not path:
            continue
        if path.startswith(_ICEBERG_PREFIX):
            names.append(path[len(_ICEBERG_PREFIX):].strip())
        elif path.startswith(_REGISTERED_PREFIX):
            bare = path[len(_REGISTERED_PREFIX):].strip()
            if bare.lower() in registered:
                names.append(registered[bare.lower()])
        elif "/" not in path and ":" not in path and path.lower() in registered:
            names.append(registered[path.lower()])
    raw_sql = str((query_config or {}).get("raw_sql") or "")
    if raw_sql and registered:
        low = raw_sql.lower()
        for lname, name in registered.items():
            if re.search(r"\b" + re.escape(lname) + r"\b", low):
                names.append(name)
    return sorted(set(names))


_ICEBERG_KINDS = ("id", "timestamp")
_ICEBERG_HOW = ("the versions are listed at GET /api/v1/views/{slug}/versions "
                "(one list per Iceberg table the view reads)")


def time_travel_details(pv: Dict[str, Any],
                        connection_config: Optional[Dict[str, Any]] = None,
                        *, connection_unreadable: Optional[str] = None,
                        connection_type: Optional[str] = None,
                        ) -> TimeTravelAnswer:
    """THE decision, with its kinds and road (2026-11-08).

    Iceberg first (unchanged since FB-38): a frozen query that reads an
    Iceberg table travels on QueryStudio's own read.  Then the SQL road: a
    single-connection view whose connection TYPE declares pin kinds
    (``core/connectors/version_capability.py`` -- Snowflake a time,
    Databricks a version or a time, Trino / Starburst / Athena / Oracle as
    declared) travels by rewriting the statement so EVERY table carries the
    source's clause.  A type that declares none refuses with ITS reason
    (PostgreSQL keeps no table versions).  A view over TWO sources
    (``secondary_connection_id``) cannot be read as of one time -- decided,
    not guessed.  Unknown stays unknown: an unreadable connection is None."""
    src = str(pv.get("source_type") or "saved_query")
    slug = pv.get("slug") or "{slug}"
    if src not in TIME_TRAVEL_SOURCE_TYPES:
        return TimeTravelAnswer(False, (
            f"Time travel (?snapshot_id= / ?as_of_timestamp=) is not implemented "
            f"for a view whose source_type is '{src}': only a view over ONE saved "
            f"query (an Iceberg table, or a Snowflake / Databricks / Trino / Oracle "
            f"source that keeps history) can read a named version.  The request is "
            f"refused rather than answered with CURRENT data under a historical "
            f"label.  GET /api/v1/views/{slug} reports time_travel_supported."))
    qc = pv.get("query_config") or {}
    tables = iceberg_table_refs(qc, connection_config)
    if tables:
        return TimeTravelAnswer(True, None, _ICEBERG_KINDS, _ICEBERG_HOW.format(slug=slug),
                                ROAD_ICEBERG, connection_type)
    if qc.get("secondary_connection_id"):
        return TimeTravelAnswer(False, (
            f"Time travel (?snapshot_id= / ?as_of_timestamp=) is not available on "
            f"this view: it reads TWO sources (a cross-source query), and a view over "
            f"two sources cannot be read as of one time -- each source keeps its own "
            f"history.  The request is refused rather than answered with current data.  "
            f"GET /api/v1/views/{slug} reports time_travel_supported."), connection_type=connection_type)
    if connection_unreadable:
        return TimeTravelAnswer(None, (
            f"Whether this view supports time travel could not be determined: "
            f"{connection_unreadable}.  The request is refused rather than "
            f"answered with data of unknown vintage; retry, or ask an "
            f"administrator to check connection {qc.get('connection_id')!r}."), connection_type=connection_type)
    ctype = str(connection_type or "").strip().lower()
    if ctype:
        from core.connectors.version_capability import capability_for
        cap = capability_for(ctype)
        if not cap.native_qs and cap.kinds and _reads_sql_text(qc):
            problem = _sql_pin_problem(qc, ctype)
            if problem:
                return TimeTravelAnswer(False, (
                    f"Time travel (?snapshot_id= / ?as_of_timestamp=) is not available on this "
                    f"view: {problem}  GET /api/v1/views/{slug} reports time_travel_supported."),
                    connection_type=ctype)
            kinds = tuple(k for k in ("id", "timestamp") if k in cap.kinds)
            return TimeTravelAnswer(True, None, kinds, cap.how_listed, ROAD_SQL, ctype)
        if not cap.native_qs and not cap.kinds:
            return TimeTravelAnswer(False, (
                f"Time travel (?snapshot_id= / ?as_of_timestamp=) is not available on "
                f"this view: its {ctype} source keeps no history to read. "
                f"{cap.reason or ''} The request is refused rather than answered with "
                f"current data.  GET /api/v1/views/{slug} reports time_travel_supported."
            ), connection_type=ctype)
    return TimeTravelAnswer(False, (
        f"Time travel (?snapshot_id= / ?as_of_timestamp=) is not available on "
        f"this view: its frozen query reads no Iceberg table (S3 parquet and "
        f"local files have no snapshots to travel to), so a snapshot would be "
        f"ignored and CURRENT data returned.  The request is refused instead.  "
        f"GET /api/v1/views/{slug} reports time_travel_supported."), connection_type=connection_type)


def answer_for_view(pv: Dict[str, Any], get_connection_raw=None,
                    conn_cache: Optional[Dict[int, Any]] = None) -> TimeTravelAnswer:
    """THE wrapper every route reads (2026-11-08): fetches the view's connection
    record through ``get_connection_raw`` (its config for a registered-table
    ref, its TYPE for the SQL road), reports an unreadable connection as
    UNKNOWN (None, never "no"), and hands everything to
    :func:`time_travel_details`.  ``conn_cache`` lets a listing read each
    connection once.  The consumer meta route
    (``published_views_api._time_travel_answer_for``) and the management list
    (``management._with_time_travel``) both call this -- one decision."""
    conn_cfg = None
    conn_type = None
    unreadable = None
    if str(pv.get("source_type") or "saved_query") in TIME_TRAVEL_SOURCE_TYPES:
        qc = pv.get("query_config") or {}
        cid = qc.get("connection_id")
        if cid and get_connection_raw is not None:
            try:
                key = int(cid)
                if conn_cache is not None and key in conn_cache:
                    rec = conn_cache[key]
                else:
                    rec = get_connection_raw(key)
                    if conn_cache is not None:
                        conn_cache[key] = rec
                if rec:
                    conn_cfg = rec.get("config") or {}
                    conn_type = rec.get("connection_type")
                else:
                    unreadable = f"connection {cid} was not found"
            except Exception as exc:                     # noqa: BLE001
                unreadable = f"connection {cid} could not be read ({type(exc).__name__})"
    return time_travel_details(pv, conn_cfg, connection_unreadable=unreadable,
                               connection_type=conn_type)


#: The keys a view row carries so a consumer's page can draw the "Read as of"
#: control from the ONE answer (the management list and the consumer meta
#: route spell them the same way).
TIME_TRAVEL_ROW_KEYS = ("time_travel_supported", "time_travel_unavailable_reason",
                        "time_travel_kinds", "time_travel_how_listed", "time_travel_road")


def time_travel_row(answer: TimeTravelAnswer) -> Dict[str, Any]:
    return {"time_travel_supported": answer.supported,
            "time_travel_unavailable_reason": answer.reason,
            "time_travel_kinds": list(answer.kinds),
            "time_travel_how_listed": answer.how_listed,
            "time_travel_road": answer.road}


def _sql_pin_problem(qc: Dict[str, Any], connection_type: str) -> Optional[str]:
    """Why the view's raw SQL could NOT be pinned (it already reads a table at
    a version, it cannot be parsed, it reads no table), or None.  Asked here
    so the meta route says "no" BEFORE a consumer pulls; the pin itself asks
    again on the final statement."""
    raw = str(qc.get("raw_sql") or qc.get("custom_sql") or "").strip()
    if not raw:
        return None
    from core import iceberg_versions as _iv
    from core.sql_filter_wrapper import dialect_for_connection_type
    dialect = dialect_for_connection_type(connection_type)
    try:
        if _iv._already_versioned(raw, dialect):
            return ("its SQL already reads a table at a version of its own (one time for the "
                    "whole view; the request does not layer a second one on it).")
        if not _iv.sql_table_refs(raw, dialect):
            return "its SQL reads no table, so there is nothing to read as of a time."
    except _iv.IcebergVersionRefusal as exc:
        return str(exc)
    return None


def _reads_sql_text(qc: Dict[str, Any]) -> bool:
    """A SQL-source view has a statement to pin: raw / custom SQL, or a
    structured query over named tables (the handler builds its SQL)."""
    if str(qc.get("raw_sql") or qc.get("custom_sql") or "").strip():
        return True
    return bool(qc.get("files"))
