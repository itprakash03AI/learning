/**
 * Is a filter row filled in?  -- the client mirror of
 * backend/core/federation_engine.py::is_unfilled_filter (2026-10-03).
 *
 * The owner's report saved an untouched "Add Filter" row as
 * {operator: 'eq', value: ''} and the run said `REGION = ''`: 0 rows behind a
 * 200 while the dataset returned 4.  An unfilled row is not a filter.  The
 * server refuses to save one (422 naming the column) and refuses to run one;
 * the builder must not SUBMIT one, and says which row is unfinished.
 */

export interface FilterRow {
  column_id: number;
  operator: string;
  value: any;
  value2?: any;
  /** 2026-10-25 (the owner: "why will I add a value while creating reports ...
   *  it should run with any values") -- the person RUNNING the report picks
   *  the value; saved as a report parameter on this column, never a filter */
  ask_at_run?: boolean;
}

/** The operators a run-time question can stand for: one value, a list, a range. */
export const ASKABLE_OPERATORS = ['eq', 'in', 'between'];

/** Every operator a filter row may use, in the words the screens show (2026-11-07: ONE list for the
 *  tabular builder and the designer's Filters pane; the pivot builder's shorter list is its own). */
export const FILTER_OPERATORS: { value: string; label: string }[] = [
  { value: 'eq', label: '= Equals' },
  { value: 'neq', label: '!= Not Equals' },
  { value: 'gt', label: '> Greater Than' },
  { value: 'gte', label: '>= Greater or Equal' },
  { value: 'lt', label: '< Less Than' },
  { value: 'lte', label: '<= Less or Equal' },
  { value: 'in', label: 'In List' },
  { value: 'not_in', label: 'Not In List' },
  { value: 'between', label: 'Between' },
  { value: 'like', label: 'Contains (LIKE)' },
  { value: 'not_like', label: 'Not Contains' },
  { value: 'starts_with', label: 'Starts With' },
  { value: 'ends_with', label: 'Ends With' },
  { value: 'is_null', label: 'Is Null' },
  { value: 'is_not_null', label: 'Is Not Null' },
];

/** The parameter an "ask when the report runs" row becomes. */
export function askedParameter(f: FilterRow,
                               col: { id: number; friendly_name?: string; physical_name?: string; data_type?: string } | undefined):
    { name: string; label: string; parameter_type: string; lov_column_id: number; values_source: 'any' | 'auto' } {
  const phys = String(col?.physical_name || `column_${f.column_id}`);
  const isDate = String(col?.data_type || '').toLowerCase() === 'date';
  const op = f.operator || 'eq';
  const parameter_type = op === 'in' ? 'multi_select'
    : op === 'between' ? (isDate ? 'date_range' : 'text')
    : isDate ? 'date' : 'dropdown';
  return { name: phys.toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '') || `p${f.column_id}`,
           label: col?.friendly_name || phys, parameter_type, lov_column_id: f.column_id,
           // a date asked at run time takes any day on a calendar (2026-10-29)
           values_source: parameter_type === 'date' || parameter_type === 'date_range' ? 'any' : 'auto' };
}

/** 2026-10-29 -- a condition of the dataset's own SQL WHERE, as
 *  `GET /api/datasets/{id}/source-filters` lists it (backend
 *  core/source_filters.py).  The literal in the query is the default. */
export interface SourceFilter {
  key: string;            // 'fact_tetb.system_id'
  column: string;         // 'SYSTEM_ID'
  qualifier?: string;     // 'FACT_TETB'
  table?: string;
  op: string;             // eq | in | between | gt | gte | lt | lte | neq
  values: string[];
  value_kind?: string;
  is_date?: boolean;
  parameter_type: string | null;   // null = found but not offered
  values_source: 'any' | 'auto';
  offered: boolean;
  sql: string;
  words: string;          // "Without a value the report uses what the query says: ..."
  /** 2026-11-12 -- how many places of the query a value replaces (both sides of a JOIN, each CTE) */
  places?: number;
  /** 2026-11-12 -- a `{NAME}` the query ASKS for each time it runs (key `{name}`, column = NAME);
   *  `values` is what the dataset uses when nobody gives one -- empty = the report cannot run without it */
  placeholder?: boolean;
  /** (review) does the DATASET declare the `{NAME}`?  false = it only LOOKS like a value asked at
   *  run time: the text is sent as written until a report parameter is linked to it */
  declared?: boolean;
  table_ref?: string;
}

/** 2026-11-12 -- a column the query returns whose values the query itself FIXES
 *  (`BUSINESS_DATE = <one day>`): a filter on the RESULTS can only ever find those. */
export interface FixedOutput {
  output: string;         // the column as the query names it
  key: string;            // the source filter (or placeholder) that fixes it
  values: string[];
  placeholder?: boolean;
  words: string;
}

/** A placeholder the DATASET declares and gives no value: the report cannot run unless it is asked. */
export function mustBeAsked(f: SourceFilter): boolean {
  return !!f.placeholder && f.declared !== false && !(f.values || []).length;
}

/** The parameter a "Filter at the source" condition becomes when it is
 *  asked when the report runs: bound to the query's condition
 *  (`source_column`), never to an output column. */
export function sourceParameter(f: SourceFilter):
    { name: string; label: string; parameter_type: string; source_column: string;
      lov_column_id: null; values_source: 'any' | 'auto'; is_required: boolean; default_value: '' } {
  const base = (f.column || f.key).toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '');
  return { name: base || f.key.replace(/[^a-z0-9_]+/gi, '_'), label: f.column || f.key,
           parameter_type: f.parameter_type || (f.placeholder ? 'text' : 'multi_select'), source_column: f.key,
           lov_column_id: null, values_source: f.values_source || (f.is_date ? 'any' : 'auto'),
           // a value the query asks for and the dataset does not give: the viewer must (once a
           // parameter is linked to a {NAME}, the name IS asked for -- declared or not)
           is_required: !!f.placeholder && !(f.values || []).length, default_value: '' };
}

/** "used in 2 places of the query" -- said only when it is more than one. */
export function placesWords(f: Pick<SourceFilter, 'places'>): string {
  return (f.places || 1) > 1 ? ` (used in ${f.places} places of the query)` : '';
}

/** The words a source filter shows beside its tick.  `all` = the whole list: two conditions
 *  on the same column name (one per table) are each named with their table. */
export function sourceFilterWords(f: SourceFilter, all?: SourceFilter[]): string {
  if (f.placeholder && f.declared === false) {
    return `{${f.column}} -- looks like a value asked at run time; tick it to ask for it${placesWords(f)}`;
  }
  if (f.placeholder) {
    return `{${f.column}} -- ${(f.values || []).length
      ? `the query asks for it; ${f.values.join(', ')} when nobody gives one`
      : 'the query asks for it and cannot run without it'}${placesWords(f)}`;
  }
  const vals = f.op === 'between' ? `from ${f.values[0]} to ${f.values[1]}` : f.values.join(', ');
  return `${f.qualifier ? `${f.qualifier}.` : ''}${f.column}${tableWords(f, all)} -- now ${vals}${placesWords(f)}`;
}

/** " (table EXT)" when another condition of the list is on the same column name. */
export function tableWords(f: SourceFilter, all?: SourceFilter[]): string {
  const table = f.table_ref || f.table;
  if (!table || !all) return '';
  const twin = all.some(o => o.key !== f.key && !o.placeholder
    && String(o.column || '').toLowerCase() === String(f.column || '').toLowerCase());
  return twin ? ` (table ${table})` : '';
}

/** The fixed output a column of the report is, if the dataset's query fixes it --
 *  matched by the column's own name in the query, any case. */
export function fixedOutputOf(
  col: { physical_name?: string; friendly_name?: string } | undefined | null,
  fixed: FixedOutput[] | null | undefined,
): FixedOutput | undefined {
  const name = String(col?.physical_name || '').trim().toLowerCase();
  if (!name) return undefined;
  return (fixed || []).find(f => String(f.output || '').trim().toLowerCase() === name);
}

export const NO_VALUE_OPERATORS = ['is_null', 'is_not_null'];
export const LIST_OPERATORS = ['in', 'not_in'];
/** Text-pattern operators: the operand is a pattern the author types. */
export const PATTERN_OPERATORS = ['like', 'not_like', 'starts_with', 'ends_with',
                                  'contains', 'not_contains'];

const blank = (v: any) => v === null || v === undefined || v === '';

/** Same rule as the server's `_coerce_in_list`: a comma string is a list. */
export function inListItems(value: any): any[] {
  if (blank(value)) return [];
  if (Array.isArray(value)) return value.filter(v => !blank(v));
  if (typeof value === 'string') {
    return value.split(',').map(s => s.trim()).filter(s => s !== '');
  }
  return [value];
}

export function isUnfilledFilter(f: FilterRow): boolean {
  if (f.ask_at_run) return false;          // its value is asked when the report runs
  const op = f.operator || 'eq';
  if (NO_VALUE_OPERATORS.includes(op)) return false;
  if (LIST_OPERATORS.includes(op)) return inListItems(f.value).length === 0;
  if (op === 'between') {
    let lo = f.value; let hi = f.value2;
    if (blank(hi) && Array.isArray(lo) && lo.length === 2) [lo, hi] = lo;
    return blank(lo) || blank(hi);
  }
  return blank(f.value) || Array.isArray(f.value);
}

/** One sentence per unfinished row, naming its column. */
export function unfilledFilterProblems(
  filters: FilterRow[],
  columns: Array<{ id: number; friendly_name?: string; physical_name?: string }>,
): string[] {
  return filters.flatMap((f, i) => {
    if (!isUnfilledFilter(f)) return [];
    const c = columns.find(x => x.id === f.column_id);
    const name = c ? (c.friendly_name || c.physical_name) : `column ${f.column_id}`;
    return [`Filter ${i + 1} (${name}) has no value -- pick one or remove the row.`];
  });
}

/** The wire form: an IN list travels as a list. */
export function filterForSave(f: FilterRow): FilterRow {
  if (LIST_OPERATORS.includes(f.operator)) return { ...f, value: inListItems(f.value) };
  return f;
}

// ── 2026-11-12 (review round 2) -- ONE question for the same value on several tables ──────────
//
// The owner's JOIN writes the same business date on fact_tetb (a CTE) and on fact_tetb_ext (the
// JOIN side).  The server keeps them as TWO conditions -- a value is never put into another
// table's condition by itself -- and the builder offers them as ONE question by default: one
// parameter whose `applies` lists every ticked condition, so the viewer picks the date once.

/** The conditions that ask the same thing as `f`: the same column name, operator, kind and
 *  current value(s), on other tables.  `f` itself first, the rest in the list's order. */
export function twinsOf(f: SourceFilter, all: SourceFilter[] | null | undefined): SourceFilter[] {
  if (f.placeholder || !f.offered) return [f];
  const sig = (x: SourceFilter) => [String(x.column || '').toLowerCase(), x.op, x.parameter_type,
                                    (x.values || []).join('\u0001')].join('\u0002');
  const mine = sig(f);
  return [f, ...(all || []).filter(o => o.key !== f.key && !o.placeholder && o.offered && sig(o) === mine)];
}

export interface SourceQuestion {
  lead: SourceFilter;          // the first condition of the question (its row, its test ids)
  members: SourceFilter[];     // the conditions ONE value is given to (the lead first)
  targets: SourceFilter[];     // every condition that could be asked together (members + the ones set apart)
}

/** The questions the builder offers: conditions that ask the same thing are ONE question unless
 *  the author set one apart (`apart` = its key), which is then a question of its own. */
export function sourceQuestions(all: SourceFilter[], apart: string[] = []): SourceQuestion[] {
  const out: SourceQuestion[] = [];
  const placed = new Set<string>();
  for (const f of all) {
    if (placed.has(f.key)) continue;
    if (apart.includes(f.key)) { placed.add(f.key); out.push({ lead: f, members: [f], targets: [f] }); continue; }
    const targets = twinsOf(f, all);
    const members = targets.filter(t => !apart.includes(t.key));
    members.forEach(m => placed.add(m.key));
    out.push({ lead: f, members, targets });
  }
  return out;
}

/** "fact_tetb (2 places)" -- the table a condition is on, in the words of the query. */
export function targetWords(f: SourceFilter): string {
  const table = f.table_ref || f.table || f.qualifier || f.column;
  return `${table}${(f.places || 1) > 1 ? ` (${f.places} places)` : ''}`;
}

/** "BUSINESS_DATE -- now 2025-09-30; asked once for: fact_tetb (2 places), fact_tetb_ext" */
export function questionWords(q: SourceQuestion): string {
  const f = q.lead;
  const vals = f.op === 'between' ? `from ${f.values[0]} to ${f.values[1]}` : f.values.join(', ');
  return `${f.column} -- now ${vals}; asked once for: ${q.members.map(targetWords).join(', ')}`;
}

/** The ONE parameter a question becomes: bound to its first condition, and -- when it has
 *  several -- given to every one of them (`applies`). */
export function questionParameter(members: SourceFilter[]) {
  const p = sourceParameter(members[0]);
  return members.length > 1
    ? { ...p, applies: members.map(m => ({ to: 'source', source_column: m.key })) }
    : p;
}

/** The conditions of the dataset's query a parameter fills. */
export function paramSourceKeys(p: { source_column?: string | null; applies?: any[] | null }): string[] {
  const keys = (Array.isArray(p.applies) ? p.applies : [])
    .filter(t => t && t.to === 'source' && t.source_column).map(t => String(t.source_column));
  if (p.source_column && !keys.includes(String(p.source_column))) keys.unshift(String(p.source_column));
  return keys;
}

/** `p` filling exactly `keys` (none left = null: the parameter goes). */
export function withSourceKeys<T extends { source_column?: string | null; applies?: any[] | null }>(
  p: T, keys: string[]): T | null {
  if (!keys.length) return null;
  const others = (Array.isArray(p.applies) ? p.applies : []).filter(t => !(t && t.to === 'source'));
  const applies = keys.length > 1 || others.length
    ? [...keys.map(k => ({ to: 'source', source_column: k })), ...others] : null;
  return { ...p, source_column: keys[0], applies };
}
