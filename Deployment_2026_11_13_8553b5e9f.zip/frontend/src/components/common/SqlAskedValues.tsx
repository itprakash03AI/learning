/**
 * The values a dataset's query ASKS for (2026-11-12).
 *
 * The owner: "query parameter is not always hardcoded, it's dynamic and the
 * value will be passed at run time".  A name in braces in the query --
 * `WHERE BUSINESS_DATE = '{BUSINESS_DATE}'` -- can be a value the query takes
 * each time it runs.  It is one only when it is DECLARED: ticked here (the
 * dataset's `sql_param_defaults` names it), or named by a parameter of the
 * report that runs it.  A word in braces nobody declares is plain text of
 * the query and is sent as written -- `LIKE '%{id}%'` keeps working.
 *
 * A declared name may be given the value to use when nobody gives one
 * (reading the columns, a preview, a value list, anything that is not a
 * report).  Declared with no value, such a run is refused in words -- the
 * name is never sent to the source.
 *
 * The names are read from the text here only to draw the rows; the server
 * reads them again (backend core/source_filters.py) and is the one that
 * puts a value in.
 */
import React from 'react';
import { Box, Checkbox, FormControlLabel, TextField, Typography } from '@mui/material';

/** The `{NAME}`s of a SQL text, each once, in order -- not one inside a
 *  comment or a "quoted identifier", not a doubled `{{NAME}}` (the server's
 *  rule, for the screen). */
export function askedNames(sql: string): string[] {
  const text = String(sql || '')
    .replace(/--[^\n]*/g, ' ')
    .replace(/\/\*[\s\S]*?\*\//g, ' ')
    .replace(/"[^"]*"/g, ' ');
  const seen = new Set<string>();
  const out: string[] = [];
  for (const m of text.matchAll(/\{([A-Za-z_][A-Za-z0-9_]*)\}/g)) {
    const at = m.index ?? 0;
    if (text[at - 1] === '{' && text[at + m[0].length] === '}') continue;   // {{NAME}}
    const low = m[1].toLowerCase();
    if (!seen.has(low)) { seen.add(low); out.push(m[1]); }
  }
  return out;
}

const keyOf = (values: Record<string, string> | null | undefined, name: string) =>
  Object.keys(values || {}).find(k => k.toLowerCase() === name.toLowerCase());

/** What to send as `sql_param_defaults`: every DECLARED name the query still
 *  has, with its value ('' = declared, no value of its own).  A name that is
 *  not in the result is plain text of the query. */
export function askedValuesForSave(sql: string, values: Record<string, string> | null | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  for (const name of askedNames(sql)) {
    const hit = keyOf(values, name);
    if (hit !== undefined) out[name] = String((values || {})[hit] ?? '').trim();
  }
  return out;
}

/** The server's `sql_param_defaults` as this box holds it (a null value = declared, none of its own). */
export function askedValuesFromServer(doc: any): Record<string, string> {
  if (!doc || typeof doc !== 'object') return {};
  return Object.fromEntries(Object.entries(doc).map(
    ([k, v]) => [k, Array.isArray(v) ? v.join(', ') : String(v ?? '')]));
}

export default function SqlAskedValues({ sql, value, onChange }: {
  sql: string;
  /** the DECLARED names and their values; a name not in it is plain text */
  value: Record<string, string> | null | undefined;
  onChange: (next: Record<string, string>) => void;
}) {
  const names = React.useMemo(() => askedNames(sql), [sql]);
  if (names.length === 0) return null;
  const declared = (name: string) => keyOf(value, name) !== undefined;
  const valueOf = (name: string) => { const k = keyOf(value, name); return k === undefined ? '' : String((value || {})[k] ?? ''); };
  const set = (name: string, on: boolean, text?: string) => {
    const next: Record<string, string> = {};
    for (const n of names) {
      if (n === name) { if (on) next[n] = text ?? valueOf(n); } else if (declared(n)) next[n] = valueOf(n);
    }
    onChange(next);
  };
  return (
    <Box sx={{ mt: 2 }} data-testid="sql-asked-values">
      <Typography variant="subtitle2">Values this query asks for</Typography>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
        A name in {'{ }'} looks like a value asked at run time. Tick it to ask for it: a report then gives it
        through a parameter, and you can set the value to use when nobody gives one (reading the columns, a
        preview, a value list). Ticked with no value, a run that gives none is refused rather than sent to the
        source. Left unticked, the text is sent to the source exactly as written.
      </Typography>
      {names.map(name => (
        <Box key={name} sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5, flexWrap: 'wrap' }}>
          <FormControlLabel sx={{ mr: 0, minWidth: 260 }}
            label={<Typography variant="body2">Ask for {`{${name}}`} when the query runs</Typography>}
            control={<Checkbox size="small" checked={declared(name)}
              inputProps={{ 'data-testid': `sql-asked-${name}-declare`, 'aria-label': `Ask for ${name} when the query runs` } as any}
              onChange={e => set(name, e.target.checked)} />} />
          {declared(name) ? (
            <TextField size="small" sx={{ minWidth: 260 }}
              label="Value when nobody gives one" value={valueOf(name)}
              placeholder="2025-09-30, or @TODAY"
              inputProps={{ 'data-testid': `sql-asked-${name}` }}
              onChange={e => set(name, true, e.target.value)} />
          ) : (
            <Typography variant="caption" color="text.secondary" data-testid={`sql-asked-${name}-words`}>
              Looks like a value asked at run time -- tick it to ask for it. Now it is sent as written.
            </Typography>
          )}
        </Box>
      ))}
    </Box>
  );
}
