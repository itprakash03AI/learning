/**
 * The report parameter editor — ONE editor, both builders.
 *
 * 2026-09-03.  BusinessReportBuilder and PivotReportBuilder each carried
 * their own parameter UI, and they had drifted badly:
 *
 *  - the Filter Column picker was fixed on 2026-08-31 to show for EVERY
 *    parameter type (the backend applies a parameter only when the column
 *    is set, and that rule covers all six types).  The fix landed in one
 *    of the two builders.  In the other, a Date Range parameter still
 *    could not be bound to a column at all: the viewer was prompted for a
 *    value and the value did nothing;
 *  - static values, cascade authoring and help text existed only in the
 *    business builder.  PivotReportViewer renders cascading prompts
 *    perfectly — it shares the viewer hook — so the pivot builder was
 *    refusing to author something the pivot viewer already supported;
 *  - the pivot builder saved parameters by deleting them all and creating
 *    them one at a time, so a failure part-way left the report with some
 *    of its parameters and none of its cascade.
 *
 * A capability that exists in one of two builders is the recurring defect
 * in this codebase, so the answer is not to copy the missing half across:
 * it is to have one editor and one save path.  Both builders now render
 * this component and save through `paramRowsToBatchItems` into the atomic
 * batch endpoint.
 */
import React from 'react';
import api from '../../services/api';
import DateDefaultPicker from './DateDefaultPicker';
import ColumnValuePicker from '../common/ColumnValuePicker';
import ValueTablePicker from './ValueTablePicker';
import { safeFetch } from '../../services/api/core';
import { isTemporalColumn } from './reportWizardDraft';
import { BUSINESS_CALENDAR_TOKENS } from '../../utils/dateTokens';
import {
  Box, Paper, TextField, FormControl, InputLabel, Select, MenuItem,
  Checkbox, FormControlLabel, IconButton, Tooltip, Chip, Button,
  Autocomplete, Typography, ListSubheader, Alert,
} from '@mui/material';
import {
  FixedOutput, SourceFilter, fixedOutputOf, paramSourceKeys, placesWords, sourceParameter, tableWords, targetWords,
  twinsOf, withSourceKeys,
} from '../../utils/reportFilters';
import { joinRangeDefault, rangeDefaultSides } from '../../utils/parameterUtils';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
} from '@mui/icons-material';
import {
  ParamRow, ValuesSource, newParamRow, removeParamRow,
} from './reportAuthoringModel';
import { InfoOutlined as InfoIcon } from '@mui/icons-material';
import ChoicesListBox from './ChoicesListBox';
import ParamMoreSettings from './ParamMoreSettings';
import ParamHowItWorks from './ParamHowItWorks';

/** 2026-10-23 -- where the viewer's choices come from, in words. */
export const VALUES_SOURCE_OPTIONS: { value: ValuesSource; label: string; help: string }[] = [
  { value: 'auto', label: 'This parameter’s own list (recommended)',
    help: 'A list kept in QueryStudio’s database and refreshed on a schedule: every value of the '
      + 'column on its source table (SELECT DISTINCT, no WHERE), or the table’s recorded partitions for '
      + 'a partition column. You can see and change its query below. A saved list, if you made one, wins.' },
  { value: 'data', label: 'This parameter’s own list, from the data',
    help: 'The same list in QueryStudio’s database, filled from the column’s distinct values.' },
  { value: 'metadata', label: 'This parameter’s own list, from the table’s partitions',
    help: 'The same list in QueryStudio’s database, filled from the partition values in the table’s '
      + 'metadata (Iceberg / Hive / Trino) without scanning the data. Only for a partition column.' },
  { value: 'static', label: 'A saved list',
    help: 'Exactly the values you save here, in your order. Fill it from the partitions or '
      + 'the data, then edit it.' },
  { value: 'list', label: 'A value list',
    help: 'A named list saved in QueryStudio (Modeling -> Value Lists) -- instant, the same for every report, '
      + 'synced from its query when the source changes. Shows each value with its name.' },
  { value: 'table', label: 'Another table',
    help: 'The values of a column in another table -- for example the company master -- '
      + 'read from the source (cached, and filtered by the viewer’s row security). '
      + 'The choice still filters this report’s column.' },
];

/** "A value list": the named lists saved in QueryStudio, by name. */
function ValueListChoice({ value, onChange, idPrefix }: {
  value: number | null; onChange: (id: number | null) => void; idPrefix: string;
}) {
  const [lists, setLists] = React.useState<any[] | null>(null);
  const [problem, setProblem] = React.useState('');
  React.useEffect(() => {
    safeFetch('/api/value-lists').then((r: any) => setLists(r?.items || []))
      .catch((e: any) => { setLists([]); setProblem(`The value lists could not be read: ${e?.message || e}`); });
  }, []);
  const chosen = (lists || []).find(l => l.id === value);
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5, maxWidth: 420 }} data-testid={`${idPrefix}-value-list`}>
      <FormControl size="small">
        <InputLabel id={`${idPrefix}-vl-label`}>Value list</InputLabel>
        <Select labelId={`${idPrefix}-vl-label`} label="Value list" value={value ?? ''}
          onChange={e => onChange(String(e.target.value) === '' ? null : Number(e.target.value))}>
          <MenuItem value=""><em>Choose a list</em></MenuItem>
          {(lists || []).map(l => <MenuItem key={l.id} value={l.id}>{l.name} ({l.value_count} values)</MenuItem>)}
        </Select>
      </FormControl>
      {chosen && chosen.last_status !== 'ok' && (
        <Typography variant="caption" color="warning.main">
          {chosen.last_status === 'never' ? 'This list has not been synced yet.' : `Its last sync failed: ${chosen.last_error || ''}`}
        </Typography>
      )}
      {lists && !lists.length && !problem && (
        <Typography variant="caption" color="text.secondary">No value list yet -- create one under Modeling → Value Lists.</Typography>
      )}
      {problem && <Typography variant="caption" color="error" role="alert">{problem}</Typography>}
    </Box>
  );
}

/** The saved-list editor with "fill from ..." -- the capture. */
function SavedListEditor({ p, idx, datasetId, onValues }: {
  p: ParamRow; idx: number; datasetId?: number | null;
  onValues: (v: string[] | null) => void;
}) {
  const [busy, setBusy] = React.useState<'' | 'metadata' | 'data'>('');
  const [note, setNote] = React.useState<string | null>(null);
  const fill = async (source: 'metadata' | 'data') => {
    if (!datasetId || !p.lov_column_id) return;
    setBusy(source);
    setNote(null);
    try {
      const r: any = await api.getColumnValues(datasetId, {
        column_id: p.lov_column_id, limit: 500, source });
      const vals = (r?.values || []).map((v: any) => String(v)).filter((v: string) => v !== '');
      if (!vals.length) {
        setNote(r?.reason || r?.source_note || 'No values were found.');
        return;
      }
      onValues(vals);
      const parts = [`${vals.length} value(s) filled from ${r?.source === 'metadata'
        ? `the partitions of ${r?.table || 'the table'}` : 'the data'}.`];
      if (r?.truncated) parts.push('The list was cut at the limit.');
      if (r?.source_note) parts.push(r.source_note);
      setNote(parts.join(' '));
    } catch (e: any) {
      setNote(e?.message || 'The values could not be read.');
    } finally {
      setBusy('');
    }
  };
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, flexWrap: 'wrap' }}>
        <Autocomplete
          multiple freeSolo size="small"
          options={[]}
          value={p.static_values || []}
          onChange={(_e, v) => onValues((v as string[]).length ? (v as string[]) : null)}
          sx={{ minWidth: 260 }}
          renderInput={(params) => (
            <TextField {...params} label="Saved list"
              inputProps={{ ...params.inputProps, 'data-testid': `param-${idx}-saved-list` }}
              helperText="The viewer is offered exactly these, in this order" />
          )}
        />
        <Button size="small" disabled={!datasetId || !p.lov_column_id || !!busy}
                data-testid={`param-${idx}-fill-metadata`}
                onClick={() => fill('metadata')}>
          {busy === 'metadata' ? 'Reading…' : 'Fill from the table’s partitions'}
        </Button>
        <Button size="small" disabled={!datasetId || !p.lov_column_id || !!busy}
                data-testid={`param-${idx}-fill-data`}
                onClick={() => fill('data')}>
          {busy === 'data' ? 'Reading…' : 'Fill from the data'}
        </Button>
      </Box>
      {note && (
        <Typography variant="caption" color="text.secondary" data-testid={`param-${idx}-fill-note`}>
          {note}
        </Typography>
      )}
    </Box>
  );
}

export const PARAM_TYPES = [
  { value: 'dropdown', label: 'Dropdown' },
  { value: 'multi_select', label: 'Multi-Select' },
  { value: 'text', label: 'Text Input' },
  { value: 'date', label: 'Date Picker' },
  { value: 'date_range', label: 'Date Range' },
  { value: 'numeric', label: 'Numeric Input' },
  // 2026-11-01 (FD-04..08): a period anchored on the business date it depends on; two dates to compare
  { value: 'period', label: 'Period (Daily / MTD / QTD / YTD / trends)' },
  { value: 'cob_compare', label: 'Two dates to compare (A vs B)' },
  // 2026-11-01 -- the general parameter model (core/reports/param_contract.py)
  { value: 'number_range', label: 'Number range (from / to)' },
  { value: 'boolean', label: 'Yes / No' },
  { value: 'hierarchy', label: 'Hierarchy (one value per level)' },
];

export const RELATIVE_DATE_OPTIONS = [
  { value: '', label: 'No Default' },
  { value: '@TODAY', label: '@TODAY — today’s date' },
  { value: '@YESTERDAY', label: '@YESTERDAY — yesterday' },
  { value: '@MONTH_START', label: '@MONTH_START — first day of this month' },
  { value: '@MONTH_END', label: '@MONTH_END — last day of this month' },
  { value: '@YEAR_START', label: '@YEAR_START — first day of this year' },
  { value: '@YEAR_END', label: '@YEAR_END — last day of this year' },
  { value: '@LAST_7_DAYS', label: '@LAST_7_DAYS — 7 days ago' },
  { value: '@LAST_30_DAYS', label: '@LAST_30_DAYS — 30 days ago' },
  { value: '@LAST_90_DAYS', label: '@LAST_90_DAYS — 90 days ago' },
  // 2026-09-28 -- the business-calendar tokens (core/business_calendar_tokens.py):
  // the calendar and the N are picked beside the token (DateDefaultPicker) and
  // stored in the one spelling the server resolves, e.g. @PREV_BUSINESS_DAY:LDN.
  ...BUSINESS_CALENDAR_TOKENS.map(t => ({ value: t.value, label: t.label })),
  { value: '__custom__', label: 'Custom date...' },
];

const LIST_TYPES = ['dropdown', 'multi_select'];
const DATE_TYPES = ['date', 'date_range'];

export interface ReportParameterEditorProps {
  rows: ParamRow[];
  onChange: (rows: ParamRow[]) => void;
  /** Dataset columns: {id, friendly_name, physical_name}. */
  columns: any[];
  /**
   * The dataset the columns belong to.  When given, the author can PICK a
   * value from the column instead of typing one.
   *
   * 2026-09-03 -- authoring a parameter meant typing its default and its
   * curated choices into free-text boxes, blind: the author had to already
   * know how the data spells the value.  A default that does not match
   * anything produces a report with no rows and no error, and a static
   * list with a typo produces a dropdown whose entries match nothing.
   * The values are one request away (`POST /api/datasets/{id}/column-
   * values`, the same route the dataset filter panel uses), and they are
   * fetched only when the author opens the control -- never on render, so
   * this adds no scans to loading the builder.
   *
   * Typing is still allowed (`freeSolo`): a curated list may legitimately
   * name a value the data does not contain yet, which is one of the
   * reasons static lists exist.
   */
  datasetId?: number | null;
  /** 2026-11-01 -- the canvas actions and the {TOKEN}s a parameter may be given to */
  actionIds?: string[];
  tokens?: string[];
  /**
   * 2026-10-29 -- the conditions of the dataset's own SQL WHERE a parameter
   * may fill ("Filter at the source", backend core/source_filters.py).  When
   * not given, the editor reads them itself for `datasetId`.
   */
  sourceFilters?: SourceFilter[] | null;
  /** 2026-11-12 -- the columns the dataset's query itself fixes; read with the
   *  conditions when not given.  A parameter on the RESULTS of one is warned. */
  fixedOutputs?: FixedOutput[] | null;
}

export function ReportParameterEditor(
  { rows, onChange, columns, datasetId, sourceFilters, fixedOutputs, actionIds, tokens }: ReportParameterEditorProps,
) {
  // the dataset's own conditions, read once per dataset unless the caller
  // hands them over (the builders already read the dataset)
  const [moreOpen, setMoreOpen] = React.useState<Record<string, boolean>>({});
  const [loadedSource, setLoadedSource] = React.useState<SourceFilter[]>([]);
  const [loadedFixed, setLoadedFixed] = React.useState<FixedOutput[]>([]);
  React.useEffect(() => {
    if (sourceFilters !== undefined || !datasetId) { setLoadedSource([]); setLoadedFixed([]); return; }
    let cancelled = false;
    api.getDatasetSourceFilters(datasetId)
      .then((r: any) => {
        if (cancelled) return;
        setLoadedSource((r?.filters || []).filter((f: any) => f.offered));
        setLoadedFixed(Array.isArray(r?.fixed_outputs) ? r.fixed_outputs : []);
      })
      .catch(() => { if (!cancelled) { setLoadedSource([]); setLoadedFixed([]); } });
    return () => { cancelled = true; };
  }, [datasetId, sourceFilters]);
  const sourceOptions: SourceFilter[] = (sourceFilters ?? loadedSource).filter(f => f.offered);
  const fixedList: FixedOutput[] = fixedOutputs ?? loadedFixed;
  const sourceByKey = (key: string | null) => sourceOptions.find(f => f.key === key);

  const update = (idx: number, field: keyof ParamRow, value: any) => {
    onChange(rows.map((r, i) => {
      if (i !== idx) return r;
      const next: ParamRow = { ...r, [field]: value };
      // "Any date" belongs to a date; a parameter that stops being one
      // goes back to the column's values (2026-10-29)
      if (field === 'parameter_type' && !DATE_TYPES.includes(String(value))
          && next.values_source === 'any') next.values_source = 'auto';
      if (field === 'parameter_type' && DATE_TYPES.includes(String(value))
          && !DATE_TYPES.includes(r.parameter_type) && next.values_source === 'auto') next.values_source = 'any';
      return next;
    }));
  };
  const colLabel = (c: any) => c.friendly_name || c.physical_name;
  // Each row's controls need unique ids, or an InputLabel labels nothing:
  // MUI only associates the two when the Select carries labelId + id.
  // Unlabelled controls are unreachable by screen reader and by name in
  // tests, which is the same invisibility in two different audiences.
  const domId = (p: ParamRow, what: string) =>
    `param-${p._key.replace(':', '-')}-${what}`;

  // 2026-10-03 (owner): "report parameter should be GENERIC and should come
  // from table distinct values".  A parameter is bound to a COLUMN and its
  // choices are that column's distinct values from the source -- fetched by
  // the viewer at run time, cascaded by its parent.  Values here (the
  // default, a legacy hand-typed list) are PICKED through the same control
  // the filter step uses (ColumnValuePicker): loading, an error and "no
  // values" are three different states, never one empty list.
  const colById = (id: number | null) => columns.find((c: any) => c.id === id);
  const fetchFor = (columnId: number) => () =>
    api.getColumnValues(datasetId as number, {
      column_id: columnId, include_range: isTemporalColumn(colById(columnId)) });

  /** Picking the column is the primary act: it names the parameter (when
   *  the author has not), makes a date column a date prompt, and drops a
   *  default that belonged to the previous column. */
  /** 2026-10-29 -- bind the parameter to a CONDITION of the dataset's query
   *  (filter at the source): the condition's shape decides the type and the
   *  choices; the query's literal is the default, so no default is typed. */
  const bindSource = (idx: number, f: SourceFilter) => {
    onChange(rows.map((r, i) => {
      if (i !== idx) return r;
      const s = sourceParameter(f);
      // (review round 2) the same value on several tables is ONE question by default: the
      // parameter is given to every such condition (each can be unticked below)
      const twins = twinsOf(f, sourceOptions);
      const others = (Array.isArray(r.applies) ? r.applies : []).filter((t: any) => !(t && t.to === 'source'));
      return {
        ...r, source_column: s.source_column, lov_column_id: null, default_value: '',
        applies: twins.length > 1 || others.length
          ? [...twins.map(t => ({ to: 'source', source_column: t.key })), ...others] : null,
        parameter_type: s.parameter_type, values_source: s.values_source,
        // a value the query asks for takes the query's own name for it
        name: r.name.trim() ? r.name : (f.placeholder ? s.name : `p_${s.name}`),
        label: r.label.trim() ? r.label : s.label,
        is_required: f.placeholder ? s.is_required : r.is_required,
      };
    }));
  };

  const bindColumn = (idx: number, columnId: number | null) => {
    onChange(rows.map((r, i) => {
      if (i !== idx) return r;
      const c = colById(columnId);
      const next: ParamRow = { ...r, lov_column_id: columnId, source_column: null };
      // a parameter that leaves the query's conditions leaves ALL of them
      if (Array.isArray(r.applies) && r.applies.some((t: any) => t && t.to === 'source')) {
        const kept = r.applies.filter((t: any) => !(t && t.to === 'source'));
        next.applies = kept.length ? kept : null;
      }
      if (columnId !== r.lov_column_id) next.default_value = '';
      if (c) {
        const phys = String(c.physical_name || '');
        if (!r.name.trim()) next.name = `p_${phys.toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '')}`;
        if (!r.label.trim()) next.label = c.friendly_name || phys;
        if (isTemporalColumn(c) && r.parameter_type === 'dropdown') {
          next.parameter_type = 'date';
          // a new date parameter takes any day on a calendar (2026-10-29)
          if (next.values_source === 'auto') next.values_source = 'any';
        }
      }
      return next;
    }));
  };

  return (
    <Box>
      {rows.map((p, idx) => (
        <Paper key={p._key} elevation={1} sx={{ p: 2, mb: 2 }}>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', alignItems: 'center' }}>
            <TextField size="small" label="Name" value={p.name}
              onChange={e => update(idx, 'name', e.target.value)} sx={{ width: 140 }} />
            <TextField size="small" label="Label" value={p.label}
              onChange={e => update(idx, 'label', e.target.value)} sx={{ width: 200 }} />
            <FormControl size="small" sx={{ minWidth: 130 }}>
              <InputLabel id={domId(p, 'type-label')}>Type</InputLabel>
              <Select value={p.parameter_type} label="Type"
                labelId={domId(p, 'type-label')} id={domId(p, 'type')}
                onChange={e => update(idx, 'parameter_type', e.target.value)}>
                {PARAM_TYPES.map(pt => (
                  <MenuItem key={pt.value} value={pt.value}>{pt.label}</MenuItem>
                ))}
              </Select>
            </FormControl>

            {/* Shown for EVERY parameter type, not just the two list-backed
                ones.  The backend applies a parameter as a filter ONLY when
                this column is set (_build_report_filters: `if not
                param.get("lov_column_id"): continue`), and that rule covers
                all six types.  Rendering the picker for dropdown/multi_select
                alone meant Text, Date, Date Range and Numeric parameters
                could not be bound to a column AT ALL: the viewer was prompted
                for a value — required by default — and the value then did
                nothing, with no error anywhere.  Date Range is the commonest
                report parameter there is. */}
            {/* 2026-10-29 -- TWO kinds of filter (the owner: "filter data at
                source and bring, and local filter").  A column of the report
                filters the RESULTS; a condition of the dataset's own query
                filters AT THE SOURCE -- the value goes into that condition
                and the query runs on the source.  Option values carry their
                kind (c:<column id> / s:<condition key>). */}
            <FormControl size="small" sx={{ minWidth: 180 }}>
              <InputLabel id={domId(p, 'col-label')}>Filter Column</InputLabel>
              <Select value={p.source_column ? `s:${p.source_column}` : p.lov_column_id ? `c:${p.lov_column_id}` : ''}
                label="Filter Column"
                labelId={domId(p, 'col-label')} id={domId(p, 'col')}
                data-testid={`param-${idx}-binding`}
                onChange={e => {
                  const v = String(e.target.value || '');
                  if (v.startsWith('s:')) {
                    const f = sourceByKey(v.slice(2));
                    if (f) bindSource(idx, f);
                  } else {
                    bindColumn(idx, v.startsWith('c:') ? Number(v.slice(2)) : null);
                  }
                }}>
                <MenuItem value="">None</MenuItem>
                {sourceOptions.length > 0 && (
                  <ListSubheader>Filter the results (a column of the report)</ListSubheader>
                )}
                {columns.map((c: any) => (
                  <MenuItem key={c.id} value={`c:${c.id}`}>{colLabel(c)}</MenuItem>
                ))}
                {sourceOptions.length > 0 && (
                  <ListSubheader>Filter at the source (a condition of the dataset's query)</ListSubheader>
                )}
                {sourceOptions.map(f => (
                  <MenuItem key={f.key} value={`s:${f.key}`} data-testid={`source-option-${f.key}`}>
                    {f.placeholder
                      ? (f.declared === false
                        ? `{${f.column}} -- looks like a value asked at run time`
                        : `{${f.column}} -- a value the query asks for${f.values.length ? ` (${f.values.join(', ')} when nobody gives one)` : ''}`)
                      : <>{f.qualifier ? `${f.qualifier}.` : ''}{f.column}{tableWords(f, sourceOptions)} -- now {f.op === 'between'
                        ? `from ${f.values[0]} to ${f.values[1]}` : f.values.join(', ')}</>}
                    {placesWords(f)}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            {!p.lov_column_id && !p.source_column && (
              <Tooltip title="Pick the column this parameter filters. Until you
                do, the viewer will be asked for a value and it will have no
                effect on the report.">
                <Chip size="small" color="warning" variant="outlined"
                      label="filters nothing" />
              </Tooltip>
            )}
            {p.source_column && (
              <Typography variant="caption" color="text.secondary" sx={{ maxWidth: 360 }}
                          data-testid={`param-${idx}-source-words`}>
                {sourceByKey(p.source_column)
                  ? `Runs at the source${placesWords(sourceByKey(p.source_column)!)}. ${sourceByKey(p.source_column)!.words}`
                  : 'Runs at the source. This condition is not in the dataset\'s query any more -- pick another or remove the parameter.'}
              </Typography>
            )}
            {(() => {
              // (review round 2) ONE value for the same condition on several tables: each table
              // is a tick; unticked, that table's condition keeps what the query writes
              const f = p.source_column ? sourceByKey(p.source_column) : undefined;
              const twins = f ? twinsOf(f, sourceOptions) : [];
              if (twins.length < 2) return null;
              const filled = paramSourceKeys(p);
              return (
                <Box sx={{ flexBasis: '100%', display: 'flex', flexWrap: 'wrap', alignItems: 'center', columnGap: 1 }}
                     data-testid={`param-${idx}-targets`}>
                  <Typography variant="caption" color="text.secondary">One value for:</Typography>
                  {twins.map(t => (
                    <FormControlLabel key={t.key} sx={{ mr: 0 }}
                      label={<Typography variant="caption">{targetWords(t)}</Typography>}
                      control={<Checkbox size="small" sx={{ py: 0 }} checked={filled.includes(t.key)}
                        disabled={filled.includes(t.key) && filled.length < 2}
                        inputProps={{ 'data-testid': `param-${idx}-target-${t.key}`,
                                      'aria-label': `One value for ${targetWords(t)}` } as any}
                        onChange={e => onChange(rows.map((r, i) => {
                          if (i !== idx) return r;
                          const keys = e.target.checked ? [...paramSourceKeys(r), t.key]
                            : paramSourceKeys(r).filter(k => k !== t.key);
                          return withSourceKeys(r, Array.from(new Set(keys))) || r;
                        }))} />} />
                  ))}
                </Box>
              );
            })()}
            {(() => {
              // 2026-11-12 -- THE TRAP: this parameter filters the RESULTS of a column the
              // dataset's query already fixes to one value, so another value finds nothing
              const fixed = p.lov_column_id && !p.source_column
                ? fixedOutputOf(colById(p.lov_column_id), fixedList) : undefined;
              const f = fixed ? sourceByKey(fixed.key) : undefined;
              if (!fixed || !f) return null;
              return (
                <Alert severity="warning" sx={{ flexBasis: '100%' }} data-testid={`param-${idx}-fixed`}
                  action={<Button color="inherit" size="small" data-testid={`param-${idx}-to-source`}
                    onClick={() => bindSource(idx, f)}>Filter at the source instead</Button>}>
                  {fixed.words}
                </Alert>
              );
            })()}

            {/* Author-curated choices.  The default is the column's DISTINCT
                values, which is right most of the time and wrong whenever the
                author wants a curated subset, a value the data does not
                contain yet (next quarter's region), or the column is too
                large to scan.  A static list also keeps the dropdown usable
                while the source is unreachable.  It does not replace Filter
                Column: that still says WHICH column the choice filters. */}
            {/* 2026-10-03 -- the GENERIC path is the column: the viewer is
                offered its distinct values at run time, and that is all a
                new parameter offers.  A hand-typed list is no longer
                authored here; a report that already HAS one keeps it
                (readable, editable, clearable) so nothing saved changes
                meaning -- clearing it returns the prompt to the column. */}
            {/* 2026-10-23 -- WHERE the viewer's choices come from (the rule:
                backend core/reports/param_values.py).  The owner: "at least
                partition columns values should be available ... as we are
                on iceberg metadata ... it can have a static list to be saved". */}
            {LIST_TYPES.includes(p.parameter_type) && (!!p.lov_column_id || !!p.source_column || !!p.static_values?.length) && (() => {
              const src = p.values_source || 'auto';
              const opt = VALUES_SOURCE_OPTIONS.find(o => o.value === src) || VALUES_SOURCE_OPTIONS[0];
              const showList = src === 'static' || (src === 'auto' && !!p.static_values?.length);
              return (
                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                    <FormControl size="small" sx={{ minWidth: 230 }}>
                      <InputLabel id={domId(p, 'src-label')}>Choices come from</InputLabel>
                      <Select value={src} label="Choices come from"
                        labelId={domId(p, 'src-label')} id={domId(p, 'src')}
                        data-testid={`param-${idx}-values-source`}
                        onChange={e => update(idx, 'values_source', e.target.value as ValuesSource)}>
                        {VALUES_SOURCE_OPTIONS.map(o => (
                          <MenuItem key={o.value} value={o.value}>{o.label}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                    <Tooltip title={opt.help}>
                      <InfoIcon fontSize="small" color="action" aria-label={`About: ${opt.label}`} />
                    </Tooltip>
                  </Box>
                  <Typography variant="caption" color="text.secondary"
                              data-testid={`param-${idx}-values-source-help`} sx={{ maxWidth: 420 }}>
                    {src === 'auto' && p.static_values?.length
                      ? 'Your saved list is offered (clear it to use the partitions or the data).'
                      : opt.help}
                  </Typography>
                  {showList && (
                    <SavedListEditor p={p} idx={idx} datasetId={datasetId}
                      onValues={v => update(idx, 'static_values', v)} />
                  )}
                  {['auto', 'data', 'metadata'].includes(src) && !p.static_values?.length && p.lov_column_id && (
                    <Box id={`param-${idx}-choices-list`}><ChoicesListBox info={p.choices_list || { has_list: false, words: p.id
                      ? 'The list is made when the report is saved; press Refresh now to make it at once.'
                      : 'The list is made in QueryStudio’s database when this parameter is saved.' }}
                      paramId={p.id ?? null}
                      onChanged={i => onChange(rows.map((r, j) => (j === idx ? { ...r, choices_list: i } : r)))} /></Box>
                  )}
                  {src === 'list' && (
                    <ValueListChoice idPrefix={`param-${idx}`} value={p.value_list_id}
                      onChange={id => update(idx, 'value_list_id', id)} />
                  )}
                  {src === 'table' && (
                    <ValueTablePicker idPrefix={`param-${idx}`}
                      value={{ connectionId: p.lov_source_connection_id, table: p.lov_source_table,
                               column: p.lov_source_column }}
                      onChange={v => onChange(rows.map((r, i) => (i === idx ? {
                        ...r, lov_source_connection_id: v.connectionId,
                        lov_source_table: v.table, lov_source_column: v.column,
                      } : r)))} />
                  )}
                </Box>
              );
            })()}

            {/* Cascade.  Only rows ABOVE this one may be the parent, which
                is what keeps the chain acyclic by construction — the backend
                refuses a cycle, but the editor should not be able to build
                one.  The value is the parent's editor key, never its id:
                the ids are about to be replaced by the save. */}
            {idx > 0 && LIST_TYPES.includes(p.parameter_type) && (
              <FormControl size="small" sx={{ minWidth: 160 }}>
                <InputLabel id={domId(p, 'dep-label')}>Depends On</InputLabel>
                <Select value={p.depends_on_key || ''} label="Depends On"
                  labelId={domId(p, 'dep-label')} id={domId(p, 'dep')}
                  onChange={e => {
                    const key = (e.target.value as string) || null;
                    // 2026-10-03 -- the column the parent's value filters is,
                    // by default, the PARENT's own column (REGION -> the
                    // child's list is narrowed to REGION = the choice).
                    const parentCol = key
                      ? rows.find(r => r._key === key)?.lov_column_id ?? null : null;
                    onChange(rows.map((r, i) => (i === idx
                      ? {
                          ...r,
                          depends_on_key: key,
                          // Dropping the parent drops the column its value
                          // filtered — half a cascade is silently ignored.
                          cascade_filter_column_id: key
                            ? (r.cascade_filter_column_id || parentCol) : null,
                        }
                      : r)));
                  }}>
                  <MenuItem value="">None</MenuItem>
                  {rows.slice(0, idx).map(pp => (
                    <MenuItem key={pp._key} value={pp._key}>
                      {pp.label || pp.name || '(unnamed)'}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            )}
            {p.depends_on_key != null && (
              <FormControl size="small" sx={{ minWidth: 160 }}
                           error={!p.cascade_filter_column_id}>
                <InputLabel id={domId(p, 'casc-label')}>Cascade Filter Col</InputLabel>
                <Select value={p.cascade_filter_column_id || ''} label="Cascade Filter Col"
                  labelId={domId(p, 'casc-label')} id={domId(p, 'casc')}
                  onChange={e => update(idx, 'cascade_filter_column_id',
                                        e.target.value ? Number(e.target.value) : null)}>
                  <MenuItem value="">None</MenuItem>
                  {columns.map((c: any) => (
                    <MenuItem key={c.id} value={c.id}>{colLabel(c)}</MenuItem>
                  ))}
                </Select>
                {!p.cascade_filter_column_id && (
                  <Typography variant="caption" color="error"
                              sx={{ mt: 0.5, fontSize: 11 }}>
                    Pick the column the parent filters, or the cascade does
                    nothing
                  </Typography>
                )}
              </FormControl>
            )}

            {/* 2026-10-29 -- which days the viewer may pick (the owner: "why
                can't I select any date rather than only the values in the
                data").  A list is the column's DISTINCT dates, never the
                report's own output. */}
            {DATE_TYPES.includes(p.parameter_type) && (!!p.lov_column_id || !!p.source_column) && (
              <FormControl size="small" sx={{ minWidth: 230 }}>
                <InputLabel id={domId(p, 'days-label')}>Days the viewer may pick</InputLabel>
                <Select value={p.values_source === 'any' ? 'any' : 'data'} label="Days the viewer may pick"
                  labelId={domId(p, 'days-label')} id={domId(p, 'days')}
                  data-testid={`param-${idx}-days`}
                  onChange={e => update(idx, 'values_source', e.target.value === 'any' ? 'any' : 'auto')}>
                  <MenuItem value="any">Any date (a calendar)</MenuItem>
                  <MenuItem value="data">Only dates that have data</MenuItem>
                </Select>
              </FormControl>
            )}

            {/* Date parameters get the relative-date macros; the backend
                resolves @TODAY and friends at run time -- and, since
                2026-09-28, the business-calendar tokens (@PREV_BUSINESS_DAY
                [:CAL], @BUSINESS_DAY_N:3[:CAL], ...), previewed from the
                server so the author sees the date the token means today. */}
            {p.parameter_type === 'date_range' ? (
              // 2026-10-30 -- a range has TWO defaults, stored as `FROM..TO`
              // (backend core/reports/param_model.py); one picker made a range
              // default a single day run as "=".
              <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }} data-testid={`param-${idx}-range-default`}>
                <DateDefaultPicker value={rangeDefaultSides(p.default_value).from} options={RELATIVE_DATE_OPTIONS}
                                   idBase={domId(p, 'def-from')} label="Default from"
                                   onChange={v => update(idx, 'default_value',
                                     joinRangeDefault(v, rangeDefaultSides(p.default_value).to))} />
                <DateDefaultPicker value={rangeDefaultSides(p.default_value).to} options={RELATIVE_DATE_OPTIONS}
                                   idBase={domId(p, 'def-to')} label="Default to"
                                   onChange={v => update(idx, 'default_value',
                                     joinRangeDefault(rangeDefaultSides(p.default_value).from, v))} />
              </Box>
            ) : p.parameter_type === 'date' ? (
              <DateDefaultPicker value={p.default_value || ''} options={RELATIVE_DATE_OPTIONS}
                                 idBase={domId(p, 'def')}
                                 onChange={v => update(idx, 'default_value', v)} />
            ) : p.source_column ? (
              // the query's own value is the default; a typed one replaces it
              <TextField size="small" label="Default" value={p.default_value}
                onChange={e => update(idx, 'default_value', e.target.value)}
                placeholder="As in the query" helperText="Leave empty to use what the query says"
                sx={{ width: 180 }} />
            ) : p.lov_column_id && datasetId ? (
              // Bound to a column, so the values are knowable -- a typed
              // default that matches nothing yields an empty report with
              // no error anywhere, which is the failure mode that matters.
              <ColumnValuePicker
                label="Default" testId={`param-${idx}-default`}
                fetchValues={fetchFor(p.lov_column_id)}
                fetchKey={`${datasetId}:${p.lov_column_id}`}
                searchValues={(q: string) => api.getColumnValues(datasetId, {
                  column_id: p.lov_column_id as number,
                  parent_filters: [{ column_id: p.lov_column_id, operator: 'contains', value: q }] })}
                value={p.default_value || ''}
                onChange={v => update(idx, 'default_value', v || '')}
                placeholder="Pick from the column"
                sx={{ width: 220 }}
              />
            ) : (
              <TextField size="small" label="Default" value={p.default_value}
                onChange={e => update(idx, 'default_value', e.target.value)}
                sx={{ width: 120 }} />
            )}

            <TextField size="small" label="Help text (tooltip)" value={p.description || ''}
              onChange={e => update(idx, 'description', e.target.value)}
              placeholder="Shown as a tooltip next to this parameter"
              inputProps={{ maxLength: 500 }} sx={{ width: 220 }} />
            <FormControlLabel
              control={<Checkbox checked={p.is_required}
                                 onChange={e => update(idx, 'is_required', e.target.checked)} />}
              label="Required"
            />
            <Button size="small" onClick={() => setMoreOpen(m => ({ ...m, [p._key]: !m[p._key] }))} data-testid={`param-${idx}-more-toggle`}>
              {moreOpen[p._key] ? 'Fewer settings' : 'More settings'}
            </Button>
            {moreOpen[p._key] && (
              <ParamMoreSettings p={p} idx={idx} rows={rows} columns={columns} update={update}
                sourceKeys={(sourceFilters ?? loadedSource).map((f: any) => String(f.key || f.column || '').toLowerCase()).filter(Boolean)}
                actionIds={actionIds ?? []} tokens={tokens ?? []} />
            )}
            <Tooltip title="Remove this parameter">
              <IconButton size="small"
                          aria-label={`Remove parameter ${p.label || p.name || idx + 1}`}
                          onClick={() => onChange(removeParamRow(rows, idx))}>
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Box>
          {/* 2026-11-01 -- "How this works" (the owner: "how generic parameters work is
              still a black box for me"): where its choices come from, what it filters
              and where, its default, who sees it, what it depends on -- in plain words */}
          <ParamHowItWorks p={p} idx={idx} rows={rows} columns={columns} sourceFilters={sourceFilters ?? loadedSource}
            onChoicesList={i => onChange(rows.map((r, j) => (j === idx ? { ...r, choices_list: i } : r)))} />
        </Paper>
      ))}
      <Button size="small" startIcon={<AddIcon />}
              onClick={() => onChange([...rows, newParamRow()])}>
        Add Parameter
      </Button>
    </Box>
  );
}

export default ReportParameterEditor;
