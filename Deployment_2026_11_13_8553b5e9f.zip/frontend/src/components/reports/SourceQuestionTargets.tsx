/**
 * The tables ONE question is asked for (2026-11-12, review round 2).
 *
 * The owner's JOIN writes the same business date on fact_tetb and on
 * fact_tetb_ext.  They are two conditions of the query; the builder asks for
 * them as ONE value by default.  Each table is a tick here: ticked, the value
 * the viewer picks goes into that table's condition too; unticked, that
 * condition is set apart -- a row of its own, asked separately or left as the
 * query writes it.  A value is never put into a table that is not ticked.
 */
import React from 'react';
import { Box, Checkbox, FormControlLabel, Typography } from '@mui/material';
import { SourceQuestion, targetWords } from '../../utils/reportFilters';

export default function SourceQuestionTargets({ question, apart, onToggle, dense }: {
  question: SourceQuestion;
  /** the keys of the conditions set apart */
  apart: string[];
  /** `together` = the tick's new state */
  onToggle: (key: string, together: boolean) => void;
  dense?: boolean;
}) {
  if (question.targets.length < 2) return null;
  return (
    <Box sx={{ pl: dense ? 3.5 : 4, display: 'flex', flexWrap: 'wrap', alignItems: 'center', columnGap: 1 }}
         data-testid={`source-targets-${question.lead.key}`}>
      <Typography variant="caption" color="text.secondary">One value for:</Typography>
      {question.targets.map(t => (
        <FormControlLabel key={t.key} sx={{ mr: 0 }}
          label={<Typography variant="caption">{targetWords(t)}</Typography>}
          control={<Checkbox size="small" sx={{ py: 0 }} checked={!apart.includes(t.key)}
            // the last one cannot be set apart from itself
            disabled={!apart.includes(t.key) && question.members.length < 2}
            inputProps={{ 'data-testid': `source-target-${t.key}`,
                          'aria-label': `One value for ${targetWords(t)}` } as any}
            onChange={e => onToggle(t.key, e.target.checked)} />} />
      ))}
    </Box>
  );
}
