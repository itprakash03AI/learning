/**
 * The builder's settings for the outline and band tiles and the number
 * formats of any tile (2026-10-30).  Hosted by CanvasReportBuilder's tile
 * properties; every check is canvasOutline.outlineProblems (the server's).
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Autocomplete, Box, Button, Checkbox, Divider, FormControlLabel, IconButton, MenuItem, Stack, TextField, Typography,
} from '@mui/material';
import api from '../../../services/api';
import { AGG_LABEL, Aggregation, CanvasColumn, CanvasTile, allowedAggregations, defaultAggregation, isMeasureColumn, isNumericColumn } from './canvasModel';
import { toOutlineFields } from './canvasEdit';
import { GOOD_WHEN, KPI_ICONS, KPI_TILE_STYLES, KPI_TILE_STYLE_WORDS, MAX_SPARK_POINTS, MIN_SPARK_POINTS, type KpiIcon } from './canvasKpi';
import { KPI_ICON_WORDS, KpiIconPicture } from './kpiIcons';
import { isHex } from './canvasTheme';
import {
  ColorRule, formatNumber, MAX_LABEL, MAX_RULES, NEGATIVE_LABEL, NegativeStyle, openLevelOf, RULE_COLOR_LABEL, RULE_FILLS,
  RULE_OP_LABEL, RULE_OPS, RuleColor, RuleOp, ruleProblems, TileFormat, totalLabel, type TotalsPosition,
} from './canvasOutline';

/** "Colour the cell when the value is not equal to 0: Amber" -- one line per rule. */
function ColorRules({ id, rules, onChange }: { id: number; rules: ColorRule[]; onChange: (r: ColorRule[]) => void }) {
  const put = (i: number, p: Partial<ColorRule>) => onChange(rules.map((r, j) => {
    if (j !== i) return r;
    const next: ColorRule = { ...r, ...p };
    if (next.op !== 'between') delete next.value2;
    else if (next.value2 == null) next.value2 = next.value;
    return next;
  }));
  const problems = ruleProblems(rules);
  return (
    <Box data-testid={`tile-format-rules-${id}`}>
      <Typography variant="caption" color="text.secondary">Colour the cell when the value…</Typography>
      {rules.map((r, i) => (
        <Stack key={i} direction="row" spacing={0.5} alignItems="center" sx={{ mt: 0.5 }} data-testid={`tile-format-rule-${id}-${i}`}>
          <TextField select size="small" value={r.op} sx={{ width: 130 }} inputProps={{ 'aria-label': 'When' }}
            onChange={e => put(i, { op: e.target.value as RuleOp })}>
            {RULE_OPS.map(o => <MenuItem key={o} value={o}>{RULE_OP_LABEL[o]}</MenuItem>)}
          </TextField>
          <TextField size="small" value={String(r.value ?? '')} sx={{ width: 80 }} inputProps={{ 'aria-label': 'Number' }}
            onChange={e => put(i, { value: e.target.value })} />
          {r.op === 'between' && (
            <TextField size="small" value={String(r.value2 ?? '')} sx={{ width: 80 }} inputProps={{ 'aria-label': 'And' }}
              onChange={e => put(i, { value2: e.target.value })} />
          )}
          <TextField select size="small" value={r.color} sx={{ width: 100 }} inputProps={{ 'aria-label': 'Colour' }}
            onChange={e => put(i, { color: e.target.value as RuleColor })}>
            {(Object.keys(RULE_FILLS) as RuleColor[]).map(c => (
              <MenuItem key={c} value={c}><Box component="span" sx={{ bgcolor: RULE_FILLS[c], px: 1 }}>{RULE_COLOR_LABEL[c]}</Box></MenuItem>
            ))}
          </TextField>
          <IconButton size="small" aria-label="Remove this colour rule" onClick={() => onChange(rules.filter((_, j) => j !== i))}>✕</IconButton>
        </Stack>
      ))}
      {rules.length < MAX_RULES && (
        <Button size="small" sx={{ mt: 0.5 }} data-testid={`tile-format-rule-add-${id}`}
          onClick={() => onChange([...rules, { op: 'ne', value: 0, color: 'amber' }])}>Add a colour rule</Button>
      )}
      {problems.map((p, i) => <Typography key={i} variant="caption" color="error" component="div">{p}</Typography>)}
    </Box>
  );
}

type Change = (f: (t: CanvasTile) => CanvasTile) => void;

const valueRank = (c: CanvasColumn) => (isMeasureColumn(c) ? 0 : isNumericColumn(c) ? 1 : 2);

/** Levels (in order, or from a dataset hierarchy), starting level, totals. */
export function OutlineTileSettings({ tile, cols, columns, datasetId, onChange, grouped = true, onMakeValue }: {
  tile: CanvasTile; cols: Map<number, CanvasColumn>; columns: CanvasColumn[]; datasetId: number | null; onChange: Change;
  /** the report's rows are grouped (the aggregations a value may take: canvasModel.allowedAggregations) */
  grouped?: boolean;
  /** mark a dataset field as a value added up with Sum (the builder; absent = not offered) */
  onMakeValue?: (columnId: number) => Promise<void>;
}) {
  const [making, setMaking] = useState<number | null>(null);
  const [makeError, setMakeError] = useState('');
  const [hierarchies, setHierarchies] = useState<any[]>([]);
  useEffect(() => {
    if (!datasetId) { setHierarchies([]); return; }
    let cancelled = false;
    Promise.resolve(api.listDrillHierarchies(datasetId))
      .then((r: any) => { if (!cancelled) setHierarchies(Array.isArray(r) ? r : (r?.items || [])); })
      .catch(() => { if (!cancelled) setHierarchies([]); });
    return () => { cancelled = true; };
  }, [datasetId]);
  const levels = tile.levels ?? [];
  const n = levels.length;
  const label = (id: number) => cols.get(id)?.label ?? `column #${id}`;
  const totals = tile.totals ?? {};
  const setTotals = (f: (t: NonNullable<CanvasTile['totals']>) => NonNullable<CanvasTile['totals']>) =>
    onChange(t => ({ ...t, totals: f({ ...(t.totals ?? {}) }) }));
  const setLevels = (v: number[]) => onChange(t => ({
    ...t, levels: v,
    open_level: Math.min(Math.max(1, t.open_level ?? 1), Math.max(1, v.length)),
    totals: { ...(t.totals ?? {}), levels: (t.totals?.levels ?? []).slice(0, v.length) },
  }));
  // 2026-11-12 (UAT: "an outline needs at least one value to show" with the values picked elsewhere): the
  // grid's VALUES are picked HERE -- before, this step had no place for them at all
  const valueIds = tile.measures.map(m => m.column_id);
  const valueOptions = columns.filter(c => !levels.includes(c.id))
    // the dataset's values first, then other numeric fields (a Snowflake NUMBER marked as a dimension), then the rest
    .sort((a, b) => valueRank(a) - valueRank(b))
    .map(c => c.id);
  const setValues = (ids: number[]) => onChange(t => ({
    ...t, measures: ids.map(id => t.measures.find(m => m.column_id === id)
      ?? { column_id: id, aggregation: defaultAggregation(cols.get(id), grouped) }),
  }));
  const setAggregation = (id: number, a: Aggregation) =>
    onChange(t => ({ ...t, measures: t.measures.map(m => (m.column_id === id ? { ...m, aggregation: a } : m)) }));
  // fields a finance grid does not use (left by a change of type): say so, and offer to make them levels
  const stray = [...tile.dimensions, ...(tile.series != null ? [tile.series] : [])].filter(id => !levels.includes(id));
  return (
    <Stack spacing={1} data-testid="outline-settings">
      {stray.length > 0 && (
        <Alert severity="warning" sx={{ py: 0 }} data-testid="outline-stray-fields"
          action={<Button size="small" data-testid="outline-stray-fix" onClick={() => onChange(t => toOutlineFields(t))}>Use them as levels</Button>}>
          A finance grid shows levels (its rows) and values only. {stray.map(label).join(', ')} {stray.length === 1 ? 'is' : 'are'} left from the visual's old type.
        </Alert>
      )}
      {hierarchies.length > 0 && (
        <TextField select size="small" label="Take the levels from a hierarchy" value=""
          onChange={e => {
            const h = hierarchies.find(x => String(x.id) === e.target.value);
            const ids = (h?.levels || []).map((l: any) => Number(l.column_id)).filter((i: number) => cols.has(i));
            if (ids.length) setLevels(ids);
          }} inputProps={{ 'data-testid': 'outline-hierarchy' }}>
          {hierarchies.map(h => <MenuItem key={h.id} value={String(h.id)}>{h.name}</MenuItem>)}
        </TextField>
      )}
      <Autocomplete multiple size="small" options={columns.filter(c => !isMeasureColumn(c)).map(c => c.id)}
        value={levels} getOptionLabel={i => label(i)} onChange={(_, v) => setLevels(v)}
        renderInput={p => <TextField {...p} label="Levels (top first)" helperText={n === 0 ? 'The rows: pick at least one field, for example Product Area.' : undefined}
          inputProps={{ ...p.inputProps, 'data-testid': 'outline-levels' }} />} />
      <Autocomplete multiple size="small" options={valueOptions} value={valueIds} getOptionLabel={i => label(i)}
        onChange={(_, v) => setValues(v)}
        renderInput={p => <TextField {...p} label="Values (the numbers in each row)"
          helperText={valueIds.length === 0 ? 'Pick at least one value, for example Formal PnL.' : undefined}
          inputProps={{ ...p.inputProps, 'data-testid': 'outline-values' }} />} />
      {tile.measures.map(m => {
        const col = cols.get(m.column_id);
        const allowed = allowedAggregations(col, grouped);
        // 2026-11-12 (UAT): a NUMBER the dataset marks as a field to group by can only be COUNTED in grouped rows
        // (adding it up there could count a value twice) -- say so, and offer to mark it a value in the dataset
        const onlyCounted = grouped && !!col && !isMeasureColumn(col) && isNumericColumn(col);
        return (
          <Box key={m.column_id}>
            <TextField select size="small" fullWidth label={`${label(m.column_id)}: how it adds up`} value={m.aggregation}
              onChange={e => setAggregation(m.column_id, e.target.value as Aggregation)}
              inputProps={{ 'data-testid': `outline-value-agg-${m.column_id}` }}>
              {(allowed.includes(m.aggregation) ? allowed : [m.aggregation, ...allowed]).map(a => <MenuItem key={a} value={a}>{AGG_LABEL[a] ?? a}</MenuItem>)}
            </TextField>
            {onlyCounted && (
              <Alert severity="info" sx={{ py: 0, mt: 0.5 }} data-testid={`outline-value-only-counted-${m.column_id}`}
                action={onMakeValue && (
                  <Button size="small" disabled={making === m.column_id} data-testid={`outline-make-value-${m.column_id}`}
                    onClick={async () => {
                      setMaking(m.column_id); setMakeError('');
                      try { await onMakeValue(m.column_id); } catch (e: any) {
                        setMakeError(`${label(m.column_id)} could not be changed in the dataset${e?.message ? `: ${e.message}` : ''}. Ask the dataset's owner to mark it as a value (Sum).`);
                      } finally { setMaking(null); }
                    }}>Add it up (Sum)</Button>)}>
                {label(m.column_id)} is marked as a field to group by in the dataset, so here it can only be counted. To add it up, mark it as a value (Sum) in the dataset.
              </Alert>
            )}
          </Box>
        );
      })}
      {makeError && <Alert severity="warning" sx={{ py: 0 }} data-testid="outline-make-value-error">{makeError}</Alert>}
      {n > 0 && (
        <TextField select size="small" label="Opens to" value={openLevelOf(tile)}
          onChange={e => onChange(t => ({ ...t, open_level: Number(e.target.value) }))}
          inputProps={{ 'data-testid': 'outline-open-level' }}>
          {levels.map((id, i) => <MenuItem key={id} value={i + 1}>{label(id)}</MenuItem>)}
        </TextField>
      )}
      {n > 1 && (
        <TextField select size="small" label="Subtotals" value={totals.position === 'bottom' ? 'bottom' : 'top'}
          onChange={e => setTotals(tt => ({ ...tt, position: e.target.value as TotalsPosition }))}
          inputProps={{ 'data-testid': 'outline-total-position' }}
          helperText="Where an open row's total shows: on the row itself, or on a line under its rows.">
          <MenuItem value="top">On the open row itself</MenuItem>
          <MenuItem value="bottom">On a line under its rows</MenuItem>
        </TextField>
      )}
      {n > 1 && <Typography variant="caption" color="text.secondary">Totals inside the outline</Typography>}
      {levels.slice(0, Math.max(0, n - 1)).map((id, i) => (
        <Stack key={id} direction="row" spacing={0.5} alignItems="center">
          <Checkbox size="small" checked={!!totals.levels?.[i]} sx={{ p: 0.5 }}
            inputProps={{ 'aria-label': `${label(id)} total`, ...({ 'data-testid': `outline-total-${i}` } as any) }}
            onChange={e => setTotals(tt => {
              const arr = Array.from({ length: n }, (_, j) => !!tt.levels?.[j]);
              arr[i] = e.target.checked;
              return { ...tt, levels: arr };
            })} />
          <TextField size="small" fullWidth value={totals.labels?.[String(i)] ?? ''} placeholder={totalLabel({ ...tile, totals: { ...totals, labels: {} } }, i, cols)}
            onChange={e => setTotals(tt => ({ ...tt, labels: { ...(tt.labels ?? {}), [String(i)]: e.target.value.slice(0, MAX_LABEL) } }))}
            inputProps={{ 'data-testid': `outline-total-label-${i}` }} disabled={!totals.levels?.[i]} />
        </Stack>
      ))}
      <Stack direction="row" spacing={0.5} alignItems="center">
        <Checkbox size="small" checked={!!totals.grand} sx={{ p: 0.5 }}
          inputProps={{ 'aria-label': 'Grand total', ...({ 'data-testid': 'outline-grand' } as any) }}
          onChange={e => setTotals(tt => ({ ...tt, grand: e.target.checked }))} />
        <TextField size="small" fullWidth value={totals.labels?.grand ?? ''} placeholder="Grand Total" disabled={!totals.grand}
          onChange={e => setTotals(tt => ({ ...tt, labels: { ...(tt.labels ?? {}), grand: e.target.value.slice(0, MAX_LABEL) } }))} />
      </Stack>
    </Stack>
  );
}

/** Which of the report's parameters the band shows (none picked = every one). */
export function BandTileSettings({ tile, paramNames, onChange }: {
  tile: CanvasTile; paramNames: { name: string; label: string; type?: string }[]; onChange: Change;
}) {
  const byName = new Map(paramNames.map(p => [p.name, p.label]));
  return (
    <Stack spacing={1} data-testid="band-settings">
      <Typography variant="caption" color="text.secondary">
        The band shows the values the report ran with, and the report code on the right.
      </Typography>
      <Autocomplete multiple size="small" options={paramNames.map(p => p.name)} value={tile.parameters ?? []}
        getOptionLabel={n => byName.get(n) ?? n}
        onChange={(_, v) => onChange(t => ({ ...t, parameters: v.length ? v : undefined }))}
        renderInput={p => <TextField {...p} label="Values to show (empty = all)" />} />
      <Autocomplete multiple size="small" options={paramNames.filter(p => ['period', 'dropdown'].includes(String(p.type ?? ''))).map(p => p.name)} value={tile.chips ?? []}
        getOptionLabel={n => byName.get(n) ?? n} data-testid="band-chips"
        onChange={(_, v) => onChange(t => ({ ...t, chips: v.length ? v : undefined }))}
        renderInput={p => <TextField {...p} label="Show as chips (a period or a dropdown with up to 8 choices)" />} />
      <Typography variant="caption" color="text.secondary">The choices sit in a row like FY 19-20 · FY 18-19; a dropdown with more choices keeps its cell.</Typography>
    </Stack>
  );
}

/** The KPI card's settings of a number tile (2026-11-02, canvasKpi.ts): icon, comparison, good-when, style, fill, sparkline. */
export function KpiTileSettings({ tile, cols, columns, grouped, hasCompareParameter, onChange }: {
  tile: CanvasTile; cols: Map<number, CanvasColumn>; columns: CanvasColumn[]; grouped: boolean; hasCompareParameter: boolean; onChange: Change;
}) {
  const label = (id: number) => cols.get(id)?.label ?? `column #${id}`;
  const cmpKind = tile.compare?.kind ?? 'none';
  const cmpMeasure = tile.compare?.kind === 'measure' ? tile.compare : null;
  const setCompare = (kind: string) => onChange(t => {
    const { compare: _c, ...rest } = t;
    if (kind === 'none') return rest;
    if (kind === 'parameter') return { ...rest, compare: { kind: 'parameter' } };
    const first = columns.find(c => isNumericColumn(c) && c.id !== t.measures[0]?.column_id) ?? columns[0];
    return { ...rest, compare: { kind: 'measure', column_id: first?.id ?? 0, aggregation: defaultAggregation(first, grouped) } };
  });
  return (
    <Box data-testid="kpi-settings">
      <Divider sx={{ my: 1 }} />
      <Typography variant="subtitle2">The card</Typography>
      <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 1 }}>
        A number tile is a KPI card: an icon, the value, and how it changed against a previous value -- green when the change is good, red when it is bad.
      </Typography>
      <Stack spacing={1}>
        <TextField select size="small" label="Icon" value={tile.icon ?? ''} onChange={e => onChange(t => ({ ...t, icon: (e.target.value || undefined) as KpiIcon | undefined }))}
          inputProps={{ 'data-testid': 'kpi-icon' }}>
          <MenuItem value="">No icon</MenuItem>
          {KPI_ICONS.map(i => <MenuItem key={i} value={i}><Stack direction="row" spacing={1} alignItems="center"><KpiIconPicture icon={i} size={18} /><span>{KPI_ICON_WORDS[i]}</span></Stack></MenuItem>)}
        </TextField>
        <TextField select size="small" label="Compare with" value={cmpKind} onChange={e => setCompare(e.target.value)} inputProps={{ 'data-testid': 'kpi-compare' }}
          helperText={cmpKind === 'parameter' && !hasCompareParameter ? 'Set "Compare two dates" on the canvas first (below the tiles).' : cmpKind === 'measure' ? 'Another value of the same result, for example a budget or last year.' : 'Nothing: the card shows the value only.'}>
          <MenuItem value="none">Nothing</MenuItem>
          <MenuItem value="parameter">The report&apos;s two dates (previous date, previous month end, same day last year)</MenuItem>
          <MenuItem value="measure">Another value (budget, target, last year)</MenuItem>
        </TextField>
        {cmpMeasure && (
          <Stack direction="row" spacing={0.5}>
            <TextField select size="small" label="Value" value={cmpMeasure.column_id} sx={{ flex: 1 }} inputProps={{ 'data-testid': 'kpi-compare-column' }}
              onChange={e => onChange(t => ({ ...t, compare: { kind: 'measure', column_id: Number(e.target.value), aggregation: defaultAggregation(cols.get(Number(e.target.value)), grouped), label: cmpMeasure.label } }))}>
              {columns.map(c => <MenuItem key={c.id} value={c.id}>{c.label}</MenuItem>)}
            </TextField>
            <TextField select size="small" label="Add up as" value={cmpMeasure.aggregation} sx={{ width: 140 }} inputProps={{ 'data-testid': 'kpi-compare-agg' }}
              onChange={e => onChange(t => ({ ...t, compare: { ...cmpMeasure, aggregation: e.target.value as Aggregation } }))}>
              {allowedAggregations(cols.get(cmpMeasure.column_id), grouped).map(a => <MenuItem key={a} value={a}>{AGG_LABEL[a]}</MenuItem>)}
            </TextField>
            <TextField size="small" label="Shown as" value={cmpMeasure.label ?? ''} sx={{ width: 120 }} placeholder={label(cmpMeasure.column_id)}
              inputProps={{ 'data-testid': 'kpi-compare-label', maxLength: 60 }}
              onChange={e => onChange(t => ({ ...t, compare: { ...cmpMeasure, label: e.target.value || undefined } }))} />
          </Stack>
        )}
        {cmpKind !== 'none' && (
          <TextField select size="small" label="A good change is" value={tile.good_when ?? 'up'} onChange={e => onChange(t => ({ ...t, good_when: e.target.value as any }))}
            inputProps={{ 'data-testid': 'kpi-good-when' }} helperText="Revenue going up is good; a cost going up is bad.">
            {GOOD_WHEN.map(g => <MenuItem key={g} value={g}>{g === 'up' ? 'Up (shown green when it rises)' : 'Down (shown green when it falls)'}</MenuItem>)}
          </TextField>
        )}
        <Stack direction="row" spacing={0.5}>
          <TextField select size="small" label="Card style" value={tile.style ?? 'theme'} sx={{ flex: 1 }} inputProps={{ 'data-testid': 'kpi-style' }}
            onChange={e => onChange(t => ({ ...t, style: e.target.value === 'theme' ? undefined : e.target.value as any }))}>
            {KPI_TILE_STYLES.map(s => <MenuItem key={s} value={s}>{KPI_TILE_STYLE_WORDS[s]}</MenuItem>)}
          </TextField>
          <Stack direction="row" spacing={0.5} alignItems="center">
            <input type="color" value={isHex(tile.fill) ? tile.fill! : '#1e6fd9'} aria-label="Card fill colour" data-testid="kpi-fill"
              onChange={e => onChange(t => ({ ...t, fill: e.target.value }))} style={{ width: 34, height: 30, border: '1px solid #ccc', borderRadius: 6, padding: 0, background: 'none' }} />
            {tile.fill && <Button size="small" onClick={() => onChange(t => { const { fill: _f, ...rest } = t; return rest; })} data-testid="kpi-fill-clear">Use the theme&apos;s</Button>}
          </Stack>
        </Stack>
        <Stack direction="row" spacing={0.5}>
          <TextField select size="small" label="Sparkline follows" value={tile.sparkline?.column_id ?? ''} sx={{ flex: 1 }} inputProps={{ 'data-testid': 'kpi-spark-column' }}
            helperText="A small line of the value by a date or ordered column, its last points"
            onChange={e => onChange(t => { const { sparkline: _s, ...rest } = t; return e.target.value === '' ? rest : { ...rest, sparkline: { column_id: Number(e.target.value), points: t.sparkline?.points ?? 12 } }; })}>
            <MenuItem value="">No sparkline</MenuItem>
            {columns.filter(c => !isMeasureColumn(c)).map(c => <MenuItem key={c.id} value={c.id}>{c.label}</MenuItem>)}
          </TextField>
          {tile.sparkline && (
            <TextField size="small" type="number" label="Points" value={tile.sparkline.points} sx={{ width: 90 }}
              inputProps={{ min: MIN_SPARK_POINTS, max: MAX_SPARK_POINTS, 'data-testid': 'kpi-spark-points' }}
              onChange={e => onChange(t => ({ ...t, sparkline: { ...(t.sparkline!), points: Number(e.target.value) } }))} />
          )}
        </Stack>
      </Stack>
    </Box>
  );
}

const EXAMPLE = -1234567.891;

/** The number format of each NUMERIC field a tile shows -- its values, and its numeric rows (levels /
 *  fields: an ID, a year) -- set per field (2026-11-12, the owner: "customizable per field"). */
export function TileFormatSettings({ tile, cols, onChange }: { tile: CanvasTile; cols: Map<number, CanvasColumn>; onChange: Change }) {
  const shown = tile.kind === 'outline' ? (tile.levels ?? []) : [...tile.dimensions, ...(tile.series != null ? [tile.series] : [])];
  const ids = [...new Set([...tile.measures.map(m => m.column_id), ...shown.filter(id => isNumericColumn(cols.get(id)))])];
  if (ids.length === 0) return null;
  const set = (id: number, f: TileFormat | null) => onChange(t => {
    const next = { ...(t.formats ?? {}) };
    if (f) next[String(id)] = f; else delete next[String(id)];
    return { ...t, formats: Object.keys(next).length ? next : undefined };
  });
  return (
    <Box data-testid="tile-formats">
      <Divider sx={{ my: 1 }} />
      <Typography variant="caption" color="text.secondary">Number format</Typography>
      {ids.map(id => {
        const f = tile.formats?.[String(id)];
        const on = !!f;
        // a value starts as 1,234.56; a numeric ROW field (an ID, a year) as plain 1234
        const isValue = tile.measures.some(m => m.column_id === id);
        const cur: TileFormat = { decimals: isValue ? 2 : 0, thousands: isValue, negative: 'minus', zero: 'show', ...(f ?? {}) };
        const put = (p: Partial<TileFormat>) => set(id, { ...cur, ...p });
        return (
          <Box key={id} sx={{ mt: 0.5 }}>
            <FormControlLabel control={<Checkbox size="small" checked={on} sx={{ p: 0.5 }}
              inputProps={{ 'data-testid': `tile-format-on-${id}` } as any}
              onChange={e => set(id, e.target.checked ? cur : null)} />}
              label={<Typography variant="body2">{cols.get(id)?.label ?? `column #${id}`}</Typography>} />
            {on && (
              <Stack spacing={0.75} sx={{ pl: 3 }}>
                <Stack direction="row" spacing={0.5}>
                  <TextField select size="small" label="Decimals" value={cur.decimals} sx={{ width: 90 }}
                    onChange={e => put({ decimals: Number(e.target.value) })} inputProps={{ 'data-testid': `tile-format-decimals-${id}` }}>
                    {[0, 1, 2, 3, 4, 5, 6].map(d => <MenuItem key={d} value={d}>{d}</MenuItem>)}
                  </TextField>
                  <TextField select size="small" label="Below zero" value={cur.negative} sx={{ flex: 1 }}
                    onChange={e => put({ negative: e.target.value as NegativeStyle })} inputProps={{ 'data-testid': `tile-format-negative-${id}` }}>
                    {(Object.keys(NEGATIVE_LABEL) as NegativeStyle[]).map(k => <MenuItem key={k} value={k}>{NEGATIVE_LABEL[k]}</MenuItem>)}
                  </TextField>
                </Stack>
                <Stack direction="row" spacing={1} alignItems="center">
                  <FormControlLabel control={<Checkbox size="small" checked={cur.thousands !== false} sx={{ p: 0.5 }}
                    onChange={e => put({ thousands: e.target.checked })} />} label={<Typography variant="body2">1,000s</Typography>} />
                  <FormControlLabel control={<Checkbox size="small" checked={cur.zero === 'blank'} sx={{ p: 0.5 }}
                    onChange={e => put({ zero: e.target.checked ? 'blank' : 'show' })} />} label={<Typography variant="body2">Leave 0 blank</Typography>} />
                </Stack>
                <Typography variant="caption" color={cur.negative === 'red_brackets' ? 'error' : 'text.secondary'}>
                  Example: {formatNumber(EXAMPLE, cur)}
                </Typography>
                <ColorRules id={id} rules={cur.rules ?? []}
                  onChange={rules => put({ rules: rules.length ? rules : undefined })} />
                <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap data-testid={`tile-format-scale-${id}`}>
                  <FormControlLabel control={<Checkbox size="small" checked={!!cur.scale} sx={{ p: 0.5 }} inputProps={{ 'data-testid': `tile-format-scale-on-${id}` } as any}
                    onChange={e => put({ scale: e.target.checked ? { low: '#ffffff', high: '#1e6fd9' } : undefined })} />}
                    label={<Typography variant="body2">Colour by size (small to large)</Typography>} />
                  {cur.scale && (<>
                    <input type="color" value={cur.scale.low} aria-label="Colour of the smallest value" data-testid={`tile-format-scale-low-${id}`}
                      onChange={e => put({ scale: { ...cur.scale!, low: e.target.value } })} style={{ width: 30, height: 26, border: '1px solid #ccc', borderRadius: 6, padding: 0, background: 'none' }} />
                    <input type="color" value={cur.scale.high} aria-label="Colour of the largest value" data-testid={`tile-format-scale-high-${id}`}
                      onChange={e => put({ scale: { ...cur.scale!, high: e.target.value } })} style={{ width: 30, height: 26, border: '1px solid #ccc', borderRadius: 6, padding: 0, background: 'none' }} />
                  </>)}
                </Stack>
                <FormControlLabel control={<Checkbox size="small" checked={cur.sign_colour === true} sx={{ p: 0.5 }} inputProps={{ 'data-testid': `tile-format-sign-${id}` } as any}
                  onChange={e => put({ sign_colour: e.target.checked ? true : undefined })} />}
                  label={<Typography variant="body2">Colour the sign: green above zero, red below</Typography>} />
              </Stack>
            )}
          </Box>
        );
      })}
    </Box>
  );
}
