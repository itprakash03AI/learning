/**
 * The Build tab (2026-11-07, the simple builder): the selected visual's
 * field WELLS (canvasWells.ts) -- X axis / Y axis / Legend, Category /
 * Values, Rows / Columns / Values, and so on by kind.  A well takes a
 * dropped field (FIELD_MIME) or a pick from its own small list; a value row
 * keeps "Add up as" (only the exact ways, allowedAggregations) and "Shown
 * as", with the old test ids `tile-agg-<i>` / `tile-measure-label-<i>`; the
 * well pickers carry `tile-category` / `tile-series` / `tile-add-value`.
 * The finance grid, the header band, the insight and the report's table
 * keep their own settings here, unchanged.
 */
import React, { useState } from 'react';
import { Autocomplete, Box, Button, Chip, IconButton, MenuItem, Paper, Stack, TextField, Tooltip, Typography } from '@mui/material';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import InfoIcon from '@mui/icons-material/InfoOutlined';
import {
  AGG_LABEL, Aggregation, allowedAggregations, CanvasColumn, CanvasTile, isMeasureColumn,
} from '../canvas/canvasModel';
import { FIELD_MIME } from '../canvas/ReportCanvasView';
import { placeInWell, removeFromWell, Well, WellItem, wellItems, wellsFor } from '../canvas/canvasWells';
import { BandTileSettings, OutlineTileSettings } from '../canvas/CanvasOutlineSettings';
import InsightTileEditor from '../canvas/InsightTileEditor';
import type { SuggestedField } from './visualSuggest';

type Change = (f: (t: CanvasTile) => CanvasTile) => void;

export default function BuildTab({ tile, cols, columns, grouped, onChange, onNote, reportTableCols, setReportTableCols, datasetId, paramNames, suggest, suggested, onMakeValue }: {
  tile: CanvasTile; cols: Map<number, CanvasColumn>; columns: CanvasColumn[]; grouped: boolean;
  onChange: Change; onNote: (words: string) => void;
  reportTableCols: number[]; setReportTableCols: (f: (r: number[]) => number[]) => void;
  datasetId: number | null; paramNames: { name: string; label: string; type?: string }[];
  /** 2026-11-09 -- the dataset's suggestion for a slot (designer/visualSuggest.ts), or null */
  suggest?: (well: Well) => SuggestedField | null;
  /** fields the steps filled in by suggestion (marked "suggested" until changed) */
  suggested?: Set<number>;
  /** mark a dataset field as a value added up with Sum (the finance grid offers it) */
  onMakeValue?: (columnId: number) => Promise<void>;
}) {
  const label = (id: number) => cols.get(id)?.label ?? `column #${id}`;
  const wells = wellsFor(tile.kind);

  if (tile.kind === 'report') {
    return (
      <Stack spacing={1} data-testid="build-tab">
        <Typography variant="caption" color="text.secondary">
          The report&apos;s own table pages through every row of the report. When a value is clicked on another visual, it shows only the matching rows.
        </Typography>
        <WellFrame well={{ id: 'columns', label: 'Columns', role: 'mixed', max: null, testId: 'tile-columns' }}
          onDropColumn={id => setReportTableCols(r => r.includes(id) ? r : [...r, id])}>
          <Autocomplete multiple size="small" options={columns.filter(c => !c.hidden).map(c => c.id)} value={reportTableCols.filter(i => cols.has(i))}
            getOptionLabel={i => label(i)} onChange={(_, v) => setReportTableCols(() => v)}
            renderInput={p => <TextField {...p} label="Its columns" inputProps={{ ...p.inputProps, 'data-testid': 'tile-columns' }} />} />
        </WellFrame>
      </Stack>
    );
  }
  if (tile.kind === 'outline') return <Box data-testid="build-tab"><OutlineTileSettings tile={tile} cols={cols} columns={columns} datasetId={datasetId} grouped={grouped} onMakeValue={onMakeValue} onChange={onChange} /></Box>;
  if (tile.kind === 'band') return <Box data-testid="build-tab"><BandTileSettings tile={tile} paramNames={paramNames} onChange={onChange} /></Box>;
  if (tile.kind === 'insight') return <Box data-testid="build-tab"><InsightTileEditor tile={tile} columns={columns} cols={cols} grouped={grouped} onChange={onChange} /></Box>;

  const place = (well: Well, col: CanvasColumn) => {
    const r = placeInWell(tile, well, col, grouped);
    if (r.note) onNote(r.note);
    else onChange(() => r.tile);
  };
  return (
    <Stack spacing={1.25} data-testid="build-tab">
      {wells.map(well => {
        const items = wellItems(tile, well);
        const room = well.max == null || items.length < well.max || (well.role === 'measure' && (well.slots?.[1] ?? 0) - (well.slots?.[0] ?? 0) === 1);
        return (
          <WellFrame key={well.id} well={well} onDropColumn={id => { const c = cols.get(id); if (c) place(well, c); }}>
            {items.map((it, i) => it.kind === 'measure'
              ? <ValueRow key={`${it.column_id}-${it.index}`} item={it} tile={tile} cols={cols} grouped={grouped} onChange={onChange} />
              : <Chip key={`${it.kind}-${it.column_id}-${i}`} size="small" sx={{ mr: 0.5, mb: 0.5, maxWidth: '100%' }}
                  label={suggested?.has(it.column_id) ? `${label(it.column_id)} (suggested)` : label(it.column_id)}
                  data-testid={`well-${well.id}-field-${it.column_id}`}
                  onDelete={() => onChange(t => removeFromWell(t, it))} deleteIcon={<DeleteIcon aria-label={`Remove ${label(it.column_id)}`} />} />)}
            {room && (() => {
              const s = suggest?.(well);
              return s ? (
                <Stack direction="row" alignItems="center" spacing={0.5} sx={{ mb: 0.5 }} data-testid={`well-${well.id}-suggest`}>
                  <Typography variant="caption" sx={{ flex: 1, minWidth: 0 }} noWrap title={`Suggested: ${s.label} -- ${s.why}`}>
                    Suggested: <b>{s.label}</b> <span style={{ opacity: 0.75 }}>({s.why})</span>
                  </Typography>
                  <Button size="small" onClick={() => { const c = cols.get(s.column_id); if (c) place(well, c); }}
                    data-testid={`well-${well.id}-suggest-use`}>Use</Button>
                </Stack>
              ) : null;
            })()}
            {room && (
              <TextField select size="small" fullWidth value="" sx={{ mt: items.length ? 0.5 : 0 }}
                label={items.length ? 'Add a field' : 'Drop a field here, or pick one'}
                onChange={e => { const c = cols.get(Number(e.target.value)); if (c) place(well, c); }}
                inputProps={{ 'data-testid': well.testId, 'aria-label': `${well.label}: add a field` }}>
                {columns.filter(c => !c.hidden).filter(c => well.role !== 'measure' || true).map(c => (
                  <MenuItem key={c.id} value={c.id}>{c.label}{isMeasureColumn(c) ? ' (value)' : ''}</MenuItem>
                ))}
              </TextField>
            )}
          </WellFrame>
        );
      })}
      {grouped && (
        <Typography variant="caption" color="text.secondary" component="div">
          This report&apos;s rows are already added up, so only the exact ways to add them up again are offered.
        </Typography>
      )}
    </Stack>
  );
}

/** One well: its name, its hint, a drop target. */
function WellFrame({ well, onDropColumn, children }: { well: Well; onDropColumn: (columnId: number) => void; children: React.ReactNode }) {
  const [over, setOver] = useState(false);
  return (
    <Paper variant="outlined" data-testid={`well-${well.id}`} data-over={over ? 'yes' : undefined}
      onDragOver={e => { if (e.dataTransfer.types.includes(FIELD_MIME)) { e.preventDefault(); e.stopPropagation(); setOver(true); } }}
      onDragLeave={() => setOver(false)}
      onDrop={e => { setOver(false); const id = Number(e.dataTransfer.getData(FIELD_MIME)); if (id) { e.preventDefault(); e.stopPropagation(); onDropColumn(id); } }}
      sx={{ p: 1, borderColor: over ? 'primary.main' : undefined, borderStyle: over ? 'dashed' : 'solid', bgcolor: over ? 'action.hover' : undefined }}>
      <Stack direction="row" alignItems="center" spacing={0.5} sx={{ mb: 0.5 }}>
        <Typography variant="caption" sx={{ fontWeight: 600, flex: 1 }}>{well.label}</Typography>
        {well.hint && <Tooltip title={well.hint}><InfoIcon sx={{ fontSize: 14, color: 'text.secondary' }} aria-label={well.hint} /></Tooltip>}
      </Stack>
      {children}
    </Paper>
  );
}

/** One value in a well: its name, "Shown as", "Add up as" (the exact ways only), remove. */
function ValueRow({ item, tile, cols, grouped, onChange }: { item: WellItem; tile: CanvasTile; cols: Map<number, CanvasColumn>; grouped: boolean; onChange: Change }) {
  const i = item.index!;
  const m = tile.measures[i];
  if (!m) return null;
  const name = cols.get(m.column_id)?.label ?? `column #${m.column_id}`;
  const allowed = allowedAggregations(cols.get(m.column_id), grouped);
  return (
    <Stack direction="row" spacing={0.5} alignItems="center" sx={{ mb: 0.5 }} data-testid={`well-value-${i}`}>
      <Typography variant="body2" sx={{ flex: 1, minWidth: 0 }} noWrap title={name}>{name}</Typography>
      <TextField size="small" label="Shown as" value={m.label ?? ''} sx={{ width: 110 }} placeholder={name}
        onChange={e => onChange(t => ({ ...t, measures: t.measures.map((x, j) => j === i ? { ...x, label: e.target.value || undefined } : x) }))}
        inputProps={{ 'data-testid': `tile-measure-label-${i}`, maxLength: 60 }} />
      <TextField select size="small" label="Add up as" value={m.aggregation} sx={{ width: 120 }}
        onChange={e => onChange(t => ({ ...t, measures: t.measures.map((x, j) => j === i ? { ...x, aggregation: e.target.value as Aggregation } : x) }))}
        inputProps={{ 'data-testid': `tile-agg-${i}` }}>
        {(allowed.includes(m.aggregation) ? allowed : [m.aggregation, ...allowed]).map(a => (
          <MenuItem key={a} value={a} disabled={!allowed.includes(a)}>{AGG_LABEL[a] ?? a}</MenuItem>
        ))}
      </TextField>
      <IconButton size="small" aria-label={`Remove ${name}`} onClick={() => onChange(t => removeFromWell(t, item))}><DeleteIcon fontSize="small" /></IconButton>
    </Stack>
  );
}
