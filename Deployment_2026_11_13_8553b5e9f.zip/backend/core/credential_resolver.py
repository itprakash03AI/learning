"""Unified S3 Credential Resolver — single source of truth for all modules.

Used by: Published API, Feed Generation, Report Generation, Query Execution,
Business Query Builder, ETL Engine.

Handles all auth modes:
  - "keys"        → credentials already in config (pass through)
  - "portal"      → 3-step JWT flow via CredentialManager / aws_portal_auth
  - "assume_role" → STS AssumeRole via boto3
  - "profile"     → AWS CLI profile via boto3
  - "iam_role"    → IAM instance role (EKS/EC2)

On-prem vs AWS S3 differences:
  - On-prem (Dell ECS, MinIO, Ceph): has endpoint_url + path_style=True,
    uses static keys directly, s3_access_mode="presigned" (DuckDB never
    gets credentials — boto3 generates pre-signed URLs).
  - AWS S3: may use portal/STS/IAM; DuckDB httpfs gets credentials directly.
  - When endpoint_url is present, portal/STS/IAM resolution is skipped
    (on-prem doesn't support these AWS-specific mechanisms).

Returns a copy of conn_config with AWS credentials injected and auth_mode="keys".
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def extract_username_from_consumer(consumer: Any) -> str:
    """Phase 131 deep-dive #8 — single source of truth for "who is the
    triggering user" when resolving credentials.

    Six call sites scattered across feed_engine / published_views_api /
    federation_views_api / execute_api / data_grid_api / sql_query_api
    were each constructing a username string differently (some passed
    literal "feed_engine" / "feed_delivery" / "published_view:slug"
    which the portal_password_vault could never match).  This helper
    normalises the lookup so every caller gets identical semantics.

    Accepts any of:
      - dict-with-feed-config shape: ``{_triggered_by_user: "alice"}``
        (feed_engine attaches this on entry to execute_feed)
      - dict-with-api-user shape: ``{username: "alice"}`` or
        ``{name: "alice"}`` (published_views_api / federation_views_api)
      - dict-with-user-data shape: ``{user_data: {username: "alice"}}``
        (session-resolved consumer)
      - plain string username
      - None / falsy → returns ""

    Returns the username string suitable for vault lookup, or "" when
    no real user identity is available (batch/API-key contexts).
    The downstream resolver handles "" by falling through to system
    account / hybrid / auto modes per the connection's policy.
    """
    if not consumer:
        return ""
    if isinstance(consumer, str):
        return consumer.strip()
    if isinstance(consumer, dict):
        # Priority order — feed_engine's explicit marker first, then
        # api_user's two common key shapes, then nested user_data.
        for key in ("_triggered_by_user", "username", "name"):
            v = consumer.get(key)
            if isinstance(v, str) and v.strip():
                return v.strip()
        nested = consumer.get("user_data") or consumer.get("user")
        if isinstance(nested, dict):
            return extract_username_from_consumer(nested)
    return ""


def resolve_s3_for_consumer(conn_config: dict, consumer: Any = None,
                              force_refresh: bool = False,
                              min_lifetime_seconds: float = 0) -> dict:
    """Phase 131 deep-dive #8 — preferred entry point for S3 credential
    resolution.  Wraps resolve_s3_credentials with the username
    extracted from a consumer object (feed_config / api_user / session
    user / plain string / None), eliminating the "different username
    construction in every call site" anti-pattern.

    Call sites that previously passed literal strings like
    "feed_engine" / "feed_delivery" / "published_view:slug" should
    migrate to this helper so the portal_password_vault lookup actually
    hits for personal-mode private connections.

    ``min_lifetime_seconds`` (BF-461, 2026-05-19) — preflight refresh
    threshold for long-running operations.  When > 0, cached creds with
    less than this much remaining lifetime are treated as a cache miss
    so we get a fresh ~1h-TTL session before the operation begins.
    Long-running callers (feed gen, cross-source, raw-SQL streaming, PV
    execute, federation materialization) should pass at least 600
    (10 minutes) to leave headroom over the slowest expected run.
    Short query paths (BQB structured, EXPLAIN) should leave at 0.
    """
    return resolve_s3_credentials(
        conn_config,
        username=extract_username_from_consumer(consumer),
        force_refresh=force_refresh,
        min_lifetime_seconds=min_lifetime_seconds,
    )


def resolve_s3_keys(conn_config: dict, username: str = "", **kw) -> tuple:
    """``(key, secret, token)`` for ``conn_config`` through THE chain --
    for the roads that hand DuckDB or boto3 bare keys (the query builder's
    in-process DuckDB, the DuckDB child, federation's CREATE SECRET).

    2026-10-26 -- those three each carried their OWN copy of the
    portal / STS / profile chain, so a rule fixed here (an AWS VPC endpoint
    is not on-prem; a system account resolved from the vault; the VPCE
    ``bucket.`` normalisation) reached the feed worker and not the query
    builder, or the other way round.  Empty strings when the chain found
    nothing -- the caller says why (BF-476 stamp), it never substitutes.
    """
    resolved = resolve_s3_credentials(conn_config, username=username, **kw) or {}
    return (str(resolved.get("aws_access_key_id") or ""),
            str(resolved.get("aws_secret_access_key") or ""),
            str(resolved.get("aws_session_token") or ""))


def _is_aws_endpoint(endpoint: str) -> bool:
    """True for an AWS S3 endpoint in any spelling (regional, global,
    dual-stack, VPC interface endpoint, GovCloud, China) -- offline, by host."""
    if not endpoint:
        return False
    from urllib.parse import urlparse
    host = (urlparse(endpoint if "://" in endpoint else f"https://{endpoint}").hostname or "").lower()
    return host.endswith(".amazonaws.com") or host.endswith(".amazonaws.com.cn")


def is_onprem_s3(conn_config: dict) -> bool:
    """THE on-prem rule (Dell ECS, MinIO, Ceph): an endpoint that is not
    AWS's, or path-style with no AWS endpoint.  An on-prem store takes
    static keys only -- the portal / STS / IAM chain never runs against
    it.  Read by the chain below and by the boto3 handler
    (``core.s3_storage.build_s3_config``), so both answer alike."""
    cfg = conn_config or {}
    ep = str(cfg.get("endpoint_url") or cfg.get("endpoint") or "").strip()
    aws = _is_aws_endpoint(ep)
    return bool((ep and not aws) or (cfg.get("path_style") is True and not aws))


def _mark_system_account_keys(conn_config: dict) -> None:
    """A system account's keys ARE the credential: once they are on the
    config its ``auth_mode`` is ``keys`` (2026-10-26).  Before, a
    connection saved as ``iam_role`` + a vault system account came back
    with the vault keys AND ``auth_mode=iam_role``; the roads that read
    keys off the config (the feed worker) used the vault, the roads that
    dispatch on ``auth_mode`` (the query builder, the boto3 handler) ran
    the instance role -- one connection, two identities."""
    if ((conn_config.get("aws_access_key_id") or "").strip()
            and (conn_config.get("aws_secret_access_key") or "").strip()
            and (conn_config.get("auth_mode") or "").lower() != "portal"):
        conn_config["auth_mode"] = "keys"


def _normalize_endpoint_in_config(conn_config: dict) -> dict:
    """Apply ``ssl_config.normalize_vpce_endpoint_for_s3_data`` to the
    ``endpoint_url`` in ``conn_config``.  Used as the single chokepoint
    so every consumer that calls ``resolve_s3_credentials`` receives an
    already-normalised endpoint -- the 9 ``SET s3_endpoint`` sites in
    the codebase don't each need to know about the VPCE ``bucket.``
    prefix rule.

    Idempotent -- safe to call multiple times.  Returns the input
    unchanged when ``endpoint_url`` is None / not a VPCE URL.
    """
    if not conn_config:
        return conn_config
    _ep_raw = conn_config.get("endpoint_url") or ""
    if not _ep_raw or ".vpce.amazonaws.com" not in _ep_raw.lower():
        return conn_config
    try:
        from core.ssl_config import normalize_vpce_endpoint_for_s3_data
        _ep_norm = normalize_vpce_endpoint_for_s3_data(_ep_raw)
    except Exception:
        return conn_config
    if not _ep_norm or _ep_norm == _ep_raw:
        return conn_config
    _new = dict(conn_config)
    _new["endpoint_url"] = _ep_norm
    logger.debug(
        "[cred-resolver] VPCE endpoint normalised (%s -> %s) -- "
        "downstream resolve_s3_access + boto3 calls inherit.",
        _ep_raw.lower(), _ep_norm.lower(),
    )
    return _new


def resolve_s3_credentials(conn_config: dict, username: str = "",
                           force_refresh: bool = False,
                           min_lifetime_seconds: float = 0) -> dict:
    """Resolve AWS credentials for an S3 connection config.

    Always returns a copy — never mutates the input.

    Resolution chain:
      1. Already has explicit keys (access_key + secret_key) → pass through
      2. auth_mode="portal" → CredentialManager (system account → personal → service)
      3. auth_mode="portal" fallback → legacy inject_portal_creds
      4. auth_mode="assume_role" → STS AssumeRole
      5. auth_mode="profile" → boto3 Session with named profile
      6. auth_mode="iam_role" → boto3 default credential chain (instance role)

    2026-06-24 -- single-chokepoint VPCE normalisation: this function
    is the resolver for ALL S3 connection configs.  We pre-apply the
    VPCE ``bucket.`` prefix here so every downstream consumer (boto3,
    DuckDB ``SET s3_endpoint``, presigning, federation engine, MV
    manager, multi-worker dispatcher) inherits the cert-aligned
    endpoint without per-site rewiring.

    Raises CredentialResolutionError if resolution fails and no credentials available.
    """
    # 2026-11-12 -- the fields QueryStudio stamps on a RESOLVED config are
    # server-only: one that arrives from the database or a request (not put
    # there by this process) is removed before anything is resolved or built.
    from core.qs_credentials.lifecycle import without_foreign_stamp as _no_foreign_stamp
    conn_config = _no_foreign_stamp(conn_config)
    conn_config = _normalize_endpoint_in_config(conn_config)

    # Phase 154 (2026-06-25) -- if the connection config references a
    # SystemAccount (by id or name), pre-resolve its credentials via
    # the QueryStudio qs_credentials chokepoint and inject them into
    # the config before downstream auth_mode dispatch runs.  This
    # lets a single connection row declare "use system-account svc-aws"
    # and have the runtime pull live creds from vault (or the
    # encrypted password column when use_vault=False).
    #
    # Operator: "we have secret resolver in etl folder...we need here
    # at query studio also in case of if any system account used for
    # aws s3 or trino or any source so we need to capture and store
    # those required details in databse table for each system account
    # so at runtime we can fetch credentials".
    _sa_ref = (conn_config.get("system_account_id")
               or conn_config.get("system_account_name")
               or conn_config.get("system_account"))
    # Phase 154 (2026-06-25) operator: "i dont want any risk...fix all".
    # Wire-in semantics: SystemAccount resolution is FAIL-CLOSED when
    # the connection REQUIRES it (no literal creds present), and
    # FAIL-OPEN-WITH-WARNING when literal creds are also configured
    # (operator-explicit fallback path).  Previous fail-open-always
    # behaviour silently masked vault outages + masked the BUG #2
    # ImportError -- resolver was a no-op in prod and nobody noticed.
    _has_literal_keys = bool(
        (conn_config.get("aws_access_key_id") or "").strip()
        and (conn_config.get("aws_secret_access_key") or "").strip()
    )
    if _sa_ref and not _has_literal_keys:
        try:
            from core.qs_credentials import resolve_system_account
            _sa_creds = resolve_system_account(_sa_ref)
            # kv_secrets shape returns access_key / secret_key /
            # optional session_token + endpoint_url + region.  Inject
            # under the AWS-style key names downstream code expects.
            conn_config = dict(conn_config)
            for src, tgt in (
                ("access_key",    "aws_access_key_id"),
                ("secret_key",    "aws_secret_access_key"),
                ("session_token", "aws_session_token"),
                ("endpoint_url",  "endpoint_url"),
                ("region",        "region"),
            ):
                v = _sa_creds.get(src)
                if v and not conn_config.get(tgt):
                    conn_config[tgt] = v
            # DB_accounts/AD_accounts shape (rare for S3 but supported
            # for symmetry with SQL connectors) -- preserved as
            # username/password on the config so consumers that look
            # for those keys still find them.
            if _sa_creds.get("username") and not conn_config.get("username"):
                conn_config["username"] = _sa_creds["username"]
            if _sa_creds.get("password") and not conn_config.get("password"):
                conn_config["password"] = _sa_creds["password"]
            _mark_system_account_keys(conn_config)
            logger.info(
                "[cred-resolver] resolved SystemAccount %r via %s "
                "(account_type=%s)",
                _sa_ref, _sa_creds.get("via"), _sa_creds.get("account_type"),
            )
        except Exception as _sa_exc:
            # FAIL-CLOSED: no literal fallback available -- the
            # connection ONLY had system_account_id, so a resolver
            # failure means we have no creds at all.  Re-raise as
            # CredentialResolutionError so the API path returns a
            # clear 5xx + operator sees the configuration error
            # immediately, not three days later in a log review.
            from core.credential_manager import CredentialResolutionError
            logger.error(
                "[cred-resolver] SystemAccount %r resolution failed (%s) "
                "-- FAIL-CLOSED: no literal credentials available, "
                "cannot continue.",
                _sa_ref, _sa_exc,
            )
            raise CredentialResolutionError(
                f"SystemAccount {_sa_ref!r} resolution failed and the "
                f"connection has no literal credentials to fall back to. "
                f"Root cause: {_sa_exc}"
            ) from _sa_exc
    elif _sa_ref and _has_literal_keys:
        # Fail-OPEN: operator explicitly configured BOTH a SystemAccount
        # AND literal keys.  Try the resolver, fall through to literals
        # on failure with a warning -- operator opted-in to this path.
        try:
            from core.qs_credentials import resolve_system_account
            _sa_creds = resolve_system_account(_sa_ref)
            conn_config = dict(conn_config)
            for src, tgt in (
                ("access_key",    "aws_access_key_id"),
                ("secret_key",    "aws_secret_access_key"),
                ("session_token", "aws_session_token"),
                ("endpoint_url",  "endpoint_url"),
                ("region",        "region"),
            ):
                v = _sa_creds.get(src)
                if v and not conn_config.get(tgt):
                    conn_config[tgt] = v
            if _sa_creds.get("username") and not conn_config.get("username"):
                conn_config["username"] = _sa_creds["username"]
            if _sa_creds.get("password") and not conn_config.get("password"):
                conn_config["password"] = _sa_creds["password"]
            _mark_system_account_keys(conn_config)
            logger.info(
                "[cred-resolver] resolved SystemAccount %r (literal "
                "fallback also present, not used) via %s",
                _sa_ref, _sa_creds.get("via"),
            )
        except Exception as _sa_exc:
            logger.warning(
                "[cred-resolver] SystemAccount %r resolution failed (%s) "
                "-- falling through to literal AWS keys (operator "
                "explicitly configured both).",
                _sa_ref, _sa_exc,
            )

    auth_mode = (conn_config.get("auth_mode") or "").lower()

    # ── Detect on-prem S3 (Dell ECS, MinIO, Ceph) ───────────────────────
    # On-prem has endpoint_url and/or path_style=True; uses static keys
    # stored directly in the connection config. Never uses portal/STS/IAM.
    # 2026-10-26 -- an AWS endpoint is NOT on-prem.  The owner's feed worker
    # read fact_tetb through an AWS VPC endpoint
    # (bucket.vpce-....s3.eu-west-1.vpce.amazonaws.com) with role-based
    # credentials: this rule called EVERY connection with an endpoint_url
    # "on-prem", returned it with no credentials (the IAM role / AssumeRole /
    # profile chain below never ran), and DuckDB's GETs were refused -- while
    # the query builder (api/data_grid_api.py::_resolve_s3_creds_for_con,
    # which dispatches on auth_mode alone) read the same table.  On-prem =
    # an endpoint that is not AWS's, or path-style with no AWS endpoint.
    is_onprem = is_onprem_s3(conn_config)

    # ── Short-circuit: explicit keys already present ─────────────────────
    has_explicit = bool(
        (conn_config.get("aws_access_key_id") or "").strip()
        and (conn_config.get("aws_secret_access_key") or "").strip()
    )
    if has_explicit and auth_mode != "portal":
        return dict(conn_config)

    # ── On-prem short-circuit: only uses static keys, no portal/STS ─────
    # On-prem S3 doesn't support AWS portal, STS AssumeRole, or IAM roles.
    # If keys are missing for on-prem, return config as-is with a warning.
    if is_onprem and auth_mode != "portal":
        if not has_explicit:
            logger.warning(
                "[cred-resolver] On-prem S3 (endpoint_url=%s) has no explicit "
                "credentials — check connection config",
                conn_config.get("endpoint_url", ""),
            )
        return dict(conn_config)

    # ── Portal mode: CredentialManager (preferred) ───────────────────────
    if auth_mode == "portal":
        _portal_problem = ""
        # Try 1: CredentialManager (handles system account, personal, service fallback)
        try:
            from core.credential_manager import (
                get_credential_manager, PersonalPasswordRequired,
                PortalLoginMustBeSystemAccount,
            )
            cm = get_credential_manager()
            if cm:
                resolved = cm.resolve_s3_credentials(
                    dict(conn_config), username,
                    force_refresh=force_refresh,
                    min_lifetime_seconds=min_lifetime_seconds,
                )
                logger.debug("[cred-resolver] Portal credentials resolved via CredentialManager for '%s'", username)
                return resolved
        except (PersonalPasswordRequired, PortalLoginMustBeSystemAccount):
            # 2026-10-30: the "default login must be a System Account"
            # sentence is the answer, never swallowed into a generic error.
            # BF-286: don't swallow this — the API layer needs to see it
            # so it can return 401 portal_password_required to trigger
            # the BF-285 frontend modal.  Falling through to legacy
            # inject_portal_creds would silently miss the prompt.
            raise
        except Exception as exc:
            logger.warning("[cred-resolver] CredentialManager failed for '%s': %s", username, exc)
            _portal_problem = str(exc)

        # Try 2: Legacy inject_portal_creds (fallback)
        try:
            from core.aws_portal_auth import inject_portal_creds
            trace = conn_config.get("portal_username") or username or "credential_resolver"
            resolved = inject_portal_creds(dict(conn_config), trace)
            if (resolved.get("aws_access_key_id") or "").strip():
                logger.debug("[cred-resolver] Portal credentials resolved via legacy inject for '%s'", trace)
                return resolved
        except Exception as exc:
            from core.credential_manager import PortalLoginMustBeSystemAccount
            if isinstance(exc, PortalLoginMustBeSystemAccount):
                raise
            logger.warning("[cred-resolver] Legacy portal injection failed: %s", exc)

        # Portal mode but no resolution succeeded — return as-is (caller will get auth error).
        # 2026-11-12 -- WITH THE REASON (``credential_problem``).  Unknown is not
        # empty: the config used to come back bare, and whatever was built from it
        # said "this connection logs in with each person's own password" about a
        # connection on a System Account whose Vault password had been rotated.
        logger.error("[cred-resolver] Portal credential resolution FAILED for '%s' — no credentials available%s",
                     username, f": {_portal_problem}" if _portal_problem else "")
        _unresolved = dict(conn_config)
        if _portal_problem:
            _unresolved["credential_problem"] = _portal_problem[:600]
        return _unresolved

    # ── AssumeRole: STS via boto3 ────────────────────────────────────────
    if auth_mode == "assume_role":
        try:
            return _resolve_assume_role(conn_config)
        except Exception as exc:
            logger.warning("[cred-resolver] AssumeRole failed: %s", exc)
            return dict(conn_config)

    # ── Profile / IAM Role: boto3 credential chain ───────────────────────
    if auth_mode in ("profile", "iam_role"):
        try:
            return _resolve_boto3_profile(conn_config, auth_mode)
        except Exception as exc:
            logger.warning("[cred-resolver] Profile/IAM resolution failed: %s", exc)
            return dict(conn_config)

    # ── Keys or unknown mode: pass through ───────────────────────────────
    # For "keys" mode, credentials should already be in the config.
    # For empty/unknown modes on AWS, try portal injection as a last resort
    # (inject_portal_creds checks portal.enabled and skips if no portal configured)
    # On-prem connections already short-circuited above — this only runs for AWS.
    result = dict(conn_config)
    if not has_explicit and not is_onprem:
        try:
            from core.aws_portal_auth import inject_portal_creds
            trace = conn_config.get("portal_username") or username or ""
            if trace:
                result = inject_portal_creds(result, trace)
        except Exception as _inj_exc:
            from core.credential_manager import PortalLoginMustBeSystemAccount
            if isinstance(_inj_exc, PortalLoginMustBeSystemAccount):
                # a last-resort lookup on a non-portal connection: say why
                # the default login gave nothing, keep the connection as is
                logger.warning("[cred-resolver] %s", _inj_exc)
            # else: no portal configured — fine
    return result


def _resolve_assume_role(conn_config: dict) -> dict:
    """Resolve credentials via STS AssumeRole."""
    import boto3
    from botocore.config import Config as BotoConfig

    role_arn = conn_config.get("role_arn")
    if not role_arn:
        raise ValueError("role_arn required for assume_role auth mode")

    from core.s3_storage import resolve_s3_region as _qs_region
    region = _qs_region(conn_config)
    session = boto3.Session(
        profile_name=conn_config.get("aws_profile") or None,
        region_name=region,
    )

    # The STS call verifies TLS the way every other client does
    # (core.ssl_config: a CA-bundle PATH is honoured, not coerced to a bool).
    from core.ssl_config import as_boto3_verify, resolve_ssl
    verify = as_boto3_verify(resolve_ssl(conn_config.get("ssl_verify", True)))

    # Proxy support
    try:
        from core.proxy_utils import get_boto_proxies
        proxies = get_boto_proxies()
    except Exception:
        proxies = None

    sts = session.client(
        "sts", verify=verify,
        config=BotoConfig(proxies=proxies) if proxies else None,
    )
    try:
        assume_kw = {
            "RoleArn": role_arn,
            # ONE session name on every road (the query builder, the DuckDB
            # child, federation and the boto3 handler all said
            # "parquet-engine"; this one said "querystudio" -- CloudTrail
            # showed two identities for one connection).
            "RoleSessionName": conn_config.get("role_session_name") or "parquet-engine",
        }
        if conn_config.get("external_id"):
            assume_kw["ExternalId"] = conn_config["external_id"]
        creds = sts.assume_role(**assume_kw)["Credentials"]
    finally:
        sts.close()

    result = dict(conn_config)
    result["aws_access_key_id"] = creds["AccessKeyId"]
    result["aws_secret_access_key"] = creds["SecretAccessKey"]
    result["aws_session_token"] = creds["SessionToken"]
    result["auth_mode"] = "keys"
    logger.debug("[cred-resolver] AssumeRole credentials resolved (role=%s)", role_arn)
    return result


def _resolve_boto3_profile(conn_config: dict, auth_mode: str) -> dict:
    """Resolve credentials via boto3 Session (profile or instance role)."""
    import boto3

    from core.s3_storage import resolve_s3_region as _qs_region
    region = _qs_region(conn_config)
    session = boto3.Session(
        profile_name=conn_config.get("aws_profile") or None,
        region_name=region,
    )
    resolved = session.get_credentials()
    if not resolved:
        raise ValueError(f"boto3 Session returned no credentials for auth_mode={auth_mode}")

    frozen = resolved.get_frozen_credentials()
    result = dict(conn_config)
    result["aws_access_key_id"] = frozen.access_key or ""
    result["aws_secret_access_key"] = frozen.secret_key or ""
    result["aws_session_token"] = frozen.token or ""
    result["auth_mode"] = "keys"
    logger.debug("[cred-resolver] Profile/IAM credentials resolved (mode=%s)", auth_mode)
    return result
