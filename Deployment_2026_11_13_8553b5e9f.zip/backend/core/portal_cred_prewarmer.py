"""Portal credential pre-warmer — defeats the cold-portal 30s budget bug.

2026-11-12 -- WHAT IT WARMS CHANGED.  The keys of a login the system holds
(a System Account, the login saved on a connection) now live in ONE shared,
encrypted row (``credential_leases``; ``core/qs_credentials/leases.py``), and
``resolve_s3_credentials`` below goes through their owner
(``core/qs_credentials/lifecycle.py``).  So a tick on ANY pod renews the row
for EVERY pod when it is due, and only one pod logs in.  What is still
process-local is each pod's few-second copy.  The history below is kept as it
was written: it is why the daemon runs in every process.

Strategic shape:

When ``execute_query`` calls into a portal-backed S3 connection for the
first time after pod startup, the inner BF-406 portal credential
resolution can take up to 20 seconds (slow corporate proxy + cold
portal session).  The outer 30s handler budget eats the remaining
~10s for pre-validate + DB writes and the user sees
``Query submission exceeded 30-second budget`` HTTP 504.

The fix:

Pre-warm portal credentials in the background BEFORE the user query
needs them.  Daemon iterates every active S3 connection with
``auth_mode == "portal"`` (system_account fallback) every
``interval_minutes`` (default 8m).  Each resolution populates the
existing ``aws_portal_auth._cred_cache`` so user queries hit a warm
cache and skip the 20s cold-portal cost entirely.

Reuses the existing cache (no parallel cache layer).  Fail-OPEN —
any per-connection error is logged but never blocks the tick.

Strategic placement:
  * Sits next to brain_coordinator: a runtime resilience capability.
  * Same always-register pattern as the other brain daemons.
  * Coordinator pressure flag is RESPECTED — under high S3 bandwidth
    pressure the pre-warmer defers this tick (creds will resolve
    lazily on user query, same as today).

════════════════════════════════════════════════════════════════════
THE CACHE IS PROCESS-LOCAL, AND UNTIL 2026-09-07 THE DAEMON RAN IN THE
WRONG PROCESS.
════════════════════════════════════════════════════════════════════

``aws_portal_auth._cred_cache`` is a module-level dict.  Warming it
warms ONE PYTHON PROCESS.  Measured: a child process that populates it
leaves the parent's copy empty, and vice versa.

``register_prewarmer_daemon`` is called from the scheduler block in
``main.py``, which ``PodRole`` gives to ``worker``/``hybrid`` and
withholds from ``api``.  In the deployed split every query-serving chart
stamps ``pod.role="api"`` — ``k8s/querystudioapi-helm/worker`` (4
replicas, the query executors), ``…/reports`` (2), ``…/published-api``,
``…/downloads`` — while ``…/scheduler`` is the single ``role=worker``
pod.  So the pre-warmer warmed the scheduler pod's dict, and all six
query-serving pods stayed exactly as cold as before it existed.  Worse,
each of them registered a ``portal_cred_prewarmer`` UI placeholder
saying "Runs on scheduler pod", which reads as protection those pods did
not have.

The single-pod deployment prod runs today is ``hybrid``, where the
daemon and the query path ARE the same process — which is why this was
never noticed.  The module was correct for the topology in production
and wrong for the one the charts describe.

The fix is not a new gate: a PROCESS-LOCAL warm-up belongs in EVERY
process that has the consumer.  ``start_local_prewarm_task`` runs the
same tick, on an asyncio loop, in a pod that serves queries but hosts no
daemon scheduler.  ``warm_scope`` reports what this process's cache
actually covers so the admin tile stops implying more.
"""
from __future__ import annotations

import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ── Config ────────────────────────────────────────────────────────────


def _cfg(key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        return _g("portal_cred_prewarmer", key, fallback)
    except Exception:
        return fallback


def enabled() -> bool:
    return bool(_cfg("enabled", True))


def interval_minutes() -> int:
    """Default 8m — comfortably under cache_ttl_seconds (10m) so cache
    rotates while always-fresh.  STS tokens last ~60m so we're not
    refreshing the underlying token, just keeping the cache warm."""
    return int(_cfg("interval_minutes", 8) or 8)


def cache_ttl_seconds() -> int:
    return int(_cfg("cache_ttl_seconds", 600) or 600)


def max_parallel_resolutions() -> int:
    """Cap concurrency so a portal-storm doesn't accidentally DOS the
    portal.  Default 4 — slow enough to be polite, fast enough for
    deployments with dozens of S3 connections."""
    return int(_cfg("max_parallel_resolutions", 4) or 4)


# ── Tick ring ────────────────────────────────────────────────────────


@dataclass
class PrewarmerTickRecord:
    started_at:        str
    elapsed_seconds:   float
    connections_seen:  int
    portal_eligible:   int
    pre_warmed:        int
    skipped_pressure:  int
    skipped_cached:    int
    errors:            int
    details:           List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


_RECENT_TICKS: deque = deque(maxlen=20)
_TICK_LOCK = threading.Lock()


def recent_ticks(limit: int = 10) -> List[Dict[str, Any]]:
    with _TICK_LOCK:
        return list(_RECENT_TICKS)[: max(1, min(20, int(limit)))]


# ── The daemon ───────────────────────────────────────────────────────


def prewarmer_tick(db_manager: Any) -> Dict[str, Any]:
    """One pre-warm pass across all active portal-backed S3 connections.

    Honors brain_coordinator pressure: defers entirely when pressure
    is high (creds will resolve lazily on user query, same as the
    pre-fix behaviour).

    Returns a dict-form ``PrewarmerTickRecord``.
    """
    started_at = datetime.now(timezone.utc)
    t0 = time.monotonic()
    rec = PrewarmerTickRecord(
        started_at=started_at.isoformat(),
        elapsed_seconds=0.0,
        connections_seen=0,
        portal_eligible=0,
        pre_warmed=0,
        skipped_pressure=0,
        skipped_cached=0,
        errors=0,
    )
    if not enabled():
        rec.elapsed_seconds = round(time.monotonic() - t0, 3)
        rec.details.append({"skipped_reason":
                             "portal_cred_prewarmer.enabled=false"})
        _record(rec)
        return rec.to_dict()

    # Coordinator pressure — when bandwidth is tight, the warm cache
    # can wait.  Portal cred resolution doesn't touch S3 bandwidth
    # itself but adds load to the corporate proxy + portal.  Cheap
    # alignment with the rest of the brain.
    try:
        from core.brain_coordinator import get_current_pressure
        if get_current_pressure() == "high":
            rec.skipped_pressure = 1
            rec.elapsed_seconds = round(time.monotonic() - t0, 3)
            rec.details.append({
                "skipped_reason": (
                    "brain_coordinator: bandwidth pressure — defer "
                    "portal pre-warm so the supplement scanner has "
                    "headroom"
                ),
            })
            _record(rec)
            return rec.to_dict()
    except Exception:
        pass

    try:
        conns = db_manager.list_connections(
            active_only=True, limit=500, offset=0,
        )
    except Exception as exc:
        rec.errors += 1
        rec.elapsed_seconds = round(time.monotonic() - t0, 3)
        rec.details.append({"error": f"list_connections: {exc}"[:300]})
        _record(rec)
        return rec.to_dict()

    rec.connections_seen = len(conns or [])

    # Filter to portal-backed S3 connections + de-dup by (bucket,
    # auth_mode) — same portal can back many connections; one resolution
    # warms the cache for all of them.
    eligible: List[Dict[str, Any]] = []
    seen_keys: set = set()
    for c in conns or []:
        if (c or {}).get("connection_type") != "s3":
            continue
        cfg = c.get("config") or {}
        auth_mode = (cfg.get("auth_mode") or "").lower()
        if auth_mode != "portal":
            continue
        bucket = cfg.get("bucket_name") or ""
        portal_id = cfg.get("aws_portal_id") or ""
        key = (bucket, portal_id, auth_mode)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        # 2026-10-08 -- list_connections() is the BROWSER-safe view: every
        # secret in it is "***" (core/crypto.py::masked_for_client).  A
        # portal login must use the DECRYPTED row (the bloom scanner 403'd
        # on every file of the real bucket for exactly this).  A row that
        # cannot be read is an error, never a login with the masked config.
        try:
            raw = db_manager.get_connection_raw(int(c.get("id")))
        except Exception as exc:
            rec.errors += 1
            rec.details.append({"connection_id": c.get("id"),
                                "error": f"get_connection_raw: {exc}"[:300]})
            continue
        raw_cfg = (raw or {}).get("config") if isinstance(raw, dict) else None
        if not isinstance(raw_cfg, dict):
            rec.errors += 1
            rec.details.append({"connection_id": c.get("id"),
                                "error": "decrypted connection row unavailable"})
            continue
        eligible.append({
            "connection_id":   c.get("id"),
            "connection_name": c.get("name"),
            "config":          raw_cfg,
        })

    rec.portal_eligible = len(eligible)
    if not eligible:
        rec.elapsed_seconds = round(time.monotonic() - t0, 3)
        _record(rec)
        return rec.to_dict()

    # Resolve in parallel, capped to max_parallel_resolutions.
    # Reusing concurrent.futures so we don't pull in extra deps.
    from concurrent.futures import ThreadPoolExecutor, as_completed
    workers = max(1, min(len(eligible), max_parallel_resolutions()))
    with ThreadPoolExecutor(
        max_workers=workers, thread_name_prefix="portal-prewarmer",
    ) as pool:
        futures = {
            pool.submit(_prewarm_one, conn): conn
            for conn in eligible
        }
        for fut in as_completed(futures):
            conn = futures[fut]
            try:
                outcome = fut.result()
                if outcome.get("status") == "warmed":
                    rec.pre_warmed += 1
                elif outcome.get("status") == "cached":
                    rec.skipped_cached += 1
                elif outcome.get("status") == "error":
                    rec.errors += 1
                rec.details.append({
                    "connection_id":   conn.get("connection_id"),
                    "connection_name": conn.get("connection_name"),
                    **outcome,
                })
            except Exception as exc:
                rec.errors += 1
                rec.details.append({
                    "connection_id":   conn.get("connection_id"),
                    "error":           str(exc)[:300],
                })

    rec.elapsed_seconds = round(time.monotonic() - t0, 3)
    _record(rec)
    return rec.to_dict()


def _prewarm_one(conn_entry: Dict[str, Any]) -> Dict[str, Any]:
    """Resolve credentials for one connection; results land in
    aws_portal_auth._cred_cache under the canonical
    ``sys:<system_account_id>`` key.

    Returns ``{"status": "warmed" | "cached" | "error", ...}``.

    2026-06-10 audit fix: dropped the local cache-fresh check.  The
    earlier check looked up cache_key ``"portal_id|account_id"`` —
    but credential_manager caches under ``"sys:<id>"`` for the system-
    account path.  Pre-warmer's cache lookup thus NEVER hit + we
    always re-resolved.  resolve_s3_credentials does its own cache
    lookup via min_lifetime_seconds → calls into a fresh cache slot
    are cheap no-ops anyway; outer check was double bookkeeping
    against the wrong key.

    Username threading: passes empty username so credential_manager
    walks the system_account fallback path.  Personal-creds portal
    connections don't benefit (the user's password lives outside
    the pre-warmer's reach), which is fine — those rely on the user
    entering creds explicitly so no cold-portal-on-startup penalty.

    elapsed_seconds tells the caller whether portal was actually
    contacted (multi-second) or cache served (sub-second) — the
    admin tick record carries this so ops can see real warmer
    activity vs idle "everything still cached" passes.
    """
    cfg = conn_entry.get("config") or {}
    try:
        from core.credential_resolver import resolve_s3_credentials
        t0 = time.monotonic()
        creds = resolve_s3_credentials(
            cfg, username="", force_refresh=False,
            min_lifetime_seconds=cache_ttl_seconds(),
        )
        elapsed = time.monotonic() - t0
        if creds and (creds.get("aws_access_key_id")
                       or creds.get("access_key")):
            # Sub-second elapsed = creds came from cache; user
            # query path will see the same fast path.  Multi-second
            # elapsed = portal resolution actually ran + cache is
            # now warm for the next call.  Threshold is generous —
            # corporate proxies can take 500ms on a healthy cache hit.
            status = "cached" if elapsed < 0.5 else "warmed"
            return {"status": status,
                     "resolution_seconds": round(elapsed, 3)}
        return {"status": "error",
                 "reason": "resolution returned no credentials",
                 "resolution_seconds": round(elapsed, 3)}
    except Exception as exc:
        return {"status": "error", "error": str(exc)[:300]}


def _record(rec: PrewarmerTickRecord) -> None:
    with _TICK_LOCK:
        _RECENT_TICKS.appendleft(rec.to_dict())


# ── Warm scope — which PROCESS this cache covers ───────────────────


def warm_scope(scheduler_mode: Optional[str] = None) -> Dict[str, Any]:
    """What this process's warm cache actually covers.

    UNKNOWN IS NOT EMPTY: when the pod role cannot be resolved this says
    so with a reason rather than reporting a confident "not warmed".

    Returned keys:
      * ``process_local``         — always True; it is a module-level dict.
      * ``pod_role``              — the resolved role, or None if unresolvable.
      * ``scheduler_daemon_here`` — whether the APScheduler-backed daemon
        registers on this pod at all.
      * ``warmed_by``             — ``"scheduler_daemon"`` | ``"local_task"``
        | ``"nothing"`` | ``"unknown"``.
      * ``reason``                — a sentence an operator can act on.
    """
    out: Dict[str, Any] = {
        "process_local": True,
        "cache": "aws_portal_auth._cred_cache",
        "enabled": enabled(),
        "pod_role": None,
        "scheduler_daemon_here": None,
        "local_task_running": _local_task_is_running(),
        "warmed_by": "unknown",
        "reason": "",
    }
    try:
        from core.pod_role import current as _pr_current
        role = _pr_current()
        out["pod_role"] = role.role
        out["scheduler_daemon_here"] = bool(
            role.should_run("portal_cred_prewarmer",
                            scheduler_mode=scheduler_mode))
    except Exception as exc:
        out["reason"] = (
            f"pod role could not be resolved ({exc}); this process's warm "
            f"coverage is UNKNOWN, not absent")
        return out
    if not out["enabled"]:
        out["warmed_by"] = "nothing"
        out["reason"] = ("portal_cred_prewarmer.enabled=false — no process "
                         "is being warmed, including this one")
    elif out["scheduler_daemon_here"]:
        out["warmed_by"] = "scheduler_daemon"
        out["reason"] = ("the APScheduler daemon runs in THIS process, so "
                         "this process's cred cache is the one it warms")
    elif out["local_task_running"]:
        out["warmed_by"] = "local_task"
        out["reason"] = ("this pod serves queries and hosts no daemon "
                         "scheduler, so it warms its OWN cache via "
                         "start_local_prewarm_task")
    else:
        out["warmed_by"] = "nothing"
        out["reason"] = (
            "the daemon runs on another pod and this process has no local "
            "warm task — the cache it warms is NOT this process's, so the "
            "first portal-backed query served here still pays the cold "
            "resolution this module exists to remove")
    return out


# ── Local (in-process) warm task, for pods with no daemon scheduler ──
#
# The daemon below is APScheduler-backed and registers only where
# PodRole.should_run says so.  A process-local cache needs a warm-up in
# EVERY process that reads it, so query-serving pods get this instead.

_local_task: Optional[Any] = None


def _local_task_is_running() -> bool:
    t = _local_task
    if t is None:
        return False
    try:
        return not t.done()
    except Exception:
        return False


def local_startup_delay_seconds() -> float:
    """Give the pod a moment to finish booting before the first warm.

    Deliberately NOT a new config key: an undeclared key makes any guard
    on it vacuous, and ``core.config._DEFAULTS`` is not this module's to
    extend.  Derived from the declared ``interval_minutes`` instead.
    """
    return min(30.0, max(5.0, interval_minutes() * 60.0 / 16.0))


async def _local_loop(db_manager: Any) -> None:
    """Run ``prewarmer_tick`` in THIS process, for ever.

    The tick is blocking (it resolves credentials over the network), so
    it is pushed off the event loop — a query-serving pod must not stall
    its own /health or WebSocket heartbeat to warm a cache.
    """
    import asyncio
    try:
        await asyncio.sleep(local_startup_delay_seconds())
    except asyncio.CancelledError:
        raise
    loop = asyncio.get_running_loop()
    while True:
        try:
            if enabled():
                try:
                    from core.background_jobs import is_paused as _bj_paused
                    _paused = _bj_paused("portal_cred_prewarmer")
                except Exception:
                    _paused = False
                if not _paused:
                    import time as _time
                    t0 = _time.monotonic()
                    raw = await loop.run_in_executor(
                        None, prewarmer_tick, db_manager)
                    # 2026-10-08 -- the DURABLE ledger: this pod's own warm
                    # (no APScheduler here, so no listener records it).
                    try:
                        from core.background_job_contract import record_event_tick
                        record_event_tick("portal_cred_prewarmer", raw,
                                          duration_s=_time.monotonic() - t0)
                    except Exception as _lexc:  # noqa: BLE001
                        logger.debug("portal_cred_prewarmer ledger write "
                                     "failed: %s", _lexc)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            # Fail-OPEN: a warm-up that cannot run leaves the lazy
            # resolution exactly as it was.  Never kill the loop.
            logger.warning("portal_cred_prewarmer local tick error: %s",
                           exc, exc_info=True)
        try:
            await asyncio.sleep(max(60.0, interval_minutes() * 60.0))
        except asyncio.CancelledError:
            raise


def start_local_prewarm_task(
    db_manager: Any, *, scheduler_mode: Optional[str] = None,
) -> Optional[str]:
    """Warm THIS process's cred cache.  For pods that SERVE QUERIES.

    2026-09-07.  ``register_prewarmer_daemon`` puts the warm-up on the
    daemon host; ``aws_portal_auth._cred_cache`` is a module-level dict;
    the deployed query-serving charts are ``pod.role="api"`` and run no
    daemons.  The warm cache was therefore in a process that never
    executes a user query, which is the entire premise of the module.

    Called from ``main.py``'s api / scheduler-external branch — the exact
    branch that starts no APScheduler — so the two registrations are
    mutually exclusive by construction and no pod runs both.

    Returns the registered job name, or None when this process already
    hosts the daemon (nothing to do) or registration failed.
    """
    scope = warm_scope(scheduler_mode)
    if scope.get("scheduler_daemon_here"):
        # The APScheduler daemon owns this process's cache already.
        # Two warmers in one process is a decision made twice.
        logger.debug("portal_cred_prewarmer: local task not needed — the "
                     "scheduler daemon runs in this process")
        return None
    try:
        from core import background_jobs as _bj
    except Exception as exc:
        logger.warning("portal_cred_prewarmer: background_jobs "
                       "unavailable, local warm task not started: %s", exc)
        return None

    async def _factory():
        import asyncio
        global _local_task
        _local_task = asyncio.current_task()
        try:
            await _local_loop(db_manager)
        finally:
            _local_task = None

    try:
        _bj.register(
            name="portal_cred_prewarmer",
            description=(
                f"Portal STS credential pre-warmer, running IN THIS "
                f"PROCESS every {max(1, interval_minutes())}m.  "
                f"aws_portal_auth._cred_cache is a module-level dict, so a "
                f"warm cache on the daemon pod does nothing for a "
                f"query-serving pod; this pod warms its own.  Replaces the "
                f"'runs on scheduler pod' placeholder, which claimed "
                f"protection this pod did not have.  No-ops when "
                f"portal_cred_prewarmer.enabled=false."
            ),
            factory=_factory,
            autostart=True,
            controllable=True,
        )
    except Exception as exc:
        logger.warning("portal_cred_prewarmer: local task registration "
                       "failed (non-fatal): %s", exc)
        return None
    logger.info(
        "portal_cred_prewarmer LOCAL warm task registered on this "
        "query-serving process (pod_role=%s, enabled=%s) — the cache it "
        "warms is the one this process reads",
        scope.get("pod_role"), scope.get("enabled"),
    )
    return "portal_cred_prewarmer"


# ── Scheduler registration ───────────────────────────────────────────


def register_prewarmer_daemon(
    scheduler: Any, db_manager: Any,
) -> Optional[str]:
    """Always register — tick reads ``enabled()`` and short-circuits
    when off.  Same runtime-flippable pattern as other brain daemons."""
    if scheduler is None:
        return None
    minutes = max(1, interval_minutes())
    job_id = "portal_cred_prewarmer"
    try:
        def _tick():
            # 2026-06-24 -- honour admin pause via core.background_jobs.
            try:
                from core.background_jobs import is_paused as _bj_paused
                if _bj_paused("portal_cred_prewarmer"):
                    return {"status": "skipped", "reason": "paused by admin"}
            except Exception:
                pass
            try:
                return prewarmer_tick(db_manager)      # the ledger reads the result (2026-10-07)
            except Exception as exc:
                logger.warning("portal_cred_prewarmer tick error: %s",
                               exc, exc_info=True)
        scheduler.add_job(
            _tick, "interval", minutes=minutes,
            id=job_id, replace_existing=True,
            max_instances=1, coalesce=True,
        )
        if enabled():
            logger.info(
                "portal_cred_prewarmer scheduled every %dm (job_id=%s)",
                minutes, job_id,
            )
        else:
            logger.info(
                "portal_cred_prewarmer scheduled every %dm but "
                "portal_cred_prewarmer.enabled=false — tick will no-op "
                "until the flag flips (job_id=%s)", minutes, job_id,
            )

        # 2026-06-24 -- ALSO register in core.background_jobs.
        try:
            from core import background_jobs as _bj_pcp

            def _factory():
                return None

            _bj_pcp.register(
                name="portal_cred_prewarmer",
                description=(
                    f"Phase 148 -- portal STS credential pre-warmer.  "
                    f"Every {minutes}m, refreshes portal-auth STS "
                    f"tokens for connections that are about to "
                    f"expire so the user's FIRST query of the hour "
                    f"never blocks on credential resolution.  No-ops "
                    f"when portal_cred_prewarmer.enabled=false."
                ),
                factory=_factory,
                autostart=True,
                controllable=True,
            )
            logger.info(
                "[portal_cred_prewarmer] registered in "
                "background_jobs registry -- visible in admin UI",
            )
        except Exception as _bj_pcp_exc:
            logger.debug(
                "[portal_cred_prewarmer] background_jobs "
                "registration failed (non-fatal): %s", _bj_pcp_exc,
            )
        return job_id
    except Exception as exc:
        logger.warning("register_prewarmer_daemon failed: %s", exc)
        return None


__all__ = [
    "PrewarmerTickRecord", "prewarmer_tick", "register_prewarmer_daemon",
    "recent_ticks",
    "enabled", "interval_minutes", "cache_ttl_seconds",
    "max_parallel_resolutions",
    # 2026-09-07 — the warm cache is process-local; these say which
    # process is covered, and warm the one that serves queries.
    "warm_scope", "start_local_prewarm_task", "local_startup_delay_seconds",
]
