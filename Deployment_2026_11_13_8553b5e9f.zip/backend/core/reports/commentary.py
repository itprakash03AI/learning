"""Commentary that explains the number (2026-11-07).

Record: ``docs/REPORT_COMMENTARY_PLAN_2026_11_06.html``.  A comment explains a
number and never changes one (the owner decided write-back out).  The thread,
who may read it and who may post stay where they were, ``core/reports/signoff.py``;
this module adds what a comment is ABOUT and what can be worked out from that:

* **The anchor** (:func:`clean_anchor`, :func:`anchor_identity`): a row, a column or
  a number, named by key VALUES, never by a row index, so a re-sort or a page
  keeps it.  The tile id and the words are for display; they are not its identity,
  so the same number on two tiles carries the same note.
* **Mentions** (:func:`mentions_in`, :func:`tell_mentioned`): a person is told only
  when they may view the report and see that run's rows.  THE NOTICE NEVER CARRIES
  THE NOTE: what we know of an absent person is what they last signed in with, so
  the note is read through the link, under their access at that moment.
* **The draft** (:func:`draft_for`): a sentence from the run's own numbers, worded
  by a fixed template, optionally reworded by the assistant under the grounding rule
  (``insight_story.story_for``: a number not in the data falls back to the template).
  Nothing is posted by itself.
* **Carry forward** (:func:`carry_candidate`, :func:`clean_origin`): the newest earlier
  note on the same number, in the SAME row-security scope.  Never copied by itself.
* **Needs explaining** (:func:`needs_explaining`, :func:`sign_gate`): the movements over
  the report's limit with no comment, worked out from the run.  A sign-off warns or
  refuses, per report; an overridden warning is recorded on the sign-off.

Unknown is not empty: "could not be worked out" is a status with a reason, never an
empty list (and a report set to Block refuses on it).
"""
from __future__ import annotations

import html
import logging
import re
import threading
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)

ANCHOR_KINDS = ("instance", "row", "column", "cell")
MAX_KEY_FIELDS = 12
MAX_VALUE_CHARS = 200
MAX_LIST = 200           # movements listed; the count stays exact
SETTING = "commentary"   # layout_config key; outside the report's semantic version

SCAN_LIMIT = 100_000     # movements read from the run; past it a report says it could not check them
_NULL = "\x00null"       # no value is not an empty string (microcube._build_where keeps them apart)
_NUMBER = re.compile(r"-?(?:0|[1-9]\d*)(?:\.\d+)?$")        # never a code like 007
_MOMENT = re.compile(r"(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(?:\.(\d+))?$")
_MENTION = re.compile(r"(?<![\w.@\\])@(\w(?:[\w.\-\\@]*\w)?)")


def canon_value(value: Any) -> str:
    """ONE spelling of a key value: what the database hands back (a timestamp, 1.50, 1.0) and
    what came through the browser's JSON (2026-10-31T00:00:00, 1.5, 1) name the same row.
    The screen's twin is ``canvasCommentary.canonValue``."""
    if value is None:
        return _NULL
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (datetime, date)):
        value = value.isoformat()
    if isinstance(value, (int, float, Decimal)):
        value = str(value)
    text = str(value)
    moment = _MOMENT.match(text)
    if moment:
        frac = (moment.group(3) or "").rstrip("0")
        return f"{moment.group(1)}T{moment.group(2)}" + (f".{frac}" if frac else "")
    if _NUMBER.match(text) or re.match(r"-?\d+(\.\d+)?[eE][-+]?\d+$", text):
        try:
            out = format(Decimal(text).normalize(), "f")
            return "0" if out in ("-0", "") else out
        except InvalidOperation:
            return text
    return text


def clean_for_sheet(value: Any) -> str:
    """A control character pasted into a note must not stop every reader's Excel."""
    from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
    return ILLEGAL_CHARACTERS_RE.sub("", str(value))


def mentions_in(text: Any) -> List[str]:
    """Who ``text`` mentions: ``@name``, a dotted or hyphened name whole, an e-mail
    address not at all."""
    return sorted(set(_MENTION.findall(str(text or ""))))


# ── the anchor ───────────────────────────────────────────────────────────────

def _scalar(value: Any, what: str) -> Any:
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        if len(value) > MAX_VALUE_CHARS:
            raise ValueError(f"{what} is too long to name a number.")
        return value
    raise ValueError(f"{what} must be a single value.")


def clean_anchor(raw: Any) -> Dict[str, Any]:
    """What is stored for an anchor, or ValueError with the reason."""
    if raw is None:
        return {"kind": "instance"}
    if not isinstance(raw, dict):
        raise ValueError("A comment's place must say what it is on.")
    kind = str(raw.get("kind") or "instance")
    if kind not in ANCHOR_KINDS:
        raise ValueError(f"A comment can be on the run, a row, a column or a number, not {kind!r}.")
    out: Dict[str, Any] = {"kind": kind}
    if kind in ("row", "cell"):
        key = raw.get("key")
        if not isinstance(key, dict) or not key:
            raise ValueError("A comment on a row or a number must name the row by its values.")
        if len(key) > MAX_KEY_FIELDS:
            raise ValueError(f"A row is named by at most {MAX_KEY_FIELDS} fields.")
        out["key"] = {str(k): _scalar(v, f"The value of {k}") for k, v in key.items()}
    if kind in ("column", "cell"):
        column = raw.get("column")
        if not isinstance(column, str) or not column.strip():
            raise ValueError("A comment on a column or a number must name the column.")
        out["column"] = _scalar(column, "The column's name")
    for name in ("tile_id", "label"):
        v = raw.get(name)
        if isinstance(v, (str, int)) and str(v).strip():
            out[name] = str(v)[:MAX_VALUE_CHARS]
    return out


def anchor_identity(anchor: Optional[dict]) -> Tuple[str, Tuple[Tuple[str, str], ...], str]:
    """The number a note is about: the kind, the key values and the column."""
    a = anchor if isinstance(anchor, dict) else {}
    key = a.get("key") if isinstance(a.get("key"), dict) else {}
    return (str(a.get("kind") or "instance"),
            tuple(sorted((str(k), canon_value(v)) for k, v in key.items())),
            str(a.get("column") or ""))


def anchor_words(anchor: Optional[dict]) -> str:
    """Plain words for where a note sits."""
    a = anchor if isinstance(anchor, dict) else {}
    if a.get("label"):
        return str(a["label"])
    parts = [str(v) if v is not None else "(no value)" for v in (a.get("key") or {}).values()]
    if a.get("column"):
        parts.append(str(a["column"]))
    return " · ".join(parts) if parts else "the whole run"


def label_for(db, report: Dict[str, Any], anchor: Dict[str, Any]) -> Optional[str]:
    """The words shown as fact in the panel, the PDF and the workbook, built here from the key
    and the column: a client's own label could call FX "EQ"."""
    if anchor.get("kind") == "instance":
        return None
    parts = ["(no value)" if v is None else str(v) for v in (anchor.get("key") or {}).values()]
    if anchor.get("column"):
        words = str(anchor["column"])
        try:
            ds = db.get_dataset_full(report["dataset_id"]) if report.get("dataset_id") else None
            col = next((c for c in (ds or {}).get("columns") or [] if str(c.get("physical_name")) == words), None)
            words = str((col or {}).get("friendly_name") or words)
        except Exception as exc:                             # noqa: BLE001 -- the name will do
            logger.debug("[commentary] column words not read: %s", exc)
        parts.append(words)
    return " · ".join(parts)[:MAX_VALUE_CHARS] or None


# ── where a comment came from ────────────────────────────────────────────────

def clean_origin(db, inst: Dict[str, Any], anchor: Dict[str, Any], raw: Any) -> Optional[Dict[str, Any]]:
    """``None``, a draft, or a carried note the SERVER has checked: same report, same
    scope, same number, another run.  What it records is read from the source row,
    never from the request."""
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise ValueError("A comment's origin must say where it came from.")
    kind = raw.get("kind")
    if kind == "draft":
        return {"kind": "draft", "source": "assistant" if raw.get("source") == "assistant" else "template"}
    if kind != "carried":
        raise ValueError(f"A comment begins as a draft or is carried forward, not {kind!r}.")
    try:
        source_id = int(raw.get("from_comment_id"))
    except (TypeError, ValueError):
        raise ValueError("A carried comment must say which comment it came from.")
    src = db.get_report_instance_comment(source_id)
    if (not src or int(src.get("report_id") or 0) != int(inst["report_id"])
            or str(src.get("rls_signature")) != str(inst.get("rls_signature"))
            or int(src.get("instance_id") or 0) == int(inst["id"])
            or anchor_identity(src.get("anchor")) != anchor_identity(anchor)):
        raise ValueError("That comment cannot be carried to this number.")
    return {"kind": "carried", "from_comment_id": source_id, "from_instance_id": src.get("instance_id"),
            "from_business_date": src.get("business_date"), "from_username": src.get("username")}


def carry_candidate(db, inst: Dict[str, Any], anchor: Optional[dict],
                    business_date: Optional[str] = None) -> Dict[str, Any]:
    """The newest earlier note on this number in this run's scope, or ``found: False``."""
    want = anchor_identity(clean_anchor(anchor))
    best = None
    for c in db.list_report_comments_in_scope(int(inst["report_id"]), str(inst.get("rls_signature"))):
        if c.get("parent_id") or int(c.get("instance_id") or 0) == int(inst["id"]):
            continue
        if anchor_identity(c.get("anchor")) != want:
            continue
        cdate = c.get("business_date")
        if business_date and cdate:
            if str(cdate) >= str(business_date):
                continue
        elif int(c.get("instance_id") or 0) >= int(inst["id"]):
            continue
        rank = (str(cdate or ""), int(c.get("instance_id") or 0), int(c.get("id") or 0))
        if best is None or rank > best[0]:
            best = (rank, c)
    if best is None:
        return {"found": False}
    c = best[1]
    return {"found": True, "comment_id": c.get("id"), "text": c.get("text"), "username": c.get("username"),
            "business_date": c.get("business_date"), "created_at": c.get("created_at"),
            "instance_id": c.get("instance_id")}


# ── who can be told ──────────────────────────────────────────────────────────

def person_context(db, username: str, sessions: Optional[Dict[str, dict]] = None) -> Optional[Dict[str, Any]]:
    """What is known of a person who is not the caller: their last sign-in (role and
    groups as it stored them), else the role an admin mapped.  ``None`` = not known.
    ``sessions``: the sign-ins already read, by lower-case name."""
    try:
        seen = sessions.get(str(username).lower()) if sessions is not None else db.latest_session_user(username)
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("[commentary] sign-ins not read for %s: %s", username, exc)
        seen = None
    if isinstance(seen, dict) and seen.get("username"):
        return seen
    try:
        from core import config as _cfg
        auth = _cfg.auth
        local = (auth.local_users or {}).get(username)
        role = (auth.user_roles or {}).get(str(username).lower())
        if (isinstance(local, dict) and local.get("role")) or role:
            from core.app_roles.principal import acting_principal      # THE one builder (review 3)
            return acting_principal(username, db=db, auth_method="headless")
    except Exception as exc:                                 # noqa: BLE001
        logger.debug("[commentary] role map not read: %s", exc)
    return None


def may_see_note(db, report: Dict[str, Any], inst: Optional[Dict[str, Any]], person: Dict[str, Any]) -> bool:
    """May this person read a note on ``inst`` (or, with None, a report-level note)?
    Fails closed."""
    from core.reports import signoff as so
    from core.reports.authorization import can_view_business_report
    try:
        if not can_view_business_report(report, person, db):
            return False
        if inst is None:
            # a note on the report itself is read by those who may author reports
            from core.tool_entitlement.engine import can
            return bool(can(person, "reports.create"))
        sees_all = so.sees_all_scopes(person)
        return so.scope_visible(inst.get("rls_signature"),
                                None if sees_all else so.caller_scope(db, report, person), sees_all)
    except Exception as exc:                                 # noqa: BLE001
        logger.info("[commentary] access of %s not established: %s", person.get("username"), exc)
        return False


def people_for(db, report: Dict[str, Any], inst: Optional[Dict[str, Any]], query: str, limit: int = 10) -> List[str]:
    """The names offered after an ``@``: people known here who may read the note."""
    q = str(query or "").strip().lower()
    rows = db.list_known_usernames(limit=2000) or []
    names = []
    for r in rows:
        name = r.get("username") if isinstance(r, dict) else r
        if name and (not q or q in str(name).lower()):
            names.append(str(name))
    names.sort(key=lambda n: (not n.lower().startswith(q), n.lower()))
    out: List[str] = []
    names = names[:60]                                       # each one is an access check; typing narrows them
    sessions = db.latest_session_users(names)
    for name in names:
        person = person_context(db, name, sessions)
        if person and may_see_note(db, report, inst, person):
            out.append(name)
            if len(out) >= limit:
                break
    return out


def _send_mail(username: str, subject: str, text: str) -> None:
    """Best effort beside the bell: only where an address can be derived."""
    try:
        from core import config as _cfg
        from core.published_view_schema import _address_for
        address = _address_for(username, _cfg.published_views.notify_email_domain)
        if not address:
            return
    except Exception as exc:                                 # noqa: BLE001
        logger.debug("[commentary] no address for %s: %s", username, exc)
        return

    def _go() -> None:
        try:
            from core import email_service
            if not email_service.send_email([address], subject, f"<p>{html.escape(text)}</p>", text_body=text):
                logger.warning("[commentary] mail to %s not sent: %s", username,
                               email_service.last_send_failure_reason())
        except Exception as exc:                             # noqa: BLE001
            logger.warning("[commentary] mail to %s not sent: %s", username, exc)
    threading.Thread(target=_go, name="commentary-mail", daemon=True).start()


def tell_mentioned(db, report: Dict[str, Any], inst: Optional[Dict[str, Any]], comment: Dict[str, Any],
                   author: Optional[dict], names: Optional[Sequence[str]] = None) -> Dict[str, List[str]]:
    """Tell each mentioned person; say who was not told and why.  Never raises: the
    comment is already saved."""
    out: Dict[str, List[str]] = {"told": [], "cannot_see": [], "not_known": [], "not_told": []}
    who = str((author or {}).get("username") or "")
    wanted = names if names is not None else (comment.get("mentions") or [])
    title = f"{who} mentioned you on {report.get('name') or 'a report'}"
    text = f"{who} mentioned you in a comment on the report {report.get('name') or ''}. Open it to read the comment."
    for name in wanted:
        if not name or str(name) == who:
            continue
        person = person_context(db, str(name))
        if not person:
            out["not_known"].append(str(name))
            continue
        if not may_see_note(db, report, inst, person):
            out["cannot_see"].append(str(name))
            continue
        try:
            db.log_notification(
                event_type="report_comment_mention", channel="websocket", recipient=str(person["username"]),
                status="sent", title=title[:300], message=text,
                # the link only: no note text (see the module docstring)
                payload={"report_id": report.get("id"), "instance_id": (inst or {}).get("id"),
                         "comment_id": comment.get("id"),
                         "link": note_link(report, (inst or {}).get("id"), comment.get("id"))})
            out["told"].append(str(name))
        except Exception as exc:                             # noqa: BLE001
            logger.warning("[commentary] notice to %s not written: %s", name, exc)
            out["not_told"].append(str(name))
            continue
        _send_mail(str(person["username"]), title, text)
    return out


def note_link(report: Dict[str, Any], instance_id: Any, comment_id: Any) -> str:
    """Where a notice points: the report, with the note named."""
    base = f"/finance-reports/{report.get('slug') or report.get('id')}"
    return f"{base}?note={comment_id}" + (f"&note_run={instance_id}" if instance_id else "")


# ── the report's settings ────────────────────────────────────────────────────

def settings_of(report: Optional[dict]) -> Optional[Dict[str, Any]]:
    """The report's Needs-explaining settings, or None when it has none."""
    layout = (report or {}).get("layout_config")
    raw = layout.get(SETTING) if isinstance(layout, dict) else None
    if not isinstance(raw, dict) or raw.get("measure_column_id") is None:
        return None
    return raw


_NUMERIC_WORDS = ("number", "numeric", "int", "decimal", "double", "float", "real", "bigint", "money")
_ADDITIVE = ("", "sum", "count")


def settings_problems(raw: Any, columns: Sequence[dict]) -> List[str]:
    """Why these settings cannot be saved, in words.  ``columns``: the REPORT's own columns.
    A setting that would pass silently (a text column adds up to nothing, so nothing is ever
    over the limit) or refuse forever is refused here."""
    if not isinstance(raw, dict):
        return ["Say which number to watch, what to split it by and the limit."]
    out: List[str] = []
    by_id = {int(c["id"]): c for c in columns if c.get("id") is not None}
    measure = by_id.get(raw.get("measure_column_id")) if isinstance(raw.get("measure_column_id"), int) else None
    if measure is None:
        out.append("Choose the number to watch from this report's columns.")
    else:
        kind = f"{measure.get('data_type') or ''} {measure.get('column_type') or ''}".lower()
        if "measure" not in kind and "kpi" not in kind and not any(w in kind for w in _NUMERIC_WORDS):
            out.append(f"{measure.get('friendly_name') or measure.get('physical_name')} is not a number, so it cannot be watched.")
        elif str(measure.get("aggregation") or "").lower() not in _ADDITIVE:
            out.append(f"{measure.get('friendly_name') or measure.get('physical_name')} does not add up "
                       f"({measure.get('aggregation')}), so a movement in its parts means nothing. Choose one that adds up.")
    dims = raw.get("dimensions")
    if not isinstance(dims, list) or not dims or any(d not in by_id for d in dims):
        out.append("Choose at least one field to split the movements by.")
    elif len(set(dims)) != len(dims) or raw.get("measure_column_id") in dims:
        out.append("Each field to split by must be different from the others and from the number.")
    amount, pct = raw.get("limit_amount"), raw.get("limit_percent")
    for v, words in ((amount, "The amount"), (pct, "The percentage")):
        if v is not None and (isinstance(v, bool) or not isinstance(v, (int, float)) or v < 0):
            out.append(f"{words} must be a number that is not negative.")
    if amount is None and pct is None:
        out.append("Set a limit: an amount, a percentage or both.")
    if raw.get("at_signoff", "warn") not in ("warn", "block"):
        out.append("At sign-off, a report either warns or refuses.")
    return out


# ── the run's numbers ────────────────────────────────────────────────────────

class _Run:
    """What every worked-out answer needs about one run, read once."""

    def __init__(self, db, report: Dict[str, Any], inst: Dict[str, Any], user: dict):
        from core.report_framework import ports as _rf_ports
        _derive_artifact_grain = _rf_ports.host().derive_artifact_grain
        from core.reports.canvas_compare import compare_setting
        from core.reports.contract import require_artifact
        from core.reports.insight_story import run_context
        if not report.get("dataset_id"):
            raise _Refused("This works out numbers for a report built on a dataset; this report runs its own SQL.")
        try:
            self.artifact = require_artifact(str(inst.get("execution_id")), inst.get("artifact_path"))
        except Exception:                                    # noqa: BLE001
            raise _Refused("This run's result is no longer kept, so its numbers cannot be read.")
        ds = db.get_dataset_full(report["dataset_id"]) or {}
        self.columns: List[dict] = list(ds.get("columns") or [])
        self.by_id = {int(c["id"]): c for c in self.columns if c.get("id") is not None}
        self.by_name = {str(c.get("physical_name")): c for c in self.columns}
        self.grain, self.group_columns = _derive_artifact_grain(db, report)
        self.previous = lambda: earlier_run(db, report, inst, user)
        cmp_ = compare_setting(report, db.list_report_parameters(int(report["id"])) or [],
                               run_context(db, report, str(inst.get("execution_id"))))
        self.compare = ({"basis": "auto", "column_id": cmp_["column_id"], "a": cmp_["a"], "b": cmp_["b"]}
                        if isinstance(cmp_, dict) and not cmp_.get("error") and cmp_.get("column_id") else {"basis": "auto"})

    def changes(self, measure: Dict[str, Any], dimensions: List[int], *, slicers: Optional[dict] = None,
                top_n: Optional[int] = 5) -> Dict[str, Any]:
        from core import config as _cfg
        from core.reports.canvas_insights import measure_changes
        return measure_changes(self.artifact, measure=measure, dimensions=dimensions, columns=self.columns,
                               compare=self.compare, slicers=slicers, grain=self.grain,
                               group_columns=self.group_columns, previous=self.previous, top_n=top_n,
                               threads=_cfg.business_reports.microcube_threads,
                               memory_limit=_cfg.business_reports.microcube_memory_limit)


class _Refused(Exception):
    """A reason, in plain words, why this cannot be worked out."""


def earlier_run(db, report: Dict[str, Any], inst: Dict[str, Any], user: dict) -> Dict[str, Any]:
    """The run this one is compared with, for a comment or a sign-off.

    NOT simply the newest earlier run (2026-11-07, the review): pressing Run again would compare a
    run with its own copy, every change 0, and CLEAR a report set to Block; someone's run for another
    desk would become the base.  So: the same values asked for except an earlier date, the latest
    such date; with no date asked for, the same values on another day or another source snapshot.
    The scope: the run's own, which the caller's must equal unless they see every scope (a run's
    scope was already checked for them; a person whose access narrowed gets the reason)."""
    from core.reports.authorization import can_view_business_report
    from core.reports.canvas_insights import _INSTANCE_LOOKBACK, _order_key, _when
    from core.reports.contract import require_artifact
    from core.reports import insights as ins
    from core.reports.insight_story import run_context
    from core.reports.signoff import caller_scope, sees_all_scopes
    if not user or not can_view_business_report(report, user, db):
        raise ins.InsightRefused("You may not view this report, so no earlier run of it is opened.")
    signature = str(inst.get("rls_signature"))
    if not sees_all_scopes(user):
        live = caller_scope(db, report, user)
        if not live:
            raise ins.InsightRefused("Your access to rows could not be checked, so no earlier run is opened.")
        if str(live) != signature:
            raise ins.InsightRefused("Your access to rows has changed since this run, so it is not compared with an "
                                     "earlier one. Run the report again.")
    params = db.list_report_parameters(int(report["id"])) or []
    date_names = [str(p.get("name")) for p in params if isinstance(p, dict) and p.get("parameter_type") == "date"]
    mine = run_context(db, report, str(inst.get("execution_id")))
    mine_date = next((str(mine[n])[:10] for n in date_names if mine.get(n)), None)
    mine_rest = {k: v for k, v in mine.items() if k not in date_names}
    found = []
    for r in db.list_report_instances(int(report["id"]), _INSTANCE_LOOKBACK) or []:
        if (r.get("id") == inst.get("id") or str(r.get("execution_id")) == str(inst.get("execution_id"))
                or str(r.get("rls_signature")) != signature or r.get("status") == "expired"
                or _order_key(r) >= _order_key(inst)):
            continue
        run_date = None
        if str(r.get("params_fingerprint")) == str(inst.get("params_fingerprint")):
            if date_names:
                continue                                     # the same date asked for again: a copy of this run
            same_source = str(r.get("source_version") or "") == str(inst.get("source_version") or "")
            same_day = str(r.get("created_at") or "")[:10] == str(inst.get("created_at") or "")[:10]
            if same_source and (r.get("source_version") or same_day):
                continue                                     # nothing could have moved
        else:
            theirs = run_context(db, report, str(r.get("execution_id")))
            run_date = next((str(theirs[n])[:10] for n in date_names if theirs.get(n)), None)
            if not date_names or not mine_date or not run_date or run_date >= mine_date:
                continue
            if {k: v for k, v in theirs.items() if k not in date_names} != mine_rest:
                continue                                     # another desk: its numbers are not this one's past
        found.append((run_date or "", _order_key(r), r))
    for run_date, _key, r in sorted(found, key=lambda x: (x[0], x[1]), reverse=True):
        try:
            path = require_artifact(str(r.get("execution_id")), r.get("artifact_path"))
        except Exception:                                    # noqa: BLE001 -- its file is gone: try older
            continue
        return {"artifact": str(path), "execution_id": r.get("execution_id"), "created_at": r.get("created_at"),
                "same_values": str(r.get("params_fingerprint")) == str(inst.get("params_fingerprint")),
                "definition_changed": str(r.get("semantic_version")) != str(inst.get("semantic_version")),
                "a_words": run_date or f"the run of {_when(r.get('created_at'))}"}
    raise ins.InsightRefused("There is no earlier run to compare this one with: the same values for an earlier date, "
                             "with the same access to rows, whose result is still kept. Run the earlier date first.")


def _canvas_tiles(report: Dict[str, Any]) -> List[dict]:
    layout = report.get("layout_config")
    canvas = layout.get("canvas") if isinstance(layout, dict) else None
    tiles = canvas.get("tiles") if isinstance(canvas, dict) else None
    return [t for t in (tiles or []) if isinstance(t, dict)]


def _tile_fields(t: dict, canvas: Optional[dict] = None) -> List[int]:
    if t.get("kind") == "outline":
        from core.reports.canvas_outline import outline_levels
        ids = outline_levels(t, canvas)      # the levels the grid opens through (a drill path)
    else:
        ids = t.get("dimensions")
    return [int(i) for i in (ids or []) if isinstance(i, int)]


def _canvas_of(report: Dict[str, Any]) -> Optional[dict]:
    layout = report.get("layout_config")
    canvas = layout.get("canvas") if isinstance(layout, dict) else None
    return canvas if isinstance(canvas, dict) else None


def _draft_inputs(report: Dict[str, Any], run: _Run, anchor: Dict[str, Any]) -> Tuple[Dict[str, Any], List[int], Dict[str, list]]:
    """(the measure, the fields to split by, the slicers) for this anchor."""
    settings = settings_of(report) or {}
    tiles = _canvas_tiles(report)
    here = next((t for t in tiles if str(t.get("id")) == str(anchor.get("tile_id"))), None)
    slicers = {str(k): [v] for k, v in (anchor.get("key") or {}).items()}
    in_key = set(slicers)
    measure = None
    column = anchor.get("column")
    candidates = ([here] if here else []) + [t for t in tiles if t is not here]
    if column and column in run.by_name:
        cid = int(run.by_name[column]["id"])
        for t in candidates:
            m = next((x for x in t.get("measures") or [] if isinstance(x, dict) and x.get("column_id") == cid), None)
            if m:
                measure = {"column_id": cid, "aggregation": m.get("aggregation") or "sum"}
                break
        measure = measure or {"column_id": cid, "aggregation": run.by_name[column].get("aggregation") or "sum"}
    elif settings.get("measure_column_id") is not None:
        measure = {"column_id": int(settings["measure_column_id"]), "aggregation": settings.get("aggregation") or "sum"}
    else:
        for t in candidates:
            m = next((x for x in t.get("measures") or [] if isinstance(x, dict) and x.get("column_id") is not None), None)
            if m:
                measure = {"column_id": int(m["column_id"]), "aggregation": m.get("aggregation") or "sum"}
                break
    if not measure or measure["column_id"] not in run.by_id:
        raise _Refused("There is no number to describe here. Choose a number on the report and try again.")

    def usable(cid: int) -> bool:
        c = run.by_id.get(cid)
        return bool(c) and str(c.get("physical_name")) not in in_key

    # the next level down from this number, else the report's choice, else any field a tile splits by
    split = [i for t in ([here] if here else []) for i in _tile_fields(t, _canvas_of(report)) if usable(i)][:1]
    if not split:
        split = [int(i) for i in (settings.get("dimensions") or []) if isinstance(i, int) and usable(i)][:1]
    if not split:
        split = [i for t in tiles for i in _tile_fields(t, _canvas_of(report)) if usable(i)][:1]
    if not split:
        # one row, named by its own key: the change has no parts, the total is still right
        split = [int(run.by_name[k]["id"]) for k in slicers if k in run.by_name][:1]
    if not split:
        raise _Refused("This report has no field to split the change by, so there is nothing to compare yet.")
    return measure, split, slicers


def _draft_sentence(anchor: Dict[str, Any], result: Dict[str, Any], run: _Run) -> str:
    from core.reports.canvas_insights import _num, _signed, _value_words
    total, basis = result["total"], result["basis"]
    measure = result["measure_words"]
    # the row's values only: the measure is said once, by its own words
    subject = " · ".join("(no value)" if v is None else str(v) for v in (anchor.get("key") or {}).values())
    head = f"{subject}: {measure}" if subject else measure
    change: Decimal = total["change"]
    if change == 0:
        return f"{head} did not change against {basis['a_words']}: {_num(total['b'])}."
    sentence = f"{head} {'up' if change > 0 else 'down'} {_num(abs(change))} against {basis['a_words']}"
    members = [m for m in result["members"] if m["change"] != 0]
    if len(result["members"]) > 1 and members:
        top = members[0]
        sentence += f", mostly {result['field_words']} {_value_words(top['values'][0])} ({_signed(top['change'])})"
    return sentence + "."


def draft_for(db, report: Dict[str, Any], inst: Dict[str, Any], user: dict, anchor: Optional[dict]) -> Dict[str, Any]:
    """``{text, source, reason, grounded}``, or ``{refused: reason}``.  Posts nothing."""
    from core.json_utils import sanitize_for_json
    from core.reports import insight_story as story
    from core.reports import insights as ins
    from core.reports import microcube as mc
    clean = clean_anchor(anchor)
    try:
        run = _Run(db, report, inst, user)
        measure, split, slicers = _draft_inputs(report, run, clean)
        res = run.changes(measure, split, slicers=slicers or None)
    except _Refused as exc:
        return {"refused": str(exc)}
    except ins.InsightRefused as exc:
        return {"refused": str(exc)}
    except mc.NonAdditiveMeasureError as exc:
        return {"refused": str(exc)}
    except Exception as exc:                                 # noqa: BLE001 -- said in words; the detail stays in the log
        logger.warning("[commentary] draft not worked out for report %s: %s", report.get("id"), exc)
        return {"refused": "The numbers for this draft could not be read. Write the comment yourself, or try again."}
    template = _draft_sentence(clean, res, run)
    settings = story.settings_of(report.get("layout_config"))
    payload = sanitize_for_json({"on": anchor_words(clean), "measure": res["measure_words"], "total": res["total"],
                                 "members": res["members"], "against": res["basis"]["a_words"]})
    out = story.story_for(payload, template, settings, basis_words=res["basis"].get("words"),
                          allow_assistant=True, principal=str(user.get("username") or ""),
                          report_id=int(report.get("id") or 0))
    return {"text": out["text"], "source": out["source"], "reason": out.get("reason"),
            "grounded": out.get("grounded", True), "template": template, "basis": res["basis"].get("words")}


# ── needs explaining ─────────────────────────────────────────────────────────

def _over_limit(a: Decimal, change: Decimal, amount: Any, percent: Any) -> bool:
    if change == 0:
        return False                        # nothing moved, whatever the limit
    if amount is not None and abs(change) >= Decimal(str(amount)):
        return True
    if percent is not None:
        if a == 0:
            return change != 0              # from nothing: no percentage is small enough
        if abs(change) / abs(a) * 100 >= Decimal(str(percent)):
            return True
    return False


def _limit_words(settings: Dict[str, Any]) -> str:
    parts = []
    if settings.get("limit_amount") is not None:
        parts.append(f"{settings['limit_amount']:,}")
    if settings.get("limit_percent") is not None:
        parts.append(f"{settings['limit_percent']}%")
    return " or ".join(parts)


def needs_explaining(db, report: Dict[str, Any], inst: Dict[str, Any], user: dict) -> Dict[str, Any]:
    """``status``: ``off`` | ``ok`` | ``no_comparison`` (a reason) | ``unknown`` (a reason).
    ``ok`` lists every movement over the limit, each with the comments on it."""
    from core.reports import insights as ins
    from core.reports import microcube as mc
    settings = settings_of(report)
    if not settings:
        return {"status": "off", "items": [], "unexplained": 0, "total": 0}
    mode = settings.get("at_signoff") if settings.get("at_signoff") in ("warn", "block") else "warn"
    base = {"mode": mode, "settings": settings, "items": [], "unexplained": 0, "total": 0,
            "limit_words": _limit_words(settings)}
    try:
        run = _Run(db, report, inst, user)
        dims = [int(i) for i in settings.get("dimensions") or []]
        measure = {"column_id": int(settings["measure_column_id"]), "aggregation": settings.get("aggregation") or "sum"}
        res = run.changes(measure, dims, top_n=SCAN_LIMIT)
    except ins.InsightRefused as exc:
        return {**base, "status": "no_comparison", "reason": str(exc)}
    except _Refused as exc:
        return {**base, "status": "unknown", "reason": str(exc)}
    except mc.NonAdditiveMeasureError as exc:
        return {**base, "status": "unknown", "reason": str(exc)}
    except Exception as exc:                                 # noqa: BLE001 -- unknown, never a clean list
        logger.warning("[commentary] movements of report %s not worked out: %s", report.get("id"), exc)
        return {**base, "status": "unknown", "reason": "The movements could not be worked out from this run."}
    # past the scan limit: the list is largest first, so an amount limit is still decided unless the
    # last one read is itself over it; a percentage cannot be (a small change on a small number)
    if res["rest"]["count"] > 0 and (settings.get("limit_percent") is not None or not res["members"] or _over_limit(
            res["members"][-1]["a"], res["members"][-1]["change"], settings.get("limit_amount"), None)):
        return {**base, "status": "unknown",
                "reason": f"This field splits the report into more than {SCAN_LIMIT:,} parts, too many to check. "
                          f"Choose a field with fewer values."}
    try:
        comments = db.list_report_instance_comments(int(inst["id"]))
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("[commentary] comments of instance %s not read: %s", inst.get("id"), exc)
        return {**base, "status": "unknown", "reason": "The comments on this run could not be read."}
    names = [str(run.by_id[i]["physical_name"]) for i in dims]
    measure_name = str(run.by_id[measure["column_id"]]["physical_name"])
    # by the number they are on, once (a report can have many movements and many notes)
    noted: Dict[Tuple, List[Any]] = {}
    for c in comments:
        if c.get("parent_id"):
            continue
        _kind, key_id, column = anchor_identity(c.get("anchor"))
        if column in ("", measure_name):
            noted.setdefault(key_id, []).append(c["id"])
    items: List[Dict[str, Any]] = []
    for m in res["members"]:
        if not _over_limit(m["a"], m["change"], settings.get("limit_amount"), settings.get("limit_percent")):
            continue
        key = dict(zip(names, m["values"]))
        want = tuple(sorted((k, canon_value(v)) for k, v in key.items()))
        words = " · ".join("(no value)" if v is None else str(v) for v in m["values"])
        items.append({"key": key, "column": measure_name, "label": words, "a": m["a"], "b": m["b"],
                      "change": m["change"], "comment_ids": noted.get(want, [])})
    # what still needs a comment comes first, and is what the list keeps: nothing that blocks a
    # sign-off may be out of reach
    items.sort(key=lambda x: (bool(x["comment_ids"]), -abs(x["change"])))
    unexplained = sum(1 for i in items if not i["comment_ids"])
    basis = res["basis"]
    return {**base, "status": "ok", "items": items[:MAX_LIST], "total": len(items), "unexplained": unexplained,
            "unexplained_labels": [i["label"] for i in items if not i["comment_ids"]][:20],
            "measure_words": res["measure_words"], "against": basis["a_words"], "basis": basis.get("words"),
            "compared_with": basis.get("previous_execution_id") or {"a": basis.get("a"), "b": basis.get("b")}}


def sign_gate(db, report: Dict[str, Any], inst: Dict[str, Any], user: dict, *, accepted: bool) -> Optional[Dict[str, Any]]:
    """Asked before a sign-off.  ``None`` = the report watches nothing.  Otherwise
    ``{"overrode", "checked"}``: what was overridden (or None), and what the check was, recorded on
    every sign-off (the limit in force and the run compared with: a limit can change afterwards).
    A refusal raises ``SignoffRefused``."""
    from core.json_utils import sanitize_for_json
    from core.reports.signoff import SignoffRefused
    state = needs_explaining(db, report, inst, user)
    status = state["status"]
    if status == "off":
        return None
    mode = state.get("mode", "warn")
    checked = sanitize_for_json({"settings": state.get("settings"), "status": status, "total": state.get("total", 0),
                                 "unexplained": state.get("unexplained", 0), "against": state.get("against"),
                                 "compared_with": state.get("compared_with"), "reason": state.get("reason")})
    if status == "ok" and not state["unexplained"]:
        return {"overrode": None, "checked": checked}
    if status == "ok":
        words = f"{state['unexplained']} movement(s) over {state['limit_words']} have no comment."
    else:
        words = f"The movements to explain could not be checked: {state.get('reason')}"
    if mode == "block":
        raise SignoffRefused(f"This run cannot be signed yet. {words}", 409)
    if not accepted:
        raise SignoffRefused(f"{words} Sign anyway?", 409)
    return {"overrode": {"mode": mode, "status": status, "count": state.get("unexplained", 0), "words": words,
                         "items": state.get("unexplained_labels", [])},
            "checked": checked}


# ── the exports ──────────────────────────────────────────────────────────────

def export_notes(db, report: Dict[str, Any], user: Optional[dict], *, instance_id: Optional[int] = None,
                 params: Optional[dict] = None) -> Optional[Dict[str, Any]]:
    """What a PDF or a workbook says about this run, under the reader's own scope.
    ``None`` = nothing to say (no signed-in person, no kept run, no comments).
    ``status: "unknown"`` = they could not be read, and the file says so: an export
    with no section must mean there were none."""
    if not user:
        return None
    from core.reports import signoff as so
    try:
        sees_all = so.sees_all_scopes(user)
        live = so.caller_scope(db, report, user)
        if instance_id is None and not sees_all and not live:
            raise ValueError("the reader's scope could not be worked out")   # not the same as "no run"
        inst = so.resolve_current_instance(db, report, user, instance_id=instance_id, params=params or {})
        if not inst:
            return None
        rows = so.visible_comments(db, report, inst, user)
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("[commentary] notes for the export of report %s not read: %s", report.get("id"), exc)
        return {"status": "unknown", "items": [],
                "reason": "The comments on this run could not be read for this file."}
    if not rows:
        return None
    replies: Dict[Any, List[dict]] = {}
    for c in rows:
        if c.get("parent_id"):
            replies.setdefault(c["parent_id"], []).append(c)
    items = []
    for c in rows:
        if c.get("parent_id"):
            continue
        items.append({"n": len(items) + 1, "on": anchor_words(c.get("anchor")), "anchor": c.get("anchor") or {},
                      "text": c.get("text"), "username": c.get("username"), "business_date": c.get("business_date"),
                      "created_at": c.get("created_at"), "resolved": bool(c.get("is_resolved")),
                      "replies": [{"username": r.get("username"), "text": r.get("text")} for r in replies.get(c["id"], [])]})
    # someone who sees every scope, exporting another scope's run: the file must not be shared with
    # those who hold the exporter's scope (business_reports_api._share_stamp)
    return {"status": "ok", "items": items, "foreign_scope": str(inst.get("rls_signature")) != str(live)}


def mark_tables(tables: Sequence[dict], notes: Optional[Dict[str, Any]]) -> None:
    """Put each note's number on the number it is about: on the cell where a table has
    that row, else beside its own tile's title.  Every note is in the section anyway."""
    if not notes or notes.get("status") != "ok":
        return
    for item in notes["items"]:
        anchor = item["anchor"]
        if anchor.get("kind") == "instance":
            continue
        want = dict(anchor.get("key") or {})
        placed = False
        for t in tables:
            fields = t.get("note_fields") or []
            if not fields or set(fields) != set(want):
                continue
            positions = [fields.index(k) for k in want]
            names = list(want)
            for ri, row in enumerate(t.get("rows") or []):
                if all(canon_value(row[p]) == canon_value(want[names[k]]) for k, p in enumerate(positions)):
                    cols = t.get("note_cols") or []
                    column = anchor.get("column")
                    if column and column not in cols:
                        break                   # this table does not show that number
                    ci = cols.index(column) if column else 0
                    t.setdefault("note_marks", {}).setdefault(f"{ri},{ci}", []).append(
                        {"n": item["n"], "username": item["username"], "text": item["text"]})
                    placed = True
                    break
        if not placed:
            for t in tables:
                if anchor.get("tile_id") is not None and str(t.get("tile_id")) == str(anchor.get("tile_id")):
                    t["title"] = f"{t.get('title') or ''} [{item['n']}]".strip()


def _item_words(item: Dict[str, Any]) -> str:
    when = item.get("business_date") or str(item.get("created_at") or "")[:10]
    return f"{item.get('username')}{f' for {when}' if when else ''}{' (resolved)' if item.get('resolved') else ''}"


NOTES_CSS = ("\n.cv-notes-head { font-size: 11pt; font-weight: bold; margin: 10pt 0 4pt; page-break-before: always; }"
             "\n.cv-notes { width: 100%; border-collapse: collapse; font-size: 8pt; }"
             "\n.cv-notes td { border: 0.5pt solid #BBBBBB; padding: 2pt 4pt; vertical-align: top; }"
             "\n.cv-notes .n { width: 18pt; font-weight: bold; }"
             "\n.cv-notes .on { width: 120pt; color: #444444; }"
             "\n.cv-notes .by { color: #666666; }"
             "\n.cv-mark { color: #B45309; font-size: 6pt; font-weight: bold; }")


def notes_pdf_html(notes: Optional[Dict[str, Any]]) -> str:
    """The Commentary section of a PDF; text escaped."""
    import html
    if not notes:
        return ""
    if notes.get("status") != "ok":
        return (f'<div class="cv-notes-head">Commentary</div>'
                f'<div class="cv-note">{html.escape(str(notes.get("reason") or ""))}</div>')
    rows = []
    for i in notes["items"]:
        said = "".join(f'<div class="by">{html.escape(str(r["username"]))}: {html.escape(str(r["text"]))}</div>'
                       for r in i["replies"])
        rows.append(f'<tr><td class="n">{i["n"]}</td><td class="on">{html.escape(i["on"])}</td>'
                    f'<td>{html.escape(str(i["text"]))}<div class="by">{html.escape(_item_words(i))}</div>{said}</td></tr>')
    return f'<div class="cv-notes-head">Commentary</div><table class="cv-notes"><tbody>{"".join(rows)}</tbody></table>'


def add_notes_sheet(wb: Any, notes: Optional[Dict[str, Any]], safe: Any) -> None:
    """The Commentary sheet of a workbook (write-only or not); cell text through the
    export's own ``safe`` (a note that starts with = is text, not a formula)."""
    if not notes:
        return
    ws = wb.create_sheet(title="Commentary")

    def text(v: Any) -> Any:
        return safe(clean_for_sheet(v))
    if notes.get("status") != "ok":
        ws.append([text(notes.get("reason") or "")])
        return
    ws.append(["#", "On", "Comment", "By", "For", "Resolved"])
    for i in notes["items"]:
        when = i.get("business_date") or str(i.get("created_at") or "")[:10]
        ws.append([i["n"], text(i["on"]), text(i["text"]), text(i["username"]), text(when),
                   "Yes" if i["resolved"] else "No"])
        for r in i["replies"]:
            ws.append([None, None, text(r["text"]), text(r["username"]), None, None])
