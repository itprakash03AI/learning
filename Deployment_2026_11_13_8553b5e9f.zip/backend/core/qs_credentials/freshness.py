"""qs_credentials.freshness -- a System Account's credential is FRESH on
every pod, or the source says why it is not.  ONE chokepoint (2026-10-30).

The owner on UAT (api pods + a reports pod + a published-api pod + the
Spark lane): "it worked but it has syncing problem ... it tries with old
pwd ... after 20-30 mins worked".  Four things made that true, and each is
answered here, in one place, so no road can answer differently:

1. ``QSCredCache.invalidate(name)`` dropped the MEMORY entry only.  The
   24-hour DISK entry then answered the very next resolve with the SAME old
   password (``resolve_system_account`` reads disk before Vault), so even
   the admin "refresh" route re-filled memory with the stale secret.  Now a
   forgotten account is DISTRUSTED: memory and disk are skipped and Vault is
   asked (:func:`forget`; the resolver consults :func:`is_distrusted`).
2. The resolver's stale / last-known-good fallback is for Vault being DOWN.
   It must never answer an AUTH failure -- the stale value IS the wrong
   password.  A distrusted name is fetched strictly: Vault answers, or the
   resolve fails with the reason (``resolver._fetch_strict``).
3. The SQL connector pool is keyed on the STORED config (which does not
   change when Vault rotates), so an idle connector built with the old
   password was handed out again.  :func:`forget` closes every idle pooled
   connector whose config names the account, and a connector that meets an
   auth failure is healed IN PLACE and retried once
   (``core/connectors/__init__.py::_wrap_with_credential_freshness``).
4. Each pod cached on its own; editing the account in the admin UI touched
   no cache at all.  Now an edit / delete / refresh ANNOUNCES on the fleet
   coherence bus (``core/cache_coherence.py``, namespace
   ``system_accounts``) and every pod :func:`observe` s it (throttled, one
   PK SELECT per ``cache.coherence_poll_seconds``) on its next resolve or
   pool access: the peer drops its cached credentials and the pooled
   connectors built from them.  A connection edit already bumps
   ``connections``; the pool honours that one too.

What counts as an AUTH failure is DECLARED (:func:`is_auth_failure`): the
source rejected the LOGIN -- Trino/Starburst HTTP 401, Oracle ORA-01017,
Snowflake "incorrect username or password", Databricks' invalid token, S3
InvalidAccessKeyId / SignatureDoesNotMatch / ExpiredToken, SFTP and Kafka
SASL authentication failures.  A statement the source refused (syntax, a
missing table, a right the caller lacks -- HTTP 403, "access denied") is
NOT one: retry safety is a declaration, and only the CONNECT is retried --
an auth refusal happens before any statement is accepted, so the retry
never runs a statement twice.

Every refresh says which pod refreshed which account and why.  Never the
secret.
"""
from __future__ import annotations

import logging
import os
import socket
import threading
from typing import Any, Callable, Dict, Optional, Set, Tuple

logger = logging.getLogger(__name__)

#: The fleet coherence namespace a System Account change is announced on.
EPOCH_NAMESPACE = "system_accounts"
#: The namespace a CONNECTION edit is announced on (connection_manager bumps
#: it); the pool honours it so a peer's SQL connectors built from the old
#: config are not reused.
CONNECTIONS_NAMESPACE = "connections"

#: Keys a connection / destination config may name its System Account under
#: (the same three ``apply_system_account`` and ``credential_resolver`` read).
ACCOUNT_REF_KEYS = ("system_account_id", "system_account_name", "system_account")


def account_ref(config: Optional[Dict[str, Any]]) -> Any:
    """The System Account a config names (id or name), or None."""
    if not isinstance(config, dict):
        return None
    for key in ACCOUNT_REF_KEYS:
        value = config.get(key)
        if value not in (None, "", 0):
            return value
    return None


def pod_name() -> str:
    """Which pod is speaking -- for the log line, never for a decision."""
    return (os.environ.get("POD_NAME") or os.environ.get("HOSTNAME")
            or socket.gethostname() or "?")[:120]


# ──────────────────────────────────────────────────────────────────────
#  The declared vocabulary of an AUTH failure
# ──────────────────────────────────────────────────────────────────────

#: Exception CLASS names (walked up each class's MRO) that mean the source
#: rejected the login.  Names, not imports: this module must not drag in
#: every driver.
_AUTH_EXC_CLASS_NAMES = frozenset({
    "TrinoAuthError",                       # trino client: HTTP 401
    "AuthenticationException",              # paramiko (SFTP)
    "BadAuthenticationType",                # paramiko: the method is refused
    "AuthenticationFailedError",            # kafka-python SASL
    "SaslAuthenticationFailedError",        # kafka-python SASL
    "IllegalSaslStateError",                # kafka-python SASL
    "NoCredentialsError",                   # botocore: nothing to sign with
    "PartialCredentialsError",
})
#: boto3 ``ClientError`` codes that mean the KEYS were rejected (not that a
#: valid key lacks a right: ``AccessDenied`` is a permission, not a login).
_AUTH_BOTO_CODES = frozenset({
    "InvalidAccessKeyId", "SignatureDoesNotMatch", "ExpiredToken",
    "ExpiredTokenException", "RequestExpired", "InvalidToken",
    "InvalidClientTokenId", "UnrecognizedClientException", "AuthFailure",
    "InvalidSecurity", "InvalidIdentityToken",
})
#: Message tokens (lower-cased ``str(exc)``) that spell a rejected login.
_AUTH_MSG_TOKENS = (
    "error 401", "401 unauthorized", "http 401", "status 401", "401 client error",
    "invalid credentials",                                   # Trino's 401 body
    "ora-01017",                                             # Oracle
    "incorrect username or password",                        # Snowflake 250001/390100
    "invalid access token", "invalid_token", "invalid token", # Databricks
    "invalidaccesskeyid", "signaturedoesnotmatch", "expiredtoken",
    "expired token", "token has expired", "invalidclienttokenid",
    "unrecognizedclientexception",
    "the security token included in the request is invalid",
    "the aws access key id you provided does not exist",
    "authentication failed", "authentication failure",       # paramiko / SASL
    "sasl authentication failed", "login failed", "login denied",
)
#: Oracle's error code for "invalid username/password; logon denied".
_ORACLE_LOGON_DENIED = 1017
#: Snowflake errnos that carry a rejected login (250001 is also "could not
#: connect", so it counts only together with the message token above).
_SNOWFLAKE_AUTH_ERRNOS = frozenset({390100, 390144, 390102})


def is_auth_failure(exc: BaseException) -> Optional[str]:
    """The reason ``exc`` (or anything in its cause chain, bounded) is the
    SOURCE REJECTING THE LOGIN -- or None for every other failure.

    None is the safe answer: an unclassified error is not retried and does
    not drop a credential.  A 403 / "access denied" is a RIGHT the login
    lacks, not a wrong login, and is None here on purpose."""
    seen = 0
    cur: Optional[BaseException] = exc
    while cur is not None and seen < 8:
        seen += 1
        names = {k.__name__ for k in type(cur).__mro__}
        hit = names & _AUTH_EXC_CLASS_NAMES
        if hit:
            return f"{sorted(hit)[0]}: the source rejected the login"
        # boto3 ClientError: the code is in ``response``.
        resp = getattr(cur, "response", None)
        if isinstance(resp, dict):
            code = str(((resp.get("Error") or {}).get("Code")) or "")
            if code in _AUTH_BOTO_CODES:
                return f"S3/AWS rejected the credentials ({code})"
        # oracledb: ``exc.args[0].code``; python-oracledb also puts the text
        # in str(exc), which the token walk below catches.
        err0 = cur.args[0] if getattr(cur, "args", None) else None
        if getattr(err0, "code", None) == _ORACLE_LOGON_DENIED:
            return "Oracle ORA-01017: invalid username/password"
        errno = getattr(cur, "errno", None)
        try:
            if errno is not None and int(errno) in _SNOWFLAKE_AUTH_ERRNOS:
                return f"Snowflake rejected the login (errno {int(errno)})"
        except (TypeError, ValueError):
            pass
        msg = str(cur).lower()
        for tok in _AUTH_MSG_TOKENS:
            if tok in msg:
                return f"the source rejected the login ({tok})"
        nxt = cur.__cause__ if cur.__cause__ is not None else cur.__context__
        cur = nxt if nxt is not cur else None
    return None


# ──────────────────────────────────────────────────────────────────────
#  Local state: distrusted cache names + the fleet epoch seen
# ──────────────────────────────────────────────────────────────────────

_lock = threading.Lock()
#: Cache names (the resolver's key: ``secret_ref`` or the account name)
#: whose memory AND disk entries must not answer until Vault has.
_distrusted: Set[str] = set()
_EPOCH_UNSET = object()
_seen: Dict[str, Any] = {EPOCH_NAMESPACE: _EPOCH_UNSET,
                         CONNECTIONS_NAMESPACE: _EPOCH_UNSET}


def is_distrusted(cache_name: str) -> bool:
    with _lock:
        return cache_name in _distrusted


def trust(cache_name: str) -> None:
    """Vault answered for ``cache_name``: its caches may serve again."""
    with _lock:
        _distrusted.discard(cache_name)


def distrust(cache_name: str) -> None:
    with _lock:
        _distrusted.add(cache_name)


def reset_state() -> None:
    """Test hook -- forget every distrust and every epoch seen."""
    with _lock:
        _distrusted.clear()
        for ns in _seen:
            _seen[ns] = _EPOCH_UNSET
    try:
        r = _resolver()
        r._versions_seen.clear()
        r._asked_vault.clear()
        r._file_seen.clear()
        r._lease_accounts.clear()
    except Exception:                                        # pragma: no cover
        pass


def _on_new_account_secret(lease: Any) -> None:
    """This pod just learned that an account's secret has a NEW version (a
    peer re-read Vault after a rotation).  What was BUILT from the old one is
    dropped here: every pooled SQL connector that logs in with a System
    Account.  The next use logs in with the new secret -- no failed login."""
    # THAT account's connectors only: which account a row belongs to is known
    # on a pod that resolved it (a pod that never did holds no connector built
    # from it).  It used to close every System Account's pools on the pod.
    n = 0
    try:
        from core.connection_pool import invalidate_pools_using_account
        account_id = _resolver()._lease_accounts.get(getattr(lease, "subject", None))
        if account_id is not None:
            n = invalidate_pools_using_account(account_id, _row_for(account_id))
    except Exception as exc:                                 # pragma: no cover
        logger.debug("freshness: pool invalidation failed: %s", exc)
    logger.warning("[credential-freshness] pod %s: %s has a new version (%s) -- %d of ITS "
                   "connector pool(s) closed; the next login uses it",
                   pod_name(), getattr(lease, "label", "") or "an account's secret",
                   getattr(lease, "version", "?"), n)


def _register_lease_hooks() -> None:
    from core.qs_credentials import leases as _leases
    _leases.on_new_version(_leases.KIND_ACCOUNT_SECRET, _on_new_account_secret)


_register_lease_hooks()


def _resolver():
    from core.qs_credentials import resolver
    return resolver


def _bus():
    from core.cache_coherence import get_bus
    return get_bus()


def _row_for(sa_ref: Any) -> Optional[Dict[str, Any]]:
    """The account row (decrypted shape not needed: only its name / secret_ref
    are read).  None when the DB is not wired or the row is gone."""
    try:
        from core.database import get_db_manager
        db = get_db_manager()
    except Exception:
        db = None
    if db is None:
        return None
    try:
        if isinstance(sa_ref, int) or (isinstance(sa_ref, str) and sa_ref.isdigit()):
            return db.get_system_account_raw(int(sa_ref))
        return _resolver()._row_by_name_decrypted(db, str(sa_ref))
    except Exception as exc:
        logger.debug("freshness: account row lookup failed for %r: %s", sa_ref, exc)
        return None


def cache_name_for(sa_ref: Any) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
    """The resolver's cache key for an account reference, and the row.  With
    no DB (a unit harness) a NAME reference is its own key -- ``secret_ref``
    defaults to the name -- and an id reference has no key."""
    row = _row_for(sa_ref)
    if row:
        from core.qs_credentials.resolver import secret_cache_key
        key = secret_cache_key(row)
        return (str(key) if key else None), row
    if isinstance(sa_ref, str) and not sa_ref.isdigit():
        return sa_ref, None
    return None, None


def _label(sa_ref: Any, row: Optional[Dict[str, Any]]) -> str:
    if row:
        return f"System Account {row.get('id')!r} ({row.get('name')!r})"
    return f"System Account {sa_ref!r}"


#: S3 saying "these temporary keys have ENDED" (not: the keys are wrong, not:
#: you lack a right).  Declared, like the auth vocabulary above.
_KEYS_ENDED_TOKENS = (
    "expiredtoken", "expired token", "token has expired", "requestexpired",
    "the provided token has expired", "invalidtoken",
    "the security token included in the request is expired",
    "the security token included in the request is invalid",
)


def keys_have_ended(exc_or_text: Any) -> bool:
    """Did S3 refuse the request because the temporary keys ENDED?  The
    remedy is their owner's (new keys on the next use), so this failure is
    never the CONNECTION's: it does not count towards a circuit breaker."""
    seen, cur = 0, exc_or_text
    while cur is not None and seen < 6:
        text = str(cur).lower()
        if any(tok in text for tok in _KEYS_ENDED_TOKENS):
            return True
        code = None
        try:
            code = ((getattr(cur, "response", None) or {}).get("Error") or {}).get("Code")
        except Exception:                                    # noqa: BLE001
            code = None
        if code in ("ExpiredToken", "ExpiredTokenException", "RequestExpired", "InvalidToken"):
            return True
        if not isinstance(cur, BaseException):
            break
        cur, seen = (cur.__cause__ or cur.__context__), seen + 1
    return False


#: S3 saying "I do not know this key" -- what a store that DELETES ended
#: temporary keys answers instead of ExpiredToken (MinIO does; measured on the
#: rig).  For keys that are TEMPORARY the remedy is the same: new keys.
_KEYS_UNKNOWN_TOKENS = (
    "invalidaccesskeyid", "invalid access key id", "invalidclienttokenid",
    "the aws access key id you provided does not exist",
    "the access key id you provided does not exist",
)
#: a refusal with NO reason (a presigned download answered 403): it may be
#: the keys, it may be a right the login lacks
_MAYBE_KEYS_TOKENS = ("http 403", "403 forbidden", "status 403", "error 403")

CERTAIN = "certain"
MAYBE = "maybe"


def temporary_keys_refused(exc_or_text: Any) -> Optional[str]:
    """For keys that are TEMPORARY (portal keys, held in the shared row): did
    S3 refuse them?  ``"certain"`` -- they ended, or S3 does not know them;
    ``"maybe"`` -- a bare 403; ``None`` -- anything else (a missing file, a
    network failure, "access denied" to something the login may not read).
    Never used for static keys: there, an unknown key is a wrong setting."""
    if keys_have_ended(exc_or_text):
        return CERTAIN
    seen, cur, maybe = 0, exc_or_text, False
    while cur is not None and seen < 6:
        text = str(cur).lower()
        if any(tok in text for tok in _KEYS_UNKNOWN_TOKENS):
            return CERTAIN
        try:
            code = ((getattr(cur, "response", None) or {}).get("Error") or {}).get("Code")
        except Exception:                                    # noqa: BLE001
            code = None
        if code in ("InvalidAccessKeyId", "InvalidClientTokenId"):
            return CERTAIN
        if "accessdenied" not in text and "access denied" not in text \
                and any(tok in text for tok in _MAYBE_KEYS_TOKENS):
            maybe = True
        if not isinstance(cur, BaseException):
            break
        cur, seen = (cur.__cause__ or cur.__context__), seen + 1
    return MAYBE if maybe else None


# ──────────────────────────────────────────────────────────────────────
#  forget / announce / observe
# ──────────────────────────────────────────────────────────────────────


def forget(sa_ref: Any, *, reason: str, connection_id: Any = None,
           announce: bool = False) -> Optional[str]:
    """Drop everything THIS pod holds that was built from the account's
    credential, and (``announce``) tell every other pod to do the same.

    * the resolver's memory entry is dropped and the name is DISTRUSTED, so
      the disk entry does not answer either -- the next resolve asks Vault
      and never falls back to a stale value;
    * every idle pooled SQL connector whose config names the account is
      closed (an active one is healed by its own wrapper); with a
      ``connection_id``, that connection's pools and S3 handler too;
    * ``announce`` bumps the ``system_accounts`` epoch (peers drop their
      credential + pools on their next observe) and the ``connections``
      epoch (every pod's S3 handlers built from it expire).

    Returns the epoch token announced (None when not announced / no DB).
    Says which pod did it and why; never the secret."""
    cache_name, row = cache_name_for(sa_ref)
    resolver = _resolver()
    dropped = []
    if cache_name:
        resolver._cred_cache.invalidate(cache_name)
        distrust(cache_name)
        dropped.append("credential cache (memory; disk distrusted)")
    # 2026-11-12 -- the SHARED copy (core/qs_credentials/leases.py) is marked
    # refused: the next use, on ANY pod, re-reads the source once and every
    # pod takes the new version -- no pod has to fail with the old one first.
    try:
        from core.qs_credentials import leases as _leases, lifecycle as _lifecycle
        _name = (resolver.lease_name(row) if row else None) or cache_name
        if _name:
            distrust(_name)
            _subject = _lifecycle.account_subject(_name)
            if _leases.reject(_leases.KIND_ACCOUNT_SECRET, _subject):
                dropped.append("the shared credential row (marked refused)")
            _leases.forget_local(_leases.KIND_ACCOUNT_SECRET, _subject)
        if announce:
            # an administrator acted on THIS account: a login the portal refused
            # with ITS password may be tried again now.  Only its rows -- every
            # other account keeps the five minutes that protect its AD login.
            _account_id = (row or {}).get("id") if row else (sa_ref if str(sa_ref).isdigit() else None)
            _leases.clear_refusals(
                subjects=[_lifecycle.account_subject(_name)] if _name else [],
                label_marks=[f"{_lifecycle.ACCOUNT_MARK}{_account_id}"] if _account_id not in (None, "") else [])
    except Exception as exc:                                 # pragma: no cover
        logger.debug("freshness: shared row not marked: %s", exc)
    try:
        from core.connection_pool import invalidate_pools_using_account, invalidate_pool
        n = invalidate_pools_using_account(sa_ref, row)
        if n:
            dropped.append(f"{n} pooled SQL connector pool(s)")
        if connection_id is not None:
            invalidate_pool(int(connection_id))
            dropped.append(f"connection {connection_id}'s pool")
    except Exception as exc:                                 # pragma: no cover
        logger.debug("freshness: pool invalidation failed: %s", exc)
    if connection_id is not None:
        try:
            from core.connection_manager import get_connection_manager
            cm = get_connection_manager()
            if cm is not None and hasattr(cm, "invalidate_s3_handler"):
                cm.invalidate_s3_handler(int(connection_id),
                                         reason=f"credential forgotten: {reason}",
                                         _forget_account=False)
                dropped.append(f"connection {connection_id}'s S3 handler")
        except Exception as exc:                             # pragma: no cover
            logger.debug("freshness: S3 handler invalidation failed: %s", exc)
    token = None
    if announce:
        try:
            bus = _bus()
            label = row.get("id") if row else sa_ref
            token = bus.bump(EPOCH_NAMESPACE, reason=f"system_account:{label}:{reason}"[:120])
            conn_token = bus.bump(CONNECTIONS_NAMESPACE,
                                  reason=f"system_account:{label}:{reason}"[:120])
            # Self-acknowledge both: this pod dropped the account's state
            # surgically above; its own announcement must not widen that to
            # every pool.  (connection_manager keeps its own view of the
            # connections epoch and still expires this pod's S3 handlers.)
            with _lock:
                if token is not None:
                    _seen[EPOCH_NAMESPACE] = token
                if conn_token is not None:
                    _seen[CONNECTIONS_NAMESPACE] = conn_token
        except Exception as exc:
            logger.warning("freshness: fleet announce failed (peers converge by "
                           "their TTLs): %s", exc)
    logger.warning(
        "[credential-freshness] pod %s forgot %s -- %s; dropped: %s%s",
        pod_name(), _label(sa_ref, row), reason,
        ", ".join(dropped) or "nothing cached here",
        "; announced to every pod" if token else "",
    )
    return token


def forget_all_local(reason: str) -> None:
    """A PEER changed a System Account: distrust every credential this pod
    could serve (memory names + the disk file's names), drop memory, and
    close every pooled connector built from any account."""
    resolver = _resolver()
    cache = resolver._cred_cache
    names: Set[str] = set()
    try:
        with cache._lock:
            names.update(cache._mem.keys())
    except Exception:                                        # pragma: no cover
        pass
    try:
        names.update(cache._disk_read_all().keys())
    except Exception:                                        # pragma: no cover
        pass
    for name in names:
        distrust(name)
    cache.reset_mem()
    n = 0
    try:
        from core.connection_pool import invalidate_pools_using_account
        n = invalidate_pools_using_account(None, None)
    except Exception as exc:                                 # pragma: no cover
        logger.debug("freshness: pool invalidation failed: %s", exc)
    logger.warning(
        "[credential-freshness] pod %s: %s -- %d cached credential(s) will be "
        "re-read from Vault, %d System-Account connector pool(s) closed",
        pod_name(), reason, len(names), n,
    )


def observe() -> bool:
    """Has a PEER pod announced a System Account change (or a connection
    edit) since this pod last looked?  Throttled by the bus (one PK SELECT
    per ``cache.coherence_poll_seconds`` per namespace).  On a change the
    local state is dropped here, once.  Fail-open: no DB / a read error
    leaves everything as it is.  Returns True when something was dropped."""
    try:
        bus = _bus()
        tokens = {ns: bus.current_token(ns) for ns in (EPOCH_NAMESPACE, CONNECTIONS_NAMESPACE)}
    except Exception as exc:
        logger.debug("freshness: epoch read failed (fail-open): %s", exc)
        return False
    changed_accounts = changed_connections = False
    with _lock:
        for ns, token in tokens.items():
            seen = _seen[ns]
            if seen is _EPOCH_UNSET:
                _seen[ns] = token            # baseline: a boot drops nothing
                continue
            if token is not None and token != seen:
                _seen[ns] = token
                if ns == EPOCH_NAMESPACE:
                    changed_accounts = True
                else:
                    changed_connections = True
    if changed_accounts:
        forget_all_local("a peer pod changed a System Account")
    if changed_connections:
        try:
            from core.connection_pool import invalidate_all_pools
            n = invalidate_all_pools()
            logger.info("[credential-freshness] pod %s: a peer pod changed a "
                        "connection -- %d SQL connector pool(s) closed", pod_name(), n)
        except Exception as exc:                             # pragma: no cover
            logger.debug("freshness: pool invalidation failed: %s", exc)
    return changed_accounts or changed_connections


# ──────────────────────────────────────────────────────────────────────
#  retry ONCE on an auth failure -- the one rule every road calls
# ──────────────────────────────────────────────────────────────────────

_SECRET_FIELDS = ("password", "secret_key", "private_key", "token", "access_token",
                  "session_token", "access_key")


def _secret_fingerprint(creds: Optional[Dict[str, Any]]) -> Tuple:
    if not isinstance(creds, dict):
        return ()
    return tuple((k, creds.get(k)) for k in _SECRET_FIELDS if creds.get(k))


def heal(sa_ref: Any, exc: BaseException, *, connection_id: Any = None,
         what: str = "", previous: Optional[Dict[str, Any]] = None,
         ) -> Optional[Dict[str, Any]]:
    """``exc`` came from using the account's credential.  If it is an AUTH
    failure: forget the credential here, re-resolve it strictly from Vault
    and return the fresh creds -- the caller retries ONCE with them.  Returns
    None when ``exc`` is not an auth failure, or when Vault still holds the
    very secret the source just rejected (a retry would only fail the same
    way: the source and Vault disagree, and that is said in the log)."""
    reason = is_auth_failure(exc)
    if reason is None:
        return None
    forget(sa_ref, reason=f"{what or 'login'} failed: {reason}",
           connection_id=connection_id)
    fresh = _resolver().resolve_system_account(sa_ref)
    cache_name, row = cache_name_for(sa_ref)
    if previous is not None and _secret_fingerprint(fresh) == _secret_fingerprint(previous):
        logger.error(
            "[credential-freshness] pod %s: %s -- Vault holds the SAME secret "
            "the source just rejected (%s); not retrying.  The password at the "
            "source and in Vault disagree.", pod_name(), _label(sa_ref, row), reason)
        return None
    logger.warning(
        "[credential-freshness] pod %s refreshed %s from Vault (%s) and retries %s once",
        pod_name(), _label(sa_ref, row), fresh.get("via", "?"), what or "the login")
    return fresh


def with_fresh_credentials(sa_ref: Any, attempt: Callable[[Dict[str, Any]], Any], *,
                           creds: Optional[Dict[str, Any]] = None,
                           connection_id: Any = None, what: str = ""):
    """Run ``attempt(creds)``; on an AUTH failure forget the credential,
    re-resolve from Vault and run it ONCE more with the fresh creds.  Any
    other exception propagates untouched after one attempt.  ``creds`` may
    be passed when the caller already resolved them (no second resolve)."""
    if creds is None:
        creds = _resolver().resolve_system_account(sa_ref)
    try:
        return attempt(creds)
    except Exception as exc:
        fresh = heal(sa_ref, exc, connection_id=connection_id, what=what, previous=creds)
        if fresh is None:
            raise
        return attempt(fresh)


def creds_view(config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """The secret-bearing fields of a RESOLVED connection config, in the
    creds-dict shape ``heal`` compares against Vault's fresh answer."""
    if not isinstance(config, dict):
        return {}
    return {k: config.get(k) for k in _SECRET_FIELDS if config.get(k)}


def with_fresh_config(connection_type: str, stored_config: Dict[str, Any],
                      attempt: Callable[[Dict[str, Any]], Any], *,
                      resolved: Optional[Dict[str, Any]] = None,
                      connection_id: Any = None, what: str = ""):
    """The SQL-config twin of :func:`with_fresh_credentials`: the connection's
    System Account is applied to ``stored_config`` (``apply_system_account``),
    ``attempt(resolved_config)`` runs, and on an AUTH failure the account is
    forgotten, re-applied from Vault and ``attempt`` runs ONCE more.  A
    config that names no account runs once, untouched.  ``resolved`` skips
    the first apply when the caller already holds the resolved config."""
    from core.connectors import apply_system_account
    sa_ref = account_ref(stored_config)
    if resolved is None:
        resolved = apply_system_account(connection_type, stored_config)
    try:
        return attempt(resolved)
    except Exception as exc:
        if sa_ref is None:
            raise
        fresh = heal(sa_ref, exc, connection_id=connection_id,
                     what=what or f"{connection_type} login", previous=creds_view(resolved))
        if fresh is None:
            raise
        return attempt(apply_system_account(connection_type, stored_config))


__all__ = [
    "EPOCH_NAMESPACE", "CONNECTIONS_NAMESPACE", "ACCOUNT_REF_KEYS",
    "account_ref", "is_auth_failure", "is_distrusted", "trust", "distrust",
    "forget", "forget_all_local", "observe", "heal", "with_fresh_credentials",
    "with_fresh_config", "creds_view", "cache_name_for", "pod_name", "reset_state", "keys_have_ended",
    "temporary_keys_refused",
]
