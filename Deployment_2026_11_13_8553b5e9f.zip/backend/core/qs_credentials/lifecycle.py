"""qs_credentials.lifecycle -- ONE owner of every credential's life (2026-11-12).

Each KIND of credential DECLARES how it is obtained, when it ends, how it is
renewed, what counts as its login being refused, and what a background job
(no person) may use.  Every consumer asks this module when it USES the
credential; none keeps a copy of its own for longer than a few seconds.

    kind              obtained from            ends                renewed
    ----------------  -----------------------  ------------------  -------------------------
    portal_keys       the AWS portal login     the keys' own end   before the end, by ONE pod
    account_secret    Vault, or a mounted      never by itself     re-read every 15 min by ONE
                      file (Vault operator)                        pod, and at once when refused
    stored_password   the System Account row   never               when an admin edits the row
    static_keys       the connection row       never               when an admin edits the row
    personal          the person's password,   with the session    by the person (never stored,
                      in ONE pod's memory                          never in the shared row)

Where it lives: ``leases.py`` holds the shared, encrypted row and the
one-renewer rule; ``freshness.py`` holds what an AUTH failure is and what a pod
drops when a credential changes; this module is the kinds and the two shared
ones' renewals.  ``docs/CREDENTIAL_LIFECYCLE_2026_11_12.html`` is the record.
"""
from __future__ import annotations

import hmac as _hmac
import logging
import os
import secrets as _secrets
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

from core.qs_credentials import leases
from core.qs_credentials.leases import (
    CredentialUnavailable, ERROR_REFUSED, ERROR_UNAVAILABLE, KIND_ACCOUNT_SECRET,
    KIND_PORTAL_KEYS, Lease, RenewalFailed, Renewed,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class CredentialKind:
    name: str
    obtained_from: str
    ends: str
    renewed: str
    refused_when: str
    background_job: str
    shared_row: bool


#: THE declaration.  The design page prints this table; a test reads it.
KINDS: Dict[str, CredentialKind] = {k.name: k for k in (
    CredentialKind(
        "portal_keys", "the AWS portal, logged in to with a System Account (or the login saved on the connection)",
        "when the keys themselves end (about an hour; the portal says when)",
        "before the end, by ONE pod: a fifth of the life early, at most 10 minutes",
        "S3 answers ExpiredToken / InvalidToken / InvalidAccessKeyId; the portal answers 401",
        "yes", True),
    CredentialKind(
        "account_secret", "Vault, or a file the Vault operator mounts into the pod",
        "never by itself: it changes when someone rotates it",
        "re-read by ONE pod every secrets.cache_ttl_seconds (15 min), and at once when a source refuses it",
        "the source answers the login with 401 / ORA-01017 / incorrect username or password",
        "yes", True),
    CredentialKind(
        "stored_password", "the System Account row (encrypted in the database)",
        "never", "when an administrator edits the account (every pod is told)",
        "the source refuses the login", "yes", False),
    CredentialKind(
        "static_keys", "the connection row (encrypted in the database)",
        "never", "when an administrator edits the connection (every pod is told)",
        "S3 answers InvalidAccessKeyId / SignatureDoesNotMatch", "yes", False),
    CredentialKind(
        "personal", "the person's own password, typed at login or in the password window",
        "with the person's session; held in ONE pod's memory, never written anywhere",
        "by the person", "the portal answers 401",
        "NO -- a job with no person has no personal password; that is not a failure of the connection", False),
)}

#: keys whose end the portal did not say are renewed this often (AWS's
#: shortest key life is 900 s)
UNKNOWN_LIFE_RENEW_SECONDS = 600.0
#: a refusal that MAY be about the keys does not mark keys younger than this
MAYBE_REFUSED_MIN_AGE_SECONDS = 60.0

#: what a background check says about a connection only a PERSON can log in to
NOT_CHECKED_PERSONAL = ("Not checked: this connection logs in with each person's own password, and a "
                        "background check has no person. It is tested when a person uses it.")


# ──────────────────────────────────────────────────────────────────────
#  portal_keys
# ──────────────────────────────────────────────────────────────────────

def portal_subject(username: str, portal_kwargs: Optional[Dict[str, Any]] = None,
                   account_ref: Any = None) -> Tuple[str, str]:
    """``(subject, label)`` of the AWS keys of one portal login: the login,
    the role, the AWS account, the portal and the Service-First reference --
    ``aws_portal_auth.creds_cache_key``, THE key of portal keys.  Three
    connections on one login and one role share one row.

    The subject is a hash of those PUBLIC parts only.  It is shown (the admin
    page, a health row's id, the config a child process is handed), so it must
    say nothing about the password: a first version mixed a hash of the
    password in, and anyone who could read a subject could have tested
    passwords against it offline.  What binds the keys to the password that
    earned them is the PROOF kept INSIDE the encrypted payload
    (``_password_proof``), compared after the row is decrypted."""
    from core.aws_portal_auth import creds_cache_key
    kw = dict(portal_kwargs or {})
    key = creds_cache_key(f"login:{str(username or '').strip().lower()}", **kw)
    role = kw.get("role_name") or "default role"
    account = kw.get("account_id")
    label = f"AWS keys of {username} / {role}" + (f" / account {account}" if account else "")
    if account_ref not in (None, "", 0):
        label += f"{ACCOUNT_MARK}{account_ref}"
    return leases.subject_of(key), label


#: how a row's label names the System Account whose login earned it (so an
#: action on THAT account finds its rows, and no other account's)
ACCOUNT_MARK = " -- System Account "


def _password_proof(password: str, salt: str) -> str:
    """What is kept (inside the encrypted payload) to know the password a
    caller presents is the one that earned the keys.  Salted per row; never
    stored or shown outside the payload."""
    import hashlib
    return hashlib.sha256(f"{salt}|{password}".encode("utf-8")).hexdigest()


def _holds_the_login(lease: Optional[Lease], password: str) -> bool:
    p = (lease.payload or {}) if lease is not None else {}
    return bool(p.get("proof_salt")) and p.get("proof") == _password_proof(password, str(p.get("proof_salt")))


def _plain_portal_failure(exc: BaseException) -> str:
    try:
        from core.proxy_utils import sanitize_proxy_error
        return sanitize_proxy_error(str(exc))[:600]
    except Exception:                                        # noqa: BLE001
        return str(exc)[:600]


def _portal_refused(exc: BaseException) -> bool:
    """The portal said NO to the username and password (not: it was down)."""
    text = str(exc).lower()
    if "refused this password" in text:
        return True
    return "jwt authentication failed" in text and ("http 401" in text or "http 403" in text)


def _renewed_from(creds: Dict[str, Any], password: str, label: str) -> Renewed:
    import secrets as _secrets
    salt = _secrets.token_hex(8)
    renew_after = None
    if not creds.get("expiration_iso") and creds.get("expires_at"):
        # the portal did NOT say when these keys end: QueryStudio's own
        # figure is a guess.  They are renewed every UNKNOWN_LIFE_RENEW_SECONDS
        # -- shorter than the shortest life AWS gives (15 minutes) -- so a
        # guess that is too long never becomes keys that ended in use.
        # Measured on the rig: keys that really ended after 900 s were used
        # for an hour, and every read failed from minute 15.
        renew_after = time.time() + min(UNKNOWN_LIFE_RENEW_SECONDS,
                                        max(30.0, (float(creds["expires_at"]) - time.time()) * 0.8))
        logger.info("[credential-lifecycle] %s: the portal did not say when these keys end; they are "
                    "renewed in %d s", label, int(renew_after - time.time()))
    return Renewed(payload={"aws_access_key_id": creds["aws_access_key_id"],
                            "aws_secret_access_key": creds["aws_secret_access_key"],
                            "aws_session_token": creds.get("aws_session_token") or "",
                            "expires_at": creds.get("expires_at"),
                            "expiration_iso": creds.get("expiration_iso"),
                            "said_expiry": bool(creds.get("expiration_iso")),
                            "proof_salt": salt, "proof": _password_proof(password, salt)},
                   expires_at=float(creds["expires_at"]) if creds.get("expires_at") else None,
                   renew_after=renew_after, source="portal")


def portal_keys(login: Callable[[], Optional[Tuple[str, str]]], *,
                username: str = "", portal_kwargs: Optional[Dict[str, Any]] = None,
                account_ref: Any = None, min_lifetime_seconds: float = 0.0,
                force: bool = False) -> Dict[str, Any]:
    """AWS keys for a portal login that the SYSTEM holds (a System Account,
    the login saved on a connection, the default portal login) -- from the
    shared row, renewed before they end by ONE pod.

    ``login()`` answers ``(username, password)`` as its source holds them NOW
    -- never a copy taken earlier -- or None when the account cannot give one.
    ``account_ref`` names the System Account the password came from: when the
    portal refuses it, the account is re-read from its source ONCE and the
    login tried once more with what it holds now.

    The row answers only a caller who HOLDS the login: the password it
    presents must be the one that earned the keys (the proof inside the
    payload).  A caller with another password is sent to the portal with ITS
    password -- a rotation then replaces the row's keys, a wrong password is
    refused and the row is not touched.

    Returns ``{aws_access_key_id, aws_secret_access_key, aws_session_token,
    expires_at, obtained_at, renew_after, lease_subject, lease_version}``.
    Raises :class:`CredentialUnavailable` with the reason in plain words."""
    kw = dict(portal_kwargs or {})
    pair = login()
    if not pair or not pair[0] or not pair[1]:
        raise CredentialUnavailable(
            f"The login of {username or 'this connection'} could not be read "
            f"(see the System Account's status).", ERROR_UNAVAILABLE)
    user, password = str(pair[0]), str(pair[1])
    subject, label = portal_subject(user, kw, account_ref)

    def renew(_previous: Optional[Lease]) -> Renewed:
        from core.aws_portal_auth import PortalAuthError, fetch_credentials
        # the password AS ITS ROW HOLDS IT NOW, not this pod's few-second copy:
        # another pod may have just learned that it changed (the portal refused
        # the old one there).  Measured on the rig: without this the old
        # password went to the portal once more from each pod that renewed
        # inside those few seconds -- and every such try is a failed AD login.
        leases.forget_local(KIND_ACCOUNT_SECRET)
        now_pair = login() or (user, password)
        use_user, use_password = str(now_pair[0] or user), str(now_pair[1] or password)
        try:
            creds = fetch_credentials(use_user, use_password, **kw)
        except PortalAuthError as exc:
            if not _portal_refused(exc):
                raise RenewalFailed(f"The AWS portal could not be reached for {user}: {_plain_portal_failure(exc)}",
                                    ERROR_UNAVAILABLE, retry_seconds=15) from exc
            fresh = None
            if account_ref is not None:
                # the password itself was refused: is it still the one its source holds?
                from core.qs_credentials import freshness
                try:
                    fresh = freshness.heal(account_ref, _AuthRefusal(str(exc)), what="AWS portal login",
                                           previous={"password": use_password})
                except Exception as heal_exc:                # noqa: BLE001
                    raise RenewalFailed(
                        f"The AWS portal refused the login of {user}, and the account could not be read "
                        f"again: {str(heal_exc)[:300]}", ERROR_REFUSED,
                        retry_seconds=leases.refused_seconds()) from heal_exc
            if not fresh or not fresh.get("password") or fresh.get("password") == use_password:
                if account_ref is None:
                    # a login typed on a connection: THIS password is not sent again
                    # by this pod for five minutes (aws_portal_auth remembers the
                    # refused password), but the ROW is not closed -- another
                    # connection holding the right password for this login must
                    # not be locked out by someone's wrong one
                    raise RenewalFailed(f"The AWS portal refused the username and password of {user}.",
                                        ERROR_REFUSED) from exc
                raise RenewalFailed(
                    f"The AWS portal refused the username and password of {user}"
                    f" -- the same password its System Account holds now"
                    f". It is not tried again for {int(leases.refused_seconds() // 60)} minutes, so the "
                    f"AD account is not locked. Correct the password, then use Refresh on the account.",
                    ERROR_REFUSED, retry_seconds=leases.refused_seconds()) from exc
            use_user, use_password = str(fresh.get("username") or use_user), str(fresh["password"])
            try:
                creds = fetch_credentials(use_user, use_password, **kw)
            except PortalAuthError as exc2:
                refused = _portal_refused(exc2)
                raise RenewalFailed(
                    f"The AWS portal {'refused' if refused else 'could not take'} the new login of {user}: "
                    f"{_plain_portal_failure(exc2)}", ERROR_REFUSED if refused else ERROR_UNAVAILABLE,
                    retry_seconds=leases.refused_seconds() if refused else 15) from exc2
            logger.warning("[credential-lifecycle] the portal refused the old password of %s; its System "
                           "Account holds a new one and the login with it worked", user)
        return _renewed_from(creds, use_password, label)

    lease = leases.obtain(KIND_PORTAL_KEYS, subject, renew, label=label, source="portal",
                          need_seconds=min_lifetime_seconds, force=force)
    if not _holds_the_login(lease, password):
        lease = _other_password(lease, login, user, password, kw, subject, label, account_ref)
    # how THIS process gets the keys of this login again: a client built from
    # these keys asks through here when it signs
    _RENEWERS[subject] = lambda need=0.0: portal_keys(
        login, username=username, portal_kwargs=portal_kwargs, account_ref=account_ref,
        min_lifetime_seconds=need)
    return _keys_view(lease)


def _other_password(lease: Lease, login: Callable[[], Optional[Tuple[str, str]]], user: str, password: str,
                    kw: Dict[str, Any], subject: str, label: str, account_ref: Any) -> Lease:
    """The caller's password is NOT the one that earned the row's keys.

    * this pod's copy of the account was a few seconds old (another pod
      learned of a rotation): read the account again -- if it now holds the
      row's password, the row answers;
    * otherwise the caller goes to the portal with ITS OWN password.  If the
      portal takes it (the password was rotated, and the caller knows the new
      one first) the row's keys are replaced by the ones it earned.  If the
      portal refuses it, the caller is refused and the ROW IS NOT TOUCHED --
      a wrong password never gets the keys, never removes them, and never
      costs the rightful login its place."""
    from core.aws_portal_auth import PortalAuthError, fetch_credentials
    leases.forget_local(KIND_ACCOUNT_SECRET)
    again = login()
    if again and again[1] and str(again[1]) != password and _holds_the_login(lease, str(again[1])):
        return lease
    try:
        creds = fetch_credentials(user, password, **kw)
    except PortalAuthError as exc:
        refused = _portal_refused(exc)
        raise CredentialUnavailable(
            (f"The AWS portal refused the username and password of {user}." if refused else
             f"The AWS portal could not be reached for {user}: {_plain_portal_failure(exc)}"),
            ERROR_REFUSED if refused else ERROR_UNAVAILABLE) from exc
    logger.warning("[credential-lifecycle] %s: the login's password changed -- the keys it earns now "
                   "replace the row's", label)
    return leases.obtain(KIND_PORTAL_KEYS, subject, lambda _prev: _renewed_from(creds, password, label),
                         label=label, source="portal", force=True)


class _AuthRefusal(Exception):
    """A portal 401 in the words ``freshness.is_auth_failure`` knows."""

    def __init__(self, text: str):
        super().__init__(f"HTTP 401 invalid credentials: {text}")


#: subject -> how THIS process gets that login's keys again (set whenever it
#: resolved them itself); a boto3 client asks by subject each time it signs
_RENEWERS: Dict[str, Callable[..., Dict[str, Any]]] = {}


def _keys_view(lease: Lease) -> Dict[str, Any]:
    p = dict(lease.payload or {})
    return {"aws_access_key_id": p.get("aws_access_key_id") or "",
            "aws_secret_access_key": p.get("aws_secret_access_key") or "",
            "aws_session_token": p.get("aws_session_token") or "",
            "expires_at": lease.expires_at or p.get("expires_at"),
            "expiration_iso": p.get("expiration_iso"),
            "obtained_at": lease.obtained_at, "renew_after": lease.renew_after,
            "lease_subject": lease.subject, "lease_version": lease.version}


#: what ``stamp_keys`` puts on a RESOLVED config.  SERVER-ONLY: a connection
#: saved by a person, a config in a request, a row read from the database may
#: never carry them (the save routes refuse them; anything that arrives with
#: them and no valid grant has them removed).
SERVER_ONLY_FIELDS = ("aws_credentials_lease", "aws_credentials_version", "aws_credentials_expire_at",
                      "aws_credentials_renew_after", "aws_credentials_grant")

#: subject -> the GRANT this process hands out with that row's keys, and back.
#: A grant is a random token made in this process, never stored, never shown.
_GRANT_OF: Dict[str, str] = {}
_GRANTED: Dict[str, str] = {}
_grant_lock = threading.Lock()


def _grant_for(subject: str) -> str:
    with _grant_lock:
        token = _GRANT_OF.get(subject)
        if token is None:
            token = _secrets.token_urlsafe(24)
            _GRANT_OF[subject] = token
            _GRANTED[token] = subject
        return token


def granted(subject: Any, grant: Any) -> bool:
    """Did THIS process hand out the keys of ``subject`` with ``grant``?

    The row's subject is a hash of public parts (the login's name, the role,
    the account, the portal) -- anyone can compute it, and it is shown.  So a
    subject alone proves nothing: review round 2 found that a connection whose
    saved config carried ``aws_credentials_lease`` = the subject of a service
    account's login was handed that account's keys the moment its client
    refreshed.  What proves the keys were GIVEN is the grant: a random token
    this process put beside them when it resolved the login (the password
    proved, ``_holds_the_login``).  It cannot be computed, is in no table and
    on no page; a config that did not come from ``stamp_keys`` in this process
    cannot hold it."""
    if not subject or not grant or not isinstance(grant, str):
        return False
    with _grant_lock:
        known = _GRANTED.get(grant)
    return known is not None and _hmac.compare_digest(str(known), str(subject))


def carried_lease(config: Any) -> Optional[Tuple[str, Any]]:
    """``(subject, version)`` of the keys a RESOLVED config was given by this
    process -- or None: no stamp, or a stamp this process did not make."""
    if not isinstance(config, dict):
        return None
    subject = config.get("aws_credentials_lease")
    if not granted(subject, config.get("aws_credentials_grant")):
        return None
    return str(subject), config.get("aws_credentials_version")


def without_foreign_stamp(config: Any) -> Any:
    """A config as it may be RESOLVED: the server-only fields are removed
    unless this process put them there.  Every resolver starts with this, so a
    stamp that came from the database or a request never reaches a client."""
    if not isinstance(config, dict) or not any(k in config for k in SERVER_ONLY_FIELDS):
        return config
    if granted(config.get("aws_credentials_lease"), config.get("aws_credentials_grant")):
        return config
    logger.warning("[credential-lifecycle] a connection config carried %s that this process did not put "
                   "there -- removed (these fields are set by QueryStudio only, never saved or sent)",
                   ", ".join(k for k in SERVER_ONLY_FIELDS if k in config))
    return {k: v for k, v in config.items() if k not in SERVER_ONLY_FIELDS}


def refuse_server_only_fields(config: Any) -> None:
    """For the routes that take a connection's config from a person: these
    fields cannot be saved or sent.  Raises ValueError in plain words."""
    if isinstance(config, dict):
        sent = [k for k in SERVER_ONLY_FIELDS if k in config]
        if sent:
            raise ValueError(
                f"A connection cannot carry {', '.join(sent)}. QueryStudio sets these itself while it "
                f"reads with the connection; they are never saved or sent. Remove them and save again.")


def portal_keys_by_subject(subject: str, grant: Any = None, *, min_lifetime_seconds: float = 0.0) -> Dict[str, Any]:
    """The keys of a lease a consumer was handed EARLIER, as they are NOW --
    what a boto3 client calls each time it is about to sign with keys that are
    near their end.

    ONLY for a caller that holds the GRANT those keys were handed out with
    (:func:`granted`): the subject alone is public and releases nothing.  The
    process that resolved the keys asks the SAME WAY again (the login at that
    moment, so a password rotated since is followed -- measured on the rig, a
    client kept per connection once went on asking for the old password's row
    and failed every listing after a rotation).  A process that was only
    handed a config (a child process) holds no grant of its own: its client
    keeps the keys it was given until they end."""
    if not granted(subject, grant):
        raise CredentialUnavailable(
            "These AWS keys were not handed out by this QueryStudio process, so they are not renewed "
            "here. (A connection's saved settings cannot name another login's keys.)", ERROR_REFUSED)
    again = _RENEWERS.get(subject)
    if again is not None:
        return again(min_lifetime_seconds)
    lease = leases.obtain(KIND_PORTAL_KEYS, subject, None, source="portal",
                          need_seconds=min_lifetime_seconds)
    return _keys_view(lease)


def portal_keys_refused(subject: Optional[str], version: Optional[int] = None, reason: str = "",
                        certain: bool = True) -> bool:
    """S3 refused these keys (ExpiredToken, InvalidToken, an unknown key ...).
    The row is marked; the next use -- on any pod -- gets new ones.  Only the
    lease named is touched: the other connections' keys stay.  ``certain=False``
    (a bare 403): keys got less than a minute ago are not marked."""
    if not subject:
        return False
    marked = leases.reject(KIND_PORTAL_KEYS, subject, version,
                           younger_than_is_not_refused=0.0 if certain else MAYBE_REFUSED_MIN_AGE_SECONDS)
    if marked:
        logger.warning("[credential-lifecycle] pod %s: S3 refused the AWS keys of lease %s (version %s)%s -- "
                       "the next use renews them", leases._pod(), subject[:12], version,
                       f": {reason[:200]}" if reason else "")
    return marked


def stamp_keys(config: Dict[str, Any], creds: Dict[str, Any]) -> Dict[str, Any]:
    """Put portal keys on a connection config, WITH where they came from
    (``aws_credentials_lease`` / ``_version`` / ``_expire_at`` /
    ``_renew_after``) and the GRANT that proves this process handed them out
    (``aws_credentials_grant``, :func:`granted`).  The ONLY place these fields
    are set: a client built from the config in this process can then ask for
    the keys as they are at use time."""
    out = {k: v for k, v in config.items() if k not in SERVER_ONLY_FIELDS}
    out["aws_access_key_id"] = creds["aws_access_key_id"]
    out["aws_secret_access_key"] = creds["aws_secret_access_key"]
    out["aws_session_token"] = creds.get("aws_session_token", "") or ""
    out["auth_mode"] = "keys"
    if creds.get("lease_subject"):
        out["aws_credentials_lease"] = creds["lease_subject"]
        out["aws_credentials_version"] = creds.get("lease_version")
        out["aws_credentials_grant"] = _grant_for(creds["lease_subject"])
    if creds.get("expires_at"):
        out["aws_credentials_expire_at"] = float(creds["expires_at"])
    if creds.get("renew_after"):
        out["aws_credentials_renew_after"] = float(creds["renew_after"])
    return out


def keys_refused_for_config(config: Optional[Dict[str, Any]], reason: str = "", certain: bool = True) -> bool:
    """The reactive half, for a RESOLVED config (it carries its lease).  Only
    a lease this process handed out (:func:`carried_lease`): a config that
    merely NAMES another login's row cannot have that row's keys thrown away."""
    lease = carried_lease(config)
    if lease is None:
        return False
    return portal_keys_refused(lease[0], lease[1], reason, certain)


def failure_is_the_keys(config: Optional[Dict[str, Any]], exc_or_text: Any) -> bool:
    """A read with a RESOLVED config failed.  If its keys are temporary and S3
    refused THEM, their owner is told -- the next read has new keys -- and the
    answer is True (the failure is the credential's, not the connection's)."""
    if carried_lease(config) is None:
        return False
    from core.qs_credentials import freshness
    how = freshness.temporary_keys_refused(exc_or_text)
    if how is None:
        return False
    keys_refused_for_config(config, str(exc_or_text)[:200], certain=(how == freshness.CERTAIN))
    return how == freshness.CERTAIN


def seconds_left_of_keys(config_or_expiry: Any) -> Optional[float]:
    """How long the temporary keys on a resolved config still live, or None
    when they do not end (static keys) / it is not known."""
    expire_at = config_or_expiry.get("aws_credentials_expire_at") if isinstance(config_or_expiry, dict) \
        else config_or_expiry
    try:
        return None if not expire_at else float(expire_at) - time.time()
    except (TypeError, ValueError):
        return None


# ──────────────────────────────────────────────────────────────────────
#  account_secret: Vault, or a mounted file
# ──────────────────────────────────────────────────────────────────────

def recheck_seconds() -> float:
    """How often ONE pod asks Vault (or reads the file) again for a secret
    nobody refused -- the memory TTL the per-pod cache used to have."""
    try:
        from core.config import get as _g
        return float(_g("secrets", "cache_ttl_seconds", 900) or 900)
    except Exception:                                        # noqa: BLE001
        return 900.0


def account_secret(cache_name: str, label: str, source: str,
                   fetch: Callable[[bool], Any], *, refused: bool = False,
                   recheck: bool = False) -> Tuple[Any, Lease]:
    """A System Account's secret (the Vault payload, the file's content) from
    the shared row.  ``fetch(strict)`` reads the source: ``strict`` (the
    credential was refused) must never answer a remembered value.

    ONE pod reads the source -- the first time, every ``recheck_seconds`` and
    at once after a refusal -- and writes a new VERSION only when the content
    changed; every other pod sees that version on its next use and drops what
    it built from the old one (``leases.on_new_version``).

    ``refused``: a source said no to this credential -- the row is marked and
    re-read strictly.  ``recheck``: this pod was told the account CHANGED
    (an administrator edited it on another pod) -- re-read strictly now, but
    nothing was refused, so an unchanged answer is not called a disagreement."""
    subject = leases.subject_of(f"account:{cache_name}")
    if refused:
        leases.reject(KIND_ACCOUNT_SECRET, subject)

    def renew(previous: Optional[Lease]) -> Renewed:
        # with a row in hand, the source is ASKED and must answer -- if it cannot,
        # the row keeps its value (this renewal fails, the copy in hand is used).
        # Only a row that does not exist yet may be started from a pod's own copy.
        strict = refused or recheck or previous is not None
        try:
            payload = fetch(strict)
        except Exception as exc:                             # noqa: BLE001
            # no back-off: the read itself tries twice, ONE caller at a time asks,
            # and "fix Vault, then retry" must work at once
            raise RenewalFailed(f"{label}: {source} could not be read: {type(exc).__name__}: {str(exc)[:400]}",
                                ERROR_UNAVAILABLE) from exc
        return Renewed(payload={"secret": payload}, expires_at=None,
                       renew_after=time.time() + recheck_seconds(), source=source)

    lease = leases.obtain(KIND_ACCOUNT_SECRET, subject, renew, label=label, source=source, force=recheck)
    return (lease.payload or {}).get("secret"), lease


def account_subject(cache_name: str) -> str:
    return leases.subject_of(f"account:{cache_name}")


# ── a password the platform mounts as a FILE (the Vault Secrets Operator / agent) ──

FILE_KEYS = ("password_file", "secret_file")


def file_source_of(row: Optional[Dict[str, Any]]) -> Optional[str]:
    """The mounted file (or folder) a System Account reads its login from, or
    None.  Set as ``config.password_file`` on the account."""
    cfg = (row or {}).get("config") if isinstance(row, dict) else None
    if not isinstance(cfg, dict):
        return None
    for key in FILE_KEYS:
        value = str(cfg.get(key) or "").strip()
        if value:
            return value
    return None


def read_mounted_secret(path: str, default_username: str = "") -> Dict[str, Any]:
    """``{"username", "password"}`` from what the platform mounted.

    * a FOLDER (how a Kubernetes Secret is mounted): the files ``password``
      and, when present, ``username`` -- one key per file;
    * a FILE holding JSON ``{"username": ..., "password": ...}``;
    * a FILE holding only the password (the username is the account's own).

    Raises with the reason: a file that is missing, empty or unreadable is
    "could not read", never an empty password."""
    def _text(p: str) -> str:
        with open(p, "r", encoding="utf-8") as fh:
            return fh.read().strip("\r\n")

    if os.path.isdir(path):
        pw_file = os.path.join(path, "password")
        if not os.path.isfile(pw_file):
            raise FileNotFoundError(f"the mounted folder {path} has no 'password' file")
        user_file = os.path.join(path, "username")
        username = _text(user_file) if os.path.isfile(user_file) else default_username
        password = _text(pw_file)
    elif os.path.isfile(path):
        raw = _text(path)
        username, password = default_username, raw
        if raw.lstrip().startswith("{"):
            import json
            try:
                doc = json.loads(raw)
            except ValueError as exc:
                raise ValueError(f"the mounted file {path} looks like JSON but does not parse: {exc}") from exc
            if not isinstance(doc, dict):
                raise ValueError(f"the mounted file {path} is not a JSON object")
            username = str(doc.get("username") or doc.get("user") or default_username)
            password = str(doc.get("password") or "")
    else:
        raise FileNotFoundError(f"the mounted secret {path} is not there on this pod")
    if not password:
        raise ValueError(f"the mounted secret {path} holds no password")
    return {"username": username, "password": password}


# ──────────────────────────────────────────────────────────────────────
#  the admin view
# ──────────────────────────────────────────────────────────────────────

def _iso(epoch: Optional[float]) -> Optional[str]:
    if not epoch:
        return None
    from datetime import datetime, timezone
    return datetime.fromtimestamp(float(epoch), tz=timezone.utc).isoformat(timespec="seconds")


def state() -> List[Dict[str, Any]]:
    """Each credential the system holds, in words an operator reads: what it
    is, where it came from, when it was got, when it ends, who renewed it
    last, the last failure and its reason, on which pods.  Never a payload."""
    now = time.time()
    out: List[Dict[str, Any]] = []
    for row in leases.state():
        left = row.get("seconds_left")
        if not row.get("held"):
            status, words = "not held", "No credential is held yet."
        elif row.get("rejected"):
            status, words = "refused", "The source refused it; it is renewed on its next use."
        elif left is not None and left <= 0:
            status, words = "ended", "It has ended and was not renewed."
        elif row.get("last_error"):
            status, words = "renewal failed", "The copy in hand is still good; the last renewal failed."
        else:
            status, words = "good", "Good."
        out.append({
            "kind": row["kind"], "what": row.get("label") or row["subject"][:12], "source": row.get("source"),
            "status": status, "status_text": words, "version": row["version"],
            "obtained_at": _iso(row.get("obtained_at")), "expires_at": _iso(row.get("expires_at")),
            "renew_after": _iso(row.get("renew_after")), "seconds_left": left,
            "last_renewed_by": row.get("last_renewed_by"), "renewals": row.get("renewals"),
            "renewing_by": row.get("renewing_by"),
            "last_error": row.get("last_error"), "last_error_kind": row.get("last_error_kind"),
            "last_error_at": _iso(row.get("last_error_at")),
            "retry_after": _iso(row.get("retry_after")) if (row.get("retry_after") or 0) > now else None,
            "pods": row.get("pods") or [],
            "pod_versions": {p: (v or {}).get("version") for p, v in (row.get("seen_by") or {}).items()},
            "subject": row["subject"],
        })
    return out


__all__ = [
    "CredentialKind", "KINDS", "NOT_CHECKED_PERSONAL", "ACCOUNT_MARK", "portal_subject", "portal_keys",
    "portal_keys_by_subject", "portal_keys_refused", "stamp_keys", "keys_refused_for_config",
    "seconds_left_of_keys", "failure_is_the_keys", "SERVER_ONLY_FIELDS", "granted", "carried_lease",
    "without_foreign_stamp", "refuse_server_only_fields", "account_secret", "account_subject", "recheck_seconds",
    "file_source_of", "read_mounted_secret", "state", "CredentialUnavailable",
]
