"""qs_credentials.leases -- ONE shared, encrypted row per credential, renewed by
ONE pod and read by every pod when it USES the credential (2026-11-12).

The owner on UAT: "i have 3 aws s3 connection with diff bucket with same
account ... all connections are dropping frequently", "after every 5 mins i
guess connection status as failed for all 3", "need better solution as it will
be biggest issues on pwd synching ... keep in db in encrypted form".

Before this, every pod kept its OWN copy of every credential (AWS keys from the
portal in a module dict, a Vault password in a 15-minute memory + 24-hour disk
cache), renewed it on its OWN clock, and learned that a password had changed
only by failing with it.  Measured on the rig: after the password changed in
Vault every pod went on logging in to the portal with the OLD one; the portal
refused it, the login was not tried again for five minutes, and every
connection on that login failed together -- then again, five minutes later.

The row (``core.db.models.CredentialLease``, table ``credential_leases``):

* **one copy** -- ``payload`` is the credential, encrypted under the data keys
  (``core/crypto.py``); ``version`` goes up by one each time it is replaced;
* **one renewer** -- a pod that finds the credential due takes
  ``renewing_by`` / ``lease_until`` by compare-and-set on ``version`` (the
  UPDATE's row count is the answer), asks the source ONCE and writes the new
  version.  Every other pod goes on with the copy in hand while it is still
  good, or waits for the new version when it is not.  A renewer that dies is
  replaced after ``lease_until``;
* **read at use time** -- a pod may keep the decrypted payload in memory for a
  few seconds (``secrets.lease_memory_seconds``) and then asks the row for its
  ``version`` again (one primary-key SELECT, no payload); a different version
  drops the memory copy;
* **a refused credential is said once** -- ``rejected_version`` marks the
  version a source refused; the next reader renews it, and when the source of
  truth still holds the same value the row says so (``last_error``) and nobody
  asks again before ``retry_after``.  One failed login for the fleet, not one
  per pod per request;
* **could not read is never empty** -- a payload that does not decrypt is
  ``unreadable`` with the reason; it is obtained again from the source, never
  replaced by an older value.

With no database (a unit harness, a child process) the SAME protocol runs on
an in-memory store, so one process still single-flights.

Never logs a payload.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

KIND_PORTAL_KEYS = "portal_keys"
KIND_ACCOUNT_SECRET = "account_secret"

#: why a renewal failed (``last_error_kind``); declared, the status reads them
ERROR_REFUSED = "refused"            # the source said no to the login
ERROR_UNAVAILABLE = "unavailable"    # the source could not be reached / answered 5xx
ERROR_UNREADABLE = "unreadable"      # the stored row could not be decrypted
ERROR_SAME_SECRET = "same_secret"    # the source of truth holds the value that was refused
#: this pod cannot ENCRYPT, so nothing may be written to the shared row
ERROR_NOT_ENCRYPTED = "not_encrypted"


class CredentialUnavailable(Exception):
    """No usable credential, and why.  ``kind`` is one of the ERROR_* words."""

    def __init__(self, message: str, kind: str = ERROR_UNAVAILABLE):
        super().__init__(message)
        self.kind = kind


class PayloadNotEncrypted(RuntimeError):
    """The shared row refuses a payload that is not encrypted."""


class RenewalFailed(Exception):
    """Raised by a ``renew`` callable to say HOW it failed: ``kind`` (an
    ERROR_* word) and ``retry_seconds`` (do not ask the source again before)."""

    def __init__(self, message: str, kind: str = ERROR_UNAVAILABLE, retry_seconds: float = 0.0):
        super().__init__(message)
        self.kind = kind
        self.retry_seconds = float(retry_seconds or 0.0)


@dataclass
class Renewed:
    """What a ``renew`` callable answers."""
    payload: Dict[str, Any]
    expires_at: Optional[float] = None        # epoch; None = does not expire by itself
    renew_after: Optional[float] = None       # epoch; None = decided from expires_at
    source: str = ""


@dataclass
class Lease:
    kind: str
    subject: str
    label: str = ""
    source: str = ""
    payload: Optional[Dict[str, Any]] = None
    version: int = 0
    obtained_at: Optional[float] = None
    expires_at: Optional[float] = None
    renew_after: Optional[float] = None
    renewing_by: Optional[str] = None
    lease_until: Optional[float] = None
    rejected_version: Optional[int] = None
    last_error: Optional[str] = None
    last_error_kind: Optional[str] = None
    last_error_at: Optional[float] = None
    retry_after: Optional[float] = None
    last_renewed_by: Optional[str] = None
    renewals: int = 0
    seen_by: Dict[str, Any] = field(default_factory=dict)
    unreadable: Optional[str] = None          # why the payload could not be read

    def seconds_left(self, now: Optional[float] = None) -> float:
        if self.expires_at is None:
            return float("inf")
        return float(self.expires_at) - (time.time() if now is None else now)

    def lifetime(self) -> Optional[float]:
        if self.expires_at is None or self.obtained_at is None:
            return None
        return max(0.0, float(self.expires_at) - float(self.obtained_at))

    def rejected(self) -> bool:
        return self.rejected_version is not None and int(self.rejected_version) == int(self.version)

    def usable(self, now: Optional[float] = None, need_seconds: float = 0.0) -> bool:
        """A payload is here, was not refused, and lives ``need_seconds`` more."""
        if self.payload is None or self.rejected():
            return False
        return self.seconds_left(now) > float(need_seconds or 0.0)

    def due(self, now: Optional[float] = None) -> bool:
        if self.renew_after is None:
            return False
        return (time.time() if now is None else now) >= float(self.renew_after)

    def being_renewed(self, now: Optional[float] = None) -> bool:
        return bool(self.renewing_by) and float(self.lease_until or 0) > (time.time() if now is None else now)

    def public(self) -> Dict[str, Any]:
        """Everything but the payload -- for the admin page and the health rows."""
        now = time.time()
        left = self.seconds_left(now)
        return {
            "kind": self.kind, "subject": self.subject, "label": self.label, "source": self.source,
            "version": self.version, "held": self.version > 0,
            "obtained_at": self.obtained_at, "expires_at": self.expires_at, "renew_after": self.renew_after,
            "seconds_left": None if left == float("inf") else round(left, 1),
            "renewing_by": self.renewing_by if self.being_renewed(now) else None,
            "rejected": self.rejected(), "last_error": self.last_error, "last_error_kind": self.last_error_kind,
            "last_error_at": self.last_error_at, "retry_after": self.retry_after,
            "last_renewed_by": self.last_renewed_by, "renewals": self.renewals,
            "pods": sorted((self.seen_by or {}).keys()), "seen_by": self.seen_by or {},
        }


def subject_of(key: str) -> str:
    """A credential's key (a login + role + ..., an account's secret ref) as
    the row's ``subject``: its SHA-256, so the key's own text (a username, a
    URL) is never a primary key and its length never matters."""
    return hashlib.sha256(str(key).encode("utf-8")).hexdigest()


def renew_margin(lifetime: Optional[float]) -> float:
    """How long BEFORE its end a credential is renewed: a fifth of its life,
    never less than 30 s, never more than 10 minutes.  An hour of AWS keys is
    renewed 10 minutes early; 150 s of them 30 s early."""
    if not lifetime or lifetime <= 0:
        return 30.0
    return max(30.0, min(600.0, float(lifetime) * 0.2))


def effective_need(need_seconds: float, lifetime: Optional[float]) -> float:
    """A caller may ask for ``need_seconds`` of remaining life (a long read
    asks for 10 minutes).  It is honoured up to HALF the credential's life:
    asking 600 s of keys that live 150 s must not mean "log in on every
    read" -- measured on the rig, that is what it meant."""
    need = max(0.0, float(need_seconds or 0.0))
    if lifetime and lifetime > 0:
        need = min(need, float(lifetime) / 2.0)
    return need


def _cfg(key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        value = _g("secrets", key, fallback)
        return fallback if value is None else value
    except Exception:                                        # noqa: BLE001
        return fallback


def memory_seconds() -> float:
    return float(_cfg("lease_memory_seconds", 5) or 5)


def renew_lease_seconds() -> float:
    return float(_cfg("lease_renew_seconds", 30) or 30)


def _pod() -> str:
    """Which pod is speaking -- for the log line and the "seen on" list."""
    from core.qs_credentials.freshness import pod_name
    return pod_name()


_OWNER_NONCE = uuid.uuid4().hex[:6]


def owner_id() -> str:
    """Who HOLDS a renewal: this PROCESS.  The pod's name alone is not an
    owner -- a pod runs several worker processes with one hostname, and two of
    them would each believe the renewal was theirs (one taking it over after
    the lease, the other still finishing, both allowed to write).  The pod's
    name stays first, so the row still reads as "renewing on pod X"."""
    return f"{_pod()}#{os.getpid()}-{_OWNER_NONCE}"[:150]


# ──────────────────────────────────────────────────────────────────────
#  the stores: the database row, or (no database) this process
# ──────────────────────────────────────────────────────────────────────

_HEAD_FIELDS = ("version", "expires_at", "renew_after", "renewing_by", "lease_until",
                "rejected_version", "retry_after", "last_error_kind")


class _MemoryStore:
    """The same protocol with no database: one process, nothing encrypted
    (nothing leaves the process).  A unit harness and a child process use it."""

    name = "memory"

    def __init__(self) -> None:
        self._rows: Dict[Tuple[str, str], Lease] = {}
        self._lock = threading.Lock()

    def read(self, kind: str, subject: str) -> Optional[Lease]:
        with self._lock:
            row = self._rows.get((kind, subject))
            return None if row is None else Lease(**{**row.__dict__, "seen_by": dict(row.seen_by or {})})

    def head(self, kind: str, subject: str) -> Optional[Dict[str, Any]]:
        row = self.read(kind, subject)
        return None if row is None else {f: getattr(row, f) for f in _HEAD_FIELDS}

    def ensure(self, kind: str, subject: str, label: str, source: str) -> None:
        with self._lock:
            self._rows.setdefault((kind, subject), Lease(kind=kind, subject=subject, label=label, source=source))

    def claim(self, kind: str, subject: str, version: int, pod: str, until: float, now: float) -> bool:
        with self._lock:
            row = self._rows.get((kind, subject))
            if row is None or row.version != version:
                return False
            if row.renewing_by and float(row.lease_until or 0) >= now:
                return False
            row.renewing_by, row.lease_until = pod, until
            return True

    def complete(self, kind: str, subject: str, owner: str, renewed: Renewed, now: float,
                 label: str = "", renewed_by: str = "") -> Optional[int]:
        pod = renewed_by or owner
        with self._lock:
            row = self._rows.get((kind, subject))
            if row is None or row.renewing_by != owner:
                return None
            row.payload, row.version = dict(renewed.payload), row.version + 1
            row.obtained_at, row.expires_at, row.renew_after = now, renewed.expires_at, renewed.renew_after
            row.renewing_by = row.lease_until = row.rejected_version = None
            row.last_error = row.last_error_kind = row.last_error_at = row.retry_after = None
            row.last_renewed_by, row.renewals, row.unreadable = pod, row.renewals + 1, None
            row.source = renewed.source or row.source
            row.label = label or row.label
            return row.version

    def checked(self, kind: str, subject: str, pod: str, renew_after: Optional[float],
                error: Optional[str], error_kind: Optional[str], retry_after: Optional[float],
                now: float, clear_rejection: bool = False) -> None:
        with self._lock:
            row = self._rows.get((kind, subject))
            if row is None or row.renewing_by != pod:
                return
            row.renewing_by = row.lease_until = None
            if renew_after is not None:
                row.renew_after = renew_after
            row.last_error, row.last_error_kind = error, error_kind
            row.last_error_at = now if error else None
            row.retry_after = retry_after
            if clear_rejection:
                row.rejected_version = None

    def due_now(self, kind: str, subject: str, now: float) -> None:
        with self._lock:
            row = self._rows.get((kind, subject))
            if row is not None:
                row.renew_after = now

    def reject(self, kind: str, subject: str, version: int) -> bool:
        with self._lock:
            row = self._rows.get((kind, subject))
            if row is None or row.version != version or row.rejected_version == version:
                return False
            row.rejected_version = version
            return True

    def seen(self, kind: str, subject: str, pod: str, version: int, now: float) -> None:
        with self._lock:
            row = self._rows.get((kind, subject))
            if row is not None:
                row.seen_by = dict(row.seen_by or {}, **{pod: {"at": round(now, 1), "version": version}})

    def all(self) -> List[Lease]:
        with self._lock:
            return [Lease(**{**r.__dict__, "payload": None}) for r in self._rows.values()]

    def delete(self, kind: str, subject: str) -> None:
        with self._lock:
            self._rows.pop((kind, subject), None)


class _DbStore:
    """Rows of ``credential_leases``.  Every write is one small statement in
    its own transaction; the two that decide (``claim``, ``complete``) are
    conditional UPDATEs whose row count is the answer."""

    name = "database"

    def __init__(self, db: Any) -> None:
        self._db = db

    @staticmethod
    def _model():
        from core.db.models import CredentialLease
        return CredentialLease

    def _to_lease(self, r: Any, with_payload: bool = True) -> Lease:
        lease = Lease(kind=r.kind, subject=r.subject, label=r.label or "", source=r.source or "",
                      version=int(r.version or 0), obtained_at=r.obtained_at, expires_at=r.expires_at,
                      renew_after=r.renew_after, renewing_by=r.renewing_by, lease_until=r.lease_until,
                      rejected_version=r.rejected_version, last_error=r.last_error,
                      last_error_kind=r.last_error_kind, last_error_at=r.last_error_at,
                      retry_after=r.retry_after, last_renewed_by=r.last_renewed_by,
                      renewals=int(r.renewals or 0), seen_by=dict(r.seen_by or {}))
        if with_payload and r.payload:
            try:
                from core.crypto import decrypt_value
                plain = decrypt_value(r.payload)
                if not plain:
                    raise ValueError("the stored value does not open with this pod's data keys")
                lease.payload = json.loads(plain)
                if not isinstance(lease.payload, dict):
                    raise ValueError("the stored value is not a credential")
            except Exception as exc:                         # noqa: BLE001
                lease.payload = None
                lease.unreadable = f"{type(exc).__name__}: {exc}"[:300]
        return lease

    def read(self, kind: str, subject: str) -> Optional[Lease]:
        M = self._model()
        with self._db.get_session() as s:
            r = s.query(M).filter(M.kind == kind, M.subject == subject).first()
            return None if r is None else self._to_lease(r)

    def head(self, kind: str, subject: str) -> Optional[Dict[str, Any]]:
        M = self._model()
        with self._db.get_session() as s:
            r = (s.query(M.version, M.expires_at, M.renew_after, M.renewing_by, M.lease_until,
                         M.rejected_version, M.retry_after, M.last_error_kind)
                 .filter(M.kind == kind, M.subject == subject).first())
            return None if r is None else dict(zip(_HEAD_FIELDS, r))

    def ensure(self, kind: str, subject: str, label: str, source: str) -> None:
        M = self._model()
        _db_written[0] = True
        try:
            with self._db.get_session() as s:
                if s.query(M.version).filter(M.kind == kind, M.subject == subject).first() is None:
                    s.add(M(kind=kind, subject=subject, label=(label or "")[:300], source=source or None,
                            version=0, renewals=0))
        except Exception as exc:                             # noqa: BLE001
            # two pods inserting the same row: the loser's INSERT fails on the
            # primary key, and the row it wanted is there
            from sqlalchemy.exc import IntegrityError
            if not isinstance(exc, IntegrityError):
                raise

    def claim(self, kind: str, subject: str, version: int, pod: str, until: float, now: float) -> bool:
        from sqlalchemy import or_
        M = self._model()
        with self._db.get_session() as s:
            n = (s.query(M)
                 .filter(M.kind == kind, M.subject == subject, M.version == version,
                         or_(M.renewing_by.is_(None), M.lease_until.is_(None), M.lease_until < now))
                 .update({M.renewing_by: pod, M.lease_until: until}, synchronize_session=False))
            return n == 1

    def complete(self, kind: str, subject: str, owner: str, renewed: Renewed, now: float,
                 label: str = "", renewed_by: str = "") -> Optional[int]:
        from core.crypto import encrypt_value
        M = self._model()
        pod = renewed_by or owner
        stored = encrypt_value(json.dumps(renewed.payload, default=str))
        if not isinstance(stored, str) or not stored.startswith("enc::"):
            # core/crypto hands the text back UNCHANGED when it cannot encrypt
            # (no cryptography library).  A credential is never written to the
            # shared row in the clear: this refuses, and the caller says so.
            raise PayloadNotEncrypted(
                "this pod cannot encrypt, so the credential was NOT written to the shared row "
                "(credential_leases); it is used on this pod only")
        with self._db.get_session() as s:
            values = {M.payload: stored, M.version: M.version + 1, M.obtained_at: now,
                      M.expires_at: renewed.expires_at, M.renew_after: renewed.renew_after,
                      M.renewing_by: None, M.lease_until: None, M.rejected_version: None,
                      M.last_error: None, M.last_error_kind: None, M.last_error_at: None,
                      M.retry_after: None, M.last_renewed_by: pod, M.renewals: M.renewals + 1}
            if renewed.source:
                values[M.source] = renewed.source
            if label:
                values[M.label] = label[:300]
            n = (s.query(M).filter(M.kind == kind, M.subject == subject, M.renewing_by == owner)
                 .update(values, synchronize_session=False))
            if n != 1:
                return None
            r = s.query(M.version).filter(M.kind == kind, M.subject == subject).first()
            return int(r[0]) if r else None

    def checked(self, kind: str, subject: str, pod: str, renew_after: Optional[float],
                error: Optional[str], error_kind: Optional[str], retry_after: Optional[float],
                now: float, clear_rejection: bool = False) -> None:
        M = self._model()
        values: Dict[Any, Any] = {M.renewing_by: None, M.lease_until: None,
                                  M.last_error: (error or None) and str(error)[:1000],
                                  M.last_error_kind: error_kind, M.last_error_at: now if error else None,
                                  M.retry_after: retry_after}
        if renew_after is not None:
            values[M.renew_after] = renew_after
        if clear_rejection:
            values[M.rejected_version] = None
        with self._db.get_session() as s:
            (s.query(M).filter(M.kind == kind, M.subject == subject, M.renewing_by == pod)
             .update(values, synchronize_session=False))

    def due_now(self, kind: str, subject: str, now: float) -> None:
        M = self._model()
        with self._db.get_session() as s:
            (s.query(M).filter(M.kind == kind, M.subject == subject)
             .update({M.renew_after: now}, synchronize_session=False))

    def reject(self, kind: str, subject: str, version: int) -> bool:
        from sqlalchemy import or_
        M = self._model()
        with self._db.get_session() as s:
            n = (s.query(M)
                 .filter(M.kind == kind, M.subject == subject, M.version == version,
                         or_(M.rejected_version.is_(None), M.rejected_version != version))
                 .update({M.rejected_version: version}, synchronize_session=False))
            return n == 1

    def seen(self, kind: str, subject: str, pod: str, version: int, now: float) -> None:
        M = self._model()
        with self._db.get_session() as s:
            r = s.query(M).filter(M.kind == kind, M.subject == subject).first()
            if r is not None:
                seen = dict(r.seen_by or {})
                # a pod that has not used it for a day is no longer "on" it
                seen = {p: v for p, v in seen.items() if now - float((v or {}).get("at") or 0) < 86400}
                seen[pod] = {"at": round(now, 1), "version": int(version)}
                r.seen_by = seen

    def all(self) -> List[Lease]:
        M = self._model()
        with self._db.get_session() as s:
            return [self._to_lease(r, with_payload=False) for r in s.query(M).order_by(M.kind, M.label).all()]

    def delete(self, kind: str, subject: str) -> None:
        M = self._model()
        with self._db.get_session() as s:
            s.query(M).filter(M.kind == kind, M.subject == subject).delete(synchronize_session=False)


_memory_store = _MemoryStore()
#: has this process written a row to a DATABASE store?  (the test suite
#: removes the rows a test wrote, so the next test does not read them)
_db_written = [False]
_store_override: Any = None
_db_store: Optional[_DbStore] = None
_db_problem_logged = [0.0]


def use_store(store: Any) -> None:
    """Test hook: a store to use (None = decide again)."""
    global _store_override, _db_store
    _store_override = store
    _db_store = None


def db_store(db: Any) -> _DbStore:
    return _DbStore(db)


def new_memory_store() -> _MemoryStore:
    return _MemoryStore()


def _enabled() -> bool:
    return bool(_cfg("lease_enabled", True))


_cannot_encrypt_logged = [False]


def _can_encrypt() -> bool:
    """A pod that cannot encrypt keeps its credentials to itself (the same
    rules, in its own memory) -- said once, loudly."""
    try:
        from core import crypto
        ok = bool(crypto._check_crypto())
    except Exception:                                        # noqa: BLE001
        ok = False
    if not ok and not _cannot_encrypt_logged[0]:
        _cannot_encrypt_logged[0] = True
        logger.error("[credential-lease] pod %s cannot encrypt (the cryptography library is missing): "
                     "credentials are NOT written to the shared row; this pod renews its own", _pod())
    return ok


def store() -> Any:
    """The database when this process has one PUBLISHED (a pod), else this
    process's memory.  Never creates a database of its own."""
    global _db_store
    if _store_override is not None:
        return _store_override
    if not _enabled():
        return _memory_store
    try:
        import core.database as _dbmod
        db = getattr(_dbmod, "_GLOBAL_DB_MANAGER", None)
    except Exception:                                        # noqa: BLE001
        db = None
    if db is None or not hasattr(db, "get_session"):
        return _memory_store
    if not _can_encrypt():
        return _memory_store
    if _db_store is None or _db_store._db is not db:
        _db_store = _DbStore(db)
    return _db_store


# ──────────────────────────────────────────────────────────────────────
#  this pod's few-second copy
# ──────────────────────────────────────────────────────────────────────

_mem: Dict[Tuple[str, str], Tuple[Lease, float]] = {}
_mem_lock = threading.Lock()
_flight: Dict[Tuple[str, str], threading.Lock] = {}
_seen_written: Dict[Tuple[str, str], Tuple[int, float]] = {}
#: (kind, subject) -> fn(version) called when this pod learns of a NEW version
_on_change: Dict[str, Callable[[Lease], None]] = {}


def on_new_version(kind: str, fn: Callable[[Lease], None]) -> None:
    """``fn(lease)`` runs in a pod when it first sees a version of ``kind`` it
    did not have -- the place to drop what was BUILT from the old one (a
    pooled connector holding the old password)."""
    _on_change[kind] = fn


def reset_local() -> None:
    """Test hook: forget this process's copies (never the store's rows)."""
    with _mem_lock:
        _mem.clear()
        _seen_written.clear()


def _flight_lock(kind: str, subject: str) -> threading.Lock:
    with _mem_lock:
        return _flight.setdefault((kind, subject), threading.Lock())


def _remember(lease: Lease) -> Lease:
    key = (lease.kind, lease.subject)
    changed = False
    with _mem_lock:
        old = _mem.get(key)
        # a NEW version of something this pod already held (never the first one)
        changed = (old is not None and old[0].version > 0 and old[0].version != lease.version
                   and lease.payload is not None)
        _mem[key] = (lease, time.monotonic())
    if changed:
        fn = _on_change.get(lease.kind)
        if fn is not None:
            try:
                fn(lease)
            except Exception as exc:                         # noqa: BLE001
                logger.debug("leases: on_new_version(%s) failed: %s", lease.kind, exc)
        # a routine renewal of keys is not news; a changed SECRET is
        logger.log(logging.WARNING if lease.kind == KIND_ACCOUNT_SECRET else logging.INFO,
                   "[credential-lease] pod %s now uses version %d of %s (%s) -- renewed by %s",
                   _pod(), lease.version, lease.kind, lease.label or lease.subject[:12],
                   lease.last_renewed_by or "?")
    return lease


def _note_seen(st: Any, lease: Lease, now: float) -> None:
    """Which pods use this credential, for the admin page: written at most
    once a minute per pod, and at once on a new version.  Never fails a read."""
    key = (lease.kind, lease.subject)
    last = _seen_written.get(key)
    if last is not None and last[0] == lease.version and now - last[1] < 60:
        return
    _seen_written[key] = (lease.version, now)
    try:
        st.seen(lease.kind, lease.subject, _pod(), lease.version, now)
    except Exception as exc:                                 # noqa: BLE001
        logger.debug("leases: seen_by not written: %s", exc)


def current(kind: str, subject: str, *, fresh: bool = False) -> Optional[Lease]:
    """The lease as this pod may use it now: its memory copy while it is a few
    seconds old, else the row (a version SELECT; the payload only when the
    version moved).  None when there is no row.  A store that cannot be read
    raises -- the caller decides (``obtain`` falls back to this process)."""
    key = (kind, subject)
    st = store()
    with _mem_lock:
        held = _mem.get(key)
    if held is not None and not fresh and time.monotonic() - held[1] < memory_seconds():
        return held[0]
    if held is not None:
        head = st.head(kind, subject)
        if head is None:
            with _mem_lock:
                _mem.pop(key, None)
            return None
        if int(head["version"] or 0) == held[0].version and held[0].payload is not None:
            lease = held[0]
            for f in _HEAD_FIELDS:
                setattr(lease, f, head[f])
            with _mem_lock:
                _mem[key] = (lease, time.monotonic())
            return lease
    lease = st.read(kind, subject)
    if lease is None:
        with _mem_lock:
            _mem.pop(key, None)
        return None
    return _remember(lease)


def _log_store_problem(exc: BaseException) -> None:
    now = time.monotonic()
    if now - _db_problem_logged[0] > 60:
        _db_problem_logged[0] = now
        logger.warning("[credential-lease] pod %s could not read the shared credential row (%s: %s) -- "
                       "this pod uses its own copy until the database answers",
                       _pod(), type(exc).__name__, str(exc)[:200])


def obtain(kind: str, subject: str, renew: Optional[Callable[[Optional[Lease]], Renewed]], *,
           label: str = "", source: str = "", need_seconds: float = 0.0, force: bool = False,
           wait_seconds: Optional[float] = None) -> Lease:
    """THE way a credential is got: the shared copy while it is good, renewed
    by ONE caller in the fleet when it is due, refused, missing or ``force``d.

    ``renew(previous)`` asks the source and answers a :class:`Renewed`; it
    raises :class:`RenewalFailed` to say how it failed.  With ``renew=None``
    this caller cannot renew (it only reads): it waits for another pod's
    renewal when the copy is not usable.

    Raises :class:`CredentialUnavailable` with the reason when there is no
    usable credential at the end -- never returns one that is known bad.
    """
    try:
        return _obtain(store(), kind, subject, renew, label, source, need_seconds, force, wait_seconds)
    except (CredentialUnavailable, RenewalFailed):
        raise
    except Exception as exc:                                 # noqa: BLE001
        # the DATABASE failed (down, table missing mid-upgrade): the credential
        # itself is not the problem.  This process goes on alone.
        if store() is _memory_store:
            raise
        _log_store_problem(exc)
        return _obtain(_memory_store, kind, subject, renew, label, source, need_seconds, force, wait_seconds)


def _good(lease: Optional[Lease], need: float, now: float) -> bool:
    return lease is not None and lease.usable(now, effective_need(need, lease.lifetime()))


def _obtain(st: Any, kind: str, subject: str, renew: Any, label: str, source: str,
            need_seconds: float, force: bool, wait_seconds: Optional[float]) -> Lease:
    now = time.time()
    lease: Optional[Lease] = None
    if st is store():
        lease = current(kind, subject)
    else:
        lease = st.read(kind, subject)
    if not force and _good(lease, need_seconds, now) and not lease.due(now):
        _note_seen(st, lease, now)
        return lease

    # how long a caller with NOTHING usable waits for another's renewal: that
    # renewer's whole lease and a little more (then it takes the renewal itself)
    deadline = time.monotonic() + (renew_lease_seconds() + 15 if wait_seconds is None else wait_seconds)
    forced = force
    flight = _flight_lock(kind, subject)
    if not force and lease is not None and lease.usable(now):
        # due, but still good: ONE thread of this process renews it; the others
        # go on with the copy in hand instead of queueing behind the source
        if not flight.acquire(blocking=False):
            return lease
    else:
        flight.acquire()
    try:
        while True:
            now = time.time()
            lease = st.read(kind, subject)
            if lease is None:
                if renew is None:
                    raise CredentialUnavailable(
                        f"No {kind.replace('_', ' ')} is held for {label or subject[:12]} yet, and this "
                        f"process cannot get one itself.", ERROR_UNAVAILABLE)
                st.ensure(kind, subject, label, source)
                lease = st.read(kind, subject) or Lease(kind=kind, subject=subject, label=label, source=source)
            if st is store():
                _remember(lease)
            good = _good(lease, need_seconds, now)
            if not forced and good and not lease.due(now):
                _note_seen(st, lease, now)
                return lease                                  # someone renewed it while we waited
            usable_now = lease.usable(now)
            # the source said no a moment ago (or holds the refused value): the
            # fleet does not ask again before retry_after
            if lease.retry_after and now < float(lease.retry_after) and not forced:
                if usable_now:
                    _note_seen(st, lease, now)
                    return lease
                # nothing usable is left, and the source failed a moment ago --
                # it said NO, or it could not be reached or read.  NOBODY asks it
                # again before retry_after: every reader on every pod is told
                # the row's last failure and when the next try is.  (A source
                # that is down was asked by every reader of every pod, every few
                # seconds, for as long as it stayed down.)  A person's Test or
                # Refresh (``force``) may try at once.
                raise CredentialUnavailable(
                    f"{_why(lease) or 'The last renewal failed'} (next attempt at {_clock(lease.retry_after)})",
                    lease.last_error_kind or ERROR_UNAVAILABLE)
            if renew is not None and st.claim(kind, subject, lease.version, owner_id(),
                                              now + renew_lease_seconds(), now):
                return _renew_as_owner(st, lease, renew, label, usable_now, now)
            # another caller is renewing it (or this one cannot)
            if usable_now and not forced:
                _note_seen(st, lease, now)
                return lease                                  # still good: no one waits
            if time.monotonic() >= deadline:
                if usable_now:
                    return lease
                raise CredentialUnavailable(
                    _why(lease) or f"The {kind.replace('_', ' ')} for {lease.label or subject[:12]} is not "
                                   f"usable and its renewal did not finish in time"
                                   + (f" (being renewed by {lease.renewing_by})" if lease.renewing_by else "."),
                    lease.last_error_kind or ERROR_UNAVAILABLE)
            if forced and not lease.being_renewed(now) and renew is None:
                forced = False
            time.sleep(0.2)
            fresh = st.head(kind, subject)
            if fresh is not None and int(fresh["version"] or 0) != lease.version:
                forced = False                                # a new version is what "force" asked for
    finally:
        flight.release()


def _why(lease: Lease) -> str:
    if lease.last_error:
        return str(lease.last_error)
    if lease.unreadable:
        return f"The stored credential could not be read ({lease.unreadable})"
    return ""


def _clock(when: Any) -> str:
    try:
        return time.strftime("%H:%M:%S UTC", time.gmtime(float(when)))
    except (TypeError, ValueError, OverflowError, OSError):
        return "a later time"


#: a source that could not be reached or read is asked again after this long,
#: doubling with every failure in a row, up to the ceiling; a success resets it
RETRY_FIRST_SECONDS = 30.0
RETRY_CEILING_SECONDS = 600.0


def retry_delay(lease: Lease, now: float, usable_now: bool) -> float:
    """How long nobody asks a source again after it FAILED (not refused):
    30 s, doubling with each failure in a row, to 10 minutes.  While the
    credential in hand is still good the next try is never later than a third
    of the life it has left (at least 5 s) -- an outage at renewal time must
    not run the keys out."""
    delay = RETRY_FIRST_SECONDS
    if (lease.last_error and lease.last_error_kind not in (ERROR_REFUSED, ERROR_SAME_SECRET)
            and lease.retry_after and lease.last_error_at):
        before = float(lease.retry_after) - float(lease.last_error_at)
        if before > 0:
            delay = max(RETRY_FIRST_SECONDS, before * 2.0)
    delay = min(delay, RETRY_CEILING_SECONDS)
    if usable_now:
        left = lease.seconds_left(now)
        if left != float("inf"):
            delay = min(delay, max(5.0, left / 3.0))
    return delay


def refused_seconds() -> float:
    """How long the fleet does not ask a source again after it said no."""
    return float(_cfg("lease_refused_seconds", 300) or 300)


def _renew_as_owner(st: Any, lease: Lease, renew: Any, label: str, usable_now: bool, now: float) -> Lease:
    """This caller holds the renewal.  Ask the source once; write the answer."""
    kind, subject, pod, owner = lease.kind, lease.subject, _pod(), owner_id()
    previous = lease if lease.payload is not None else None
    if lease.unreadable:
        logger.error("[credential-lease] pod %s could not read the stored %s for %s (%s) -- "
                     "getting it again from its source", pod, kind, lease.label or subject[:12], lease.unreadable)
    try:
        renewed = renew(previous)
    except RenewalFailed as exc:
        if exc.kind in (ERROR_REFUSED, ERROR_SAME_SECRET):
            # the source said NO: the renew callable says how long (or not at all)
            retry_after = (now + exc.retry_seconds) if exc.retry_seconds else None
        else:
            # it could not be reached or read: a growing wait, for the whole fleet
            retry_after = now + retry_delay(lease, now, usable_now)
        st.checked(kind, subject, owner, None, str(exc), exc.kind, retry_after, now)
        logger.warning("[credential-lease] pod %s could not renew %s for %s: %s%s%s", pod, kind,
                       lease.label or subject[:12], str(exc)[:300],
                       "; the copy in hand is still good and is used" if usable_now else "",
                       f"; next attempt at {_clock(retry_after)}" if retry_after else "")
        if usable_now:
            lease.last_error, lease.last_error_kind, lease.last_error_at = str(exc), exc.kind, now
            lease.retry_after = retry_after
            lease.renewing_by = lease.lease_until = None
            return _remember(lease) if st is store() else lease
        raise CredentialUnavailable(str(exc), exc.kind) from exc
    except BaseException as exc:
        # an unexpected failure (the login raising, a bug in a renew callable)
        # must not hold the renewal for the whole lease -- and it is the
        # SOURCE that failed, not the shared row: it is said as that, once.
        # (It used to travel up as it was, was read as "the database could not
        # be read", and the source was asked a second time on this pod's own
        # store.)
        why = f"{type(exc).__name__}: {str(exc)[:300]}"
        try:
            st.checked(kind, subject, owner, None, why, ERROR_UNAVAILABLE,
                       now + retry_delay(lease, now, usable_now), now)
        except Exception:                                    # noqa: BLE001
            pass
        if not isinstance(exc, Exception):
            raise
        if usable_now:
            logger.warning("[credential-lease] pod %s: renewing %s for %s raised %s; the copy in hand is used",
                           pod, kind, lease.label or subject[:12], why)
            return lease
        raise CredentialUnavailable(f"{lease.label or kind}: could not be renewed ({why})",
                                    ERROR_UNAVAILABLE) from exc
    done = time.time()
    if renewed.renew_after is None and renewed.expires_at is not None:
        renewed.renew_after = float(renewed.expires_at) - renew_margin(float(renewed.expires_at) - done)
    if previous is not None and _same_payload(previous.payload, renewed.payload) and renewed.expires_at is None:
        # the source of truth holds what we already have: the version stays, so
        # no pod drops what it built from it.  If a source had REFUSED this
        # value, that is said once -- the source and the source of truth
        # disagree -- and nobody asks again before retry_after.
        error = kind_ = retry = None
        if lease.rejected():
            error = (f"{lease.label or 'This credential'}: the login was refused, and "
                     f"{renewed.source or lease.source or 'its source'} still holds the same value. "
                     f"The two disagree; it is not asked again for {int(refused_seconds() // 60)} minutes.")
            kind_, retry = ERROR_SAME_SECRET, done + refused_seconds()
            logger.error("[credential-lease] pod %s: %s", pod, error)
        st.checked(kind, subject, owner, renewed.renew_after, error, kind_, retry, done, clear_rejection=True)
        lease.renew_after = renewed.renew_after
        lease.renewing_by = lease.lease_until = lease.rejected_version = None
        lease.last_error, lease.last_error_kind, lease.retry_after = error, kind_, retry
        lease.last_error_at = done if error else None
        return _remember(lease) if st is store() else lease
    try:
        version = st.complete(kind, subject, owner, renewed, done, label, renewed_by=pod)
    except PayloadNotEncrypted as exc:
        # nothing was written.  The row says why; this caller still has the
        # credential it just obtained, for itself.
        st.checked(kind, subject, owner, None, str(exc), ERROR_NOT_ENCRYPTED, None, done)
        logger.error("[credential-lease] pod %s: %s (%s)", pod, exc, lease.label or subject[:12])
        return Lease(kind=kind, subject=subject, label=label or lease.label, source=renewed.source,
                     payload=dict(renewed.payload), version=lease.version, obtained_at=done,
                     expires_at=renewed.expires_at, renew_after=renewed.renew_after, last_renewed_by=pod,
                     last_error=str(exc), last_error_kind=ERROR_NOT_ENCRYPTED)
    if version is None:
        # the renewal outlived its lease and another pod finished one: theirs is the row
        fresh = st.read(kind, subject)
        if fresh is not None and fresh.usable(done):
            return _remember(fresh) if st is store() else fresh
        version = lease.version + 1
    out = Lease(kind=kind, subject=subject, label=label or lease.label, source=renewed.source or lease.source,
                payload=dict(renewed.payload), version=version, obtained_at=done,
                expires_at=renewed.expires_at, renew_after=renewed.renew_after, last_renewed_by=pod,
                renewals=lease.renewals + 1, seen_by=lease.seen_by)
    left = out.seconds_left(done)
    logger.info("[credential-lease] pod %s renewed %s for %s: version %d%s", pod, kind,
                out.label or subject[:12], version,
                "" if left == float("inf") else f", good for {int(left)} s, renewed again in "
                                                f"{int(float(out.renew_after or done) - done)} s")
    if st is store():
        _remember(out)
        _note_seen(st, out, done)
    # the renewer tidies: rows of this kind that ENDED five minutes ago and
    # were not renewed are in nobody's use (a deleted connection, a login no
    # longer asked for).  Here, where rows are written -- never in a probe
    # that only reads.
    if renewed.expires_at is not None:
        prune(kind, 300.0)
    return out


def _same_payload(a: Optional[Dict[str, Any]], b: Optional[Dict[str, Any]]) -> bool:
    return json.dumps(a or {}, sort_keys=True, default=str) == json.dumps(b or {}, sort_keys=True, default=str)


def reject(kind: str, subject: str, version: Optional[int] = None, *,
           younger_than_is_not_refused: float = 0.0) -> bool:
    """A source REFUSED this version of the credential.  The row says so, and
    the next ``obtain`` -- on any pod -- renews it.  A pod that reports a
    version that is no longer the row's changes nothing: the row was already
    renewed.  Returns True when the row was marked.

    ``younger_than_is_not_refused`` (seconds) is for a refusal that MAY be
    about the credential (an S3 "403" with no reason): a credential obtained
    less than that long ago is not marked -- it cannot have ended already, and
    a right the login lacks must not become a login on every read."""
    try:
        st = store()
        head = st.head(kind, subject)
        if head is None:
            return False
        if younger_than_is_not_refused > 0:
            full = st.read(kind, subject)
            if full is None or full.obtained_at is None \
                    or time.time() - float(full.obtained_at) < younger_than_is_not_refused:
                return False
        if version is None:
            version = int(head["version"] or 0)
        if (head.get("last_error_kind") == ERROR_SAME_SECRET and head.get("retry_after")
                and time.time() < float(head["retry_after"])):
            return False          # already asked: the source of truth holds this very value
        marked = st.reject(kind, subject, int(version))
    except Exception as exc:                                 # noqa: BLE001
        _log_store_problem(exc)
        marked = False
    with _mem_lock:
        held = _mem.get((kind, subject))
        if held is not None and held[0].version == version:
            _mem.pop((kind, subject), None)
    return marked


def clear_refusals(*, subjects: Any = (), label_marks: Any = ()) -> int:
    """An administrator corrected ONE thing (a System Account): the sources
    that said no to IT may be asked again now.  Only the rows named -- by
    ``subjects``, or whose label carries one of ``label_marks`` -- lose their
    ``retry_after``; every other login keeps its five minutes (clearing all of
    them let a Refresh on account A resume failed AD logins for account B).
    Returns how many rows were cleared."""
    wanted = {str(s) for s in (subjects or ())}
    marks = tuple(str(m) for m in (label_marks or ()) if m)
    if not wanted and not marks:
        return 0
    st = store()
    n = 0
    try:
        for lease in st.all():
            if not lease.retry_after:
                continue
            if lease.subject not in wanted and not any((lease.label or "").endswith(m) for m in marks):
                continue
            now = time.time()
            if st.claim(lease.kind, lease.subject, lease.version, owner_id(), now + 5, now):
                st.checked(lease.kind, lease.subject, owner_id(), None, lease.last_error,
                           lease.last_error_kind, None, now)
                forget_local(lease.kind, lease.subject)
                n += 1
    except Exception as exc:                                 # noqa: BLE001
        _log_store_problem(exc)
    return n


def renew_soon(kind: str, subject: Optional[str] = None) -> int:
    """Someone asked for fresh credentials (the admin's "clear").  The rows
    become DUE: the next use renews them -- one caller -- while every other
    goes on with the copy in hand.  Nothing is thrown away: if the source
    cannot be reached just then, the copy still works.  Returns the count."""
    n = 0
    try:
        st = store()
        now = time.time()
        for lease in st.all():
            if lease.kind == kind and (subject is None or lease.subject == subject):
                st.due_now(lease.kind, lease.subject, now)
                n += 1
    except Exception as exc:                                 # noqa: BLE001
        _log_store_problem(exc)
    forget_local(kind, subject)
    return n


def forget_local(kind: str, subject: Optional[str] = None) -> None:
    """Drop this pod's few-second copy (the row is untouched)."""
    with _mem_lock:
        for key in [k for k in _mem if k[0] == kind and (subject is None or k[1] == subject)]:
            _mem.pop(key, None)


def prune(kind: str, ended_for_seconds: float = 3600.0) -> int:
    """Remove rows of ``kind`` whose credential ENDED more than
    ``ended_for_seconds`` ago -- the keys of a password that was rotated away
    are never asked for again.  Returns how many were removed."""
    st = store()
    now = time.time()
    n = 0
    try:
        for lease in st.all():
            # a row that still says "this login was refused, do not ask before ..."
            # is kept: removing it would forget the refusal and resume the logins
            if lease.kind == kind and lease.expires_at and now - float(lease.expires_at) > ended_for_seconds \
                    and not lease.being_renewed(now) and not (lease.retry_after and now < float(lease.retry_after)):
                st.delete(lease.kind, lease.subject)
                n += 1
    except Exception as exc:                                 # noqa: BLE001
        _log_store_problem(exc)
    return n


def state() -> List[Dict[str, Any]]:
    """Every credential held, without its payload: where it came from, when it
    was got, when it ends, who renewed it, the last failure, on which pods."""
    return [lease.public() for lease in store().all()]


def remove(kind: str, subject: str) -> None:
    try:
        store().delete(kind, subject)
    except Exception as exc:                                 # noqa: BLE001
        _log_store_problem(exc)
    forget_local(kind, subject)


__all__ = [
    "KIND_PORTAL_KEYS", "KIND_ACCOUNT_SECRET", "ERROR_REFUSED", "ERROR_UNAVAILABLE",
    "ERROR_UNREADABLE", "ERROR_SAME_SECRET", "CredentialUnavailable", "RenewalFailed", "Renewed",
    "Lease", "subject_of", "renew_margin", "effective_need", "obtain", "current", "reject",
    "forget_local", "state", "remove", "store", "use_store", "db_store", "new_memory_store",
    "reset_local", "on_new_version", "memory_seconds", "renew_lease_seconds", "refused_seconds",
    "clear_refusals", "prune", "renew_soon", "ERROR_NOT_ENCRYPTED", "PayloadNotEncrypted", "owner_id",
]
