"""Filter at the SOURCE: a report parameter inside the dataset's own WHERE
(2026-10-29; docs/REPORT_SOURCE_FILTERS_2026_10_29.html).

The owner: "created dataset for reports is like hardcode values in where
clause for that query, it's not generic ... whatever where clause is there and
if user selects multiple values then that column should accept values as IN
clause and run directly on source ... two types of filter: filter data at
source and bring, and local filter."

A dataset's custom SQL carries literals in its WHERE::

    WHERE FACT_TETB.SYSTEM_ID IN ('SAPADB', 'MOTIFADJ')
      AND FACT_TETB.BUSINESS_CLOSE_DATE = CAST('2025-09-30' AS DATE)

A report on that dataset wraps the SQL from outside (``WITH qs_base AS (...)
SELECT .. WHERE <report filters>``), so until today a report could filter only
the formatted, already-grouped OUTPUT -- never those literals, and never a
column the query does not return (SYSTEM_ID).

This module makes the predicates of the WHERE *parameters*:

* :func:`discover` PARSES the SQL (sqlglot, never a regex) and lists each
  top-level AND-ed conjunct of the root SELECT's WHERE that is ``column <op>
  literal(s)`` as a :class:`SourcePredicate` -- its key (the column as the SQL
  spells it, lower-cased: ``fact_tetb.system_id``), its table (alias
  resolved), its operator, the literal values as text and their kind.  The
  literal IS the default: a report run without a value runs the query as
  written.
* :func:`apply` puts the values a report run supplies INTO those predicates:
  one value -> ``=``, several -> ``IN (...)``, a range -> ``BETWEEN``; the
  literal is rendered in the ORIGINAL literal's kind (a string quoted with its
  quotes doubled by sqlglot's own generator, a number that must parse as one,
  a DATE cast that must be an ISO date), and the new predicate's text is
  spliced into the author's SQL at the old conjunct's character span, so every
  other byte of the query is as written.  No binding -> the text untouched.
  An empty value NEVER removes the predicate (a partition predicate silently
  dropped would scan the ocean and return MORE rows); a predicate the SQL no
  longer has REFUSES (CLAUDE.md s4: a filter that cannot be rendered must
  refuse, never drop).
* :func:`split_filters` is how the federation engine tells a source binding
  (``{"source_column": key, ...}``) from a filter on an output column -- the
  ONE place the two kinds are told apart.

The decision (where a source parameter lives) is in the record: the
predicates are DERIVED from the dataset's SQL, never stored; the BINDING is a
report parameter's ``source_column``.  The dataset's SQL stays ONE text shared
by reports, published APIs, dashboards and feeds.

2026-11-12 (the owner, UAT, Snowflake: "report not working for a different
business date, works only for the hard-coded business date -- the parameter is
just filtering the existing dataset"; "query parameter is not always
hardcoded, it's dynamic and the value will be passed at run time").  A QUERY
PARAMETER replaces the value inside the dataset's own SQL and runs at the
source; a FILTER narrows the rows that came back.  Four things were missing:

* a date written through a function WITH A FORMAT
  (``TO_DATE('2025-09-30','YYYY-MM-DD')``, ``TO_DATE('30-SEP-25','DD-MON-RR')``,
  ``TO_TIMESTAMP(..)``, ``TRY_`` forms) is a literal: it is read with its own
  format into an ISO date, and a new value is written back INTO THE AUTHOR'S
  OWN function and format (an explicit parse stays an explicit parse);
* EVERY SELECT scope is read -- CTE bodies, FROM / JOIN derived tables, the
  UNION branches inside them -- not only the root (a subquery inside an
  expression, ``IN (SELECT ..)``, is not: its meaning differs);
* the SAME condition written in several scopes (both sides of a JOIN, each
  CTE) is ONE parameter: a value replaces it in every place;
* a ``{NAME}`` PLACEHOLDER in the SQL is a value the query ASKS for at run
  time: it is listed beside the conditions (key ``{name}``), filled by
  :func:`apply` through ``core.parameters.substitute_sql_params`` (the one
  type-safe renderer of feeds and raw-SQL reports), and a placeholder with no
  value REFUSES -- it is never sent to the source, never dropped.
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from datetime import date as _date, datetime as _datetime
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)

#: the key a filter dict carries when it binds a SOURCE predicate
SOURCE_KEY = "source_column"
#: the keys a source binding may carry (``value_type``: date | number | text,
#: the kind of value a PLACEHOLDER is filled with)
BINDING_KEYS = frozenset({SOURCE_KEY, "operator", "value", "value2", "value_type"})

#: operators a predicate may have; ``in`` and ``eq`` take one value or many
COMPARISON_OPS = {"EQ": "eq", "NEQ": "neq", "GT": "gt", "GTE": "gte", "LT": "lt", "LTE": "lte"}
_FLIP = {"gt": "lt", "gte": "lte", "lt": "gt", "lte": "gte", "eq": "eq", "neq": "neq"}
_OP_WORDS = {"eq": "=", "neq": "<>", "gt": ">", "gte": ">=", "lt": "<", "lte": "<=",
             "in": "IN", "between": "BETWEEN"}

_DATE_KINDS = ("cast:DATE",)
_TIMESTAMP_PREFIXES = ("cast:TIMESTAMP", "cast:DATETIME")

#: the operator of a ``{NAME}`` placeholder entry (key ``{name}``)
PLACEHOLDER_OP = "placeholder"
_PH_DATE, _PH_LIST, _PH_TEXT = "placeholder:date", "placeholder:list", "placeholder:text"
#: an operator that FIXES its column to the values the query names
_FIXING_OPS = ("eq", "in", "between")


class SourceFilterRefused(ValueError):
    """A source binding that cannot be rendered.  Always a sentence a support
    person can act on; the routes answer it as a 422 (``http_status`` is what
    ``api.connector_errors.refusal_status`` -- the one status rule -- reads)."""
    http_status = 422
    #: the ``{NAME}``s nobody gave a value, when THAT is the refusal (as the query
    #: spells them) -- a route that knows which control fills one can say "pick it first"
    missing: Tuple[str, ...] = ()


@dataclass(frozen=True)
class SourcePredicate:
    key: str                 #: ``fact_tetb.system_id`` (``#2`` suffixed when a column recurs); ``{name}`` for a placeholder
    column: str              #: the column as spelled, ``SYSTEM_ID`` (a placeholder: its NAME as spelled)
    qualifier: str           #: the qualifier as spelled, ``FACT_TETB`` ('' when bare)
    table: str               #: the real table's bare name, lower-cased ('' when unknown)
    table_ref: str           #: the table as the SQL spells it (``icbg.fins.fact_tetb``)
    op: str                  #: eq | in | between | gt | gte | lt | lte | neq | placeholder
    values: Tuple[str, ...]  #: the literal(s) as text, in the query's order (a placeholder: its default, or none)
    kind: str                #: string | number | boolean | cast:<TYPE> | placeholder:<date|list|text>
    sql: str                 #: the conjunct as the query spells it (a placeholder: the line that asks)
    index: int               #: its position among its WHERE's AND-ed conjuncts (-1: a placeholder)
    places: int = 1          #: how many places of the query a value replaces (2026-11-12)
    value_column: str = ""   #: a placeholder compared with a column: that column (its choices)
    #: a ``{NAME}``: does the DATASET declare it (``sql_param_defaults`` names it)?  An
    #: undeclared one is plain text of the query -- sent as written -- until a report
    #: parameter is linked to it.
    declared: bool = True

    @property
    def is_placeholder(self) -> bool:
        return self.op == PLACEHOLDER_OP

    @property
    def is_date(self) -> bool:
        if self.kind in _DATE_KINDS or self.kind == _PH_DATE:
            return True
        return self.kind == "string" and bool(self.values) and all(_iso_date(v) for v in self.values)

    @property
    def parameter_type(self) -> Optional[str]:
        """The report parameter type this predicate is offered as, or None
        when no parameter type carries its shape (a BETWEEN on a number)."""
        if self.is_placeholder:
            return "date" if self.kind == _PH_DATE else ("multi_select" if self.kind == _PH_LIST else "text")
        if self.op in ("eq", "in"):
            return "date" if self.is_date else "multi_select"
        if self.op == "between":
            return "date_range" if self.is_date else None
        if self.is_date:
            return "date"
        return "numeric" if self.kind == "number" else "text"

    @property
    def values_source(self) -> str:
        return "any" if self.is_date else "auto"

    @property
    def default_words(self) -> str:
        """Plain words for the screen: what the query uses without a value."""
        vals = ", ".join(self.values)
        if self.op == "between":
            return f"from {self.values[0]} to {self.values[1]}"
        if self.op in ("eq", "in", PLACEHOLDER_OP):
            return vals
        return f"{_OP_WORDS[self.op]} {vals}"

    @property
    def words(self) -> str:
        if self.is_placeholder:
            if not self.declared:
                return ("This looks like a value asked at run time. The dataset does not declare it, so "
                        "it is sent as written; link a report parameter to it to ask for it.")
            if self.values:
                return (f"The dataset's query asks for this value each time it runs. Without a value "
                        f"it uses: {self.default_words}")
            return ("The dataset's query asks for this value each time it runs. Without a value "
                    "the report does not run.")
        return f"Without a value the report uses what the query says: {self.default_words}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key, "column": self.column, "qualifier": self.qualifier,
            "table": self.table, "table_ref": self.table_ref, "op": self.op, "values": list(self.values),
            "value_kind": self.kind, "sql": self.sql, "is_date": self.is_date,
            "parameter_type": self.parameter_type, "values_source": self.values_source,
            "offered": self.parameter_type is not None,
            "words": self.words,
            "places": self.places, "placeholder": self.is_placeholder,
            "declared": bool(self.declared),
        }


@dataclass(frozen=True)
class Discovery:
    predicates: Tuple[SourcePredicate, ...] = ()
    declined: Tuple[Tuple[str, str], ...] = ()   #: (conjunct sql, why)
    reason: Optional[str] = None                 #: why NOTHING could be read
    #: conditions whose value IS a quoted placeholder (``D = '{BD}'``): not
    #: listed (the placeholder is), still found by their column key so a
    #: binding saved against one keeps running
    shadows: Tuple[SourcePredicate, ...] = ()
    #: ``(output column as the query names it, key of a LISTED entry)``: a column the query
    #: returns whose values the query itself FIXES (2026-11-12, the trap: a
    #: filter on the results can then only ever find those values)
    fixed: Tuple[Tuple[str, str], ...] = ()
    star: bool = False                           #: the root SELECT returns ``*``

    def by_key(self) -> Dict[str, SourcePredicate]:
        out = {p.key: p for p in self.shadows}
        out.update({p.key: p for p in self.predicates})
        return out

    @property
    def placeholders(self) -> Tuple[SourcePredicate, ...]:
        return tuple(p for p in self.predicates if p.is_placeholder)

    def fixed_for(self, output_name: Any) -> Optional[SourcePredicate]:
        """The condition (or placeholder) that fixes the values of the output
        column ``output_name``, else None."""
        name = str(output_name or "").strip().strip('"').lower()
        if not name:
            return None
        by_key = {p.key: p for p in self.predicates}
        for out, key in self.fixed:
            if out.lower() == name and key in by_key:
                return by_key[key]
        if self.star:
            for p in self.predicates:
                col = (p.value_column or p.column).lower()
                if col == name and (p.op in _FIXING_OPS or (p.is_placeholder and p.value_column)):
                    return p
        return None

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"filters": [p.to_dict() for p in self.predicates],
                               "declined": [{"sql": s, "reason": r} for s, r in self.declined]}
        if self.reason:
            out["reason"] = self.reason
        by_key = {p.key: p for p in self.predicates}
        out["fixed_outputs"] = [
            {"output": name, "key": key, "values": list(by_key[key].values),
             "placeholder": by_key[key].is_placeholder, "words": fixed_words(name, by_key[key])}
            for name, key in self.fixed if key in by_key]
        return out


def fixed_words(output_name: str, pred: SourcePredicate) -> str:
    """The plain sentence of the trap: a filter on the RESULTS of a column the
    query itself fixes can only ever find what the query read."""
    if pred.is_placeholder:
        return (f"The dataset's query reads {output_name} for the one value it is given when it runs. "
                f"A filter on the results cannot bring another; fill the query's value instead "
                f"(Filter at the source).")
    return (f"The dataset's query only reads {output_name} {_fixed_values_words(pred)}. A filter on the "
            f"results cannot bring another value; put the value into the query instead "
            f"(Filter at the source).")


def _fixed_values_words(pred: SourcePredicate) -> str:
    if pred.op == "between":
        return f"from {pred.values[0]} to {pred.values[1]}"
    return "= " + ", ".join(pred.values)


# ── placeholders: a value the query ASKS for at run time ────────────────────

from core.parameters import PARAM_RE as _PARAM_RE   # noqa: E402  -- THE ``{NAME}`` vocabulary

_MARK_OPEN, _MARK_CLOSE = "", ""      # around a BARE placeholder while the SQL is parsed
_PROTECTED = re.compile("'" + _MARK_OPEN + r"(\{[A-Za-z_][A-Za-z0-9_]*\})" + _MARK_CLOSE + "'")
_WHOLE_DATE = re.compile(r"\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}(:\d{2}(\.\d{1,9})?)?)?")
_IN_BEFORE = re.compile(r"\bIN\s*\(\s*'?$", re.I)
_IN_AFTER = re.compile(r"^'?\s*\)")


def placeholder_key(name: Any) -> str:
    return "{" + str(name or "").strip().strip("{}").lower() + "}"


def is_placeholder_key(key: Any) -> bool:
    k = str(key or "").strip()
    return len(k) > 2 and k.startswith("{") and k.endswith("}")


def _placeholder_keys_of(values: Iterable[str]) -> List[str]:
    return [placeholder_key(m.group(1)) for v in values for m in _PARAM_RE.finditer(str(v))]


def _placeholder_sites(sql: str) -> List[Tuple[str, int, int, bool]]:
    """``(name, start, end, inside the author's quotes)`` for every ``{NAME}``
    of ``sql`` that is SQL -- not one in a comment or a quoted identifier, and
    not a doubled ``{{NAME}}`` (another vocabulary's spelling)."""
    return [s for s in _brace_sites(sql)
            if not (s[1] > 0 and sql[s[1] - 1] == "{" and sql[s[2]:s[2] + 1] == "}")]


def _brace_sites(sql: str) -> List[Tuple[str, int, int, bool]]:
    out: List[Tuple[str, int, int, bool]] = []
    i, n = 0, len(sql)
    while i < n:
        ch = sql[i]
        if ch == "-" and sql.startswith("--", i):
            j = sql.find("\n", i)
            i = n if j < 0 else j + 1
        elif ch == "/" and sql.startswith("/*", i):
            j = sql.find("*/", i + 2)
            i = n if j < 0 else j + 2
        elif ch == '"':
            j = sql.find('"', i + 1)
            i = n if j < 0 else j + 1
        elif ch == "'":
            j = i + 1
            while j < n:
                if sql[j] == "'":
                    if j + 1 < n and sql[j + 1] == "'":
                        j += 2
                        continue
                    break
                j += 1
            for m in _PARAM_RE.finditer(sql, i + 1, min(j, n)):
                out.append((m.group(1), m.start(), m.end(), True))
            i = j + 1
        elif ch == "{":
            m = _PARAM_RE.match(sql, i)
            if m:
                out.append((m.group(1), m.start(), m.end(), False))
                i = m.end()
            else:
                i += 1
        else:
            i += 1
    return out


def placeholders(sql: Any) -> List[str]:
    """The ``{NAME}`` placeholders of ``sql`` as spelled, each once, in order."""
    seen, out = set(), []
    for name, _s, _e, _q in _placeholder_sites(str(sql or "")):
        if name.lower() not in seen:
            seen.add(name.lower())
            out.append(name)
    return out


def declared_names(defaults: Optional[Dict[str, Any]], extra: Iterable[str] = ()) -> set:
    """The names (lower-cased) that ARE placeholders: the ones the dataset
    names in its ``sql_param_defaults`` (with or without a value) and the ones
    a run names (a report parameter linked to it, or named like it).

    2026-11-12 (review): ``{word}`` inside a dataset's SQL was sent as written
    before this module read placeholders -- ``LIKE '%{id}%'``, ``'a{b}'`` -- so
    only a DECLARED name is a placeholder; any other ``{word}`` is the query's
    own text and is left exactly as it is."""
    return {str(k).strip().lower() for k in (defaults or {})} | {str(n).strip().lower() for n in extra}


def asked(sql: Any, defaults: Optional[Dict[str, Any]] = None, extra: Iterable[str] = ()) -> List[str]:
    """The DECLARED placeholders of ``sql`` as spelled, each once, in order."""
    names = declared_names(defaults, extra)
    return [n for n in placeholders(sql) if n.lower() in names] if names else []


def _protect(sql: str) -> str:
    """``sql`` with every BARE placeholder written as a marked string literal,
    so the parser reads the statement; :func:`_unprotect` is its exact inverse."""
    out = sql
    for name, start, end, quoted in reversed(_placeholder_sites(sql)):
        if not quoted:
            out = out[:start] + "'" + _MARK_OPEN + "{" + name + "}" + _MARK_CLOSE + "'" + out[end:]
    return out


def parse_text(sql: Any) -> str:
    """``sql`` as a text a SQL PARSER reads: a bare ``{NAME}`` stands as a
    quoted value.  For reading the query's SHAPE only -- never to run."""
    out = _protect(str(sql or ""))
    return out.replace(_MARK_OPEN, "").replace(_MARK_CLOSE, "") if _MARK_OPEN in out else out


def _unprotect(sql: str) -> str:
    return _PROTECTED.sub(lambda m: m.group(1), sql) if _MARK_OPEN in sql else sql


def _in_list_site(sql: str, start: int, end: int) -> bool:
    return bool(_IN_BEFORE.search(sql[max(0, start - 40):start]) and _IN_AFTER.match(sql[end:end + 40]))


# ── reading the SQL ─────────────────────────────────────────────────────────

def _iso_date(text: str) -> bool:
    t = str(text or "")
    if len(t) < 10 or t[4] != "-" or t[7] != "-":
        return False
    try:
        _date.fromisoformat(t[:10])
    except ValueError:
        return False
    return True


class _Unreadable(Exception):
    """A value the product will not guess at; its text is the reason."""


# a date written through a function WITH A FORMAT.  sqlglot hands the format
# over half-translated (``%d-%b-RR`` for Oracle's DD-MON-RR) or untouched (a
# dialect that does not know the function), so ONE reader takes both spellings.
_MONTHS = ("january", "february", "march", "april", "may", "june", "july", "august",
           "september", "october", "november", "december")
_FMT_RAW = (("YYYY", "Y"), ("RRRR", "Y"), ("MONTH", "B"), ("MON", "b"), ("HH24", "H"),
            ("YY", "y"), ("RR", "r"), ("MM", "m"), ("DD", "d"), ("MI", "M"), ("SS", "S"))
_FMT_PCT = {"Y": "Y", "y": "y", "m": "m", "d": "d", "b": "b", "B": "B", "H": "H", "M": "M", "S": "S", "f": "f"}
_FMT_RE = {"Y": r"(\d{4})", "y": r"(\d{2})", "r": r"(\d{2})", "m": r"(\d{1,2})", "d": r"(\d{1,2})",
           "b": r"([A-Za-z]{3})", "B": r"([A-Za-z]{3,9})", "H": r"(\d{1,2})", "M": r"(\d{1,2})",
           "S": r"(\d{1,2})", "f": r"(\d{1,9})"}
_TYPED_FORMAT_CALLS = {"TsOrDsToDate": "DATE", "StrToDate": "DATE", "StrToTime": "TIMESTAMP"}
_NAMED_FORMAT_CALLS = {"TO_DATE": "DATE", "TRY_TO_DATE": "DATE", "TO_TIMESTAMP": "TIMESTAMP",
                       "TRY_TO_TIMESTAMP": "TIMESTAMP", "TO_TIMESTAMP_NTZ": "TIMESTAMP"}


def _fmt_elements(fmt: str) -> List[Tuple[str, str]]:
    """``[(part, text)]`` of a date format; part '' = text kept as written."""
    out: List[Tuple[str, str]] = []
    i, n, up, pct = 0, len(fmt), fmt.upper(), "%" in fmt
    while i < n:
        ch = fmt[i]
        if ch == "%":
            j = i + 1
            if j < n and fmt[j] == "-":
                j += 1
            if j >= n or fmt[j] not in _FMT_PCT:
                raise _Unreadable(f"its format has a part that is not read ({fmt[i:j + 1]})")
            out.append((_FMT_PCT[fmt[j]], fmt[i:j + 1]))
            i = j + 1
            if fmt.startswith("strict", i):                    # sqlglot's spelling of Spark's MM / dd
                i += len("strict")
            continue
        if ch == '"':
            j = fmt.find('"', i + 1)
            if j < 0:
                raise _Unreadable("its format has an unclosed quote")
            out.extend(("", c) for c in fmt[i + 1:j])
            i = j + 1
            continue
        for raw, part in _FMT_RAW:
            if up.startswith(raw, i):
                out.append((part, fmt[i:i + len(raw)]))
                i += len(raw)
                break
        else:
            if ch.isalpha() and not (pct and ch in "TZ"):
                j = i
                while j < n and fmt[j].isalnum():
                    j += 1
                raise _Unreadable(f"its format has a part that is not read ({fmt[i:j]})")
            out.append(("", ch))
            i += 1
    parts = [p for p, _t in out if p]
    if len(set(parts)) != len(parts):
        raise _Unreadable("its format names the same part twice")
    return out


def _fmt_match(text: str, elements: List[Tuple[str, str]]) -> Dict[str, str]:
    rx = "".join(_FMT_RE[p] if p else re.escape(t) for p, t in elements)
    m = re.fullmatch(rx, text.strip())
    if not m:
        raise _Unreadable("the value does not match its format")
    return dict(zip([p for p, _t in elements if p], m.groups()))


def _read_with_format(text: str, fmt: str, target: str) -> str:
    """The ISO text of ``text`` read with ``fmt`` (DATE: ``YYYY-MM-DD``;
    TIMESTAMP: ``YYYY-MM-DD HH:MM:SS``), or :class:`_Unreadable` -- never a
    guessed date."""
    got = _fmt_match(text, _fmt_elements(fmt))
    if "Y" in got:
        year = int(got["Y"])
    elif "r" in got:
        yy = int(got["r"])
        year = 2000 + yy if yy < 50 else 1900 + yy          # Oracle RR, read in 2000-2049
    elif "y" in got:
        yy = int(got["y"])
        if yy >= 50:
            raise _Unreadable("a two-digit year above 49 can mean two centuries")
        year = 2000 + yy
    else:
        raise _Unreadable("its format has no year")
    if "m" in got:
        month = int(got["m"])
    elif "b" in got or "B" in got:
        word = (got.get("b") or got.get("B") or "").lower()
        hits = [i + 1 for i, name in enumerate(_MONTHS)
                if (name[:3] == word if "b" in got else name == word or name[:3] == word)]
        if len(hits) != 1:
            raise _Unreadable(f"'{word}' is not a month")
        month = hits[0]
    else:
        raise _Unreadable("its format has no month")
    if "d" not in got:
        raise _Unreadable("its format has no day")
    try:
        day = _date(year, month, int(got["d"]))
    except ValueError:
        raise _Unreadable("it is not a day of the calendar")
    hh, mi, ss = int(got.get("H", 0)), int(got.get("M", 0)), int(got.get("S", 0))
    frac = got.get("f", "")
    if hh > 23 or mi > 59 or ss > 59:
        raise _Unreadable("it is not a time of the day")
    if target == "DATE":
        if hh or mi or ss or frac.strip("0"):
            raise _Unreadable("it carries a time of day")
        return day.isoformat()
    out = f"{day.isoformat()} {hh:02d}:{mi:02d}:{ss:02d}"
    return out + (f".{frac}" if frac.strip("0") else "")


def _write_with_format(iso: str, fmt: str, target: str, like: str = "") -> str:
    """``iso`` written in ``fmt`` -- the inverse of :func:`_read_with_format`,
    PROVEN by reading the text back.  ``like`` = the author's own value: a
    month name takes its case."""
    elements = _fmt_elements(fmt)
    t = str(iso).strip().replace("T", " ").replace("Z", "")
    day = _date.fromisoformat(t[:10])
    clock = (t[11:] or "00:00:00").split(".")
    hms = (clock[0].split(":") + ["0", "0"])[:3]
    frac = clock[1] if len(clock) > 1 else ""
    style = str.upper
    try:
        word = next((v for p, v in _fmt_match(like, elements).items() if p in ("b", "B")), "")
        style = str.lower if word.islower() else (str.upper if word.isupper() else str.capitalize)
    except Exception:                                          # noqa: BLE001  -- no value to copy the case of
        pass
    made = {"Y": f"{day.year:04d}", "y": f"{day.year % 100:02d}", "r": f"{day.year % 100:02d}",
            "m": f"{day.month:02d}", "d": f"{day.day:02d}",
            "b": style(_MONTHS[day.month - 1][:3]), "B": style(_MONTHS[day.month - 1]),
            "H": f"{int(hms[0]):02d}", "M": f"{int(hms[1]):02d}", "S": f"{int(hms[2]):02d}", "f": frac or "0"}
    out = "".join(made[p] if p else txt for p, txt in elements)
    want = day.isoformat() if target == "DATE" else _read_with_format(
        f"{day.isoformat()} {int(hms[0]):02d}:{int(hms[1]):02d}:{int(hms[2]):02d}" + (f".{frac}" if frac else ""),
        "%Y-%m-%d %H:%M:%S" + (".%f" if frac else ""), "TIMESTAMP")
    if _read_with_format(out, fmt, target) != want:
        raise _Unreadable("the value cannot be written in the query's format without changing it")
    return out


def _format_call(node: Any, exp: Any) -> Optional[Tuple[Any, str, str]]:
    """``(the value's literal node, its format, DATE | TIMESTAMP)`` when
    ``node`` is a date function over a string literal WITH a format."""
    name = type(node).__name__
    if name in _TYPED_FORMAT_CALLS:
        lit, fmt = getattr(node, "this", None), node.args.get("format")
        if isinstance(lit, exp.Literal) and lit.is_string and isinstance(fmt, exp.Literal) and fmt.is_string:
            return lit, str(fmt.this), _TYPED_FORMAT_CALLS[name]
        return None
    if name == "Anonymous":
        fn, args = str(node.this or "").upper(), list(node.expressions or [])
        if fn in _NAMED_FORMAT_CALLS and len(args) == 2 and all(
                isinstance(a, exp.Literal) and a.is_string for a in args):
            return args[0], str(args[1].this), _NAMED_FORMAT_CALLS[fn]
    return None


def _conjuncts(where_node: Any, exp: Any) -> List[Any]:
    """The top-level AND-ed terms of a WHERE, parentheses stripped, in order."""
    out, stack = [], [where_node.this]
    while stack:
        n = stack.pop()
        if isinstance(n, exp.And):
            stack.extend((n.right, n.left))
        elif isinstance(n, exp.Paren):
            stack.append(n.this)
        else:
            out.append(n)
    return out


def _literal(node: Any, exp: Any, dialect: Optional[str]) -> Optional[Tuple[str, str]]:
    """``(text, kind)`` for a literal node, else None.  Raises
    :class:`_Unreadable` for a date function whose value cannot be read with
    its own format."""
    if isinstance(node, exp.Literal):
        return (str(node.this), "string" if node.is_string else "number")
    if isinstance(node, exp.Neg) and isinstance(node.this, exp.Literal) and not node.this.is_string:
        return (f"-{node.this.this}", "number")
    if isinstance(node, exp.Boolean):
        return ("true" if node.this else "false", "boolean")
    if isinstance(node, (exp.Cast, exp.TryCast)) and isinstance(node.this, exp.Literal) \
            and node.this.is_string and node.args.get("to") is not None:
        return (str(node.this.this), f"cast:{node.args['to'].sql(dialect=dialect).upper()}")
    # typed literals some dialects parse as wrapper nodes (DATE '..')
    if type(node).__name__ in ("Date", "DateStr") and isinstance(getattr(node, "this", None), exp.Literal):
        return (str(node.this.this), "cast:DATE")
    if type(node).__name__ in ("Timestamp", "TimeStr") and isinstance(getattr(node, "this", None), exp.Literal):
        return (str(node.this.this), "cast:TIMESTAMP")
    # 2026-11-12 -- a date function over a literal WITH A FORMAT
    call = _format_call(node, exp)
    if call is not None:
        lit, fmt, target = call
        text = str(lit.this)
        if _PARAM_RE.search(text):
            return (text, f"cast:{target}")                    # a placeholder: filled at run time
        try:
            return (_read_with_format(text, fmt, target), f"cast:{target}")
        except _Unreadable as exc:
            raise _Unreadable(f"the date in {node.sql(dialect=dialect)} cannot be read with its format "
                              f"({exc}), so the report cannot replace it safely")
    if type(node).__name__ == "TsOrDsToDate" and node.args.get("format") is None \
            and isinstance(getattr(node, "this", None), exp.Literal) and node.this.is_string \
            and (_iso_date(str(node.this.this)) or _PARAM_RE.search(str(node.this.this))):
        return (str(node.this.this), "cast:DATE")
    return None


def _template(node: Any, exp: Any) -> Optional[Any]:
    """The date-function node a new value is written back into, else None."""
    return node if node is not None and _format_call(node, exp) is not None else None


def _template_shape(node: Any, exp: Any, dialect: Optional[str]) -> str:
    call = _format_call(node, exp) if node is not None else None
    return "" if call is None else f"{type(node).__name__}:{getattr(node, 'this', '') if type(node).__name__ == 'Anonymous' else ''}:{call[1]}"


def _column(node: Any, exp: Any) -> Optional[Tuple[str, str]]:
    """``(column, qualifier)`` as spelled for a bare column reference."""
    if isinstance(node, exp.Column) and isinstance(node.this, exp.Identifier):
        return (node.name, node.table or "")
    return None


def _alias_map(select: Any, exp: Any, dialect: Optional[str]) -> Tuple[Dict[str, Tuple[str, str]], str]:
    """``{alias_or_table_lower: (table_bare_lower, table as spelled)}`` for the
    scope's FROM / JOINs, and the one table's alias-or-name when the scope reads
    exactly one (else '')."""
    out: Dict[str, Tuple[str, str]] = {}
    tables: List[str] = []
    frm = select.args.get("from_") or select.args.get("from")
    nodes = [frm.this] if frm is not None else []
    for j in select.args.get("joins") or []:
        nodes.append(j.this)
    for t in nodes:
        if not isinstance(t, exp.Table):
            continue
        bare = str(t.name or "").lower()
        if not bare:
            continue
        ref = exp.Table(this=t.this, db=t.args.get("db"), catalog=t.args.get("catalog")).sql(dialect=dialect)
        tables.append(bare)
        out[bare] = (bare, ref)
        if t.alias:
            out[str(t.alias).lower()] = (bare, ref)
    return out, (tables[0] if len(tables) == 1 else "")


def _classify(term: Any, exp: Any, dialect: Optional[str]) -> Tuple[Optional[Dict[str, Any]], str]:
    """One conjunct -> ``(predicate fields, '')`` or ``(None, why declined)``."""
    try:
        return _classify_term(term, exp, dialect)
    except _Unreadable as exc:
        return None, str(exc)


def _classify_term(term: Any, exp: Any, dialect: Optional[str]) -> Tuple[Optional[Dict[str, Any]], str]:
    if isinstance(term, exp.Or):
        return None, "an OR: the report cannot replace one branch of it"
    if isinstance(term, exp.Not):
        return None, "a NOT: not offered"
    if isinstance(term, exp.In):
        col = _column(term.this, exp)
        if not col:
            return None, "the left side is not a plain column"
        if term.args.get("query") is not None or not term.expressions:
            return None, "IN over a subquery: not offered"
        lits = [_literal(e, exp, dialect) for e in term.expressions]
        if any(l is None for l in lits):
            return None, "a value in the IN list is not a literal"
        kinds = {k for _, k in lits}
        if len(kinds) != 1 or len({_template_shape(e, exp, dialect) for e in term.expressions}) != 1:
            return None, "the IN list mixes kinds of literal"
        return {"col": col, "op": "in", "values": tuple(t for t, _ in lits), "kind": kinds.pop(),
                "tmpl": _template(term.expressions[0], exp)}, ""
    if isinstance(term, exp.Between):
        col = _column(term.this, exp)
        low, high = term.args.get("low"), term.args.get("high")
        lo, hi = _literal(low, exp, dialect), _literal(high, exp, dialect)
        if not col:
            return None, "the left side is not a plain column"
        if lo is None or hi is None or lo[1] != hi[1] \
                or _template_shape(low, exp, dialect) != _template_shape(high, exp, dialect):
            return None, "a BETWEEN bound is not a literal"
        return {"col": col, "op": "between", "values": (lo[0], hi[0]), "kind": lo[1],
                "tmpl": _template(low, exp)}, ""
    op = COMPARISON_OPS.get(type(term).__name__)
    if not op:
        return None, "not 'column <op> value'"
    col, lit, node = _column(term.left, exp), _literal(term.right, exp, dialect), term.right
    if col is None or lit is None:
        col2, lit2 = _column(term.right, exp), _literal(term.left, exp, dialect)
        if col2 is None or lit2 is None:
            if _column(term.left, exp) and _column(term.right, exp):
                return None, "a column on both sides"
            plain = term.right if _column(term.left, exp) else (term.left if _column(term.right, exp) else None)
            if plain is not None and plain.find(exp.Column) is None:
                # 2026-11-12 -- the COLUMN is plain; it is the VALUE that is computed
                return None, ("the value is worked out by a function or expression, not written as a "
                              "plain value the report can replace")
            return None, ("the column is inside a function or expression"
                          if term.find(exp.Column) is not None else "no column")
        col, lit, op, node = col2, lit2, _FLIP[op], term.left
    return {"col": col, "op": op, "values": (lit[0],), "kind": lit[1], "tmpl": _template(node, exp)}, ""


# ── every SELECT scope of the statement ─────────────────────────────────────

class _Scope:
    """One SELECT of the statement: the root, a CTE body, a derived table in a
    FROM / JOIN, a UNION branch inside one of those."""
    __slots__ = ("select", "no", "conjuncts", "fields", "aliases", "single", "sources")

    def __init__(self, select: Any, no: int):
        self.select, self.no = select, no
        self.conjuncts: List[Any] = []
        self.fields: List[Optional[Dict[str, Any]]] = []
        self.aliases: Dict[str, Tuple[str, str]] = {}
        self.single = ""
        self.sources: Dict[str, Any] = {}          # alias -> the query node it names (a CTE / derived table)


def _set_operation(exp: Any) -> Any:
    return getattr(exp, "SetOperation", None) or exp.Union


def _selects_of(node: Any, exp: Any) -> List[Any]:
    """The SELECTs a query node IS (a UNION: each branch)."""
    while isinstance(node, (exp.Subquery, exp.Paren)):
        node = node.this
    if isinstance(node, exp.Select):
        return [node]
    if isinstance(node, _set_operation(exp)):
        return _selects_of(node.this, exp) + _selects_of(node.expression, exp)
    return []


def _walk_scopes(root: Any, exp: Any) -> List[_Scope]:
    """Every scope, the ROOT first, then nested ones in the order written:
    a SELECT's CTE bodies, then its FROM / JOIN derived tables, recursively.
    A subquery inside an expression is NOT a scope of this walk."""
    scopes: List[_Scope] = []
    seen: set = set()

    def visit(select: Any, ctes: Dict[str, Any]) -> None:
        if id(select) in seen:
            return
        seen.add(id(select))
        scope = _Scope(select, len(scopes))
        scopes.append(scope)
        visible = dict(ctes)
        nested: List[Any] = []
        with_ = select.args.get("with_") or select.args.get("with")
        for cte in (with_.expressions if with_ is not None else []):
            for sub in _selects_of(cte.this, exp):
                nested.append((sub, dict(visible)))
            if cte.alias:
                visible[str(cte.alias).lower()] = cte.this
        frm = select.args.get("from_") or select.args.get("from")
        for t in ([frm.this] if frm is not None else []) + [j.this for j in select.args.get("joins") or []]:
            if isinstance(t, exp.Subquery):
                if t.alias:
                    scope.sources[str(t.alias).lower()] = t.this
                for sub in _selects_of(t.this, exp):
                    nested.append((sub, dict(visible)))
            elif isinstance(t, exp.Table) and not t.args.get("db") and str(t.name or "").lower() in visible:
                scope.sources[str(t.alias or t.name).lower()] = visible[str(t.name).lower()]
        for sub, env in nested:
            visit(sub, env)

    visit(root, {})
    return scopes


class _Group:
    """One KEY: a condition, in every place the query writes it."""
    __slots__ = ("key", "sig", "sites", "column", "qualifier", "table", "table_ref", "op", "values",
                 "kind", "sql", "index", "shadow", "bare")

    def predicate(self) -> SourcePredicate:
        return SourcePredicate(key=self.key, column=self.column, qualifier=self.qualifier, table=self.table,
                               table_ref=self.table_ref, op=self.op, values=self.values, kind=self.kind,
                               sql=self.sql, index=self.index, places=len(self.sites))


class _Analysis:
    __slots__ = ("tree", "scopes", "groups", "declined", "reason", "fixed", "star")

    def __init__(self) -> None:
        self.tree, self.scopes, self.groups = None, [], []
        self.declined: List[Tuple[str, str]] = []
        self.reason: Optional[str] = None
        self.fixed: List[Tuple[str, str]] = []
        self.star = False


def _unmark(text: str) -> str:
    return text.replace(_MARK_OPEN, "").replace(_MARK_CLOSE, "") if _MARK_OPEN in text else text


def _sig_kind(kind: str, values: Tuple[str, ...]) -> str:
    """Kinds that mean the same DAY group together (a plain '2025-09-30' on
    one side of a JOIN, a TO_DATE of it on the other)."""
    if kind in _DATE_KINDS or (kind == "string" and values and all(len(v) == 10 and _iso_date(v) for v in values)):
        return "date"
    return kind


def _analyse(text: str, dialect: Optional[str]) -> _Analysis:
    """Parse ``text`` (bare placeholders already protected) and read every
    scope's WHERE.  Never raises."""
    an = _Analysis()
    try:
        import sqlglot
        from sqlglot import exp
    except Exception as exc:                                   # pragma: no cover
        an.reason = f"sqlglot is not available: {exc}"
        return an
    try:
        tree = sqlglot.parse_one(text, read=dialect)
    except Exception as exc:                                   # noqa: BLE001
        an.reason = f"The dataset's SQL could not be read: {_unprotect(str(exc).splitlines()[0][:200])}"
        return an
    if not isinstance(tree, exp.Select):
        an.reason = (f"The dataset's SQL is not a single SELECT ({type(tree).__name__}), "
                     "so its conditions cannot be offered as parameters.")
        return an
    an.tree = tree
    an.scopes = _walk_scopes(tree, exp)
    if all(s.select.args.get("where") is None for s in an.scopes):
        an.reason = "The dataset's SQL has no WHERE, so there is no condition to open up."
        return an
    seen: Dict[str, int] = {}
    site_key: Dict[Tuple[int, int], str] = {}
    for scope in an.scopes:
        where = scope.select.args.get("where")
        scope.aliases, scope.single = _alias_map(scope.select, exp, dialect)
        if where is None:
            continue
        scope.conjuncts = _conjuncts(where, exp)
        for i, term in enumerate(scope.conjuncts):
            fields, why = _classify(term, exp, dialect)
            scope.fields.append(fields)
            shown = _unprotect(term.sql(dialect=dialect))
            if fields is None:
                an.declined.append((shown, why))
                continue
            column, qualifier = fields["col"]
            marked = any(_MARK_OPEN in v for v in fields["values"])
            values = tuple(_unmark(v) for v in fields["values"])
            fields["values"] = values
            table, table_ref = scope.aliases.get(qualifier.lower() if qualifier else scope.single,
                                                 (qualifier.lower(), qualifier))
            # 2026-11-12 (review): the SAME TABLE's column.  ``region = 'EU'`` over shipments in a
            # CTE and over orders in the root are two conditions that happen to look alike; one
            # key would rewrite both.  A scope whose table is not known (it reads a derived
            # table, or several with no qualifier) never joins another.
            real = str(table_ref or table or "").lower() if (qualifier.lower() if qualifier else scope.single) \
                in scope.aliases else ""
            sig = (real, column.lower(), fields["op"], _sig_kind(fields["kind"], values), values)
            group = None
            if scope.no > 0 and real:
                # the SAME condition on the SAME table in ANOTHER scope is one parameter; within
                # one scope nothing is grouped
                group = next((g for g in an.groups if g.sig == sig and all(s[0] != scope.no for s in g.sites)), None)
            if group is None:
                base_key = f"{qualifier}.{column}".lower() if qualifier else column.lower()
                n = seen.get(base_key, 0) + 1
                seen[base_key] = n
                group = _Group()
                group.key = base_key if n == 1 else f"{base_key}#{n}"
                group.sig, group.sites = sig, []
                group.column, group.qualifier, group.table, group.table_ref = column, qualifier, table, table_ref
                group.op, group.values, group.kind, group.sql, group.index = (
                    fields["op"], values, fields["kind"], shown, i)
                group.shadow = any(_PARAM_RE.search(v) for v in values)
                group.bare = marked
                an.groups.append(group)
            group.sites.append((scope.no, i))
            site_key[(scope.no, i)] = group.key
    _trace_fixed(an, site_key, exp)
    return an


def _trace_fixed(an: _Analysis, site_key: Dict[Tuple[int, int], str], exp: Any) -> None:
    """Which OUTPUT columns of the root SELECT the query itself fixes: the
    column is followed through the derived tables / CTEs it comes from to a
    scope whose WHERE pins it (``=``, ``IN``, ``BETWEEN``)."""
    by_select = {id(s.select): s for s in an.scopes}

    def own_columns(scope: _Scope, node: Any) -> List[Tuple[str, str]]:
        out = []
        for c in node.find_all(exp.Column):
            if c.find_ancestor(exp.Select) is scope.select and isinstance(c.this, exp.Identifier):
                pair = (str(c.table or "").lower(), str(c.name or "").lower())
                if pair not in out:
                    out.append(pair)
        return out

    def fixed_in(scope: _Scope, qualifier: str, name: str, depth: int) -> Optional[str]:
        for i, f in enumerate(scope.fields):
            if f is None or f["op"] not in _FIXING_OPS:
                continue
            col, q = str(f["col"][0]).lower(), str(f["col"][1]).lower()
            if col == name and (not q or not qualifier or q == qualifier):
                return site_key.get((scope.no, i))
        if depth >= 6:
            return None
        sources = ([scope.sources[qualifier]] if qualifier in scope.sources else
                   ([] if qualifier else list(scope.sources.values())))
        for node in sources:
            subs = [by_select[id(s)] for s in _selects_of(node, exp) if id(s) in by_select]
            if len(subs) != 1:
                continue                      # a UNION: every branch would have to fix it -- not claimed
            sub = subs[0]
            for e in sub.select.expressions:
                if isinstance(e, exp.Star) or (isinstance(e, exp.Column) and isinstance(e.this, exp.Star)):
                    hit = fixed_in(sub, "", name, depth + 1)
                    if hit:
                        return hit
                    continue
                if str(e.alias_or_name or "").lower() != name:
                    continue
                cols = own_columns(sub, e)
                if len(cols) == 1:
                    hit = fixed_in(sub, cols[0][0], cols[0][1], depth + 1)
                    if hit:
                        return hit
        return None

    root = an.scopes[0]
    for e in root.select.expressions:
        if isinstance(e, exp.Star) or (isinstance(e, exp.Column) and isinstance(e.this, exp.Star)):
            an.star = True
            continue
        out_name = str(e.alias_or_name or "")
        cols = own_columns(root, e)
        if not out_name or len(cols) != 1:
            continue
        key = fixed_in(root, cols[0][0], cols[0][1], 0)
        if key:
            an.fixed.append((out_name, key))


def discover(sql: str, dialect: Optional[str] = None,
             defaults: Optional[Dict[str, Any]] = None) -> Discovery:
    """The source conditions of EVERY SELECT scope of ``sql`` and the
    ``{NAME}`` placeholders it asks for.  ``defaults`` = the dataset's value for
    a placeholder nobody fills (shown as its default).  Never raises."""
    text = str(sql or "").strip().rstrip(";")
    if not text:
        return Discovery(reason="The dataset has no SQL of its own.")
    sites = _placeholder_sites(text)
    an = _analyse(_protect(text) if sites else text, dialect)
    listed = [g.predicate() for g in an.groups if not g.shadow]
    shadows = [g.predicate() for g in an.groups if g.shadow and not g.bare]
    all_shadows = [g for g in an.groups if g.shadow]
    from core.parameters import looks_like_date
    by_lower = {str(k).lower(): v for k, v in (defaults or {}).items() if v not in (None, "")}
    named = declared_names(defaults)
    seen: set = set()
    for name, start, end, _quoted in sites:
        low = name.lower()
        if low in seen:
            continue
        seen.add(low)
        mine = [(s, e) for n, s, e, _q in sites if n.lower() == low]
        over = next((g for g in all_shadows if placeholder_key(name) in _placeholder_keys_of(g.values)), None)
        if (over is not None and (over.kind in _DATE_KINDS or over.kind.startswith(_TIMESTAMP_PREFIXES))) \
                or looks_like_date(name):
            kind = _PH_DATE
        elif all(_in_list_site(text, s, e) for s, e in mine):
            kind = _PH_LIST
        else:
            kind = _PH_TEXT
        line_from = text.rfind("\n", 0, start) + 1
        line_to = text.find("\n", end)
        default = by_lower.get(low)
        listed.append(SourcePredicate(
            key=placeholder_key(name), column=name, qualifier="",
            table=over.table if over is not None else "", table_ref=over.table_ref if over is not None else "",
            op=PLACEHOLDER_OP,
            values=tuple(str(v) for v in (default if isinstance(default, (list, tuple)) else [default])
                         if v not in (None, "")) if default is not None else (),
            kind=kind, sql=text[line_from:(len(text) if line_to < 0 else line_to)].strip()[:300], index=-1,
            places=len(mine), value_column=over.column if over is not None else "",
            declared=low in named))
    declined = list(an.declined)
    reason = an.reason
    if reason and sites:
        # the placeholders are still what the query asks for
        declined.append(("the query's own conditions", reason))
        reason = None
    # a column fixed by a condition whose value is a placeholder is fixed by THAT placeholder
    via = {g.key: (_placeholder_keys_of(g.values) or [g.key])[0] for g in all_shadows}
    fixed = tuple((name, via.get(key, key)) for name, key in an.fixed)
    return Discovery(predicates=tuple(listed), declined=tuple(declined), reason=reason,
                     shadows=tuple(shadows), fixed=fixed, star=an.star)


_MEMO: Dict[Tuple[str, str, str], Discovery] = {}


def discover_cached(sql: str, dialect: Optional[str] = None,
                    defaults: Optional[Dict[str, Any]] = None) -> Discovery:
    """:func:`discover`, memoised by the text's digest (a pure function; the
    owner's 352-line query parses in tens of milliseconds, paid once)."""
    key = (hashlib.sha256(str(sql or "").encode("utf-8")).hexdigest(), str(dialect or ""),
           repr(sorted((str(k), str(v)) for k, v in (defaults or {}).items())) if defaults else "")
    hit = _MEMO.get(key)
    if hit is None:
        if len(_MEMO) > 256:
            _MEMO.clear()
        hit = _MEMO[key] = discover(sql, dialect, defaults)
    return hit


# ── the bindings a run supplies ─────────────────────────────────────────────

def is_source_binding(f: Any) -> bool:
    return isinstance(f, dict) and bool(f.get(SOURCE_KEY))


def split_filters(raw: Optional[Iterable[Any]]) -> Tuple[List[Dict[str, Any]], List[Any]]:
    """``(source bindings, the other filters)``.  A binding with a key this
    module does not know is refused here, so a misspelt ``values`` can never
    pass as an empty one (the engine's own rule for its filters)."""
    bindings: List[Dict[str, Any]] = []
    rest: List[Any] = []
    for f in raw or []:
        if is_source_binding(f):
            unknown = sorted(set(f) - BINDING_KEYS)
            if unknown:
                raise SourceFilterRefused(
                    f"The source filter on {f.get(SOURCE_KEY)!r} carries key(s) {unknown} this "
                    f"report does not understand; it takes {sorted(BINDING_KEYS)}.")
            bindings.append(f)
        else:
            rest.append(f)
    return bindings, rest


def _values_of(binding: Dict[str, Any]) -> List[str]:
    v = binding.get("value")
    if isinstance(v, dict):
        v = [v.get("from"), v.get("to")]
    if isinstance(v, (list, tuple)):
        items = list(v)
    else:
        items = [v]
    if binding.get("value2") not in (None, ""):
        items.append(binding["value2"])
    return [str(x) for x in items if x is not None and str(x).strip() != ""]


def _range_of(binding: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    v = binding.get("value")
    if isinstance(v, dict):
        lo, hi = v.get("from"), v.get("to")
    elif isinstance(v, (list, tuple)):
        lo = v[0] if len(v) > 0 else None
        hi = v[1] if len(v) > 1 else binding.get("value2")
    else:
        lo, hi = v, binding.get("value2")
    clean = lambda x: None if x is None or str(x).strip() == "" else str(x)   # noqa: E731
    return clean(lo), clean(hi)


class _Site:
    """One place a condition is written: what a new value is rendered against."""
    __slots__ = ("column", "qualifier", "op", "values", "kind", "tmpl", "marks")

    def __init__(self, fields: Dict[str, Any], marks: Dict[str, Tuple[Any, str]]):
        self.column, self.qualifier = fields["col"]
        self.op, self.values, self.kind, self.tmpl = fields["op"], fields["values"], fields["kind"], fields.get("tmpl")
        self.marks = marks


def _render_literal(text: str, pred: Any, label: str, exp: Any, dialect: Optional[str]) -> Any:
    """A literal node of the predicate's ORIGINAL kind, or a refusal.  A date
    the query writes through a function with a format goes back into THAT
    function and format (a marked literal the caller swaps for the call)."""
    kind = pred.kind
    t = str(text).strip()
    if kind == "string":
        return exp.Literal.string(t)
    if kind == "number":
        try:
            float(t)
        except (TypeError, ValueError):
            raise SourceFilterRefused(f"{label} takes a number; {text!r} is not one.")
        return exp.Literal.number(t)
    if kind == "boolean":
        return exp.Boolean(this=t.lower() in ("true", "1", "yes", "y"))
    if kind.startswith("cast:"):
        to_type = kind[len("cast:"):]
        if kind in _DATE_KINDS:
            if not _iso_date(t):
                raise SourceFilterRefused(f"{label} takes a date as YYYY-MM-DD; {text!r} is not one.")
            t = t[:10]
        elif kind.startswith(_TIMESTAMP_PREFIXES):
            try:
                _datetime.fromisoformat(t.replace("T", " ").replace("Z", ""))
            except ValueError:
                raise SourceFilterRefused(f"{label} takes a date and time (YYYY-MM-DD HH:MM:SS); "
                                          f"{text!r} is not one.")
        tmpl = getattr(pred, "tmpl", None)
        if tmpl is not None:
            lit, fmt, target = _format_call(tmpl, exp)
            try:
                written = _write_with_format(t, fmt, target, like=str(lit.this))
            except (_Unreadable, ValueError) as exc:
                raise SourceFilterRefused(f"{label}: {text!r} cannot be written in the query's own date "
                                          f"format ({exc}).")
            mark = f"{len(pred.marks)}"
            pred.marks[mark] = (tmpl, written)
            return exp.Literal.string(mark)
        return exp.Cast(this=exp.Literal.string(t), to=exp.DataType.build(to_type, dialect=dialect))
    raise SourceFilterRefused(f"{label}: a literal of kind {kind!r} cannot be rendered.")   # pragma: no cover


def _new_predicate(pred: Any, binding: Dict[str, Any], exp: Any,
                   dialect: Optional[str]) -> Optional[Any]:
    """The replacement node, or None when the binding supplies no value."""
    label = f"The source filter on {pred.qualifier + '.' if pred.qualifier else ''}{pred.column}"
    col = exp.column(pred.column, table=pred.qualifier or None)
    if pred.op == "between":
        lo, hi = _range_of(binding)
        if lo is None and hi is None:
            return None
        lo_node = _render_literal(lo if lo is not None else pred.values[0], pred, label, exp, dialect)
        hi_node = _render_literal(hi if hi is not None else pred.values[1], pred, label, exp, dialect)
        return exp.Between(this=col, low=lo_node, high=hi_node)
    values = _values_of(binding)
    if not values:
        return None
    if pred.op in ("eq", "in"):
        lits = [_render_literal(v, pred, label, exp, dialect) for v in values]
        if len(lits) == 1:
            return exp.EQ(this=col, expression=lits[0])
        return exp.In(this=col, expressions=lits)
    if len(values) != 1:
        raise SourceFilterRefused(f"{label} compares with {_OP_WORDS[pred.op]} and takes ONE value; "
                                  f"{len(values)} were given.")
    cls = {"neq": exp.NEQ, "gt": exp.GT, "gte": exp.GTE, "lt": exp.LT, "lte": exp.LTE}[pred.op]
    return cls(this=col, expression=_render_literal(values[0], pred, label, exp, dialect))


def _call_text(tmpl: Any, written: str, piece: Optional[str], exp: Any, dialect: Optional[str]) -> str:
    """The author's date function with ``written`` as its value.  From the
    query's own text when the call is found there (every byte of the function
    and its format as written); else generated, and PROVEN to read back as the
    same function, format and value -- or refused."""
    import sqlglot
    lit, fmt, target = _format_call(tmpl, exp)
    new_lit = exp.Literal.string(written).sql(dialect=dialect)
    if piece:
        try:
            from sqlglot.tokens import TokenType as T
            toks = sqlglot.tokenize(piece, read=dialect)
            for i, tok in enumerate(toks):
                if tok.token_type != T.STRING or i < 2 or toks[i - 1].token_type != T.L_PAREN:
                    continue
                depth, close = 0, None
                for j in range(i - 1, len(toks)):
                    if toks[j].token_type == T.L_PAREN:
                        depth += 1
                    elif toks[j].token_type == T.R_PAREN:
                        depth -= 1
                        if depth == 0:
                            close = j
                            break
                if close is None:
                    continue
                start, stop = toks[i - 2].start, toks[close].end + 1
                try:
                    same = sqlglot.parse_one(piece[start:stop], read=dialect).sql(
                        dialect=dialect, comments=False) == tmpl.sql(dialect=dialect, comments=False)
                except Exception:                              # noqa: BLE001
                    same = False
                if same:
                    return piece[start:tok.start] + new_lit + piece[tok.end + 1:stop]
        except Exception as exc:                               # noqa: BLE001
            logger.info("[source-filters] the date function was not found in the text (%s)", exc)
    made = tmpl.copy()
    if type(made).__name__ == "Anonymous":
        made.set("expressions", [exp.Literal.string(written), made.expressions[1]])
    else:
        made.set("this", exp.Literal.string(written))
    text = made.sql(dialect=dialect)
    try:
        back = _format_call(sqlglot.parse_one(text, read=dialect), exp)
    except Exception:                                          # noqa: BLE001
        back = None
    if back is None or str(back[0].this) != written or back[1] != fmt or back[2] != target:
        raise SourceFilterRefused(
            f"The date function {tmpl.sql(dialect=dialect)} cannot be written back with a new value "
            f"in this query's dialect without changing its meaning; the report is not run.")
    return text


def _swap_marks(text: str, marks: Dict[str, Tuple[Any, str]], piece: Optional[str], exp: Any,
                dialect: Optional[str]) -> str:
    for mark, (tmpl, written) in marks.items():
        text = text.replace(exp.Literal.string(mark).sql(dialect=dialect),
                            _call_text(tmpl, written, piece, exp, dialect))
    return text


_CLAUSE_END = ("GROUP_BY", "ORDER_BY", "HAVING", "LIMIT", "OFFSET", "QUALIFY", "WINDOW",
               "UNION", "INTERSECT", "EXCEPT", "FETCH", "SEMICOLON", "FOR")


def _where_groups(text: str, dialect: Optional[str], exp: Any) -> Optional[List[Tuple[Tuple[str, ...], List[Tuple[int, int]]]]]:
    """Every WHERE of ``text`` -- at ANY parenthesis depth -- as ``(its
    conjuncts re-parsed, their character spans)``, in the order written; None
    when the text cannot be tokenised.  A WHERE whose pieces cannot be proven
    is left out (its scope then finds no span and the statement regenerates)."""
    try:
        import sqlglot
        from sqlglot.tokens import TokenType as T
        toks = sqlglot.tokenize(text, read=dialect)
    except Exception:                                          # noqa: BLE001
        return None
    ends = {getattr(T, n) for n in _CLAUSE_END if hasattr(T, n)}
    depths: List[int] = []
    d = 0
    for tok in toks:
        depths.append(d)
        if tok.token_type == T.L_PAREN:
            d += 1
        elif tok.token_type == T.R_PAREN:
            d -= 1
    out = []
    for w, tok in enumerate(toks):
        if tok.token_type != T.WHERE:
            continue
        level = depths[w]
        pieces: List[List[Any]] = [[]]
        pending_between = 0
        for j in range(w + 1, len(toks)):
            t, at = toks[j], depths[j]
            if at == level and (t.token_type in ends or t.token_type == T.R_PAREN):
                break                       # a clause end, or the parenthesis that closes this scope
            if at == level and t.token_type == T.BETWEEN:
                pending_between += 1
            elif at == level and t.token_type == T.AND:
                if pending_between:
                    pending_between -= 1
                else:
                    pieces.append([])
                    continue
            pieces[-1].append(t)
        if any(not p for p in pieces):
            continue
        spans, parsed = [], []
        try:
            for piece in pieces:
                start, end = piece[0].start, piece[-1].end + 1
                node = sqlglot.parse_one(text[start:end], read=dialect)
                while isinstance(node, exp.Paren):
                    node = node.this
                parsed.append(node.sql(dialect=dialect, comments=False))   # a comment is not the condition
                spans.append((start, end))
        except Exception:                                      # noqa: BLE001
            continue
        out.append((tuple(parsed), spans))
    return out


def _scope_spans(text: str, dialect: Optional[str], scopes: List[_Scope],
                 exp: Any) -> Dict[int, List[Tuple[int, int]]]:
    """``{scope number: the character span of each of its WHERE conjuncts}``
    for every scope whose WHERE is PROVEN in the text: the WHEREs of the text
    whose re-parsed pieces equal the scope's conjuncts, as many of them as
    there are such scopes, matched in the order written (identical WHEREs take
    identical replacements, so the order among them cannot matter)."""
    groups = _where_groups(text, dialect, exp)
    if not groups:
        return {}
    by_sig: Dict[Tuple[str, ...], List[List[Tuple[int, int]]]] = {}
    for sig, spans in groups:
        by_sig.setdefault(sig, []).append(spans)
    wanted: Dict[Tuple[str, ...], List[_Scope]] = {}
    for s in scopes:
        if s.conjuncts:
            wanted.setdefault(tuple(c.sql(dialect=dialect, comments=False) for c in s.conjuncts), []).append(s)
    out: Dict[int, List[Tuple[int, int]]] = {}
    for sig, same in wanted.items():
        found = by_sig.get(sig) or []
        if len(found) != len(same):
            continue
        for s, spans in zip(same, found):
            out[s.no] = spans
    return out


def _apply_conditions(body: str, dialect: Optional[str], bindings: Sequence[Dict[str, Any]]) -> str:
    """``body`` with every bound condition replaced, in EVERY place it is written."""
    import sqlglot                                             # noqa: F401
    from sqlglot import exp
    text = _protect(body)
    an = _analyse(text, dialect)
    if an.reason:
        raise SourceFilterRefused(
            f"The report's source filters cannot be applied: {an.reason}")
    by_key = {g.key: g for g in an.groups if not g.bare}
    replacements: Dict[Tuple[int, int], Tuple[Any, Dict[str, Tuple[Any, str]]]] = {}
    given: set = set()
    for b in bindings:
        key = str(b.get(SOURCE_KEY) or "").strip().lower()
        group = by_key.get(key)
        if group is None:
            raise SourceFilterRefused(
                f"The report's source filter {key!r} is not a condition of the dataset's query any "
                f"more. Conditions the query has: {', '.join(sorted(by_key)) or '(none)'}. Remove "
                f"the parameter or bind it to one of these; the report is not run unfiltered.")
        made = []
        for scope_no, idx in group.sites:
            marks: Dict[str, Tuple[Any, str]] = {}
            node = _new_predicate(_Site(an.scopes[scope_no].fields[idx], marks), b, exp, dialect)
            if node is None:
                break                      # no value: the query's own literal stands, in every place
            made.append(((scope_no, idx), (node, marks)))
        if len(made) != len(group.sites):
            continue
        if key in given:
            raise SourceFilterRefused(
                f"The source filter {key!r} was given twice in one run.")
        given.add(key)
        replacements.update(made)
    if not replacements:
        return body
    spans = _scope_spans(text, dialect, an.scopes, exp)
    if all(scope_no in spans for scope_no, _i in replacements):
        edits = []
        for (scope_no, idx), (node, marks) in replacements.items():
            start, end = spans[scope_no][idx]
            edits.append((start, end, _swap_marks(node.sql(dialect=dialect), marks, text[start:end], exp, dialect)))
        out = text
        for start, end, new in sorted(edits, reverse=True):
            out = out[:start] + new + out[end:]
        return _unprotect(out)
    # a span could not be proven (a nested AND group, a clause this reader does
    # not know): the statement is regenerated by sqlglot in the same dialect
    logger.info("[source-filters] conjunct spans not provable; the statement is regenerated")
    all_marks: Dict[str, Tuple[Any, str]] = {}
    n = 0
    for (scope_no, idx), (node, marks) in replacements.items():
        for mark, what in marks.items():                       # one statement: every mark its own name
            n += 1
            fresh = f"r{n}"
            for lit in node.find_all(exp.Literal):
                if lit.is_string and str(lit.this) == mark:
                    lit.set("this", fresh)
            all_marks[fresh] = what
        an.scopes[scope_no].conjuncts[idx].replace(node)
    return _unprotect(_swap_marks(an.tree.sql(dialect=dialect), all_marks, None, exp, dialect))


def _backslash_escapes(dialect: Optional[str]) -> bool:
    """Does ``dialect`` read a backslash inside a string as an escape?  (Then
    a value's backslashes are doubled before it is put between quotes, or
    ``\\'`` would end the string early.)"""
    try:
        from sqlglot import exp
        return exp.Literal.string("\\").sql(dialect=dialect) != "'\\'"
    except Exception:                                          # noqa: BLE001
        return True


def _resolve_default(value: Any, name: str = "") -> Any:
    """A dataset's own value for a placeholder, through the ONE date vocabulary
    every road reads (``core.date_resolver.resolve_date_token``: ``@TODAY``,
    ``@PREV_BUSINESS_DAY:LDN``, ``-1d``, ``${monthEnd}``; a bare word such as
    ``today`` only for a placeholder that is named like a date)."""
    if not isinstance(value, str):
        return value
    v = value.strip()
    from core.parameters import looks_like_date
    if not (v.startswith("@") or "${" in v or re.fullmatch(r"[+-]\d+d", v, re.I) or looks_like_date(name)):
        return value
    try:
        from core.date_resolver import resolve_date_token
        return resolve_date_token(v)
    except ValueError as exc:
        raise SourceFilterRefused(f"The dataset's own value {value!r} for {{{name}}} could not be "
                                  f"worked out: {exc}")


def _fill(sql: str, original: str, dialect: Optional[str], bindings: Dict[str, Dict[str, Any]],
          defaults: Optional[Dict[str, Any]]) -> str:
    """``sql`` with every ``{NAME}`` placeholder filled: a run's value, else
    the dataset's own.  A placeholder with neither REFUSES."""
    from core.parameters import substitute_sql_params
    asked = {n.lower(): n for n in reversed(placeholders(original))}
    for name in bindings:
        if name not in asked:
            raise SourceFilterRefused(
                f"The report gives a value for {{{name}}}, which the dataset's query does not ask for "
                f"any more. Values the query asks for: "
                f"{', '.join('{' + n + '}' for n in asked.values()) or '(none)'}. Remove the parameter "
                f"or bind it to one of these; the report is not run.")
    values: Dict[str, Tuple[Any, str]] = {}
    for k, v in (defaults or {}).items():
        if v is None or (isinstance(v, str) and not v.strip()) or (isinstance(v, (list, tuple)) and not v):
            continue
        values[str(k).lower()] = (_resolve_default(v, str(k)), "")
    for name, b in bindings.items():
        v = b.get("value")
        if isinstance(v, (list, tuple)):
            v = [x for x in v if x is not None and str(x).strip() != ""]
            if not v:
                continue
            v = v[0] if len(v) == 1 else v
        elif v is None or str(v).strip() == "":
            continue
        if isinstance(v, dict):
            raise SourceFilterRefused(f"The value for {{{name}}} is ONE value where the dataset's query "
                                      f"writes it; a range was given.")
        values[name] = (v, str(b.get("value_type") or "").lower())
    # only a DECLARED name is a placeholder (the dataset's, or one this run names);
    # any other {word} is the query's own text and stays exactly as written
    named = declared_names(defaults, bindings)
    sites = [s for s in _placeholder_sites(sql) if s[0].lower() in named]
    missing = []
    for name, _s, _e, _q in sites:
        if name.lower() not in values and name not in missing:
            missing.append(name)
    if missing:
        names = ", ".join("{" + n + "}" for n in missing)
        refusal = SourceFilterRefused(
            f"The dataset's query asks for a value for {names} and none was given. Give the report a "
            f"parameter named {' / '.join(missing)} (or link one to it under Filter at the source), or "
            f"give the dataset a value to use when nobody gives one. The query is not sent to the "
            f"source without it.")
        refusal.missing = tuple(missing)
        raise refusal
    escape = _backslash_escapes(dialect)
    out = sql
    for name, start, end, quoted in reversed(sites):
        value, vtype = values[name.lower()]
        many = isinstance(value, (list, tuple))
        label = f"The value for {{{name}}}"
        if many and not _in_list_site(sql, start, end):
            raise SourceFilterRefused(
                f"{label} is ONE value where the query writes it; {len(value)} were given. Write it "
                f"as IN ({{{name}}}) in the dataset's query to take several.")
        items = [str(x) for x in (value if many else [value])]
        if vtype == "date":
            for x in items:
                # the WHOLE value is a date (or a date and a time) -- not a date followed by more
                if not (_iso_date(x) and _WHOLE_DATE.fullmatch(x.strip())):
                    raise SourceFilterRefused(f"{label} is a date as YYYY-MM-DD; {x!r} is not one.")
        ptype = "string"
        if vtype == "number" or (not vtype and not quoted and isinstance(value, (int, float))
                                 and not isinstance(value, bool)):
            for x in items:
                try:
                    float(x)
                except ValueError:
                    raise SourceFilterRefused(f"{label} is a number; {x!r} is not one.")
            ptype = "integer" if all(re.fullmatch(r"[+-]?\d+", x.strip()) for x in items) else "number"
        if escape:
            items = [x.replace("\\", "\\\\") for x in items]
        val: Any = items if many else items[0]
        try:
            if quoted:
                made = substitute_sql_params("'{" + name + "}'", {name: val}, [])[1:-1]
            elif many and ptype != "string":
                made = ", ".join(substitute_sql_params("{" + name + "}", {name: x}, [{"name": name, "type": ptype}])
                                 for x in items)
            else:
                made = substitute_sql_params("{" + name + "}", {name: val}, [{"name": name, "type": ptype}])
        except ValueError as exc:
            raise SourceFilterRefused(f"{label}: {exc}")
        out = out[:start] + made + out[end:]
    return out


def apply(sql: str, dialect: Optional[str], bindings: Sequence[Dict[str, Any]],
          defaults: Optional[Dict[str, Any]] = None) -> str:
    """THE one place a dataset's SQL becomes a run's SQL: every bound
    condition replaced (in every place it is written), every ``{NAME}``
    placeholder filled (a binding keyed ``{name}``, else the dataset's own
    ``defaults``).  Raises :class:`SourceFilterRefused`; with nothing to do
    returns ``sql`` untouched (byte-identical)."""
    text = str(sql or "")
    fills: Dict[str, Dict[str, Any]] = {}
    conditions: List[Dict[str, Any]] = []
    for b in bindings or []:
        key = str(b.get(SOURCE_KEY) or "").strip().lower()
        if is_placeholder_key(key):
            if key[1:-1] in fills:
                raise SourceFilterRefused(f"The value for {key} was given twice in one run.")
            fills[key[1:-1]] = b
        else:
            conditions.append(b)
    asks = "{" in text and bool(asked(text, defaults, fills))
    if not conditions and not asks and not fills:
        return sql
    body = text.rstrip()
    trailing = text[len(body):]
    semi = ""
    if body.endswith(";"):
        body, semi = body[:-1], ";"
    out = _apply_conditions(body, dialect, conditions) if conditions else body
    if asks or fills:
        out = _fill(out, body, dialect, fills, defaults)
    if out == body:
        return sql
    return out + semi + trailing


def bound_summary(bindings: Sequence[Dict[str, Any]]) -> str:
    """One line for the log: which predicates were bound, with how many values."""
    parts = []
    for b in bindings:
        vals = _values_of(b)
        parts.append(f"{b.get(SOURCE_KEY)}={len(vals)} value(s)")
    return ", ".join(parts)


def reset_for_tests() -> None:
    _MEMO.clear()


__all__ = [
    "SOURCE_KEY", "BINDING_KEYS", "PLACEHOLDER_OP", "SourceFilterRefused", "SourcePredicate", "Discovery",
    "discover", "discover_cached", "is_source_binding", "split_filters", "apply",
    "placeholders", "asked", "declared_names", "placeholder_key", "is_placeholder_key", "fixed_words",
    "parse_text",
    "bound_summary", "reset_for_tests",
]
