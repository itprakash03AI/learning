/**
 * The Visuals grid (2026-11-07, the simple builder): one icon per kind of
 * visual -- every kind the old "Show as" menu offered plus the finance grid,
 * the header band, the insight and the report's table.  With a visual
 * selected a click CHANGES its kind (changeKind keeps the fields that fit);
 * with none selected a click ADDS one.  Each button keeps the old
 * `canvas-add-<kind>` test id, so the rig specs that add a number or an
 * insight still find it.  QueryStudio's own icons, nothing copied.
 */
import React from 'react';
import { Box, IconButton, Tooltip, Typography } from '@mui/material';
import NumbersIcon from '@mui/icons-material/Numbers';
import TableChartIcon from '@mui/icons-material/TableChart';
import PivotTableChartIcon from '@mui/icons-material/PivotTableChart';
import GridOnIcon from '@mui/icons-material/GridOn';
import BarChartIcon from '@mui/icons-material/BarChart';
import AlignHorizontalLeftIcon from '@mui/icons-material/AlignHorizontalLeft';
import StackedBarChartIcon from '@mui/icons-material/StackedBarChart';
import ShowChartIcon from '@mui/icons-material/ShowChart';
import AreaChartIcon from '@mui/icons-material/AreaChart';
import StackedLineChartIcon from '@mui/icons-material/StackedLineChart';
import AddchartIcon from '@mui/icons-material/Addchart';
import RadarIcon from '@mui/icons-material/Radar';
import PieChartIcon from '@mui/icons-material/PieChart';
import DonutLargeIcon from '@mui/icons-material/DonutLarge';
import ViewQuiltIcon from '@mui/icons-material/ViewQuilt';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import StairsIcon from '@mui/icons-material/Stairs';
import ScatterPlotIcon from '@mui/icons-material/ScatterPlot';
import BubbleChartIcon from '@mui/icons-material/BubbleChart';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import ViewHeadlineIcon from '@mui/icons-material/ViewHeadline';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import TableRowsIcon from '@mui/icons-material/TableRows';
import { KIND_LABEL, TileKind } from '../canvas/canvasModel';
import { OWN_SETTINGS, SHOW_AS } from '../canvas/canvasEdit';

/** the order of the grid: the common kinds first, the finance pieces last */
export const GRID_KINDS: TileKind[] = [...SHOW_AS, ...OWN_SETTINGS];

export const KIND_ICON: Record<TileKind, React.ReactElement> = {
  number: <NumbersIcon />, table: <TableChartIcon />, pivot: <PivotTableChartIcon />, heatmap: <GridOnIcon />,
  bar: <BarChartIcon />, hbar: <AlignHorizontalLeftIcon />, stacked_bar: <StackedBarChartIcon />, line: <ShowChartIcon />,
  area: <AreaChartIcon />, stacked_area: <StackedLineChartIcon />, combo: <AddchartIcon />, radar: <RadarIcon />,
  pie: <PieChartIcon />, donut: <DonutLargeIcon />, treemap: <ViewQuiltIcon />, funnel: <FilterAltIcon />,
  waterfall: <StairsIcon />, scatter: <ScatterPlotIcon />, bubble: <BubbleChartIcon />,
  outline: <AccountTreeIcon />, band: <ViewHeadlineIcon />, insight: <LightbulbIcon />, report: <TableRowsIcon />,
};

/** plain words for the grid (KIND_LABEL keeps the longer names used elsewhere) */
export const GRID_LABEL: Record<TileKind, string> = {
  ...KIND_LABEL,
  number: 'Card', bar: 'Column', hbar: 'Bar', stacked_bar: 'Stacked column', line: 'Line', area: 'Area', stacked_area: 'Stacked area',
  combo: 'Columns and lines', pie: 'Pie', pivot: 'Matrix', heatmap: 'Heat map', scatter: 'Scatter', bubble: 'Bubble',
  outline: 'Finance grid', band: 'Header band', insight: 'Insight', report: "The report's table",
};

export default function VisualsGrid({ selectedKind, hasReportTile, onPick }: {
  /** the kind of the selected visual (a click changes it), or null (a click adds one) */
  selectedKind: TileKind | null;
  hasReportTile: boolean;
  onPick: (kind: TileKind) => void;
}) {
  const switchable = selectedKind != null && !OWN_SETTINGS.includes(selectedKind);
  return (
    <Box data-testid="visuals-grid">
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 0.25 }}>
        {GRID_KINDS.map(k => {
          const changes = switchable && !OWN_SETTINGS.includes(k);
          const disabled = k === 'report' && hasReportTile;
          const tip = disabled ? "The report's table is already on the page"
            : changes ? (k === selectedKind ? `${GRID_LABEL[k]} -- the selected visual` : `Show the selected visual as ${GRID_LABEL[k].toLowerCase()}`)
            : `Add ${GRID_LABEL[k].toLowerCase() === "the report's table" ? "the report's table" : `a ${GRID_LABEL[k].toLowerCase()}`}`;
          return (
            <Tooltip key={k} title={tip}>
              <span>
                <IconButton size="small" aria-label={tip} data-testid={`canvas-add-${k}`} disabled={disabled}
                  onClick={() => onPick(k)} data-kind={k} data-selected={k === selectedKind ? 'yes' : undefined}
                  sx={{ borderRadius: 1, border: '1px solid', borderColor: k === selectedKind ? 'primary.main' : 'transparent',
                        bgcolor: k === selectedKind ? 'action.selected' : undefined, color: 'text.secondary' }}>
                  {KIND_ICON[k]}
                </IconButton>
              </span>
            </Tooltip>
          );
        })}
      </Box>
      <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 0.5 }} data-testid="visuals-grid-hint">
        {switchable ? 'A click changes the selected visual. Click the empty canvas first to add a new one.' : 'A click adds a visual to the page.'}
      </Typography>
    </Box>
  );
}
