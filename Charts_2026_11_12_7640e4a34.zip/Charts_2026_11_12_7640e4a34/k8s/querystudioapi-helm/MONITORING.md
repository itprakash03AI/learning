# Monitoring QueryStudio — Strategy + Stack

You said you don't have a UI dashboard yet. Here's the recommended stack
(industry-standard, every piece is open-source), what's already wired into
this chart tree, and what you need to install cluster-side to light it up.

## The 4-layer stack

```
┌──────────────────────────────────────────────────────────┐
│  Grafana          ← visualisation + dashboards            │
│  Alertmanager     ← PagerDuty / Slack / email routing     │
├──────────────────────────────────────────────────────────┤
│  Prometheus       ← scrapes /metrics every 30s            │
│  Loki             ← stores pod logs                       │
├──────────────────────────────────────────────────────────┤
│  ServiceMonitor   ← tells Prometheus what to scrape       │ ← in this chart tree
│  PrometheusRule   ← alert definitions                     │ ← in this chart tree
│  Promtail (DS)    ← ships pod logs to Loki                │ ← example in monitoring/
├──────────────────────────────────────────────────────────┤
│  QueryStudio pods (already emit /metrics + JSON logs)     │ ← no code change needed
└──────────────────────────────────────────────────────────┘
```

**The bottom layer already exists** in the QueryStudio code:
- `/metrics` exposed by [system_api.py:86](backend/api/system_api.py#L86) (Prometheus exposition format)
- HTTP request counters + latency histograms emitted by [main.py:902](backend/main.py#L902)
- DuckDB tuning gauges from Phase 139
- Structured JSON logs to stdout

You don't have to instrument anything. You just need to **scrape** + **store**
+ **visualise**.

## What's wired in this chart tree

| Asset | Location | Default state |
|---|---|---|
| `ServiceMonitor` (per chart) | `<chart>/templates/servicemonitor.yaml` | `serviceMonitor.enabled: false` — flip on per chart |
| `PrometheusRule` (fleet alerts) | `api/templates/prometheusrule.yaml` | `prometheusRule.enabled: false` |
| Grafana dashboard JSON | `monitoring/grafana-dashboard.json` | Import manually or via Grafana Operator |
| Promtail DaemonSet (logs → Loki) | `monitoring/promtail-daemonset.yaml` | Apply via `oc apply -f` after editing LOKI_URL |

## What you need to install cluster-side

Pick the path that matches your environment:

### Path A — kube-prometheus-stack (fastest, most complete)

One Helm install brings **Prometheus + Alertmanager + Grafana + node-exporter
+ kube-state-metrics + all the CRDs** (`ServiceMonitor`, `PrometheusRule`,
`PodMonitor`, `AlertmanagerConfig`):

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm install monitoring prometheus-community/kube-prometheus-stack \
  --namespace monitoring --create-namespace \
  --set grafana.adminPassword=...
```

Then enable the QS-side templates:

```bash
helm upgrade qs-api ./api \
  -f env/prod.yaml \
  --set serviceMonitor.enabled=true \
  --set prometheusRule.enabled=true \
  -n querystudio-prod
```

Repeat `--set serviceMonitor.enabled=true` for `worker`, `feed-worker`,
`scheduler`, `published-api`, `etl-polling` deploys.

Import the dashboard:
```bash
# UI: Grafana → Dashboards → New → Import → upload monitoring/grafana-dashboard.json
# Or via Grafana Operator GrafanaDashboard CR.
```

### Path B — bring-your-own Prometheus

If your org already runs Prometheus (Splunk-prom, Thanos, Mimir, etc.),
verify the CRDs exist (`kubectl get crd | grep monitoring.coreos.com`).
If they do, flip the QS-side toggles. If not, point your existing
Prometheus at the QS Service endpoints via static config — every backend
pod exposes `/metrics` on its main port.

### Path C — pull-only, no Prometheus

Scrape from outside the cluster (Datadog Agent, New Relic Infrastructure,
SumoLogic). Each agent has its own DaemonSet / sidecar pattern. The
`/metrics` exposition format is the same; no code change needed.

## Logs → Loki (or your existing log aggregator)

`monitoring/promtail-daemonset.yaml` ships a Promtail DaemonSet that:
- Watches every node's `/var/log/pods/`
- Filters pods labelled `app.kubernetes.io/part-of=querystudio`
- JSON-decodes structured backend logs → makes `level`, `trace_id`,
  `run_id`, `report_id` searchable in Loki
- Drops chatty `/health` + `/metrics` polls

Steps:
```bash
# 1. Install Loki (skip if you have it).
helm install loki grafana/loki -n loki --create-namespace

# 2. Edit LOKI_URL in monitoring/promtail-daemonset.yaml.

# 3. Apply.
oc apply -f monitoring/promtail-daemonset.yaml -n querystudio-prod
```

If you use Splunk / Elasticsearch / Sumo instead of Loki, replace the
Promtail DaemonSet with the vendor's collector — log structure is the same.

## What each component emits

| Pod | Endpoint | Notable metrics | Log format |
|---|---|---|---|
| api | `:8000/metrics` | `querystudio_requests_total`, `querystudio_request_duration_seconds_bucket`, `querystudio_db_pool_*`, DuckDB tuning gauges | JSON |
| worker | `:8000/metrics` | `querystudio_worker_chunks_processed_total`, `querystudio_worker_arrow_bytes_returned_total` | JSON |
| feed-worker | `:8004/metrics` | `querystudio_feed_queue_pending`, `querystudio_feed_queue_in_flight`, `querystudio_feed_run_duration_seconds` | JSON |
| scheduler | `:8001/metrics` | `querystudio_scheduler_last_tick_timestamp_seconds`, `querystudio_scheduler_dispatched_total` | JSON |
| published-api | `:8003/metrics` | Same shape as api, scoped to `/api/v1/*` | JSON |
| etl-polling | `:9000/metrics` (via health server) | `etl_polling_runs_claimed_total`, `etl_polling_oracle_errors_total` | JSON |
| spark-connect | `:4040/metrics/prometheus` (Spark UI) | JVM + Spark job metrics | text (Spark log4j) |
| ui | nginx access/error logs only | n/a (no /metrics) | nginx access |

If a metric name above doesn't exist yet, the PrometheusRule rule will
silently no-op until it does. Wire the metric in code first, then enable
the rule.

## Alert thresholds (in `prometheusrule.yaml`)

| Alert | Threshold | Severity |
|---|---|---|
| `QueryStudioPodCrashLooping` | ≥ 3 restarts in 15m | critical |
| `QueryStudioPodNotReady` | ready=false for 10m | warning |
| `QueryStudioWorkerPoolUnderscaled` | < 50% available for 5m | warning |
| `QueryStudioApi5xxRate` | > 0.5 req/s for 5m | warning |
| `QueryStudioApiLatencyP99` | > 5s for 10m | warning |
| `QueryStudioDbPoolExhausted` | > 90% checked out for 5m | critical |
| `QueryStudioFeedQueueBacklog` | > 100 pending for 15m | warning |
| `QueryStudioSchedulerStalled` | no tick in > 5m | critical |
| `QueryStudioEtlPollingDown` | `up==0` for 2m | critical |
| `QueryStudioSparkConnectDown` | `up==0` for 5m | warning |

Tune in `api/values.yaml` → `prometheusRule.additionalLabels` to wire into
your Alertmanager routing tree.

## "Built-in" observability inside QueryStudio (no infra needed)

If you can't deploy Prometheus right now, you still have:

1. **`/health` on every pod** — uptime monitor friendly (Pingdom / Uptime
   Robot / a curl loop). Returns 200 when the pod is alive.
2. **`/metrics` on every backend pod** — text exposition format; you can
   `curl` it manually or via a `kubectl port-forward`.
3. **QueryStudio Admin UI** already has a live WebSocket dashboard (Phase
   130) showing feed runs in real-time. Open it at `https://<ui-host>/admin`.
4. **Pod identity in logs** — `POD_NAME`, `POD_NAMESPACE`, `POD_IP`,
   `NODE_NAME` are injected via downwardAPI; every log line is attributable
   to a specific pod/node without setup.

## Stretch (when you have headroom)

- **Distributed tracing** (OpenTelemetry → Tempo / Jaeger) — backend
  already passes `trace_id` through logs; bolt on the OTel SDK + a
  collector to get full distributed traces.
- **Synthetic monitoring** — Pingdom or a `blackbox-exporter` scraping
  `/health` from outside the cluster.
- **SLO dashboards** — `slo-generator` or a hand-rolled rule pulling
  from the request-rate + error-rate metrics already emitted.
- **Built-in QS Observability page** — extend the QS Admin UI with a tab
  that pulls `/metrics` from every pod (via the api's existing
  pod-discovery RBAC) and renders Prom-style graphs in-app. Removes the
  external Grafana dependency for casual users; not a substitute for
  Prometheus history.

## TL;DR — do this on Monday

1. `helm install monitoring prometheus-community/kube-prometheus-stack -n monitoring --create-namespace`
2. Flip `serviceMonitor.enabled=true` on every backend chart deploy.
3. Flip `prometheusRule.enabled=true` on the api deploy.
4. Import `monitoring/grafana-dashboard.json` into Grafana.
5. (Optional) `helm install loki + apply monitoring/promtail-daemonset.yaml`.
6. Wire Alertmanager to Slack / PagerDuty.

That's a complete monitoring stack from zero to dashboards in ~30 minutes.
