# QueryStudio Helm + Monitoring — Roadmap

Three horizons. Each item has concrete commands, exit criteria, and an
estimate. Cross off as you go.

---

## Horizon 1 — Monday (≤ 4 hours)

Goal: stand up the monitoring stack and confirm the fleet is observable end-to-end.

### 1.1 Install the metrics + dashboards stack — 30 min
```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

helm install monitoring prometheus-community/kube-prometheus-stack \
  --namespace monitoring --create-namespace \
  --set grafana.adminPassword='<change-me>' \
  --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false \
  --set prometheus.prometheusSpec.ruleSelectorNilUsesHelmValues=false
```
**Exit:** `kubectl get crd | grep monitoring.coreos.com` lists `servicemonitors` and `prometheusrules`. Grafana UI reachable.

### 1.2 Enable QS-side ServiceMonitor + PrometheusRule — 15 min
Per environment (dev → uat → prod):
```bash
for c in api worker feed-worker scheduler published-api etl-polling; do
  helm upgrade qs-$c ./$c -f env/prod.yaml \
    --set serviceMonitor.enabled=true \
    --reuse-values -n querystudio-prod
done
helm upgrade qs-api ./api -f env/prod.yaml \
  --set prometheusRule.enabled=true \
  --reuse-values -n querystudio-prod
```
**Exit:** `kubectl get servicemonitor -n querystudio-prod` shows 6 entries; Prometheus targets page shows them all `UP`.

### 1.3 Import the dashboard — 5 min
Grafana → Dashboards → New → Import → upload [monitoring/grafana-dashboard.json](monitoring/grafana-dashboard.json) → select Prometheus datasource → Save.

**Exit:** dashboard shows non-zero values for all 12 panels.

### 1.4 Run the preflight on prod — 5 min
```bash
./bin/preflight.sh querystudio-prod
```
**Exit:** 0 FAIL. Investigate every WARN.

### 1.5 Wire Alertmanager to one receiver — 30 min
Pick one (Slack / PagerDuty / email) and configure via `AlertmanagerConfig` CR or `alertmanager.yaml`.
**Exit:** force-trigger a synthetic alert (`kubectl rollout restart deploy/querystudio-api`) and confirm receiver fires.

### 1.6 Document the runbook — 30 min
Append to `MONITORING.md`:
- Who's on-call rota
- Slack channel for alerts
- Runbook URL per alert (link from `prometheusrule.yaml` annotations)

**Done with Monday** ⇒ alerts fire to a human, dashboards work, preflight clean.

---

## Horizon 2 — Week 1 (this sprint)

Goal: close the remaining infra gaps from `CHECKLIST.md` and harden CI/CD.

### 2.1 Pick a secret strategy and stick to it — 2 hours
Three paths in `CHECKLIST.md` §3. Recommendation: **Path B (pre-created Secrets)** for UAT/prod, External Secrets Operator (Path C) if the org already runs it.
- Generate `qs-worker-auth.secret` (`openssl rand -hex 32`)
- Build `imagepullsecret` via `oc create secret docker-registry`
- Set all `secrets.*.create: false` in `env/uat.yaml` + `env/prod.yaml`
**Exit:** prod deploy succeeds with zero secret values in git.

### 2.2 Add ingress.yaml for non-OpenShift fallback — 3 hours
Today only `route.yaml` (OCP) exists. Add `ingress.yaml` gated by `ingress.enabled` per chart. Mirror the host/TLS shape of `route.yaml`.
**Exit:** `helm template ./api --set route.enabled=false --set ingress.enabled=true` renders a valid Ingress on a non-OCP cluster.

### 2.3 Add Promtail / logs → Loki — 1 hour
```bash
helm install loki grafana/loki -n loki --create-namespace
# Edit LOKI_URL in monitoring/promtail-daemonset.yaml
oc apply -f monitoring/promtail-daemonset.yaml -n querystudio-prod
```
**Exit:** Loki Explore shows queryable structured logs with `{component, level, run_id}` labels.

### 2.4 Replicate NetworkPolicy template to remaining charts — 2 hours
Today only `api/templates/networkpolicy.yaml` exists. Copy + customise to worker / feed-worker / scheduler / published-api / etl-polling / ui (egress rules differ per role).
**Exit:** with `networkPolicy.enabled=true` cluster-wide, every QS pod still serves its job; nothing else is reachable.

### 2.5 Add `needs:` chains in remaining CI deploy jobs — 30 min
Already wired for dev/prod stages. Repeat for uat stage where it exists.
**Exit:** `gitlab-ci.yml` lint shows no orphan `deploy:uat` jobs without an `api:deploy:uat` dependency.

### 2.6 Add CRD-presence guards to chart templates — 2 hours
Wrap `route.yaml` in `{{- if (.Capabilities.APIVersions.Has "route.openshift.io/v1") }}` and similar for `BarcLoadBalancer`, `ServiceMonitor`, `PrometheusRule`. Today the templates silently fail when the CRD is missing.
**Exit:** `helm template ./api` on a vanilla K8s cluster (no OCP CRDs) emits zero Route resources, no errors.

### 2.7 Stand up UAT, end-to-end smoke test — 2 hours
- Deploy full fleet to `querystudio-uat` via `deploy.sh uat`
- Run the smoke test suite (whatever your team uses — pytest, k6, curl batch)
- Verify Grafana shows traffic for every component

**Exit:** UAT passes the same smoke battery you run on prod today.

---

## Horizon 3 — Quarter (stretch / nice-to-have)

Goal: turn QueryStudio's operational story from "deployable" to "self-healing".

### 3.1 Distributed tracing (OpenTelemetry → Tempo) — 1 week
- Add the OTel Python SDK to `Dockerfile.api`
- Configure FastAPI auto-instrumentation
- Backend already passes `trace_id` through logs (just hook it to OTel context propagation)
- Deploy Grafana Tempo + add traces datasource in Grafana
**Exit:** trace from UI click → api → worker → S3 → response visible in Grafana with single-pane view.

### 3.2 Built-in QS Observability Page — 1 week
Extend the QS Admin UI with a new "Observability" tab that:
- Pulls `/metrics` from every backend pod (via existing pod-discovery RBAC)
- Renders mini Prom-style graphs in-app (recharts is already in the SPA)
- Surfaces last 100 log lines per pod (via kubectl-style API proxy from api pod)

Removes the external Grafana dependency for casual users; keeps Grafana for history + alerts.
**Exit:** non-SRE engineers can answer "is X pod healthy?" without leaving the QS UI.

### 3.3 SLO dashboards + error budgets — 3 days
- Define SLOs per endpoint (e.g. `POST /api/queries` 99% < 2s monthly)
- Generate burn-rate alerts via `slo-generator` or hand-rolled rules
- Add SLO panel to the Grafana overview
**Exit:** Eng team can answer "how many error budget minutes do we have left this month" in 5 seconds.

### 3.4 StatefulSet conversion for feed-worker shards — 3 days
Today feed-worker is a Deployment; every replica sees the same
`QUERYSTUDIO_FEED_SHARD` (or none). Convert to a StatefulSet so each pod
derives its shard from `metadata.name` (`feed-worker-0` → `0/N`).
**Exit:** scaling feed-worker to 4 replicas auto-shards the queue 4 ways; no manual `--set` per replica.

### 3.5 Synthetic monitoring — 1 day
Deploy `blackbox-exporter` and a `Probe` CR per public Route. Catches DNS / TLS / Ingress controller failures that internal `/health` checks miss.
**Exit:** "is the UI reachable from outside?" answered without manually curling.

### 3.6 Automated chaos drills — ongoing
Once monitoring is solid, run weekly:
- `kubectl delete pod querystudio-worker-<random>` → confirm dispatch still works
- `kubectl scale deploy/querystudio-api --replicas=0 && --replicas=3` → confirm session recovery
- Kill the scheduler → confirm `QueryStudioSchedulerStalled` fires within 5m
**Exit:** every alert has been seen at least once in a drill (not just in the rule file).

---

## Tracking

Use the issue tracker your team picks (Jira / Linear / GitHub Issues).
Create one ticket per row above. Tag with `area/monitoring`, `area/helm`,
or `area/ci`. Estimate per the time given.

Rough sequencing:
- **Monday morning** — section 1.1 – 1.4
- **Monday afternoon** — section 1.5 – 1.6
- **Week 1** — pick 3 from horizon 2 based on biggest pain
- **Quarter** — horizon 3 is bonus

When a horizon-2 item lands, move it from this file to `CHANGELOG.md` so
the roadmap doesn't bloat.
