"""Business-report authorization + delivery-audience policy — one chokepoint.

DESIGN DECISION (RLS at delivery, 2026-08-04) — stated explicitly:

A subscription delivery executes at the report OWNER's RLS scope and mails
the SAME bytes to every recipient ("same-bytes-to-all").  Recipients are
arbitrary e-mail strings — they are not principals and CANNOT be evaluated
against row-security (an external address has no RLS identity).  Re-executing
per recipient is therefore impossible in general; pretending otherwise would
be security theatre.  The enforceable enterprise semantic is
**authorization-to-distribute**:

  1. CREATE-time gate — only a principal who can already VIEW the report may
     create/point a subscription at it (they could read the owner-scoped
     rows interactively anyway, so directing where the extract goes adds no
     new data access).
  2. SEND-time re-check — before EVERY delivery the subscription creator's
     view access is re-validated (revocation-safe: unshare/unpublish stops
     the mail on the next tick, fail-closed).
  3. Audience policy — recipient addresses are validated against the
     config-driven ``delivery.allowed_recipient_domains`` allowlist at
     creation AND at send time (default empty = allow all, preserving the
     existing default; operators flip one config knob to fence deliveries
     to corporate domains).

The divergence that existed before — execution scope enforced, delivery
audience silently unchecked — is closed at this boundary, and the semantics
are documented HERE, once, instead of implied in three call sites.

``can_view_business_report`` is the single view-access decision reused by
the API layer (``_br_can_view``), subscription creation, and delivery — one
chokepoint, no drifting copies.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_EMAIL_RE = re.compile(r"^[^@\s]+@([^@\s]+\.[^@\s]+)$")


def _published_role_ok(report: dict, user: Optional[dict]) -> bool:
    """Does the report's ``role_whitelist`` admit this user's role?

    2026-08-05 audit fix: ``role_whitelist`` (BusinessReport column — "[] =
    all roles; ['admin','analyst'] = restricted") was documented as rule 6 of
    the Phase-157 resolution order but was INERT on every data endpoint: the
    entitlements source granted view for ANY authenticated user the moment
    ``is_published`` was true, before the whitelist was ever consulted.  A
    published report restricted to ["finance"] was viewable and executable by
    every authenticated user.  The whitelist now gates the is_public
    normalisation, so "published" means "published to the whitelisted roles"
    (empty whitelist = everyone, unchanged).  Owner / owner-group / explicit
    grants / admin / support are unaffected — they are evaluated before or
    independently of is_public.

    Fail-CLOSED for this source on evaluation error: the Phase-157 fallback
    below still grants published+empty-whitelist, so a broken import cannot
    black out legitimately published reports.
    """
    wl = report.get("role_whitelist") or []
    if not wl:
        return True
    try:
        # Reuse the ONE whitelist matcher (Phase-157 chokepoint) — never a
        # second implementation that can drift.
        from core.business_report_permissions import _role_whitelist_match
        return _role_whitelist_match(report, user or {})
    except Exception as exc:
        logger.debug("role_whitelist evaluation failed (fail-closed for "
                     "is_public): %s", exc)
        return False


def _resolve_sees_all(user: Optional[dict]) -> bool:
    """Whether this principal sees every report (admin-like / support / admin).

    Fail-CLOSED: a resolution failure is False, never broader access.
    """
    try:
        from core.entitlements import is_admin_like, is_support
        from core import business_report_permissions as _perm
        return bool(user) and bool(
            is_admin_like(user) or is_support(user) or _perm._is_admin(user))
    except Exception as exc:
        logger.debug("viewer-ctx admin resolution failed (fail-closed): %s", exc)
    return False


def _resolve_group_ids(db, username: str) -> frozenset:
    """Batch-resolve the group ids this username belongs to.

    Fail-CLOSED: an unavailable or broken lookup yields the empty set.
    """
    try:
        if hasattr(db, "user_groups_for_username"):
            ids = db.user_groups_for_username(username) or []
            return frozenset(int(x) for x in ids if x is not None)
    except Exception as exc:
        logger.debug("viewer-ctx group resolution failed (fail-closed): %s", exc)
    return frozenset()


def _resolve_granted_report_ids(db, username: str,
                                group_ids, role_names=()) -> tuple[frozenset, bool]:
    """Batch-resolve the report ids this caller holds an ACTIVE grant on --
    by name, by a user group, or (2026-11-10) by an application role held.

    Returns ``(ids, resolved)``.  ``resolved=False`` signals that the batch
    lookup was unavailable (partial/stub DB managers); the ctx check then
    falls back to the per-report grant lookup so grant holders are never
    silently denied.  Fail-CLOSED: empty set, not-resolved.
    """
    try:
        if hasattr(db, "list_br_grants_for_user"):
            from core.business_report_permissions import _grant_is_active
            rows = _grant_rows_for(db, username, group_ids, role_names)
            return frozenset(
                int(g["report_id"]) for g in rows
                if g.get("report_id") and _grant_is_active(g)), True
    except Exception as exc:
        logger.debug("viewer-ctx grant resolution failed (fail-closed): %s", exc)
    return frozenset(), False


def _grant_rows_for(db, username: str, group_ids, role_names) -> list:
    """The caller's grant rows by name, group and (2026-11-10) role; a stand-in
    manager from before the role grants answers the old call."""
    try:
        return db.list_br_grants_for_user(
            username, group_ids=sorted(group_ids), role_names=sorted(role_names or ())) or []
    except TypeError:
        return db.list_br_grants_for_user(username, group_ids=sorted(group_ids)) or []


def resolve_viewer_context(user: Optional[dict], db) -> Dict[str, Any]:
    """Resolve ONCE per request the per-user data the view decision needs.

    2026-08-09 (metadata-scale audit findings 2/6/7): the per-report view
    decision costs 1-5 SQL queries EACH (group membership + grants re-queried
    per ROW), which is what kills listing/search at scale.  This helper
    front-loads those lookups — 2 SQL queries per REQUEST — so
    ``can_view_business_report(..., ctx=...)`` can evaluate each report
    dict-only.  The DECISION rule itself stays single-sourced: the ctx path
    mirrors the exact Phase-157 resolution order and reuses the same
    primitive helpers (``_published_role_ok``, ``is_admin_like``,
    ``is_support``, ``_is_admin``, ``_grant_is_active``).

    Fail-CLOSED: any resolution failure yields empty sets / False flags —
    never broader access.  ``grants_resolved=False`` signals that the batch
    grant lookup was unavailable (partial/stub DB managers); the ctx check
    then falls back to the per-report grant lookup so grant holders are
    never silently denied.
    """
    username = str((user or {}).get("username")
                   or (user or {}).get("user") or "").strip()
    ctx: Dict[str, Any] = {
        "username": username,
        "sees_all": _resolve_sees_all(user),
        "group_ids": frozenset(),
        "granted_report_ids": frozenset(),
        "grants_resolved": False,
    }
    if not username or db is None:
        return ctx
    ctx["group_ids"] = _resolve_group_ids(db, username)
    from core.business_report_permissions import _user_role_names
    granted, resolved = _resolve_granted_report_ids(
        db, username, ctx["group_ids"], _user_role_names(user or {}))
    ctx["granted_report_ids"] = granted
    ctx["grants_resolved"] = resolved
    return ctx


def _ctx_identity_allows(report: dict, user: Optional[dict], username: str,
                         ctx: Dict[str, Any]) -> bool:
    """Identity-based sources of the ctx rule: published, owner, owner-group.

    Dict-only against the pre-resolved group set — 0 SQL per report.
    """
    # Published within role_whitelist (dict-only).
    if bool(report.get("is_published")) and _published_role_ok(report, user):
        return True
    # Owner (case-insensitive — matches core.entitlements).
    owner = str(report.get("owner") or "")
    if owner and owner.lower() == username.lower():
        return True
    # Owner-group membership (pre-resolved).
    og = report.get("owner_group_id")
    return og is not None and int(og) in ctx.get("group_ids", frozenset())


def _ctx_grant_allows(report: dict, user: Optional[dict], db,
                      ctx: Dict[str, Any]) -> bool:
    """Explicit per-user / per-group grants — any level implies view."""
    rid = int(report.get("id") or 0)
    if rid and rid in ctx.get("granted_report_ids", frozenset()):
        return True
    if rid and not ctx.get("grants_resolved"):
        # Batch grant lookup unavailable (stub/partial DB manager):
        # keep exact Phase-157 grant semantics via the per-report
        # chokepoint lookup instead of silently denying.
        from core.business_report_permissions import _highest_grant_level
        return bool(_highest_grant_level(rid, user or {}, db))
    return False


def _ctx_view_allows(report: dict, user: Optional[dict], db,
                     ctx: Dict[str, Any]) -> bool:
    """The BATCHED form of the view rule, in Phase-157 resolution order.

    Any edit to the resolution order in
    ``business_report_permissions.effective_level`` or in
    ``_canonical_view_allows`` MUST be mirrored here.  Raises rather than
    denying, so the caller can fall back to the canonical evaluation.
    """
    if ctx.get("sees_all"):
        return True
    username = ctx.get("username") or ""
    if not username:
        # Anonymous access only via share/embed-token paths, which
        # bypass this function — same rule as the per-report path.
        return False
    if _ctx_identity_allows(report, user, username, ctx):
        return True
    return _ctx_grant_allows(report, user, db, ctx)


def _canonical_view_allows(report: dict, user: Optional[dict], db) -> bool:
    """The per-report view decision: shared entitlements, then explicit grants.

    Each source is fail-CLOSED INDEPENDENTLY — a broken entitlements import
    still leaves the grant chokepoint a chance before the final DENY.
    """
    try:
        from core.entitlements import can_view as _can_view
        normalised = {
            "is_public":      bool(report.get("is_published"))
                              and _published_role_ok(report, user),
            "created_by":     report.get("owner"),
            "owner_group_id": report.get("owner_group_id"),
        }
        if _can_view(normalised, user, db=db):
            return True
    except Exception as exc:
        # Fail-closed on this source; the explicit-grant chokepoint below
        # still gets a chance before the final DENY.
        logger.debug("entitlements view-check failed (fail-closed): %s", exc)
    try:
        from core import business_report_permissions as _perm
        return bool(_perm.can_view(report, user, db))
    except Exception as exc:
        logger.debug("permission-chokepoint view-check failed (fail-closed): %s", exc)
        return False


def can_view_business_report(report: dict, user: Optional[dict], db,
                             ctx: Optional[Dict[str, Any]] = None) -> bool:
    """May ``user`` view ``report``?  Fail-closed on any resolution error.

    Sources consulted (in order, first ALLOW wins):
      1. shared entitlements (is_published-within-role_whitelist / owner /
         owner_group_id / admin),
      2. explicit per-user / per-group grants
         (``core.business_report_permissions`` chokepoint).

    ``ctx`` (optional, from ``resolve_viewer_context``): the batched form of
    the SAME rule for list/search paths — evaluates dict-only (0 SQL per
    report) against the pre-resolved group/grant sets.  Any edit to the
    resolution order in ``business_report_permissions.effective_level`` or
    the sources above MUST be mirrored in ``_ctx_view_allows``.
    """
    if ctx is not None:
        try:
            return _ctx_view_allows(report, user, db, ctx)
        except Exception as exc:
            logger.debug("ctx view-check failed — falling back to the "
                         "per-report path: %s", exc)
            # Fall through to the canonical per-report evaluation.
    return _canonical_view_allows(report, user, db)


def can_run_business_report(report: dict, user: Optional[dict], db) -> bool:
    """May ``user`` RUN ``report`` (execute it, export it)?  2026-11-10: the gap
    "can_run is called by nothing" closed, with nobody losing a run:

      * not viewable -> no (the view rule first, as every road already asks);
      * admin / support (``_resolve_sees_all``) -> yes, as they always could;
      * else the Phase-157 level: owner / owner group / a grant at ``runner`` or
        above / published to a role held (that road answers ``runner``).  The
        only ``view``-level grants are those made after 2026-11-10 (the earlier
        ones were restamped ``runner`` once at start): they open the saved
        result and do not run.
    """
    if not can_view_business_report(report, user, db):
        return False
    if _resolve_sees_all(user):
        return True
    try:
        from core import business_report_permissions as _perm
        return bool(_perm.can_run(report, user, db))
    except Exception as exc:
        logger.debug("permission-chokepoint run-check failed (fail-closed): %s", exc)
        return False


def _published_row_is_listable(r: dict, user: Optional[dict], db,
                               ctx: Dict[str, Any]) -> bool:
    """Whether a PUBLISHED row belongs in the consumer listing's bucket.

    Publish lifecycle (2026-08-17): archived/deprecated reports keep
    is_published so a DIRECT id stays resolvable for audit, but they
    must not appear in the consumer listing's published bucket.  Own
    rows and explicit grants are unaffected — the author keeps seeing
    their archived reports.  Mirrors the SQL clause in
    DatabaseManager._br_visibility_clauses.

    2026-08-05 audit fix (kept verbatim): a non-empty role_whitelist
    restricts a PUBLISHED report to the whitelisted roles.  The check
    runs through the view chokepoint so grants / support-role
    semantics stay consistent with GET /{id} and /execute.
    """
    if (r.get("lifecycle_status") or "") in ("archived", "deprecated"):
        return False
    if (r.get("role_whitelist") or []) and not can_view_business_report(
            r, user, db, ctx=ctx):
        return False
    return True


def _grant_expanded_rows(db, user: Optional[dict], ctx: Dict[str, Any],
                         seen_ids: set) -> List[Dict[str, Any]]:
    """Reports the caller holds an explicit grant on and has not seen yet.

    Phase 157 — the candidate ids come from the per-request ctx (single
    batch lookup); each candidate is re-checked through the chokepoint so
    a fail-CLOSED resolver keeps any odd row out.  *seen_ids* is updated
    in place, as the inline loop did.
    """
    rows: List[Dict[str, Any]] = []
    try:
        for rid in sorted(set(ctx.get("granted_report_ids", ())) - seen_ids):
            r = db.get_business_report(int(rid))
            if not r:
                continue
            if can_view_business_report(r, user, db, ctx=ctx):
                rows.append(r)
                seen_ids.add(int(rid))
    except Exception as exc:
        logger.debug("[br-perm] list grant-expansion skipped: %s", exc)
    return rows


def list_visible_business_reports(db, user: Optional[dict],
                                  dataset_id: Optional[int] = None) -> List[Dict[str, Any]]:
    """Non-admin visible business-report list — ONE chokepoint (2026-08-09).

    Extracted from ``GET /api/business-reports`` (business_reports_api) so
    the unified catalog (``GET /api/report-catalog``) applies the SAME
    visibility rule instead of its own drifted copy (metadata-scale audit
    finding 7: the catalog skipped the 2026-08-05 role_whitelist gate).
    Same house pattern as the ``_check_result_access`` extraction (76d765a5).

    Rule (unchanged from the main list endpoint):
      * own reports,
      * published reports — a non-empty ``role_whitelist`` restricts them to
        the whitelisted roles (empty = everyone),
      * Phase-157 explicit per-user / per-group grants (NOT filtered by
        ``dataset_id`` — preserved pre-extraction behavior),
    sorted by ``updated_at`` descending.

    Cost: the caller's groups + grants are resolved ONCE per request
    (``resolve_viewer_context``); each report evaluation is dict-only —
    previously every whitelist-restricted published row and every grant
    candidate cost 1-5 SQL queries.

    Callers handle the admin tier themselves (admins list everything).
    """
    username = str((user or {}).get("username") or "").strip()
    ctx = resolve_viewer_context(user, db)

    own = db.list_business_reports(owner=username, dataset_id=dataset_id)
    published = db.list_business_reports(is_published=True, dataset_id=dataset_id)

    seen_ids = {r["id"] for r in own}
    combined = list(own)
    for r in published:
        if r["id"] in seen_ids:
            continue
        if not _published_row_is_listable(r, user, db, ctx):
            continue
        combined.append(r)
        seen_ids.add(r["id"])

    combined.extend(_grant_expanded_rows(db, user, ctx, seen_ids))

    combined.sort(key=lambda r: r.get("updated_at") or "", reverse=True)
    return combined


def list_visible_business_reports_page(db, user: Optional[dict], *,
                                       limit: int = 100,
                                       cursor: Optional[str] = None,
                                       owner: Optional[str] = None,
                                       dataset_id: Optional[int] = None,
                                       published_only: bool = False,
                                       q: Optional[str] = None,
                                       sort: Optional[str] = None,
                                       favorites_only: bool = False,
                                       folder_id: Optional[int] = None,
                                       tag_id: Optional[int] = None,
                                       include_samples: bool = False) -> Dict[str, Any]:
    """PAGINATED visible business-report list — extension of the
    ``list_visible_business_reports`` chokepoint (2026-08-09, metadata-scale
    audit finding 1), not a fourth visibility rule.

    The visibility rule is the SAME resolve_viewer_context ctx evaluated by
    the unpaginated chokepoint; here it is pushed INSIDE the SQL query
    (``DatabaseManager._br_visibility_clauses`` — the clause builder
    cabf95b7 introduced for search) so pagination composes with visibility:
    filtering AFTER a limit silently shrinks or empties pages (the exact
    defect the audit found in the parametric list, reports_api.py:574-577).
    Only the role_whitelist trim on published rows stays in Python
    (JSON column), covered by the DB method's over-fetch page-honesty loop.

    Admin tier (``ctx.sees_all``) pages WITHOUT the visibility predicate —
    same "admins list everything" contract as the legacy branches.

    Returns the DB method's envelope: ``{items, next_cursor, has_more,
    limit}`` with slim ``to_summary_dict()`` items (never
    ``raw_sql_override`` — a list payload is not a detail payload).
    Raises ValueError on a malformed cursor (callers map to HTTP 400).
    """
    ctx = resolve_viewer_context(user, db)
    return db.list_business_reports_page(
        viewer=user, ctx=ctx, limit=limit, cursor=cursor,
        owner=owner, dataset_id=dataset_id,
        is_published=True if published_only else None, q=q,
        # 2026-08-11 — sort / favourites / folder / tag ride THROUGH this
        # chokepoint rather than around it, so they can only ever narrow the
        # set the visibility rule already admitted.
        sort=sort, favorites_only=favorites_only,
        folder_id=folder_id, tag_id=tag_id,
        # 2026-09-18 -- rides THROUGH the chokepoint like sort/favourites
        # above, so it can only narrow the set visibility already admitted.
        include_samples=include_samples)


def build_principal(username: str) -> Dict[str, Any]:
    """Resolve a username to a least-privilege-on-failure principal.

    Delegates to the F1 owner-context resolver (``core.scheduler``) — the
    SAME chokepoint scheduled execution uses — so delivery-time authorization
    and execution-time RLS can never disagree about who a username is.
    """
    try:
        from core.scheduler import _resolve_owner_user_ctx
        return _resolve_owner_user_ctx(username)
    except Exception as exc:
        logger.warning("principal resolution failed for %r — least-privilege "
                       "fallback (fail-closed): %s", username, exc)
        from core.app_roles.principal import unresolved_principal
        return unresolved_principal(username or "")


def _allowed_recipient_domains() -> List[str]:
    """The configured delivery-audience allowlist, normalised and lowercased.

    Unreadable config degrades to syntax-only validation (empty list) —
    which is also the documented default, so an operator opts IN.
    """
    from core import config as _cfg
    try:
        return [d.strip().lower().lstrip("@")
                for d in (_cfg.delivery.allowed_recipient_domains or [])
                if d and d.strip()]
    except Exception as exc:
        logger.warning("allowed_recipient_domains unreadable — applying "
                       "syntax-only validation: %s", exc)
        return []


def _recipient_violates(addr: str, allowed: List[str]) -> bool:
    """Whether ONE recipient breaks the delivery audience policy.

    Syntax first; then, only when a domain allowlist is configured, the
    domain must match one of it (case-insensitive, subdomains accepted).
    """
    m = _EMAIL_RE.match((addr or "").strip())
    if not m:
        return True
    if not allowed:
        return False
    domain = m.group(1).lower()
    return not any(domain == d or domain.endswith("." + d) for d in allowed)


def validate_recipients(emails: List[str]) -> List[str]:
    """Return the recipients that VIOLATE the delivery audience policy.

    Empty return = all recipients acceptable.  Policy:
      * every entry must be a plausible e-mail address;
      * when ``delivery.allowed_recipient_domains`` is configured (non-empty),
        every recipient's domain must match one of the allowed domains
        (case-insensitive, subdomains of an allowed domain accepted).
    Default config is empty → only the syntactic check applies (no behavior
    change until an operator opts in).
    """
    allowed = _allowed_recipient_domains()

    invalid: List[str] = []
    for addr in emails or []:
        if _recipient_violates(addr, allowed):
            invalid.append(addr)
    return invalid
