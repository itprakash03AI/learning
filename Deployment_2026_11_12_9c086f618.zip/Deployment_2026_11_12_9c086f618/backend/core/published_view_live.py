"""A published API runs its source's LATEST query (owner, 2026-11-11).

The owner: "publish api on snow flake still failing ... same query have updated n working in
bqb", then "we cant freeze query ... it should run latest query".

A view published from a SAVED QUERY or a SQL FILE stored a frozen copy of the SQL at publish
time (``published_views.query_config``), so an edit to the query reached the reports and the
editor but never the API: it kept running the old text until someone pressed Republish -- the
owner's API kept sending the table name as first written, and failed, while the same query
worked everywhere else.  A business-report or federation view already pointed at its source by
id and read it live; these two now do too.

ONE rule, :func:`source_query_config` -- what the view would be if it were republished now.
Used by Republish (``api/published_views/management.py``) and by the two getters every serving
road goes through (``DatabaseManager.get_published_view`` / ``get_published_view_by_slug``:
the API, GraphQL, feeds, canvas actions, datasets on a view).  When the source's query differs
from the stored copy the getter serves the source's and records it (``update_published_view``
bumps ``version`` + ``query_hash``), so the cache identity (``view_identity``, keyed on the
config) misses and nothing old is served.

Unknown is not "no change": a source that cannot be read (deleted query, missing file) keeps the
stored copy and is logged -- the view's source status (``_with_source_status``) already says the
source is gone.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

#: The source types whose query is a COPY in the view.  business_report / federation are
#: references read live already.
LIVE_SOURCE_TYPES = ("saved_query", "sql_file", "sql_query")


def apply_where_mapping(snapshot: Optional[Dict[str, Any]], where_clauses) -> Dict[str, Any]:
    """The publisher's WHERE mapping merged into a query config -- ONE rule for publish and for
    every re-read of the source (moved from the publish route, 2026-11-11).

    A STATIC row replaces any filter on the same column (by case-insensitive bare name) and is
    appended; a dynamic row adds no filter (the route puts its column in ``allowed_filters``).
    The mapping itself is kept as ``_where_clauses_mapping`` so the dialog can re-render it and
    the next re-read can re-apply it.  A new dict; the input (shared by reference with the saved
    query in some paths) is untouched."""
    wc = [dict(w) for w in (where_clauses or [])]
    out = dict(snapshot or {})
    if not wc:
        return out

    def _bare(col: str) -> str:
        return (col or "").rsplit(".", 1)[-1].lower()

    static = {_bare(w.get("column") or "") for w in wc if w.get("mode") == "static"}
    kept = [f for f in list(out.get("filters") or []) if _bare(f.get("column") or "") not in static]
    for w in wc:
        if w.get("mode") == "static":
            kept.append({"column": w.get("column"), "operator": w.get("operator"), "value": w.get("value")})
    out["filters"] = kept
    out["_where_clauses_mapping"] = wc
    return out


class SourceUnreadable(Exception):
    """The view's source could not be read; the stored copy stays."""


def source_query_config(db: Any, pv: Dict[str, Any]) -> Optional[Tuple[Dict[str, Any], Any]]:
    """``(query_config, connection_id)`` the view's source holds NOW, or None when the view's
    source type is not a copied query.  Raises :class:`SourceUnreadable` when it cannot be read."""
    source_type = pv.get("source_type") or "saved_query"
    if source_type == "sql_file":
        sf = db.get_sql_file(pv.get("sql_file_id"))
        if not sf:
            raise SourceUnreadable(f"SQL file {pv.get('sql_file_id')} not found")
        from api.sql_files_api import _get_storage_dir, _split_cross_sql
        path = _get_storage_dir() / sf["file_path"]
        if not path.exists():
            raise SourceUnreadable(f"SQL file {sf.get('name') or pv.get('sql_file_id')} is not on disk")
        primary, secondary = _split_cross_sql(path.read_text(encoding="utf-8"))
        cfg: Dict[str, Any] = {
            "source_type": "sql_file",
            "sql_file_id": pv.get("sql_file_id"),
            "raw_sql": primary,
            "connection_id": sf.get("connection_id"),
        }
        if sf.get("secondary_connection_id") and secondary:
            cfg["secondary_connection_id"] = sf["secondary_connection_id"]
            cfg["secondary_raw_sql"] = secondary
            cfg["combine_mode"] = sf.get("combine_mode", "union")
            cfg["join_config"] = sf.get("join_config")
        return _with_mapping(pv, cfg), sf.get("connection_id")
    if source_type == "sql_query":
        qc = pv.get("query_config") or {}
        sq_id = qc.get("sql_query_id")
        if not sq_id:
            return None
        sq = db.get_sql_query(sq_id)
        if not sq:
            raise SourceUnreadable(f"SQL saved query {sq_id} not found")
        cfg = {"source_type": "sql_query", "sql_query_id": sq_id,
               "raw_sql": sq["primary_sql"], "connection_id": sq["primary_connection_id"]}
        if sq.get("secondary_connection_id") and sq.get("secondary_sql"):
            cfg["secondary_connection_id"] = sq["secondary_connection_id"]
            cfg["secondary_raw_sql"] = sq["secondary_sql"]
            cfg["combine_mode"] = sq.get("combine_mode") or ("join" if sq.get("join_config") else "union")
            if sq.get("join_config"):
                cfg["join_config"] = sq["join_config"]
        return _with_mapping(pv, cfg), sq["primary_connection_id"]
    if source_type == "saved_query":
        if not pv.get("query_id"):
            return None                      # published from an ad-hoc query: the copy IS the source
        sq = db.get_query(pv.get("query_id"))
        if not sq:
            raise SourceUnreadable(f"saved query {pv.get('query_id')} not found")
        cfg = sq.get("query_config") or {}
        return _with_mapping(pv, cfg), cfg.get("connection_id")
    return None


def _with_mapping(pv: Dict[str, Any], cfg: Dict[str, Any]) -> Dict[str, Any]:
    """The publisher's own static WHERE rows, re-applied over the source's latest query."""
    mapping = (pv.get("query_config") or {}).get("_where_clauses_mapping")
    return apply_where_mapping(cfg, mapping) if mapping else dict(cfg)


def with_latest_query(db: Any, row: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """``row`` serving its source's latest query (the stored copy updated when it differs).
    Never raises: a source that cannot be read leaves the row as stored."""
    if not row or (row.get("source_type") or "saved_query") not in LIVE_SOURCE_TYPES:
        return row
    try:
        latest = source_query_config(db, row)
    except SourceUnreadable as exc:
        logger.warning("[pv-live] view %s keeps its stored query: %s", row.get("slug"), exc)
        return row
    except Exception as exc:  # noqa: BLE001 -- serving the stored copy beats failing the request
        logger.warning("[pv-live] view %s: its source could not be read (%s); the stored query "
                       "is served", row.get("slug"), exc)
        return row
    if latest is None:
        return row
    cfg, conn_id = latest
    stored = row.get("query_config") or {}
    if _same(stored, cfg) and (conn_id is None or row.get("connection_id") == conn_id):
        return row
    row["query_config"] = cfg
    if conn_id is not None:
        row["connection_id"] = conn_id
    try:
        updated = db.update_published_view(row["id"], query_config=cfg,
                                           **({"connection_id": conn_id} if conn_id is not None else {}))
        if updated:
            for k in ("version", "query_hash", "updated_at"):
                if k in updated:
                    row[k] = updated[k]
        logger.info("[pv-live] view %s follows its %s: the query changed since it was published "
                    "(now version %s)", row.get("slug"), row.get("source_type") or "saved_query",
                    row.get("version"))
    except Exception as exc:  # noqa: BLE001 -- the latest query is served either way
        logger.warning("[pv-live] view %s serves its source's latest query; recording it failed "
                       "(%s)", row.get("slug"), exc)
    return row


def _same(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
    import json
    return json.dumps(a or {}, sort_keys=True, default=str) == json.dumps(b or {}, sort_keys=True, default=str)
