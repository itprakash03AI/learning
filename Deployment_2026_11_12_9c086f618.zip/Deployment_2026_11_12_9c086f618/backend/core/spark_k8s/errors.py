"""Exception vocabulary for the spark_k8s backend.

Design rule (2026-08-22, from the day's audit culture): "the cluster said
no" and "our code is wrong" must be distinguishable AT THE TYPE LEVEL.
``SparkK8sApiError`` is raised ONLY by the client wrapper translating a
kubernetes ``ApiException`` (an HTTP status from the API server).  Every
other exception escaping this package — TypeError, KeyError, AttributeError
— is a programming error and handlers in this package deliberately let it
propagate (or log it at ERROR as a bug, never as an infra hiccup).
"""
from __future__ import annotations


class SparkK8sError(RuntimeError):
    """Base class for spark_k8s backend failures."""


class SparkK8sApiError(SparkK8sError):
    """The Kubernetes API server answered with an error status.

    The one and only shape "the cluster said no" takes inside this
    package.  ``status`` is the HTTP status code (409 = AlreadyExists,
    404 = NotFound, 403 = Forbidden, ...).
    """

    def __init__(self, status: int, reason: str = "", body: str = ""):
        self.status = int(status)
        self.reason = str(reason or "")
        self.body = str(body or "")[:2000]
        super().__init__(
            f"Kubernetes API error {self.status}"
            f"{f' ({self.reason})' if self.reason else ''}"
            f"{f': {self.body}' if self.body else ''}"
        )


class SparkK8sUnreachable(SparkK8sError):
    """The Kubernetes API server did not ANSWER (2026-10-07, D3).

    Its own type, next to ``SparkK8sApiError`` and never folded into it:
    "the cluster said no" (an HTTP status) and "nothing answered" (DNS,
    connection refused, a connect timeout, a dropped connection) are
    different facts with different remedies.  Before this the kubernetes
    client's raw ``urllib3`` exception escaped the wrapper untouched, so a
    stopped cluster failed a feed with "HTTPSConnectionPool(host=...,
    port=6443): Max retries exceeded" and the availability probe booked it
    as a BUG in the probe.

    * ``host`` -- the API server host, for the plain-language reason;
    * ``cause`` -- a short phrase ("connection refused", "the name does not
      resolve", ...), never the urllib3 text (that stays in ``detail``, for
      the log);
    * ``request_sent`` -- False ONLY when the failure happened while
      CONNECTING, so the request provably never reached the server.  A read
      timeout or a dropped connection may have been after the server acted;
      unknown is unsafe, so those are True;
    * ``nothing_created`` -- set by the submitter: True only when no create
      of this attempt succeeded AND the failing create was never sent, i.e.
      nothing of this run can exist on the cluster.  The ONLY state in which
      a run may move to another engine (a second engine over a workload
      that might exist is a double run).
    """

    def __init__(self, host: str = "", cause: str = "", *,
                 detail: str = "", request_sent: bool = True,
                 nothing_created: bool = False):
        self.host = str(host or "the Kubernetes API server")
        self.cause = str(cause or "no answer")
        self.detail = str(detail or "")[:2000]
        self.request_sent = bool(request_sent)
        self.nothing_created = bool(nothing_created)
        super().__init__(f"spark cluster unreachable: {self.host} "
                         f"({self.cause})")


class SparkK8sUnavailable(SparkK8sError):
    """A DECLARED refusal from the availability ladder.

    ``reason_code`` is one of ``availability.REASON_*`` — machine-greppable
    so routing decisions, logs and API responses all carry the same
    vocabulary.  Never raised for an unexpected condition; those keep
    their original exception type.
    """

    def __init__(self, reason_code: str, detail: str = ""):
        self.reason_code = str(reason_code)
        self.detail = str(detail or "")
        super().__init__(
            f"spark_k8s unavailable: {self.reason_code}"
            f"{f' — {self.detail}' if self.detail else ''}"
        )


class SparkK8sCredentialLifetime(SparkK8sError):
    """D10 (2026-09-02) — a DECLARED refusal at submit: this run's
    budget exceeds the expected life of the temporary credentials it
    would use.

    Its own type, not a generic error, because the ONLY correct handling
    is to leave it terminal: retrying is precisely what does not work.
    A 403 half way through a long read classifies as retryable, so the
    resubmit hits the same expiry from a clock that has already moved.
    """

    def __init__(self, execution_id: str, detail: str):
        self.execution_id = str(execution_id)
        self.detail = str(detail)
        super().__init__(
            f"spark_k8s refused {self.execution_id} at submit: {self.detail}")


class SparkK8sConfRefused(SparkK8sError, ValueError):
    """2026-11-09 -- a DECLARED refusal at submit: the run's conf could not
    be built from its feed and connection (``build_feed_conf`` raised: a
    Databricks connection without server_hostname / http_path or without a
    token, a connection type with no JDBC grammar, an Iceberg read that
    cannot be pinned).  Nothing was created.  A ValueError too, so every
    caller that read the plain refusal keeps reading it.  The router's
    submit-time rule reads ``reason_code`` / ``detail``: a SIZE-routed run
    moves to native with the reason recorded, a PINNED run fails in words.
    """
    reason_code = "conf_refused"
    nothing_created = True

    def __init__(self, execution_id: str, detail: str):
        self.execution_id = str(execution_id)
        self.detail = str(detail)
        SparkK8sError.__init__(
            self, f"spark_k8s refused {self.execution_id} at submit: {self.detail}")


class SparkK8sDriverMissing(SparkK8sError):
    """FR-ARCH-02 (2026-09-03) — a DECLARED refusal at submit: the JDBC
    driver class this run needs is not on the Spark image's declared
    classpath.

    Its own type because the correct handling is terminal-and-named:
    retrying resubmits against the same image, and the after-the-fact
    spelling of this failure (``classnotfoundexception`` from the dead
    driver pod) is already classified NON_RETRYABLE by classifier.py —
    this is the same fact caught before any pod is born.
    """

    def __init__(self, execution_id: str, detail: str):
        self.execution_id = str(execution_id)
        self.detail = str(detail)
        super().__init__(
            f"spark_k8s refused {self.execution_id} at submit: {self.detail}")
