"""The ONE Spark workload submitter (2026-08-22; driver-pod mode wired
2026-09-13).

The workload is a ``SparkApplication`` CR (``submit_mode="spark_application"``,
spark-operator turns it into a driver pod) or the driver ``Pod`` itself
(``submit_mode="driver_pod"``, no operator).  The mode reaches exactly the
seams below the ``CrStatus`` section — ``build_workload_spec``,
``create_workload``, ``get_workload``, ``list_workloads``,
``delete_workload`` — and the one status-shape branch in
``extract_cr_status``.  Nothing else in this package asks which shape it
is driving.

Both entry paths route here:

* the native ``feed_engine._execute_spark_k8s`` dispatch, and
* the Airflow feed factory, via ``POST
  /api/feed-executions/{execution_id}/spark-submit`` (the DAG no longer
  builds or creates anything itself).

Ordering contract: the per-attempt credentials Secret is created BEFORE the
CR so the driver's ``secretKeyRef`` resolves on first mount.  A 409 on the
Secret means a previous identical attempt already staged it → replace (the
payload is deterministic for a given attempt).  A 409 on the CR means the
attempt is ALREADY RUNNING → adoption, never failure; the CR name is the
idempotency key.

DELIBERATE CHANGE from the DAG-era behaviour: when Secret creation fails,
the DAG fell back to embedding credentials on the driver's command line
("fail-safe").  That fallback silently downgraded the credential posture
whenever RBAC drifted; here it is a loud failure naming the Secret RBAC.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Optional

from core.spark_k8s import availability as _avail
from core.spark_k8s.errors import (
    SparkK8sApiError,
    SparkK8sError,
    SparkK8sCredentialLifetime,
    SparkK8sDriverMissing,
    SparkK8sUnavailable,
    SparkK8sUnreachable,
)
from core.spark_k8s.jdbc import assert_driver_on_classpath
from core.spark_k8s.feed_conf import build_feed_conf
from core.spark_k8s.manifest import (
    SUBMIT_MODE_AUTO,
    SUBMIT_MODE_CR,
    SUBMIT_MODE_POD,
    SparkK8sSettings,
    assert_concrete_submit_mode,
    assert_known_submit_mode,
    build_driver_pod_spec,
    build_spark_application_spec,
    credential_lifetime_refusal,
    cr_name_for,
    secret_body_for,
    resolve_job_timeout_seconds,
    secret_name_for,
    settings_from_config,
)

logger = logging.getLogger(__name__)

BACKEND_NAME = "spark_k8s"


@dataclass(frozen=True)
class SubmitResult:
    cr_name: str
    secret_name: Optional[str]
    adopted: bool  # True == the CR already existed (409): already running


@dataclass(frozen=True)
class CrStatus:
    found: bool
    state: str            # "" | SUBMITTED | RUNNING | COMPLETED | FAILED | ...
    error_message: str = ""
    termination_time: str = ""


def extract_cr_status(cr: Optional[dict]) -> CrStatus:
    """The workload's state, whatever SHAPE the workload is.

    Two producers, one vocabulary:

    * a SparkApplication carries ``status.applicationState.{state,
      errorMessage}`` + ``status.terminationTime`` (spark-operator);
    * a driver Pod carries ``status.phase`` + ``status.reason`` (the
      kubelet).

    Branching on the shape HERE, rather than teaching the reconciler
    about two workloads, is what keeps the second submit mode from
    becoming a twin of the lifecycle: retry, backoff, grace, timeouts,
    secret handling and reaping all consume ``CrStatus`` and never look
    at the object again.
    """
    if not cr:
        return CrStatus(found=False, state="")
    status = cr.get("status") or {}
    app_state = status.get("applicationState") or {}
    if app_state or "phase" not in status:
        return CrStatus(
            found=True,
            state=str(app_state.get("state") or ""),
            error_message=str(app_state.get("errorMessage") or ""),
            termination_time=str(status.get("terminationTime") or ""),
        )
    # Pod shape.  The phase vocabulary (Pending/Running/Succeeded/
    # Failed/Unknown) is declared as DATA in classifier.py, so no code
    # here decides what a phase MEANS.
    reason = str(status.get("reason") or "")
    message = str(status.get("message") or "")
    return CrStatus(
        found=True,
        state=str(status.get("phase") or ""),
        error_message=(": ".join(p for p in (reason, message) if p)),
        termination_time=_pod_termination_time(status),
    )


def _pod_termination_time(status: dict) -> str:
    """When the driver container finished, or "".

    A Pod has no terminationTime field; the equivalent fact lives on the
    driver container's terminated state.  Returning "" when it is absent
    keeps the same contract the CR path has -- "not finished, or not
    knowable" -- rather than inventing a timestamp.
    """
    for cs in (status.get("containerStatuses") or []):
        term = ((cs.get("state") or {}).get("terminated") or {})
        finished = term.get("finishedAt")
        if finished:
            return str(finished)
    return ""


def resolve_submit_mode(settings, availability) -> str:
    """The SHAPE this submit takes -- decided ONCE, here.

    A declared concrete mode is itself.  ``auto`` is the availability
    ladder's rung (``_probe_auto``: CRD served -> CR, 404 -> driver Pod),
    which the ladder already computed and TTL-cached for this call; when
    the ladder refused, ``auto`` refuses with the ladder's reason -- it
    never guesses a shape on a 403 or an unreachable cluster.  The
    caller stores what this returns on the execution row; nothing
    downstream re-resolves.
    """
    declared = assert_known_submit_mode(
        getattr(settings, "submit_mode", SUBMIT_MODE_CR))
    if declared != SUBMIT_MODE_AUTO:
        return declared
    if not getattr(availability, "available", False):
        raise SparkK8sUnavailable(
            getattr(availability, "reason_code", "unknown"),
            "submit_mode=auto could not resolve a shape: "
            + str(getattr(availability, "detail", "") or
                  getattr(availability, "reason_code", "")))
    rung = str(getattr(availability, "rung", "") or "")
    if rung not in (SUBMIT_MODE_CR, SUBMIT_MODE_POD):
        raise SparkK8sUnavailable(
            "auto_unresolved",
            f"submit_mode=auto: the ladder answered rung {rung!r}, which is "
            f"not a workload shape -- refusing rather than guessing")
    return rung


def stored_submit_mode(execution: dict, settings=None) -> str:
    """The shape a run was SUBMITTED as, from its execution row.

    Written by ``SparkK8sRunner.submit``; read by cancel, status and
    every reconciler verb, so a run created as a CR is cancelled and
    reconciled as a CR even after the operator is uninstalled (and a
    Pod run stays a Pod after one is installed).

    A row WITHOUT the field predates 2026-09-14.  Its shape is then the
    deployment's DECLARED concrete mode (a driver_pod deployment's old
    rows are Pods), and under ``auto`` -- which did not exist when the
    row was written -- the CR shape every submit produced back then.
    Never today's probe: that would be the second decision.
    """
    stored = str((execution or {}).get("submit_mode") or "").strip().lower()
    if stored in (SUBMIT_MODE_CR, SUBMIT_MODE_POD):
        return stored
    if settings is not None:
        declared = assert_known_submit_mode(
            getattr(settings, "submit_mode", SUBMIT_MODE_CR))
        if declared in (SUBMIT_MODE_CR, SUBMIT_MODE_POD):
            return declared
    return SUBMIT_MODE_CR


def workload_kind(mode) -> str:
    """The noun for log lines and error messages -- so a driver_pod
    deployment is never told a "SparkApplication" went missing."""
    return "driver Pod" if assert_concrete_submit_mode(mode) == SUBMIT_MODE_POD \
        else "SparkApplication"


def _executor_instances(spec: dict) -> str:
    """The executor count the workload will ask for, from whichever
    shape it is: ``spec.executor.instances`` on a CR, the rendered
    ``--conf spark.executor.instances=N`` argument on a Pod."""
    if spec.get("kind") == "Pod":
        args = ((spec.get("spec") or {}).get("containers") or [{}])[0] \
            .get("args") or []
        for a in args:
            if str(a).startswith("spark.executor.instances="):
                return str(a).split("=", 1)[1]
        return "?"
    return str(((spec.get("spec") or {}).get("executor") or {})
               .get("instances", "?"))


def build_workload_spec(feed_conf_dict, execution_id, settings, mode,
                        **kw) -> dict:
    """The workload body for one CONCRETE shape -- CR or driver Pod.
    ``mode`` is what ``resolve_submit_mode`` returned (or what the row
    stores); ``settings.submit_mode`` may be ``auto`` and is not read
    here."""
    if assert_concrete_submit_mode(mode) == SUBMIT_MODE_POD:
        return build_driver_pod_spec(
            feed_conf_dict, execution_id, settings, **kw)
    return build_spark_application_spec(
        feed_conf_dict, execution_id, settings, **kw)


def create_workload(api, namespace: str, body: dict, mode) -> dict:
    if assert_concrete_submit_mode(mode) == SUBMIT_MODE_POD:
        return api.create_pod(namespace, body)
    return api.create_spark_application(namespace, body)


def get_workload(api, namespace: str, name: str, mode) -> dict:
    if assert_concrete_submit_mode(mode) == SUBMIT_MODE_POD:
        return api.get_pod(namespace, name)
    return api.get_spark_application(namespace, name)


def list_workloads(api, namespace: str, mode, **kw) -> dict:
    if assert_concrete_submit_mode(mode) == SUBMIT_MODE_POD:
        return api.list_pods(namespace, **kw)
    return api.list_spark_applications(namespace, **kw)


def delete_workload(api, namespace: str, name: str, mode) -> None:
    if assert_concrete_submit_mode(mode) == SUBMIT_MODE_POD:
        api.delete_pod(namespace, name)
        return
    api.delete_spark_application(namespace, name)


def workload_name_for(db: Any, execution: dict) -> str:
    """The workload name an execution row is bound to.

    ``external_job_id`` is what submit stored and is always preferred.
    The fallback -- a submit that died between the create and the DB
    write -- recomputes the name the SAME way submit did, which since
    2026-09-14 needs the feed name (``cr_name_for`` puts it first), so
    it is looked up here rather than guessed.  Used by cancel and by
    every reconciler site that used to call ``cr_name_for(exec_id)``
    bare -- one answer, not four.
    """
    stored = (execution or {}).get("external_job_id")
    if stored:
        return str(stored)
    exec_id = str((execution or {}).get("execution_id") or "")
    feed_name = None
    feed_id = (execution or {}).get("feed_config_id")
    if db is not None and feed_id is not None:
        try:
            cfg = db.get_feed_config(feed_id)
            feed_name = (cfg or {}).get("name")
        except Exception as exc:                   # noqa: BLE001
            logger.warning("[spark_k8s] feed name lookup for execution %s "
                           "failed (%s) -- naming the workload without it",
                           exec_id, exc)
    return cr_name_for(exec_id, feed_name=feed_name)


#: Row states after which a run's credential Secret has no reader left.
#: Everything that is not pending/running -- the reconciler's own
#: definition of "terminal" (``reconciler.ACTIVE_ROW_STATES``).
_ACTIVE_ROW_STATES = frozenset({"pending", "running"})


def release_run_credentials(db: Any, execution: dict) -> Optional[bool]:
    """Best-effort Secret release for a run that has JUST gone terminal,
    from a caller that is not the reconciler (the completion webhook).

    Never raises -- it runs beside a signed callback that must not turn
    into an error over cleanup, and the reconciler's terminal sweep
    (``SparkK8sReconciler._release_terminal_credentials``) is the
    guarantee underneath it.  Returns None when it did not try (lane
    disabled, not a spark_k8s row, row still active, cluster not
    available from this pod), else what ``release_credentials`` said.
    """
    row = dict(execution or {})
    exec_id = row.get("execution_id")
    if (row.get("execution_backend") or "").lower() != BACKEND_NAME:
        return None
    try:
        fresh = db.get_feed_execution(row["id"]) if row.get("id") else None
    except Exception as exc:                       # noqa: BLE001
        logger.warning("[spark_k8s] %s: row unreadable before the credential "
                       "release (%s) -- leaving it to the reconciler",
                       exec_id, exc)
        return None
    status = str((fresh or row).get("status") or "").lower()
    if status in _ACTIVE_ROW_STATES:
        return None                   # the retry may still need the Secret
    try:
        from core.config import spark_k8s as _sk
        if not _sk.enabled:
            return None
        if not _avail.current().available:
            return None
        return SparkK8sRunner(db).release_credentials({**row, **(fresh or {})})
    except Exception as exc:                       # noqa: BLE001
        # SparkK8sError is "the cluster said no / did not answer"; anything
        # else is a bug -- either way the reconciler releases it next tick,
        # and the callback that called us must still succeed.
        _level = logging.WARNING if isinstance(exc, SparkK8sError) \
            else logging.ERROR
        logger.log(_level, "[spark_k8s] %s: credential Secret not released "
                   "here (%s: %s) -- the reconciler's terminal sweep will",
                   exec_id, type(exc).__name__, exc)
        return None


class SparkK8sRunner:
    """Submit / cancel / inspect SparkApplications for feed executions.

    ``api`` and ``availability_fn`` are injectable so the full lifecycle is
    provable against a fake Kubernetes API with no cluster and no
    ``kubernetes`` package installed.
    """

    def __init__(self, db: Any, api: Any = None,
                 settings: Optional[SparkK8sSettings] = None,
                 availability_fn: Optional[Callable[[], "_avail.Availability"]] = None):
        self._db = db
        self._api = api
        self._settings = settings or settings_from_config()
        self._availability_fn = availability_fn or _avail.current

    @property
    def settings(self) -> SparkK8sSettings:
        return self._settings

    def _ensure_api(self):
        if self._api is None:
            from core.spark_k8s.client import make_kube_api
            self._api = make_kube_api()
        return self._api

    def update_settings(self, settings: SparkK8sSettings) -> None:
        """Config was re-read; adopt the new values without recreating the
        runner (the reconciler keeps ONE runner for the life of its loop —
        see ``SparkK8sReconciler.update_settings``)."""
        self._settings = settings

    # ── Submit ───────────────────────────────────────────────────────

    def submit(self, feed_config: dict, execution: dict, *,
               run_date=None, attempt: int = 0,
               feed_conf_override: Optional[dict] = None) -> SubmitResult:
        """Build + create the credentials Secret and SparkApplication for
        one execution attempt.  Idempotent per attempt: a duplicate call
        returns ``adopted=True`` instead of raising.

        ``feed_conf_override`` lets the reconciler resubmit a retry with
        the ORIGINAL attempt's exact ``--feed-config`` payload (read back
        from the prior attempt's Secret), so a retry that crosses midnight
        can never flip its calendar tokens.
        """
        av = self._availability_fn()
        if not av.available:
            raise SparkK8sUnavailable(av.reason_code, av.detail)

        api = self._ensure_api()
        execution_id = execution.get("execution_id") or ""
        if not execution_id:
            raise ValueError("spark_k8s submit: execution has no execution_id")

        if feed_conf_override is not None:
            feed_conf = feed_conf_override
        else:
            try:
                feed_conf = build_feed_conf(self._db, feed_config, execution_id,
                                            run_date=run_date)
            except ValueError as _conf_exc:
                # 2026-11-09 -- a conf that cannot be built is a DECLARED refusal
                # (nothing created): the engine's submit-time rule moves a
                # size-routed run to native and fails a pinned one in words.
                from core.spark_k8s.errors import SparkK8sConfRefused
                raise SparkK8sConfRefused(execution_id, str(_conf_exc)) from None
        # 2026-10-14 -- where the job reports WHERE IT IS, in the conf (not
        # on argv: an older job image ignores an unknown conf key, and would
        # refuse an unknown flag).  Set on a retry's reused conf too, so the
        # current settings apply to the new attempt.
        feed_conf = dict(feed_conf, progress={
            "url": self._settings.progress_url,
            "interval_seconds": int(self._settings.progress_interval_seconds)})

        # ── D10 (2026-09-02) — refuse a run that will outlive its credentials.
        # Checked BEFORE anything is created, so nothing has to be cleaned up
        # and the message can say what to change.  A 90-minute read on a
        # one-hour token returns 403s part way through; those classify as
        # retryable, so the resubmit hits the same expiry from a clock that
        # has already advanced and the feed spends its retries losing a race.
        _budget, _ = resolve_job_timeout_seconds(
            feed_config.get("backend_config") or {}, self._settings)
        _refusal = credential_lifetime_refusal(
            feed_conf, _budget, self._settings)
        if _refusal:
            raise SparkK8sCredentialLifetime(execution_id, _refusal)

        # ── FR-ARCH-02 (2026-09-03) — driver-classpath preflight.  The
        # classifier already recognises ClassNotFoundException from the
        # DEAD detached pod as NON_RETRYABLE; the same fact is checked
        # HERE, before any Secret or CR exists, where the message can
        # name the image rebuild.  Nothing to clean up on refusal.
        try:
            assert_driver_on_classpath(
                feed_conf, self._settings.image_driver_classes,
                image=self._settings.image)
        except ValueError as _drv_exc:
            raise SparkK8sDriverMissing(execution_id, str(_drv_exc)) \
                from _drv_exc

        secret_sink: Optional[dict] = {} if self._settings.creds_via_secret else None
        # The SHAPE is decided here, ONCE: the declared mode, or -- for
        # ``auto`` -- the ladder's rung (``av`` above, already probed and
        # cached).  It is stored on the row below and never re-resolved.
        # Name, labels and the credential Secret are identical in both
        # shapes (manifest.build_driver_pod_spec builds ON the CR builder),
        # so everything below this line is mode-blind.
        mode = resolve_submit_mode(self._settings, av)
        spec = build_workload_spec(
            feed_conf, execution_id, self._settings, mode,
            secret_sink=secret_sink, attempt=attempt,
            backend_config=feed_config.get("backend_config") or {},
        )
        kind = workload_kind(mode)
        cr_name = spec["metadata"]["name"]
        namespace = spec["metadata"]["namespace"]

        secret_name: Optional[str] = None
        secret_body: Optional[dict] = None
        if secret_sink is not None:
            # Paired 1:1 with the CR name: ``creds-<cr name>``.  Derived
            # from the spec rather than recomputed, so the two can never
            # disagree about the feed name.
            secret_name = "creds-" + cr_name
            secret_body = secret_body_for(
                execution_id, secret_sink, self._settings, attempt=attempt,
                feed_name=feed_conf.get("feed_name"))
            secret_body["metadata"]["name"] = secret_name

        # 2026-10-07 (D3) -- what THIS attempt has put on the cluster, so an
        # unreachable cluster can be answered truthfully: "nothing of this
        # run exists" (the caller may run it elsewhere) versus "something
        # may" (it must not -- a second engine would run it twice).
        staged: list = []
        try:
            if secret_body is not None:
                self._stage_secret(api, namespace, secret_name, secret_body,
                                   staged)
            adopted = self._create_or_adopt(api, namespace, spec, mode,
                                            kind, cr_name)
        except SparkK8sUnreachable as exc:
            raise self._unreachable_at_submit(
                exc, api, namespace, cr_name, mode, staged) from exc

        # Persist the attempt identity so the reconciler (on any pod, after
        # any restart) knows exactly which CR carries this execution and
        # how many attempts were spent (parsed from the name suffix).
        # ``submit_mode`` is the STORED shape (2026-09-14): cancel, status
        # and the reconciler read it from here, never from today's cluster.
        self._db.update_feed_execution(execution["id"], {
            "external_job_id": cr_name,
            "execution_backend": BACKEND_NAME,
            "submit_mode": mode,
        })
        if not adopted:
            logger.info(
                "[spark_k8s] submitted %s %s (attempt=%d, "
                "namespace=%s, image=%s, executors=%s, submit_mode=%s%s)",
                kind, cr_name, attempt, namespace, self._settings.image,
                _executor_instances(spec), mode,
                (" resolved by auto" if str(self._settings.submit_mode).lower()
                 == SUBMIT_MODE_AUTO else ""),
            )
        return SubmitResult(cr_name=cr_name, secret_name=secret_name,
                            adopted=adopted)

    @staticmethod
    def _stage_secret(api, namespace: str, secret_name: str, body: dict,
                      staged: list) -> None:
        """Create the attempt's credentials Secret (409 = an identical
        attempt already staged it -> replace).  Appends to ``staged`` the
        moment anything of this run is known to exist on the cluster."""
        try:
            api.create_secret(namespace, body)
        except SparkK8sApiError as exc:
            if exc.status != 409:
                # NO inline-credentials fallback (see module docstring)
                raise SparkK8sApiError(
                    exc.status, exc.reason,
                    f"creating credentials Secret {secret_name!r} failed "
                    f"— check the secrets RBAC "
                    f"(rbac-spark-k8s.yaml); refusing to fall back to "
                    f"command-line credentials. {exc.body}",
                ) from exc
            staged.append(f"credentials Secret {secret_name} (existing)")
            # deterministic payload for this attempt — replace
            api.replace_secret(namespace, secret_name, body)
            return
        staged.append(f"credentials Secret {secret_name}")

    @staticmethod
    def _create_or_adopt(api, namespace: str, spec: dict, mode: str,
                         kind: str, cr_name: str) -> bool:
        """POST the workload; True when it already existed (adoption)."""
        try:
            create_workload(api, namespace, spec, mode)
        except SparkK8sApiError as exc:
            if exc.status != 409:
                raise
            # The idempotency key fired: this attempt is already
            # running.  Adoption, never failure.  A Pod POST answers
            # 409 AlreadyExists on a name clash exactly as the CR does.
            logger.info(
                "[spark_k8s] %s %s already exists — "
                "adopting the running attempt (idempotent submit)",
                kind, cr_name,
            )
            return True
        return False

    def _unreachable_at_submit(self, exc: SparkK8sUnreachable, api,
                               namespace: str, cr_name: str, mode: str,
                               staged: list) -> SparkK8sUnreachable:
        """The cluster stopped answering part way through a submit.

        ``nothing_created`` is True ONLY when no create of this attempt
        succeeded AND the failing request was never sent (it failed while
        CONNECTING).  Anything else may exist on the cluster: it is
        cleaned up best-effort here (most likely unreachable too) and the
        reconciler's terminal sweep deletes whatever is left once the
        cluster answers -- the caller fails the run and never moves it to
        another engine.  The availability cache is marked unavailable NOW
        either way."""
        nothing = (not staged) and (not exc.request_sent)
        _avail.mark_unreachable(exc)
        if nothing:
            logger.warning(
                "[spark_k8s] %s: %s -- before anything of this run was "
                "created on the cluster", cr_name, exc)
        else:
            logger.error(
                "[spark_k8s] %s: %s AFTER this run touched the cluster "
                "(%s) -- it may exist there; cleaning up best-effort, and "
                "the run must NOT move to another engine",
                cr_name, exc, ", ".join(staged) or
                "the create request itself may have reached the server")
            self._cleanup_after_unreachable(api, namespace, cr_name, mode)
        return SparkK8sUnreachable(
            exc.host, exc.cause, detail=exc.detail,
            request_sent=exc.request_sent, nothing_created=nothing)

    @staticmethod
    def _cleanup_after_unreachable(api, namespace: str, cr_name: str,
                                   mode: str) -> None:
        for what, call in (
                ("workload", lambda: delete_workload(api, namespace,
                                                     cr_name, mode)),
                ("Secret", lambda: api.delete_secret(namespace,
                                                     "creds-" + cr_name))):
            try:
                call()
            except SparkK8sError as c_exc:
                logger.warning("[spark_k8s] cleanup of the %s for %s after "
                               "the cluster stopped answering: %s -- the "
                               "reconciler will finish it", what, cr_name,
                               c_exc)

    # ── Cancel ───────────────────────────────────────────────────────

    def cancel(self, execution: dict) -> bool:
        """Delete the execution's workload (+ its Secret).  The
        spark-operator tears the driver/executor pods down with a CR; for
        a driver Pod the executors go with it through the
        ``ownerReferences`` Spark stamped from
        ``spark.kubernetes.driver.pod.name``.  Returns True when a
        workload was actually deleted, False when nothing was there (both
        are successful cancels).  404s are fine; anything else propagates."""
        api = self._ensure_api()
        cr_name = workload_name_for(self._db, execution)
        # The shape the run was SUBMITTED as, from the row -- not what a
        # probe would say today (the operator may be gone since).
        mode = stored_submit_mode(execution, self._settings)
        namespace = self._settings.namespace
        deleted = False
        # 2026-10-07 (D1) -- BOTH deletes are attempted, whatever the first
        # one answered.  The workload delete used to raise straight out of
        # here on any non-404, so a cancel that met (say) a 500 on the CR
        # left the run's credential Secret on the cluster for the TTL.  The
        # first real error is still raised, after the Secret was tried.
        first_error: Optional[SparkK8sApiError] = None
        try:
            delete_workload(api, namespace, cr_name, mode)
            deleted = True
        except SparkK8sApiError as exc:
            if exc.status != 404:
                first_error = exc
        try:
            api.delete_secret(namespace, "creds-" + cr_name)
        except SparkK8sApiError as exc:
            if exc.status != 404 and first_error is None:
                first_error = exc
        if first_error is not None:
            raise first_error
        if deleted:
            logger.info("[spark_k8s] cancelled: deleted %s %s",
                        workload_kind(mode), cr_name)
        return deleted

    # ── Credentials ──────────────────────────────────────────────────

    def release_credentials(self, execution: dict) -> bool:
        """Delete the run's credential Secret -- and ONLY the Secret.

        2026-10-07 (D1).  The Secret carries the source and destination
        credentials (``FEED_CONFIG_JSON``).  It used to live exactly as
        long as the workload: the reaper deleted the pair together after
        ``completed_cr_ttl_seconds`` (3600 s), a TTL that exists so the
        DRIVER LOG survives -- not the password.  A credential must not
        outlive the job, so a terminal run's Secret goes now and its
        CR/driver pod stays for the log.

        Safe once the run is terminal: the driver resolved its
        ``secretKeyRef`` env when its container started and executors are
        never handed the Secret, so a driver still inside ``spark.stop()``
        is not affected.  NOT safe while the row is active -- the
        reconciler's retry reads the prior attempt's ``FEED_CONFIG_JSON``
        back from this Secret -- which is why every caller gates on a
        TERMINAL row.  Returns True when a Secret was deleted, False when
        none was there (both are a released credential)."""
        api = self._ensure_api()
        name = "creds-" + workload_name_for(self._db, execution)
        try:
            api.delete_secret(self._settings.namespace, name)
        except SparkK8sApiError as exc:
            if exc.status == 404:
                return False
            raise
        logger.info("[spark_k8s] %s is terminal -- credential Secret %s "
                    "deleted (the workload is kept for its driver log)",
                    (execution or {}).get("execution_id"), name)
        return True

    # ── Status ───────────────────────────────────────────────────────

    def read_status(self, cr_name: str, mode: Optional[str] = None) -> CrStatus:
        """``mode`` is the row's STORED shape (``stored_submit_mode``);
        None means "the deployment's declared shape" for a caller that
        has no row -- under ``auto`` that is the legacy CR."""
        api = self._ensure_api()
        shape = mode or stored_submit_mode({}, self._settings)
        try:
            cr = get_workload(api, self._settings.namespace, cr_name,
                              shape)
        except SparkK8sApiError as exc:
            if exc.status == 404:
                return CrStatus(found=False, state="")
            raise
        return extract_cr_status(cr)
