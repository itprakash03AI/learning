"""Credential-shaped VALUES (2026-11-10) -- the half of the secret scan that key
names cannot see: a ``user:password@`` inside a URL (the password may hold a
``/``), Oracle's ``user/password@db``, ``password=`` / ``client_secret=`` /
``access_token=`` in a connection string (quoted, as JAAS writes it, or bare --
a dotted value on the right of ``password=`` IS a value), an ``Authorization:
Basic | Bearer ...`` header, a PEM private-key block, an AWS access key id, a
GitLab or Slack token, a JWT, and any opaque value under a credential-NAMED key
(``Authorization``, ``X-API-Key``, ``*secret*``, ``*token*``, ``password`` ...).
``core.feed.governance.find_secret_paths`` finds credential KEYS; this finds
credential VALUES under any key, so a package (and a preview, a Jira comment, a
job log) is refused or masked on either.

What is NOT a secret and must pass: a placeholder (``{NAME}``, ``${vault:...}``,
``${...}``) and a SQL comparison -- ``password = col`` / ``a.password = b.password``
WITH spaces around the ``=`` and a bare identifier on the right.  A real false
positive (a sample URL in a SQL comment, a dummy login in notes) is allowed by
PATH through the caller's reviewed allow-list, never by weakening the shapes.

Pure: no I/O.  Used by ``core.release.engine._scan_secrets`` (the upload / export
gate) and by ``scripts/release_pipeline.py`` (before a byte of an export is
written; the preview before it is posted).
"""
from __future__ import annotations

import re
from collections.abc import Iterable
from typing import Any

#: a placeholder is never a value: stripped before matching, kept by the mask
PLACEHOLDER = re.compile(r"\$\{[^}]*\}|\{[A-Za-z_][A-Za-z0-9_]*\}")
KEY_WORDS = (r"(?:password|passwd|pwd|secret|client[_-]?secret|api[_-]?key|access[_-]?token|refresh[_-]?token|"
             r"auth[_-]?token|token|private[_-]?key)")
#: a bare identifier on the right of ``password = x`` (spaces around =) is a SQL column, not a value
IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]*$")
#: a credential-NAMED key (the last path segment): any opaque value under it is a secret
CREDENTIAL_KEY = re.compile(
    r"(?i)(?:^authorization$|^x-api-key$|^api[_-]?key$|secret|token|^password$|^passwd$|^pwd$|^pass$|private[_-]?key)")
#: an opaque value: no whitespace, 8+ characters
OPAQUE = re.compile(r"^\S{8,}$")

#: (kind, pattern); the LAST group is the SECRET part a mask replaces
SECRET_VALUE_PATTERNS: tuple[tuple[str, re.Pattern], ...] = (
    ("credentials in a URL", re.compile(r"(?<=://)[^/\s:@]+:([^@\s]+)(?=@)")),
    ("user/password@host", re.compile(r"(?<![\w/@:])[A-Za-z][\w.-]*/([^\s/@]{3,})@[A-Za-z0-9][\w.-]*")),
    ("password in a connection string",
     re.compile(r"(?i)\b" + KEY_WORDS + r"(\s*)=(\s*)(\"[^\"]{2,}\"|'[^']{2,}'|[^;&\s'\"]{3,})")),
    ("Authorization header", re.compile(r"(?i)\b(?:Basic|Bearer)\s+([A-Za-z0-9+/=_.-]{8,})")),
    ("private key block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----(?:[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----|[\s\S]*)")),
    ("AWS access key id", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("GitLab token", re.compile(r"\bglpat-[A-Za-z0-9_-]{20,}\b")),
    ("Slack token", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b")),
    ("JWT", re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b")),
)
_CONN = "password in a connection string"


def _secret_group(match: re.Match) -> int:
    """The group index that holds the secret part (the last group of the pattern)."""
    return match.lastindex or 0


def _is_sql_comparison(match: re.Match) -> bool:
    """``password = col`` / ``a.x = b.x``: SPACES around the ``=`` and a bare
    identifier on the right.  ``password=my.secret`` (no spaces) is a value."""
    if match.lastindex != 3:
        return False
    spaced = bool(match.group(1)) and bool(match.group(2))
    rhs = match.group(3)
    return spaced and rhs[0] not in "\"'" and bool(IDENTIFIER.match(rhs))


def _is_placeholder(match: re.Match) -> bool:
    """The secret part is nothing but placeholders (``{PASSWORD}``, ``${vault:..}``)."""
    g = _secret_group(match)
    part = match.group(g) if g else match.group(0)
    return not PLACEHOLDER.sub("", part).strip("\"' ")


def _skip(kind: str, match: re.Match) -> bool:
    return (kind == _CONN and _is_sql_comparison(match)) or _is_placeholder(match)


def secret_value_kinds(text: str, key: str | None = None) -> list[str]:
    """The kinds of credential-shaped value ``text`` carries ([] = none).  ``key`` is
    the name the value sits under (its last path segment), for the key-named rule."""
    if not isinstance(text, str) or len(text) < 6:
        return []
    stripped = PLACEHOLDER.sub("", text)
    kinds: list[str] = []
    for kind, pat in SECRET_VALUE_PATTERNS:
        for m in pat.finditer(stripped):
            if _skip(kind, m):
                continue
            kinds.append(kind)
            break
    if key and CREDENTIAL_KEY.search(str(key)) and OPAQUE.match(stripped.strip()) and not PLACEHOLDER.fullmatch(text.strip()):
        kinds.append("opaque value under a credential-named key")
    return kinds


def find_secret_values(tree: Any, _path: str = "", allow: Iterable[str] = ()) -> list[tuple[str, str]]:
    """``[(dotted path, kind)]`` for every string in ``tree`` that carries a
    credential-shaped value, whatever its key is called; paths in ``allow`` are skipped."""
    allowed = set(allow)
    out: list[tuple[str, str]] = []
    if isinstance(tree, dict):
        for k, v in tree.items():
            out += find_secret_values(v, f"{_path}.{k}" if _path else str(k), allowed)
    elif isinstance(tree, (list, tuple)):
        for i, v in enumerate(tree):
            out += find_secret_values(v, f"{_path}[{i}]", allowed)
    elif isinstance(tree, str) and _path not in allowed:
        leaf = _path.split(".")[-1].split("[")[0] if _path else ""
        out += [(_path or "<value>", kind) for kind in secret_value_kinds(tree, leaf)]
    return out


def mask_secret_values(text: str) -> str:
    """``text`` with every credential-shaped value replaced by ``***`` (placeholders
    and SQL comparisons kept)."""
    if not isinstance(text, str):
        return text
    for kind, pat in SECRET_VALUE_PATTERNS:
        def _sub(m, kind=kind):
            if _skip(kind, m):
                return m.group(0)
            g = _secret_group(m)
            if g:
                return m.group(0)[: m.start(g) - m.start(0)] + "***" + m.group(0)[m.end(g) - m.start(0):]
            return "***"
        text = pat.sub(_sub, text)
    return text


def mask_tree(tree: Any) -> Any:
    """Every string in ``tree`` masked by :func:`mask_secret_values`; a whole opaque
    value under a credential-named key becomes ``***`` (a new structure)."""
    if isinstance(tree, dict):
        return {k: ("***" if isinstance(v, str) and "opaque value under a credential-named key" in secret_value_kinds(v, str(k))
                    else mask_tree(v)) for k, v in tree.items()}
    if isinstance(tree, list):
        return [mask_tree(v) for v in tree]
    if isinstance(tree, tuple):
        return tuple(mask_tree(v) for v in tree)
    return mask_secret_values(tree) if isinstance(tree, str) else tree
