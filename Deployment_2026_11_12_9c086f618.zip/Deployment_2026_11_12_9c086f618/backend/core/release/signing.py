"""UAT SIGNS the export (2026-11-10, the fifth review): Ed25519 over the package's
identity, so the authors each item carries -- and the ``authors_since`` UAT itself
chose from its own release record -- cannot be forged by whoever uploads.

* UAT: ``governance.release.signing.private_key_ref`` = the System Account whose
  password is the private key (base64 of the 32-byte seed, or a PEM private key;
  Vault when the account uses Vault).  ``export_package`` signs when it is set.
* PROD: ``governance.release.signing.uat_public_key`` = the public key (base64 of
  the 32 raw bytes, or a PEM public key).  ``engine.upload`` in a four-eyes
  environment refuses an unsigned package or a bad signature.

The signed message is the canonical JSON of ``{checksum, source_commit,
source_environment, exported_at, exported_by, package_id, authors_since, scope,
requires, excluded}``: the checksum
covers every canonical item INCLUDING its ``authors`` list, so a changed author
breaks the checksum, and a re-computed checksum breaks the signature.

Library: ``cryptography`` (already a backend dependency), Ed25519 only.
"""
from __future__ import annotations

import base64
import json
from datetime import datetime, timezone
from typing import Any

from core.release.contract import ReleaseRefusal

ALG = "ed25519"
SIGNED_FIELDS = ("checksum", "source_commit", "source_environment", "exported_at", "exported_by", "package_id",
                 "authors_since", "scope", "requires", "excluded")


def signed_message(pkg: dict) -> bytes:
    body = {k: pkg.get(k) for k in SIGNED_FIELDS}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _b64decode(value: str) -> bytes:
    try:
        return base64.b64decode(value.strip(), validate=True)
    except Exception as exc:  # the reason travels in words
        raise ReleaseRefusal(f"the signing key is not base64: {exc}") from exc


def load_private_key(material: str):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519
    text = (material or "").strip()
    if not text:
        raise ReleaseRefusal("the signing private key is empty")
    if text.startswith("-----BEGIN"):
        key = serialization.load_pem_private_key(text.encode("utf-8"), password=None)
        if not isinstance(key, ed25519.Ed25519PrivateKey):
            raise ReleaseRefusal("the signing private key is not Ed25519")
        return key
    raw = _b64decode(text)
    if len(raw) != 32:
        raise ReleaseRefusal(f"the signing private key must be a 32-byte Ed25519 seed ({len(raw)} bytes given)")
    return ed25519.Ed25519PrivateKey.from_private_bytes(raw)


def load_public_key(material: str):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519
    text = (material or "").strip()
    if not text:
        raise ReleaseRefusal("no UAT public key is configured (governance.release.signing.uat_public_key)")
    if text.startswith("-----BEGIN"):
        key = serialization.load_pem_public_key(text.encode("utf-8"))
        if not isinstance(key, ed25519.Ed25519PublicKey):
            raise ReleaseRefusal("the UAT public key is not Ed25519")
        return key
    raw = _b64decode(text)
    if len(raw) != 32:
        raise ReleaseRefusal(f"the UAT public key must be 32 raw Ed25519 bytes ({len(raw)} bytes given)")
    return ed25519.Ed25519PublicKey.from_public_bytes(raw)


def public_key_b64(private_key) -> str:
    from cryptography.hazmat.primitives import serialization
    raw = private_key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return base64.b64encode(raw).decode("ascii")


def sign_package(pkg: dict, private_key_material: str, *, signer: str = "uat") -> dict:
    """``pkg`` with ``signature`` = {alg, signer, public_key, signed_at, sig} (the package is data)."""
    key = load_private_key(private_key_material)
    sig = key.sign(signed_message(pkg))
    pkg["signature"] = {"alg": ALG, "signer": signer, "public_key": public_key_b64(key),
                        "signed_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
                        "sig": base64.b64encode(sig).decode("ascii")}
    return pkg


def verify_package(pkg: Any, public_key_material: str) -> dict:
    """Raises ReleaseRefusal unless ``pkg['signature']`` is UAT's Ed25519 signature
    over the package's identity; returns the signature record."""
    from cryptography.exceptions import InvalidSignature
    sig = (pkg or {}).get("signature") if isinstance(pkg, dict) else None
    if not isinstance(sig, dict) or not sig.get("sig"):
        raise ReleaseRefusal("the package is not signed by UAT (no signature) -- an unsigned package cannot prove who "
                             "changed its rows; set governance.release.signing.private_key_ref on UAT")
    if str(sig.get("alg") or "") != ALG:
        raise ReleaseRefusal(f"the package signature algorithm {sig.get('alg')!r} is not {ALG}")
    key = load_public_key(public_key_material)
    try:
        key.verify(_b64decode(str(sig["sig"])), signed_message(pkg))
    except InvalidSignature as exc:
        raise ReleaseRefusal("the package signature does not match UAT's public key -- the package (its items, their "
                             "authors or its identity) was altered after UAT signed it, or it was signed by someone "
                             "else") from exc
    return sig
