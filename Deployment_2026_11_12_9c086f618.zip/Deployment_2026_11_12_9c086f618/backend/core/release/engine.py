"""The release engine: export, upload, preview, decide, approve, apply,
verify, rollback -- over the DB seam, ONE transaction per apply
(docs/RELEASE_CONFIG_DESIGN_2026_10_17.html §3).

Every operation is a value or a ``ReleaseRefusal`` that names the object:
nothing here is a silent skip, and nothing here is reachable from the run
path (a release is a CHANGE).
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Callable

from core.release import diff as diffmod
from core.release import package as pkgmod
from core.release.contract import Item, Mapping, ReleaseRefusal, Verdict
from core.release.registry import kinds_in_order, load

logger = logging.getLogger(__name__)

_MISSING = object()

#: states from which an apply may start / a rollback may start
APPLY_FROM = ("approved",)
ROLLBACK_FROM = ("applied", "verified", "applied_unverified")


# ── config (every key here IS read) ─────────────────────────────────────

def gov_cfg() -> dict:
    from core import config as _config
    return _config.get("feed_generation", "governance", {}) or {}


def release_cfg() -> dict:
    rel = dict(gov_cfg().get("release") or {})
    rel.setdefault("four_eyes_environments", ["prod"])
    rel.setdefault("require_ticket_environments", ["prod"])
    rel.setdefault("verify", {"on_failure": "hold"})
    rel.setdefault("first_release_overwrites", False)
    rel.setdefault("max_package_mb", 64)
    rel.setdefault("jira_approved_statuses", ["Approved"])
    # 2026-11-10 (the fourth review): the target verifies the GitLab deployment
    # approval ITSELF -- its own read token (a System Account), never a request's word
    rel.setdefault("gitlab", {})
    # logins that are not people: a row touched only by them has no provable author
    rel.setdefault("system_logins", ["system", "migration", "scheduler", "release", "api", "unknown"])
    # 2026-11-10 (the fifth review): UAT signs its export (Ed25519); PROD verifies
    rel.setdefault("signing", {"private_key_ref": "", "uat_public_key": ""})
    return rel


def _signing_cfg() -> dict:
    raw = dict(release_cfg().get("signing") or {})
    return {"private_key_ref": str(raw.get("private_key_ref") or "").strip(),
            "uat_public_key": str(raw.get("uat_public_key") or "").strip()}


def _is_four_eyes(env: str) -> bool:
    return env in (release_cfg()["four_eyes_environments"] or [])


def is_governed(env: str) -> bool:
    """A GOVERNED environment (sixth review): four-eyes is on, or GitLab verification
    is configured for it.  Only there the approver is a separate account
    (``releases.approve``) and may not also upload; elsewhere (dev, UAT) the
    release routes behave exactly as before this branch (``releases.manage``)."""
    if _is_four_eyes(env):
        return True
    try:
        return gitlab_verified_environment(env) is not None
    except ReleaseRefusal:
        return True            # configured for another name: governed, and fail closed later


def deployment_is_production() -> bool:
    """The 2026-09-07 question "could this deployment be PRODUCTION" (any signal),
    one level up: ``core.row_security.api.deployment_is_production``."""
    from core.row_security.api import deployment_is_production as _f
    return bool(_f())


def _named_like_production(env: str) -> bool:
    """Seventh review: a deployment environment SIGNAL (app.environment, $ENVIRONMENT ...)
    that looks like production -- prod, production, prd, live, prod-eu, eu-prod -- which the
    RLS gate's exact match ({prod, production}) missed.  Asked of the deployment signals,
    not of governance.environment: that label is the release system's own setting."""
    import re as _re
    tokens = [t for t in _re.split(r"[^a-z0-9]+", str(env or "").strip().lower()) if t]
    prod_at = [i for i, t in enumerate(tokens) if _re.fullmatch(r"(prod|production|prd|live)\d*", t)]
    if not prod_at:
        return False
    # only a word NEXT TO the production word negates it ("pre-prod", "non-prod", "not-prod",
    # "prod-like", "live-copy"); "prod-stage" / "prod-test-replica" stay production (final review)
    negations = {"pre", "non", "not", "like", "copy"}
    for i in prod_at:
        neighbours = {tokens[j] for j in (i - 1, i + 1) if 0 <= j < len(tokens)}
        if not (neighbours & negations):
            return True
    return False


def assert_production_governed(db=None) -> None:
    """PROD forgetting its label (sixth review): when ANY environment signal says
    production, this environment must be four-eyes, verify GitLab itself and hold
    UAT's public key -- otherwise EVERY release road refuses in words (fail closed,
    the RLS rule of 2026-09-07)."""
    env = this_environment(db)
    from core.config import deploy_environment_signals
    _signals = [v for v, _src in deploy_environment_signals()]
    if not (deployment_is_production() or any(_named_like_production(v) for v in _signals)):
        return
    problems = []
    if not _is_four_eyes(env):
        problems.append(f"governance.environment is {env!r} and governance.release.four_eyes_environments does not name it")
    try:
        if gitlab_verified_environment(env) is None:
            problems.append("governance.release.gitlab is not configured (this environment must verify the GitLab approval itself)")
    except ReleaseRefusal as exc:
        problems.append(str(exc))
    if not _signing_cfg()["uat_public_key"]:
        problems.append("governance.release.signing.uat_public_key is empty (an unsigned package cannot prove its authors)")
    if problems:
        raise ReleaseRefusal("this deployment is PRODUCTION (a deployment environment signal says so) but its release "
                             "governance is not: " + "; ".join(problems) + " -- fail closed: no release is exported, "
                             "uploaded, previewed, approved, applied, verified or rolled back here until that is fixed")


def _same_environment(db, rel: dict, what: str) -> None:
    """A release's environment is ALWAYS this deployment's (2026-11-10, fifth
    review): a row labelled for another environment is never acted on here."""
    env = this_environment(db)
    if str(rel.get("environment") or "") != env:
        raise ReleaseRefusal(f"release {rel.get('id')} is labelled for environment {rel.get('environment')!r}; this "
                             f"deployment is {env!r} -- a release is {what} only where it was uploaded")


def this_environment(db=None) -> str:
    """This deployment's environment (``governance.environment``).  ``db`` may carry
    ``release_environment`` -- the tests run UAT and PROD databases in ONE process;
    a real pod has one database and one config."""
    override = getattr(db, "release_environment", None) if db is not None else None
    return str(override or gov_cfg().get("environment") or "dev")


def git_truth_environments() -> list[str]:
    return list(gov_cfg().get("git_truth_environments", ["prod"]) or [])


def _audit(db, actor: str | None, action: str, release_id: int | None, details: dict) -> None:
    try:
        from core.audit import audit_event
        audit_event(db, {"username": actor or "system"}, None, action, "config_release",
                    release_id, details)
    except Exception:  # noqa: BLE001 -- audit is fire-and-forget by contract
        logger.exception("[release] audit of %s failed", action)


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ── export ─────────────────────────────────────────────────────────────────

def _area_kinds(registry, area: str) -> list[str]:
    phases = {"feedgen": 1, "reports": 2, "published": 3, "dashboards": 4}
    if area not in phases:
        raise ReleaseRefusal(f"unknown area {area!r} -- one of {sorted(phases)}")
    return [t.kind for t in registry.types() if t.phase == phases[area]]


def _problem(exc: ReleaseRefusal, kind: str | None = None, key: str | None = None) -> dict:
    return {"kind": exc.kind or kind, "key": exc.key or key, "path": exc.path, "reason": str(exc)}


def row_author_times(session, t, row, *, system_logins=()) -> dict[str, str | None]:
    """Every PERSON who ever changed ``row`` -> the time of their LATEST change (ISO, naive
    UTC), or None when no time is known (a row column with no matching timestamp).  EVERY
    one of them may not approve a release that changes the row (eighth review: no cut);
    the times travel for the record."""
    from sqlalchemy import func
    from core.db.models import AuditLog
    out: dict[str, str | None] = {}

    def _keep(name, at):
        name = str(name or "").strip()
        if not name:
            return
        iso = at.isoformat() if isinstance(at, datetime) else (str(at) if at else None)
        if name in out and out[name] is None:
            return                                   # an unknown time counts always (never cut away)
        if iso is None:
            out[name] = None
        elif name not in out or iso > out[name]:
            out[name] = iso                          # the LATEST change wins
    for col, tcol in (("updated_by", "updated_at"), ("modified_by", "updated_at"), ("created_by", "created_at"),
                      ("owner", None)):
        who = getattr(row, col, None)
        if who:
            at = getattr(row, tcol, None) if tcol else None
            _keep(who, _utc_naive(at) if at else None)
    rid = t.audit_resource_id(row)
    if rid:
        types = tuple(t.audit_resource_types) or (t.kind,)
        q = (session.query(AuditLog.username, func.max(AuditLog.timestamp))
             .filter(AuditLog.resource_type.in_(types), AuditLog.resource_id == rid).group_by(AuditLog.username))
        for name, at in q.all():
            _keep(name, _utc_naive(at) if at else None)
    skip = {str(x).strip().lower() for x in system_logins} | {""}
    return {n: at for n, at in sorted(out.items()) if n.lower() not in skip}


def closure(session, registry, scope: dict, authors: dict | None = None) -> tuple[list[Item], list[dict], list[dict]]:
    """The selected objects plus everything they depend on (forward) and
    everything attached to them (policies, routes, approvers -- reverse).

    Returns ``(items, problems, excluded)``.  EVERY object that cannot be
    exported is a problem ``{kind, key, path, reason}`` and the walk goes on
    -- a real UAT always has stale objects, and an export that stopped at
    the first one taught them to the operator one export at a time.
    ``scope["exclude"]`` (``[{kind, key, reason?}]``) leaves an object out
    DELIBERATELY: it is recorded in ``excluded`` with its reason (the package
    carries the list; the target's preview shows it); an object whose
    dependency is excluded is itself a problem (no silent hole); an exclusion
    naming an object this environment does not have is a problem too (a typo
    is not an exclusion).
    """
    from core.release.types.feedgen import ATTACHED_KINDS
    kind = str(scope.get("kind") or "everything")
    with_deps = bool(scope.get("with_dependencies", True))
    selected: dict[tuple[str, str], Item] = {}
    problems: list[dict] = []
    seen_problem: set[tuple] = set()
    worklist: list[tuple[str, str]] = []
    exclude: dict[tuple[str, str], str] = {}
    for ex in scope.get("exclude") or []:
        k, key = str((ex or {}).get("kind") or ""), str((ex or {}).get("key") or "")
        if registry.get(k) is None:
            problems.append({"kind": k, "key": key, "path": "exclude",
                             "reason": f"exclude names an unknown object type {k!r}"})
            continue
        if registry.require(k).find_row(session, key) is None:
            problems.append({"kind": k, "key": key, "path": "exclude",
                             "reason": f"exclude names {k} {key!r}, which is not in this environment"})
            continue
        exclude[(k, key)] = str((ex or {}).get("reason") or "excluded by the operator")
    excluded: list[dict] = []

    def _record(exc: ReleaseRefusal, k=None, key=None):
        d = _problem(exc, k, key)
        sig = (d["kind"], d["key"], d["path"], d["reason"])
        if sig not in seen_problem:
            seen_problem.add(sig)
            problems.append(d)

    def _take(k: str, key: str, item: Item | None) -> None:
        if (k, key) in exclude:
            if not any(e["kind"] == k and e["key"] == key for e in excluded):
                excluded.append({"kind": k, "key": key, "reason": exclude[(k, key)]})
            return
        if item is not None:
            selected[(k, key)] = item

    def _export_row(t, row):
        try:
            item = t.export_row(session, row, registry)
        except ReleaseRefusal as exc:
            _record(exc, t.kind, t.row_key(row) if not exc.key else None)
            return None
        if item is not None:
            # 2026-11-10: WHO changed the row, INSIDE the checksummed item (the audit
            # columns the definition strips; the target's four-eyes refuses a GitLab
            # approver who is one of them).  ``authors`` = {"required"} -- no cut.
            spec = authors or {}
            timed = row_author_times(session, t, row, system_logins=release_cfg()["system_logins"])
            who = sorted(timed)
            item.extra["authors"] = who
            item.extra["author_times"] = timed
            if spec.get("required") and not who:
                _record(ReleaseRefusal(f"cannot prove who changed it: {t.kind} {item.key!r} was last touched by a system "
                                       f"login and the audit log names no person", kind=t.kind, key=str(item.key)))
                return None
        return item

    def _export(k: str, key: str) -> Item | None:
        t = registry.require(k)
        row = t.find_row(session, key)
        if row is None:
            _record(ReleaseRefusal(f"{k} {key!r} is not in this environment", kind=k, key=key))
            return None
        return _export_row(t, row)

    def _rows_of(t):
        for row in t.rows(session):
            try:
                rk = t.row_key(row)
            except ReleaseRefusal as exc:
                _record(exc, t.kind, None)
                continue
            if (t.kind, rk) in exclude:
                _take(t.kind, rk, None)
                continue
            item = _export_row(t, row)
            if item is not None:
                selected[(t.kind, item.key)] = item

    if kind == "everything":
        for t in registry.types():
            _rows_of(t)
    elif kind == "area":
        for k in _area_kinds(registry, str(scope.get("area") or "")):
            _rows_of(registry.require(k))
        if with_deps:                       # an area's objects pull what they name from OTHER areas
            for item in list(selected.values()):
                worklist.extend(tuple(d) for d in item.dependencies if tuple(d) not in selected)
    else:
        registry.require(kind)
        keys = [str(k) for k in (scope.get("keys") or [])]
        if not keys:
            raise ReleaseRefusal(f"scope {kind!r} names no keys")
        worklist.extend((kind, k) for k in keys)
        if kind == "feed_group":
            from core.db.models import FeedConfig, FeedTemplate
            for gkey in keys:
                grow = registry.require("feed_group").find_row(session, gkey)
                if grow is None:
                    raise ReleaseRefusal(f"feed_group {gkey!r} is not in this environment",
                                         kind="feed_group", key=gkey)
                members = session.query(FeedConfig).filter(FeedConfig.feed_group_id == grow.id).all()
                for f in members:
                    if f.template_id is None:
                        worklist.append(("feed", str(f.name)))
                    else:
                        t = session.query(FeedTemplate).filter(FeedTemplate.id == f.template_id).first()
                        if t is not None:
                            worklist.append(("feed_template", str(t.name)))
                # templates whose body names the group (by id or by the group RULE)
                for t in session.query(FeedTemplate).all():
                    body = ((t.definition or {}).get("feed") or {})
                    if body.get("feed_group_id") == grow.id or body.get("feed_group_name") == gkey:
                        worklist.append(("feed_template", str(t.name)))
    visited: set[tuple[str, str]] = set()
    while worklist:
        k, key = worklist.pop()
        if (k, key) in selected or (k, key) in visited:
            continue
        visited.add((k, key))
        if (k, key) in exclude:
            _take(k, key, None)
            continue
        item = _export(k, key)
        if item is None:
            continue
        selected[(k, key)] = item
        if with_deps:
            worklist.extend(tuple(d) for d in item.dependencies if tuple(d) not in selected)
    if with_deps and kind != "everything":
        changed = True
        while changed:
            changed = False
            for ak in ATTACHED_KINDS:
                t = registry.get(ak)
                if t is None:
                    continue
                for row in t.rows(session):
                    try:
                        rk = t.row_key(row)
                    except ReleaseRefusal as exc:
                        _record(exc, ak, None)
                        continue
                    if (ak, rk) in selected or (ak, rk) in visited:
                        continue
                    item = _export_row(t, row)
                    if item is None:
                        visited.add((ak, rk))
                        continue
                    if any(tuple(d) in selected or tuple(d) in exclude for d in item.dependencies):
                        visited.add((ak, rk))
                        if (ak, rk) in exclude:
                            _take(ak, rk, None)
                            continue
                        selected[(ak, rk)] = item
                        changed = True
                        for d in item.dependencies:
                            if tuple(d) not in selected and tuple(d) not in exclude and tuple(d) not in visited:
                                visited.add(tuple(d))
                                dep = _export(*d)
                                if dep is not None:
                                    selected[tuple(d)] = dep
    # an object whose dependency is EXCLUDED is refused -- never a silent hole
    for (k, key), item in list(selected.items()):
        for d in item.dependencies:
            if tuple(d) in exclude:
                _record(ReleaseRefusal(
                    f"{k} {key!r} depends on {d[0]} {d[1]!r}, which is excluded ({exclude[tuple(d)]}) -- "
                    f"exclude it too, or do not exclude its dependency", kind=k, key=key, path=f"{d[0]}:{d[1]}"))
                selected.pop((k, key), None)
                break
    # every exclusion the operator named is RECORDED, reached by the walk or not
    # (the target's preview shows what was deliberately left out)
    for (k, key), reason in exclude.items():
        if not any(e["kind"] == k and e["key"] == key for e in excluded):
            excluded.append({"kind": k, "key": key, "reason": reason})
    problems.sort(key=lambda p: (str(p.get("kind")), str(p.get("key")), str(p.get("path"))))
    excluded.sort(key=lambda e: (e["kind"], e["key"]))
    return list(selected.values()), problems, excluded


def export_package(db, *, scope: dict, actor: str | None, source_commit: str | None = None) -> dict:
    registry = load()
    from core.release.types import reports as _reports
    _reports.MINTED_KEYS.clear()
    assert_production_governed(db)
    authors = _authors_spec(scope.get("authors"))
    with db.get_session(read_only=True) as session:
        items, problems, excluded = closure(session, registry, scope, authors)
    if _reports.MINTED_KEYS:
        # release keys minted during the (read-only) export: persisted now, so
        # the next export of the same row carries the same key
        with db.get_session() as session:
            for model, rid, key in _reports.MINTED_KEYS:
                row = session.query(model).filter(model.id == rid).first()
                if row is not None and not getattr(row, "release_key", None):
                    row.release_key = key
            session.flush()
        _reports.MINTED_KEYS.clear()
    if bool(scope.get("plan")):
        # the DRY RUN: every problem and exclusion of the scope, nothing built
        return {"plan": True, "scope": scope, "count": len(items),
                "items": [{"kind": i.kind, "key": i.key} for i in items],
                "problems": problems, "excluded": excluded,
                "ready": not problems and bool(items)}
    if problems:
        named = "; ".join(f"{p.get('kind')} {p.get('key')!r}: {p.get('reason')}" for p in problems)
        raise ReleaseRefusal(
            f"{len(problems)} object(s) in the scope cannot be released -- exclude them deliberately "
            f"(scope.exclude) or repair them, then export again: {named}",
            problems=problems)
    if not items:
        raise ReleaseRefusal("the scope selects nothing -- a package with no items is not a release")
    requires = sorted({k for i in items for k in registry.require(i.kind).requires_config})
    pkg = pkgmod.build_package(items, source_environment=this_environment(db), exported_by=actor,
                               scope=scope, source_commit=source_commit, requires_config=requires,
                               excluded=excluded)
    # the export never records a cut: every person travels with the time of their latest change
    # and the TARGET decides per object (seventh review)
    pkg["authors_since"] = None
    signing = _signing_cfg()
    if signing["private_key_ref"]:
        from core.release import signing as sg
        pkg = sg.sign_package(pkg, _signing_private_key(signing["private_key_ref"]), signer=this_environment(db))
    _audit(db, actor, "release.export", None,
           {"scope": scope, "items": len(items), "excluded": len(excluded), "checksum": pkg["checksum"],
            "authors_since": pkg["authors_since"], "signed": bool(pkg.get("signature"))})
    return pkg


def _signing_private_key(ref: str) -> str:
    """The private key from the System Account ``ref`` names (Vault when it uses Vault)."""
    from core import qs_credentials as qc
    try:
        creds = qc.resolve_system_account(ref) or {}
    except Exception as exc:  # the reason travels in words
        raise ReleaseRefusal(f"the export signing key could not be resolved from System Account {ref!r}: {exc}") from exc
    key = str(creds.get("password") or creds.get("private_key") or creds.get("secret_key") or "").strip()
    if not key:
        raise ReleaseRefusal(f"System Account {ref!r} holds no private key (governance.release.signing.private_key_ref)")
    return key


def _utc_naive(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    dt = value if isinstance(value, datetime) else datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return dt.astimezone(timezone.utc).replace(tzinfo=None) if dt.tzinfo else dt


def authors_cut(db, environment: str) -> datetime | None:
    """The export time of this environment's newest applied release that came from UAT
    (never a rollback / git deploy / import) -- an older export is a replay.  NOT the
    authors' rule: there is no cut for that (eighth review)."""
    return _utc_naive(db.newest_applied_export_at(environment))


# ── upload ─────────────────────────────────────────────────────────────────

def _authors_spec(raw: Any) -> dict:
    """``scope.authors`` -> {"since": datetime | None, "required": bool}.  A ``since`` is
    parsed (a malformed date is refused) but NEVER used as a cut: the export carries
    every person who ever changed each row (eighth review: no cut at all)."""
    raw = dict(raw or {}) if isinstance(raw, dict) else {}
    since = raw.get("since")
    if isinstance(since, str) and since.strip():
        try:
            since = datetime.fromisoformat(since.strip().replace("Z", "+00:00"))
        except ValueError as exc:
            raise ReleaseRefusal(f"scope.authors.since {since!r} is not an ISO date-time") from exc
    elif not isinstance(since, datetime):
        since = None
    if since is not None and since.tzinfo is not None:
        since = since.astimezone(timezone.utc).replace(tzinfo=None)   # audit_log timestamps are naive UTC
    return {"since": since, "required": bool(raw.get("required"))}


def changed_row_authors(rel: dict) -> dict[str, list[str]]:
    """``{"kind/key": [logins]}`` of the rows the PREVIEW shows as CHANGED (new,
    changed, conflict, prod_edited -- never unchanged): EVERY person who ever
    changed that object in UAT may not approve it.

    No cut (eighth review, 2026-11-10): every cut tried -- one per environment, then
    one per object -- hid an author some other way (a release rolled back, a field
    PROD kept, two clocks, a change made during the export).  "Anyone who ever
    changed it" is stricter and needs nothing else to be right; ``author_times``
    travels with each item for the record only."""
    states = {f"{e.get('kind')}/{e.get('key')}": str(e.get("state") or "") for e in ((rel.get("preview") or {}).get("items") or [])}
    out: dict[str, list[str]] = {}
    for i in (rel.get("package") or {}).get("items") or []:
        obj = f"{i.get('kind')}/{i.get('key')}"
        if states.get(obj, "changed") == "unchanged":
            continue
        skip = {str(x).strip().lower() for x in release_cfg()["system_logins"]} | {"", "-"}
        who = [str(a) for a in (i.get("authors") or []) if str(a).strip().lower() not in skip]
        if not who:
            # the diff is known HERE: a changed row nobody provable changed cannot be released
            raise ReleaseRefusal(f"cannot prove who changed it: {obj} is in this release's diff but the export names no "
                                 f"person for it (last touched by a system login; the audit log names nobody)",
                                 kind=i.get("kind"), key=str(i.get("key")))
        out[obj] = sorted(set(who))
    return out


def _refuse_replay(db, pkg: dict, environment: str) -> None:
    """Server-side replay (sixth review), governed environments only: a package id
    already uploaded here, an export older than the newest applied UAT release's, or
    any ``authors_since`` at all (eighth review: there is no cut) -- each refused in
    words."""
    pid = str(pkg.get("package_id") or "")
    if pid:
        other = db.release_with_package_id(environment, pid)
        if other is not None:
            raise ReleaseRefusal(f"package {pid} was already uploaded to {environment!r} as release {other['id']} -- a package "
                                 f"is uploaded once; export again for a new one")
    cut = authors_cut(db, environment)
    exported_at = _utc_naive(pkg.get("exported_at"))
    if cut is not None and exported_at is not None and exported_at < cut:
        # strictly OLDER: the same second as the applied export is a fresh export (a repeat of the
        # same package is caught by its package_id above); exported_at has second resolution
        raise ReleaseRefusal(f"the package was exported at {exported_at.isoformat()}, before the export of this "
                             f"environment's newest applied release ({cut.isoformat()}) -- an old package is not replayed; "
                             f"export again")
    since = _utc_naive(pkg.get("authors_since"))
    if since is not None:
        raise ReleaseRefusal(f"the package names its authors only since {since.isoformat()} -- no cut is accepted: every "
                             f"person who ever changed a row in the diff may not approve it; export with no date")


def _scan_secrets(items: list[dict], registry, allow: set | frozenset | None = None) -> None:
    """Credential-shaped KEYS (core.feed.governance) AND credential-shaped VALUES
    under any key (core.release.secret_values: user:password@ in a URL, password=
    in a connection string, a PEM block, an AWS key id, a GitLab / Slack token, a
    JWT; 2026-11-10) refuse the package."""
    from core.feed.governance import find_secret_paths
    from core.release.secret_values import find_secret_values
    for i in items:
        t = registry.require(i["kind"])
        allowed = set(t.not_secret)
        definition = i.get("definition") or {}
        hits = [p for p in find_secret_paths(definition)
                if p.split(".")[-1].split("[")[0] not in allowed]
        if hits:
            raise ReleaseRefusal(
                f"REFUSED: {i['kind']} {i['key']!r} carries credential-shaped key(s) {hits} -- "
                f"a secret in a package means a secret in the repository that held it; purge it, "
                f"never import it", kind=i["kind"], key=str(i["key"]), path=hits[0])
        allowed_paths = {a.split(":", 1)[1] for a in (allow or ()) if a.split(":", 1)[0] == f"{i['kind']}/{i['key']}"}
        values = [(p, kind) for p, kind in find_secret_values(definition) if p not in allowed_paths]
        if values:
            where = "; ".join(f"{p} ({kind})" for p, kind in values[:5])
            raise ReleaseRefusal(
                f"REFUSED: {i['kind']} {i['key']!r} carries a credential-shaped VALUE at {where} -- "
                f"a secret in a package means a secret in the repository that held it; purge it, "
                f"never import it.  A value a person has REVIEWED as not a secret is allowed by naming "
                f"'{i['kind']}/{i['key']}:{values[0][0]}' with a reason under secret_allow in "
                f"ci/release.settings.yml (the pipeline passes it as options.secret_allow)",
                kind=i["kind"], key=str(i["key"]), path=values[0][0])


def _check_requires(pkg: dict) -> list[dict]:
    from core import config as _config
    out = []
    for dotted in ((pkg.get("requires") or {}).get("config_keys") or []):
        section, _, key = str(dotted).partition(".")
        val = _config.get(section, key, _MISSING) if key else _MISSING
        if val is _MISSING:
            raise ReleaseRefusal(f"the package requires config key {dotted!r}, which this build does "
                                 f"not declare -- deploy the image / Helm change first")
        out.append({"key": dotted, "effective": val if not _looks_secret(dotted) else "***"})
    return out


def _looks_secret(dotted: str) -> bool:
    from core.secrets_at_rest import is_secret_key
    return is_secret_key(dotted.split(".")[-1])


def upload(db, pkg: Any, *, environment: str | None = None, actor: str | None, ticket: str | None = None,
           options: dict | None = None, pipeline: dict | None = None) -> dict:
    """``environment`` must be THIS deployment's (a caller's other label is refused);
    in an environment that verifies pipelines itself, ``pipeline`` = {pipeline_id,
    job_id} is verified against GitLab and recorded (the deployment must match it);
    in a four-eyes environment the package must carry UAT's signature."""
    registry = load()
    rcfg = release_cfg()
    here = this_environment(db)
    if environment not in (None, "", here):
        raise ReleaseRefusal(f"a release is uploaded for THIS environment ({here!r}); the request named {environment!r} -- "
                             f"the environment is never the caller's to choose")
    environment = here
    assert_production_governed(db)
    raw = json.dumps(pkg, ensure_ascii=False) if not isinstance(pkg, (str, bytes)) else pkg
    size_mb = len(raw.encode("utf-8") if isinstance(raw, str) else raw) / (1024 * 1024)
    if size_mb > float(rcfg["max_package_mb"]):
        raise ReleaseRefusal(f"package is {size_mb:.1f} MB; the cap is {rcfg['max_package_mb']} MB "
                             f"(feed_generation.governance.release.max_package_mb)")
    if isinstance(pkg, (str, bytes)):
        try:
            pkg = json.loads(pkg)
        except ValueError as exc:
            raise ReleaseRefusal(f"package is not valid JSON: {exc}") from exc
    items = pkgmod.validate_package(pkg, known_kinds=set(registry.kinds()))
    _scan_secrets(items, registry, allow=set((options or {}).get("secret_allow") or []))
    if environment in git_truth_environments() and not pkg.get("source_commit"):
        raise ReleaseRefusal(
            f"environment {environment!r} treats git as the truth "
            f"(feed_generation.governance.git_truth_environments): a package must carry the "
            f"source_commit the pipeline resolved -- a hand export cannot be applied here")
    requires = _check_requires(pkg)
    opts = dict(options or {})
    opts.setdefault("first_release_overwrites", bool(rcfg["first_release_overwrites"]))
    if is_governed(environment) and not (opts.get("rollback") or opts.get("git_deploy") or opts.get("import")):
        # governed environments only (seventh review): dev / UAT keep master's manual flow
        _refuse_replay(db, pkg, environment)       # the signed UAT -> PROD road; a server-built package is not a replay
    signature = None
    if _is_four_eyes(environment) and not opts.get("rollback"):
        from core.release import signing as sg
        signing = _signing_cfg()
        if not signing["uat_public_key"]:
            raise ReleaseRefusal(f"environment {environment!r} is four-eyes but holds no UAT public key "
                                 f"(governance.release.signing.uat_public_key) -- fail closed: an unsigned package cannot "
                                 f"prove who changed its rows")
        signature = sg.verify_package(pkg, signing["uat_public_key"])
    bound = None
    gcfg = gitlab_verified_environment(environment)
    if gcfg and not opts.get("rollback"):
        from core.release import gitlab_verify as gv
        bound = gv.verify_release_upload(gcfg, pipeline=pipeline or {}, pkg=pkg)
        other = db.release_with_upload_pipeline(environment, bound["pipeline_id"])
        if other is not None:
            raise ReleaseRefusal(f"pipeline {bound['pipeline_id']} already uploaded release {other['id']} to {environment!r} -- "
                                 f"ONE release per pipeline; re-use it (the plan step does) or run a new pipeline")
    row = db.create_config_release({
        "environment": environment, "state": "uploaded", "package_id": pkg.get("package_id"),
        "upload_pipeline_id": (bound or {}).get("pipeline_id"), "upload_job_id": (bound or {}).get("job_id"),
        "package_checksum": pkg["checksum"], "source_environment": pkg.get("source_environment"),
        "source_commit": pkg.get("source_commit"), "source_exported_at": pkg.get("exported_at"),
        "source_exported_by": pkg.get("exported_by"), "scope": pkg.get("scope"),
        "package": dict(pkg, items=items), "options": dict(opts, requires=requires),
        "jira_ticket": ticket, "uploaded_by": actor, "uploaded_at": _now(),
    })
    _audit(db, actor, "release.upload", row["id"],
           {"environment": environment, "checksum": pkg["checksum"], "items": len(items),
            "source": pkg.get("source_environment"), "commit": pkg.get("source_commit"),
            "signed_by": (signature or {}).get("signer"), "pipeline": bound})
    return row


# ── preview ────────────────────────────────────────────────────────────────

def _release(db, release_id: int) -> dict:
    rel = db.get_config_release(int(release_id), with_package=True)
    if rel is None:
        raise ReleaseRefusal(f"release {release_id} does not exist")
    return rel


def _items_of(rel: dict) -> list[Item]:
    return [Item.from_dict(i) for i in (rel["package"].get("items") or [])]


def preview(db, release_id: int, *, actor: str | None = None) -> dict:
    rel = _release(db, release_id)
    if rel["state"] in ("applying", "applied", "verified", "applied_unverified", "rolled_back"):
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; a preview is for a release not yet applied")
    registry = load()
    env = rel["environment"]
    items = _items_of(rel)
    mapping = Mapping(db.list_release_mappings(env))
    base = db.latest_deployment_by_key(env)
    opts = rel.get("options") or {}
    decisions = rel.get("decisions") or {}
    items = [registry.require(i.kind).effective(i, mapping) for i in items]
    in_package = {(i.kind, i.key) for i in items}
    entries: list[dict] = []
    with db.get_session(read_only=True) as session:
        for item in sorted(items, key=lambda i: (registry.kinds().index(i.kind), i.key)):
            t = registry.require(item.kind)
            missing: list[dict] = []
            try:
                resolved = t.resolve(session, item, mapping, registry, in_package)
                missing.extend(resolved.get("missing") or [])
            except ReleaseRefusal as exc:
                resolved = {"refs": {}, "env": {}}
                missing.append({"what": "refusal", "reason": str(exc), "path": exc.path})
            theirs = None
            try:
                theirs = t.current_item(session, item.key, registry)
            except ReleaseRefusal as exc:
                missing.append({"what": "target_unreadable", "reason": str(exc)})
            base_def = (base.get((item.kind, item.key)) or {}).get("definition")
            d = diffmod.three_way(base_def, item.definition, theirs.definition if theirs else None,
                                  first_release_overwrites=bool(opts.get("first_release_overwrites")))
            undecided = diffmod.undecided(d, decisions.get(f"{item.kind}|{item.key}") or {})
            entries.append({
                "kind": item.kind, "key": item.key, "hash": item.hash,
                "theirs_hash": theirs.hash if theirs else None,
                "has_base": base_def is not None,
                "state": d["state"], "conflicts": d["conflicts"], "undecided": undecided,
                "fields": [f for f in d["fields"] if f["state"] != "unchanged"],
                "unchanged_fields": sum(1 for f in d["fields"] if f["state"] == "unchanged"),
                "missing": missing, "env": resolved.get("env") or {},
                "environment_fields": item.environment_fields,
                "environment_refs": item.environment_refs,
                "dependencies": item.dependencies,
                "blocked": bool(missing), "blocked_by": [],
            })
    # cascade: an object whose dependency is blocked is blocked
    blocked = {(e["kind"], e["key"]) for e in entries if e["blocked"]}
    changed = True
    while changed:
        changed = False
        for e in entries:
            if e["blocked"]:
                continue
            bad = [list(d) for d in e["dependencies"] if tuple(d) in blocked]
            if bad:
                e["blocked"], e["blocked_by"] = True, bad
                blocked.add((e["kind"], e["key"]))
                changed = True
    counts = {s: sum(1 for e in entries if e["state"] == s) for s in diffmod.STATES}
    counts["blocked"] = sum(1 for e in entries if e["blocked"])
    counts["undecided"] = sum(len(e["undecided"]) for e in entries)
    needed = sorted({(m.get("mapping_kind") or m.get("kind"), m.get("value") or m.get("name"))
                     for e in entries for m in e["missing"]
                     if m.get("what") in ("environment_field", "environment_ref")}, key=str)
    pv = {"at": _now().isoformat(), "by": actor, "counts": counts, "items": entries,
          "ready": counts["blocked"] == 0 and counts["undecided"] == 0,
          "mappings_needed": [{"kind": k, "from_value": v} for k, v in needed],
          # what the exporter DELIBERATELY left out, with each reason
          "excluded": list(rel["package"].get("excluded") or [])}
    assert_production_governed(db)
    patch: dict = {"preview": pv, "mapping_used": mapping.to_rows(), "state": "previewed", "previewed_at": _now()}
    if rel["state"] == "approved":
        # 2026-11-10: an approval covers ONE diff.  A re-preview that shows the same
        # diff keeps it; one whose diff moved (PROD changed, a mapping changed) drops
        # the release back to previewed -- what was approved is no longer what applies.
        if preview_fingerprint(pv) == preview_fingerprint(rel.get("preview") or {}):
            patch["state"] = "approved"
        else:
            patch.update({"approved_by": None, "approved_at": None,
                          "approval_note": f"approval by {rel.get('approved_by')} DROPPED: the preview changed "
                                           f"after it was given (re-previewed by {actor or 'system'})"})
            logger.warning("[release] release %s: the preview changed after approval -- back to previewed", rel["id"])
    out = db.update_config_release(rel["id"], patch)
    _audit(db, actor, "release.preview", rel["id"], {"counts": counts, "ready": pv["ready"],
                                                   "approval_dropped": rel["state"] == "approved" and patch["state"] != "approved"})
    return out


def preview_fingerprint(pv: dict) -> str:
    """What an approval covers: every object's state and every field's values,
    the mappings needed -- never the clock or the actor."""
    import hashlib
    import json as _json
    items = [{"kind": e.get("kind"), "key": e.get("key"), "state": e.get("state"), "blocked": bool(e.get("blocked")),
              "fields": [{"path": f.get("path"), "state": f.get("state"), "ours": f.get("ours"), "theirs": f.get("theirs")}
                         for f in e.get("fields") or []],
              "missing": [m.get("reason") for m in e.get("missing") or []],
              "undecided": list(e.get("undecided") or [])}
             for e in (pv or {}).get("items") or []]
    payload = _json.dumps({"items": items, "mappings_needed": (pv or {}).get("mappings_needed") or []},
                          sort_keys=True, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def decide(db, release_id: int, decisions: dict, *, actor: str | None) -> dict:
    rel = _release(db, release_id)
    if rel["state"] not in ("uploaded", "previewed", "approved"):
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; decisions belong before the apply")
    merged = dict(rel.get("decisions") or {})
    for obj, fields in (decisions or {}).items():
        if not isinstance(fields, dict):
            raise ReleaseRefusal(f"decisions for {obj!r} must map field paths to take_release | keep_prod")
        for path, d in fields.items():
            if d not in ("take_release", "keep_prod"):
                raise ReleaseRefusal(f"{obj} {path}: decision must be take_release or keep_prod, not {d!r}")
        merged.setdefault(obj, {}).update(fields)
    # a decision changes the plan: back to previewed so it is re-approved
    db.update_config_release(rel["id"], {"decisions": merged,
                                         "state": "previewed" if rel["state"] == "approved" else rel["state"],
                                         "approved_by": None, "approved_at": None})
    _audit(db, actor, "release.decide", rel["id"], {"decisions": decisions})
    return preview(db, rel["id"], actor=actor)


# ── approve ────────────────────────────────────────────────────────────────

def gitlab_verified_environment(env: str) -> dict | None:
    """The ``governance.release.gitlab`` config when THIS environment verifies
    deployment approvals itself; None when nothing is configured.  FAIL CLOSED
    (fifth review): a configured block whose ``environment`` is missing or is not
    ``env`` refuses -- a label mismatch never switches verification off."""
    from core.release import gitlab_verify as gv
    cfg = gv.gitlab_cfg()
    if not gv.is_configured(cfg):
        return None
    if cfg["environment"] != env:
        raise ReleaseRefusal(f"governance.release.gitlab.environment is {cfg['environment'] or '(missing)'!r} but this "
                             f"deployment is {env!r} -- fail closed: fix the configuration, verification is never "
                             f"switched off by a mismatch")
    return cfg


def _require_verification(env: str) -> dict | None:
    """In a four-eyes environment GitLab verification MUST be configured (fail
    closed); elsewhere None means a person approves in the UI."""
    gcfg = gitlab_verified_environment(env)
    if gcfg is None and _is_four_eyes(env):
        raise ReleaseRefusal(f"environment {env!r} is four-eyes but governance.release.gitlab is not configured -- "
                             f"fail closed: this environment must verify the deployment approval itself")
    return gcfg


def approve(db, release_id: int, *, actor: str | None, ticket: str | None = None,
            note: str | None = None, validate_ticket_fn: Callable[..., dict] | None = None,
            approver: dict | None = None, deployment: dict | None = None,
            verify_fn: Callable[..., dict] | None = None) -> dict:
    """The approver OF RECORD (2026-11-10, fourth review): in an environment that
    verifies GitLab deployment approvals itself (``governance.release.gitlab``),
    the request carries LOOKUP KEYS only (``deployment = {pipeline_id, job_id,
    tag}``) and the SERVER reads who approved (``core.release.gitlab_verify``);
    a self-asserted ``approver`` is refused there, and in any four-eyes
    environment.  Elsewhere ``actor`` (a person in the UI) is the approver.
    Four-eyes compares every approver of record with the uploader."""
    rel = _release(db, release_id)
    _same_environment(db, rel, "approved")
    assert_production_governed(db)
    if rel["state"] not in ("previewed",):
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; approve a PREVIEWED release")
    rcfg = release_cfg()
    env = rel["environment"]
    four_eyes = _is_four_eyes(env)
    approved_by, evidence, names = actor, None, [str(actor or "")]
    gcfg = _require_verification(env)
    if gcfg:
        if approver:
            raise ReleaseRefusal(f"a self-asserted approver is not accepted in {env!r}: this environment verifies the GitLab "
                                 f"deployment approval itself -- send the lookup keys deployment={{pipeline_id, job_id, tag}}")
        if not deployment or not isinstance(deployment, dict):
            raise ReleaseRefusal(f"approving in {env!r} needs deployment={{pipeline_id, job_id, tag}} -- the lookup keys of "
                                 f"the GitLab deployment this environment verifies itself")
        from core.release import gitlab_verify as gv
        evidence = (verify_fn or gv.verify_release_approval)(gcfg, deployment=deployment, release=rel,
                                                             uat_authors=changed_row_authors(rel))
        # the deployment is CONSUMED atomically (one UPDATE guarded by NOT EXISTS), never check-then-update
        if not db.claim_approval_deployment(rel["id"], evidence["deployment_id"]):
            taken = db.release_with_approval_deployment(evidence["deployment_id"]) or {}
            raise ReleaseRefusal(f"GitLab deployment {evidence['deployment_id']} already approved release "
                                 f"{taken.get('id', '?')} -- one deployment approves ONE release; a new deployment is needed "
                                 f"for release {release_id}")
        names = [str(a.get("username") or "") for a in evidence["approvers"]]
        approved_by = ", ".join(f"{a['username']} (GitLab user {a['id']})" for a in evidence["approvers"])
        note = (note or "") + (f" | approvers of record verified by this environment against GitLab deployment "
                               f"{evidence['deployment_id']} (pipeline {evidence['pipeline_id']}, job {evidence['job_id']}, "
                               f"tag {evidence['tag']}); recorded by {actor}")
    elif approver:
        if four_eyes:
            raise ReleaseRefusal(f"a self-asserted approver is refused in {env!r} (four-eyes): configure "
                                 f"governance.release.gitlab so this environment verifies the GitLab approval itself, "
                                 f"or a person approves with their own login")
        if not approver.get("gitlab_user_id") or not approver.get("username"):
            raise ReleaseRefusal("an approver of record needs gitlab_user_id and username")
        approved_by = f"{approver['username']} (GitLab user {approver['gitlab_user_id']})"
        names = [str(approver["username"])]
        note = (note or "") + f" | approver of record: {approved_by}, {approver.get('name') or ''}; " \
                              f"evidence {approver.get('evidence') or '-'}; recorded by {actor}"
    uploaded_by = str(rel.get("uploaded_by") or "")
    # the uploader vs the approvers: in a verifying environment ONLY the identity map (QS
    # login -> GitLab id, inside the verdict) decides -- a QS name and a GitLab username are
    # different namespaces; elsewhere (a person in the UI) the login itself
    if four_eyes and not gcfg and uploaded_by and (approved_by == uploaded_by or uploaded_by in names):
        raise ReleaseRefusal(f"four-eyes: {uploaded_by!r} uploaded release {release_id} and may not approve it "
                             f"in {env!r} (feed_generation.governance.release.four_eyes_environments)")
    ticket = ticket or rel.get("jira_ticket")
    if env in (rcfg["require_ticket_environments"] or []) and not ticket:
        raise ReleaseRefusal(f"a JIRA ticket is required to approve a release to {env!r} "
                             f"(feed_generation.governance.release.require_ticket_environments)")
    from core.feed.jira_link import gate_change, validate_ticket
    # a RELEASE's own statuses (2026-11-10): "In Progress" is a CHANGE status anyone sets
    allowed = list(rcfg.get("jira_approved_statuses") or ["Approved"])
    _validate = validate_ticket_fn or (lambda t: validate_ticket(t, allowed_statuses=allowed))
    validation = _validate(ticket) if ticket else {"outcome": "skipped"}
    if ticket:
        allowed, reason = gate_change(validation)
        if not allowed:
            raise ReleaseRefusal(f"approval refused: {reason}")
    out = db.update_config_release(rel["id"], {
        "state": "approved", "approved_by": approved_by, "approved_at": _now(), "approval_note": note,
        "jira_ticket": ticket, "ticket_validation": validation, "approval_evidence": evidence})
    _audit(db, actor, "release.approve", rel["id"], {"ticket": ticket, "validation": validation,
                                                     "approver_of_record": approved_by, "evidence": evidence})
    return out


# ── apply ──────────────────────────────────────────────────────────────────

def _ensure_enabled(environment: str) -> None:
    """The master gate protects the environments where git is the truth
    (PROD): there an apply needs ``governance.enabled``.  A DB-first
    environment (DEV, UAT) applies regardless -- the legacy promotion routes
    (published-view import, DataFlow bundle import) ride this engine and
    were never gated there; gating them would be a regression, not a control."""
    if environment in git_truth_environments() and not bool(gov_cfg().get("enabled", False)):
        raise ReleaseRefusal(f"release applies to {environment!r} are disabled "
                             f"(feed_generation.governance.enabled=false) -- export, upload and preview remain available")


def apply(db, release_id: int, *, actor: str | None) -> dict:
    """ONE transaction: snapshot, every object, every ledger row -- or nothing.
    Returns the release with ``followups`` (templates whose members the
    caller must re-render) and ``ledger``.  In a four-eyes environment the
    release must carry the approval THIS environment verified itself."""
    rel = _release(db, release_id)
    _same_environment(db, rel, "applied")
    assert_production_governed(db)
    if _require_verification(rel["environment"]) and not rel.get("approval_evidence"):
        # 2026-11-10: an approval this environment did not verify itself applies nothing
        raise ReleaseRefusal(f"release {release_id} carries no approval this environment verified against GitLab "
                             f"(approval_evidence) -- approve it through the route with the deployment lookup keys")
    return _apply(db, release_id, actor=actor, restore_of=None)


def _apply(db, release_id: int, *, actor: str | None, restore_of: int | None) -> dict:
    """The transaction.  ``restore_of`` is set ONLY by :func:`rollback` (the code
    path, never a caller's flag): the snapshot of release ``restore_of`` is
    re-applied whole, its preview's blocks taken as they are."""
    rel = _release(db, release_id)
    _ensure_enabled(rel["environment"])
    take_all = restore_of is not None and rel.get("rollback_of") == restore_of
    if rel["state"] not in APPLY_FROM:
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; only an APPROVED release applies")
    pv = rel.get("preview") or {}
    if not pv:
        raise ReleaseRefusal(f"release {release_id} has no preview")
    if not pv.get("ready") and not take_all:
        raise ReleaseRefusal(
            f"release {release_id} is not ready: {pv['counts'].get('blocked', 0)} blocked object(s), "
            f"{pv['counts'].get('undecided', 0)} undecided conflict(s) -- map, decide, preview again")
    registry = load()
    env = rel["environment"]
    items = _items_of(rel)
    mapping = Mapping(rel.get("mapping_used") or db.list_release_mappings(env))
    decisions = rel.get("decisions") or {}
    by_key = {(e["kind"], e["key"]): e for e in pv.get("items") or []}
    items = [registry.require(i.kind).effective(i, mapping) for i in items]
    in_package = {(i.kind, i.key) for i in items}
    order = {k: i for i, k in enumerate(kinds_in_order(i.kind for i in items))}
    ordered = sorted(items, key=lambda i: (order[i.kind], i.key))
    commit = rel.get("source_commit") or rel["package_checksum"]
    snapshot: list[dict] = []
    created: list[dict] = []
    ledger: list[dict] = []
    followups: list[dict] = []
    from core.db.models import ConfigDeployment, ConfigRelease
    try:
        with db.get_session() as session:
            row = session.query(ConfigRelease).filter(ConfigRelease.id == rel["id"])
            try:
                row = row.with_for_update(nowait=False)
            except Exception:  # noqa: BLE001 -- dialects without row locks
                pass
            row = row.first()
            if row is None or row.state not in APPLY_FROM:
                raise ReleaseRefusal(f"release {release_id} is no longer approved (another apply?)")
            row.state, row.applied_by, row.applied_at = "applying", actor, _now()
            session.flush()
            # pass 1 -- the SNAPSHOT of every object as it is NOW, before anything
            # moves (a dataset applied first would otherwise change what its
            # report's snapshot sees), and the "nothing moved since the preview" check
            current: dict = {}
            for item in ordered:
                t = registry.require(item.kind)
                entry = by_key.get((item.kind, item.key)) or {}
                existing = t.find_row(session, item.key)
                theirs = t.export_row(session, existing, registry) if existing is not None else None
                current[(item.kind, item.key)] = (existing, theirs)
                if theirs is not None:
                    snapshot.append({"kind": item.kind, "key": item.key, "definition": theirs.definition,
                                     "hash": theirs.hash})
                    if entry.get("theirs_hash") not in (None, theirs.hash):
                        raise ReleaseRefusal(
                            f"{item.kind} {item.key!r} changed in {env} since the preview -- preview again",
                            kind=item.kind, key=item.key)
                elif entry.get("theirs_hash"):
                    raise ReleaseRefusal(f"{item.kind} {item.key!r} was deleted in {env} since the preview",
                                         kind=item.kind, key=item.key)
            # pass 2 -- apply, in vocabulary order
            for item in ordered:
                t = registry.require(item.kind)
                entry = by_key.get((item.kind, item.key)) or {}
                existing, theirs = current[(item.kind, item.key)]
                keep = set() if take_all else diffmod.keep_fields(
                    {"fields": entry.get("fields") or []}, decisions.get(f"{item.kind}|{item.key}") or {})
                if existing is not None and theirs is not None and theirs.hash == item.hash:
                    oid, action = int(existing.id), "unchanged"
                else:
                    resolved = t.resolve(session, item, mapping, registry, in_package)
                    if resolved.get("missing"):
                        raise ReleaseRefusal(
                            f"{item.kind} {item.key!r}: {resolved['missing'][0].get('reason')}",
                            kind=item.kind, key=item.key)
                    oid, action = t.apply(session, item, resolved, existing, keep_fields=keep,
                                          actor=actor, registry=registry)
                    if action == "updated" and keep:
                        action = "kept_prod" if keep >= set(item.definition) else "updated"
                    if action == "created":
                        created.append({"kind": item.kind, "key": item.key, "object_id": oid})
                    if item.kind == "feed_template":
                        followups.append({"kind": "feed_template", "key": item.key, "object_id": oid})
                dep = ConfigDeployment(
                    environment=env, object_type=item.kind, object_id=oid, name=item.key,
                    git_commit=str(commit)[:64], jira_ticket=rel.get("jira_ticket"), deployed_by=actor,
                    definition=item.definition if action != "kept_prod" else (theirs.definition if theirs else item.definition),
                    definition_hash=item.hash if action != "kept_prod" else (theirs.hash if theirs else item.hash),
                    release_id=rel["id"], action=action, package_checksum=rel["package_checksum"],
                    created_by=actor, updated_by=actor)
                session.add(dep)
                session.flush()
                ledger.append({"kind": item.kind, "key": item.key, "object_id": oid, "action": action,
                               "kept_fields": sorted(keep)})
            row.state = "applied"
            row.snapshot = snapshot
            row.snapshot_checksum = pkgmod.checksum(snapshot) if snapshot else None
            row.created_objects = created
            row.applied_at = _now()
            session.flush()
    except ReleaseRefusal as exc:
        db.update_config_release(rel["id"], {"state": "failed", "error": str(exc)})
        _audit(db, actor, "release.apply_failed", rel["id"], {"error": str(exc)})
        raise
    except Exception as exc:  # noqa: BLE001 -- the database's own refusal, named
        db.update_config_release(rel["id"], {"state": "failed", "error": f"{type(exc).__name__}: {exc}"[:2000]})
        _audit(db, actor, "release.apply_failed", rel["id"], {"error": str(exc)[:500]})
        raise ReleaseRefusal(f"apply of release {release_id} failed and NOTHING was applied: "
                             f"{type(exc).__name__}: {exc}") from exc
    _audit(db, actor, "release.apply", rel["id"],
           {"objects": len(ledger), "created": len(created), "commit": commit})
    out = db.get_config_release(rel["id"], with_package=False)
    out["ledger"] = ledger
    out["followups"] = followups
    return out


# ── verify ─────────────────────────────────────────────────────────────────

def verify(db, release_id: int, *, actor: str | None = None) -> dict:
    rel = _release(db, release_id)
    _same_environment(db, rel, "verified")
    assert_production_governed(db)
    if rel["state"] not in ("applied", "applied_unverified", "verified"):
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; verify an APPLIED release")
    registry = load()
    ledger = db.list_release_ledger(rel["id"])
    results: list[dict] = []
    with db.get_session(read_only=True) as session:
        for l in ledger:
            t = registry.get(l["object_type"])
            if t is None:
                v = Verdict("unknown", f"type {l['object_type']!r} is not registered in this build")
            elif l.get("object_id") is None:
                v = Verdict("failed", "the ledger row has no object id -- nothing was written")
            else:
                try:
                    v = t.verify(db, session, int(l["object_id"]), registry)
                except Exception as exc:  # noqa: BLE001 -- a verifier that crashes is UNKNOWN, said
                    v = Verdict("unknown", f"verifier raised {type(exc).__name__}: {exc}")
            results.append({"kind": l["object_type"], "key": l["name"], "object_id": l.get("object_id"),
                            "verdict": v.to_dict()})
    states = {r["verdict"]["state"] for r in results}
    overall = "failed" if "failed" in states else ("unknown" if "unknown" in states else "ok")
    if not results:
        overall = "unknown"
    verification = {"state": overall, "at": _now().isoformat(), "by": actor, "items": results,
                    "counts": {s: sum(1 for r in results if r["verdict"]["state"] == s)
                               for s in ("ok", "failed", "unknown")}}
    new_state = "verified" if overall == "ok" else "applied_unverified"
    out = db.update_config_release(rel["id"], {"verification": verification, "verified_at": _now(),
                                               "state": new_state})
    _audit(db, actor, "release.verify", rel["id"], {"state": overall, "counts": verification["counts"]})
    if overall != "ok":
        logger.error("[release] release %s to %s is APPLIED but NOT VERIFIED (%s): %s", rel["id"],
                     rel["environment"], overall,
                     "; ".join(f"{r['kind']} {r['key']}: {r['verdict']['reason']}"
                               for r in results if r["verdict"]["state"] != "ok")[:1000])
        policy = str((release_cfg().get("verify") or {}).get("on_failure") or "hold")
        if policy == "rollback" and overall == "failed":
            logger.error("[release] verify.on_failure=rollback: rolling release %s back", rel["id"])
            rb = rollback(db, rel["id"], actor=f"{actor or 'system'} (verify.on_failure=rollback)")
            out = db.get_config_release(rel["id"])
            out["rolled_back_by_release"] = rb["id"]
    return out


# ── rollback ───────────────────────────────────────────────────────────────

def rollback(db, release_id: int, *, actor: str | None) -> dict:
    """A NEW release whose package is the snapshot the apply took: the
    objects return to their governed form before the release; objects the
    release CREATED are deactivated where the model allows (never deleted:
    runs may reference them) and reported otherwise.  Four-eyes is waived
    for a rollback -- it restores a state that was itself approved -- and
    the waiver is recorded on the row."""
    rel = _release(db, release_id)
    _same_environment(db, rel, "rolled back")
    assert_production_governed(db)
    _ensure_enabled(rel["environment"])
    # a rollback is REVERT power: loud in the log and the audit trail (the approver account holds it)
    logger.warning("[release] ROLLBACK of release %s in %s by %s -- the objects return to the snapshot the apply took",
                   release_id, rel["environment"], actor)
    if rel["state"] not in ROLLBACK_FROM:
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; roll back an APPLIED release")
    registry = load()
    snapshot = rel.get("snapshot") or []
    created = rel.get("created_objects") or []
    items = [Item(kind=s["kind"], key=s["key"], definition=s["definition"], hash=s["hash"])
             for s in snapshot]
    deactivated: list[dict] = []
    left: list[dict] = []
    with db.get_session() as session:
        for c in created:
            t = registry.get(c["kind"])
            row = session.query(t.model).filter(t.model.id == int(c["object_id"])).first() if t else None
            if row is None:
                left.append(dict(c, why="no longer present"))
            elif hasattr(row, "is_active"):
                row.is_active = False
                deactivated.append(c)
            else:
                left.append(dict(c, why=f"{c['kind']} has no is_active -- left in place, named here"))
        session.flush()
    if not items:
        out = db.update_config_release(rel["id"], {"state": "rolled_back"})
        _audit(db, actor, "release.rollback", rel["id"], {"deactivated": deactivated, "left": left,
                                                         "restored": 0})
        out["deactivated"], out["left"] = deactivated, left
        return out
    pkg = pkgmod.build_package(items, source_environment=rel["environment"], exported_by=actor,
                               scope={"kind": "rollback", "of": rel["id"]},
                               source_commit=rel.get("source_commit"))
    row = db.create_config_release({
        "environment": rel["environment"], "state": "uploaded", "package_id": pkg["package_id"],
        "package_checksum": pkg["checksum"], "source_environment": rel["environment"],
        "source_commit": rel.get("source_commit"), "source_exported_at": pkg["exported_at"],
        "source_exported_by": actor, "scope": pkg["scope"], "package": pkg,
        "options": {"first_release_overwrites": True, "rollback": True,
                    "deactivated": deactivated, "left": left},
        "jira_ticket": rel.get("jira_ticket"), "uploaded_by": actor, "uploaded_at": _now(),
    })
    preview(db, row["id"], actor=actor)
    db.update_config_release(row["id"], {
        "state": "approved", "approved_by": actor, "approved_at": _now(),
        "approval_note": f"rollback of release {rel['id']} -- four-eyes waived for a rollback "
                         f"(it restores an approved state); recorded here",
        "rollback_of": rel["id"]})
    out = _apply(db, row["id"], actor=actor, restore_of=rel["id"])
    db.update_config_release(rel["id"], {"state": "rolled_back"})
    _audit(db, actor, "release.rollback", rel["id"], {"by_release": row["id"], "restored": len(items),
                                                     "deactivated": deactivated, "left": left})
    out["deactivated"], out["left"] = deactivated, left
    return out


# ── the legacy git deploy (POST /api/governance/deploy) ────────────────────

def apply_items(db, *, environment: str, items: list[dict], commit: str, ticket: str | None,
                actor: str | None) -> list[dict]:
    """``apply_config_deploy``'s body: reviewed definition files -> ONE
    release, approved by the reviewed commit, applied in one transaction.
    Returns ``[{object_type, object_id, name}]`` as the old seam did."""
    env = this_environment(db)
    if environment not in (None, "", env):
        raise ReleaseRefusal(f"a git deploy applies to THIS environment ({env!r}); the request named {environment!r}")
    environment = env
    if _is_four_eyes(env) or gitlab_verified_environment(env):
        raise ReleaseRefusal(f"the legacy git deploy is refused in {env!r}: this environment is released ONLY through the "
                             f"release pipeline (a release tag, GitLab's deployment approval verified by this environment, "
                             f"release:deploy) -- POST /api/governance/deploy applies nothing here")
    rel_items = [Item(kind=str(i["object_type"]), key=str(i["name"]), definition=i.get("definition") or {},
                      hash=str(i.get("definition_hash") or "")) for i in items]
    for it in rel_items:
        if not it.hash:
            from core.release.contract import item_hash
            it.hash = item_hash(it.definition)
    pkg = pkgmod.build_package(rel_items, source_environment="git", exported_by=actor,
                               scope={"kind": "git_deploy", "files": [i.get("path") for i in items]},
                               source_commit=commit)
    row = upload(db, pkg, environment=environment, actor=actor, ticket=ticket,
                 options={"first_release_overwrites": True, "git_deploy": True})
    pv = preview(db, row["id"], actor=actor)
    if not (pv.get("preview") or {}).get("ready"):
        blocked = [e for e in pv["preview"]["items"] if e["blocked"]]
        reason = (blocked[0]["missing"][0].get("reason") if blocked and blocked[0]["missing"]
                  else "undecided conflicts")
        db.update_config_release(row["id"], {"state": "failed", "error": reason})
        raise ReleaseRefusal(f"deploy refused: {reason}")
    db.update_config_release(row["id"], {
        "state": "approved", "approved_by": actor, "approved_at": _now(),
        "approval_note": f"approved by the reviewed git commit {commit} (the review happened in git)"})
    out = apply(db, row["id"], actor=actor)
    return [{"object_type": l["kind"], "object_id": l["object_id"], "name": l["key"]}
            for l in out["ledger"]]


# ── the legacy promotion routes ride the same engine ───────────────────────

def promote_items(db, items: list, *, actor: str | None, environment: str | None = None,
                  ticket: str | None = None, source_commit: str | None = None,
                  source_environment: str = "import", scope: dict | None = None,
                  connection_map: dict | None = None, overwrite_existing: bool = True,
                  dry_run: bool = False) -> dict:
    """What the Phase 98-E published-view import and the DataFlow bundle
    import now do: ONE release through the engine, answered in their old
    summary shape -- ``created / updated / skipped / errors`` plus the
    release id(s), so the Releases panel shows the same thing.

    ``connection_map`` becomes this environment's connection mapping.  With
    ``overwrite_existing=False`` every object that already exists is SKIPPED
    (a reduced release is applied).  ``dry_run`` stops after the preview.
    In a four-eyes environment the single-call import cannot approve itself:
    the release stays ``previewed`` and the summary says who must approve."""
    env = this_environment(db)
    if environment not in (None, "", env):
        raise ReleaseRefusal(f"an import applies to THIS environment ({env!r}); the request named {environment!r}")
    errors: list[dict] = []
    summary = {"dry_run": dry_run, "created": 0, "updated": 0, "skipped": 0, "errors": errors,
               "total_input": len(items), "release_ids": [], "environment": env}
    if not items:
        return summary
    if connection_map:
        db.upsert_release_mappings(env, [{"kind": "connection", "from_value": k, "to_value": v}
                                         for k, v in connection_map.items()], created_by=actor)

    def _upload_and_preview(its):
        pkg = pkgmod.build_package(its, source_environment=source_environment, exported_by=actor,
                                   scope=scope or {"kind": "import", "items": len(its)}, source_commit=source_commit)
        rel = upload(db, pkg, environment=env, actor=actor, ticket=ticket, options={"first_release_overwrites": True, "import": True})
        summary["release_ids"].append(rel["id"])
        return rel, preview(db, rel["id"], actor=actor)["preview"]

    rel, pv = _upload_and_preview(items)
    entries = pv["items"]
    by = {(e["kind"], e["key"]): e for e in entries}
    for e in entries:
        if e["blocked"]:
            reason = (e["missing"][0].get("reason") if e["missing"] else f"blocked by {e['blocked_by']}")
            errors.append({"kind": e["kind"], "slug": e["key"], "key": e["key"], "error": reason})
    keep = [i for i in items if not by[(i.kind, i.key)]["blocked"]]
    if not overwrite_existing:
        existing_keys = {(e["kind"], e["key"]) for e in entries if e["state"] != "new"}
        summary["skipped"] = len([i for i in keep if (i.kind, i.key) in existing_keys])
        keep = [i for i in keep if (i.kind, i.key) not in existing_keys]
    summary["created"] = sum(1 for i in keep if by[(i.kind, i.key)]["state"] == "new")
    summary["updated"] = sum(1 for i in keep if by[(i.kind, i.key)]["state"] != "new")
    if dry_run or not keep:
        return summary
    if len(keep) != len(items):
        rel, pv = _upload_and_preview(keep)
    try:
        approve(db, rel["id"], actor=actor, ticket=ticket, note="approved by the import call")
    except ReleaseRefusal as exc:
        errors.append({"kind": "release", "key": rel["id"], "slug": str(rel["id"]),
                       "error": f"release {rel['id']} is previewed but NOT applied: {exc} -- approve it in "
                                f"Admin -> Governance -> Configuration releases"})
        summary["created"] = summary["updated"] = 0
        return summary
    try:
        out = apply(db, rel["id"], actor=actor)
    except ReleaseRefusal as exc:
        errors.append({"kind": "release", "key": rel["id"], "slug": str(rel["id"]), "error": str(exc)})
        summary["created"] = summary["updated"] = 0
        return summary
    actions = [l["action"] for l in out.get("ledger") or []]
    summary["created"] = actions.count("created")
    summary["updated"] = sum(1 for a in actions if a in ("updated", "kept_prod"))
    summary["unchanged"] = actions.count("unchanged")
    summary["state"] = out.get("state")
    summary["followups"] = out.get("followups") or []
    return summary
