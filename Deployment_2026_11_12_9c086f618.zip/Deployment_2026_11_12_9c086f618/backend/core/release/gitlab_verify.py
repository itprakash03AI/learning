"""PROD verifies the GitLab deployment approval ITSELF (2026-11-10, the fourth and
fifth reviews).

Anything the release pipeline asserts can be forged by the tagged commit (the
script that asserts it IS the tagged commit).  So the target environment holds
its OWN GitLab read token (``feed_generation.governance.release.gitlab``: the
URL, the project id, the System Account whose password is a ``read_api`` token,
the environment name) and reads GitLab server-side.  Requests carry LOOKUP KEYS
only; every fact comes from GitLab:

* at UPLOAD (``verify_upload``): the uploading pipeline ran on the package's
  ``source_commit`` (full 40-character equality) and the uploading job belongs
  to it -- recorded on the release as the pipeline the deployment must match;
* at APPROVE (``verify_deployment``): the tag points at the release's commit
  (full sha); the pipeline ran on it for that tag; the push event names the
  PUSHER; the commit EQUALS a merged merge request's ``merge_commit_sha`` /
  ``squash_commit_sha`` / head into the default branch (no "newest MR containing
  it"); the MR's approvals name an approver who is neither its author nor the
  pusher; EVERY author / committer of the MR's commits resolves to a GitLab user
  (an e-mail GitLab cannot resolve = refused); the deployment of THIS job (paged
  list, deployable id == job id) is ``running`` (never success / failed /
  canceled), belongs to the pipeline that UPLOADED the release (missing
  ``deployable.pipeline.id`` = refused), deploys the release's commit, has
  ``approval_summary.status == approved`` (missing = NOT approved) and approvals
  with status ``approved`` each created AFTER the release was previewed; every
  approver's user id is outside {the pipeline's user, the tag's pusher, the MR
  author, the MR commits' people, the UPLOADER (its QueryStudio login mapped by
  the identity map -- no mapping = refused), the UAT authors of the CHANGED rows
  (mapped the same way; no entry = refused)}; the deployment id is CONSUMED by
  the engine (one release per deployment).

Bounded: the reader refuses after ``max_calls`` lookups or ``deadline_seconds``;
hitting a paging cap refuses.  Fail closed: an unreadable answer, a missing
field, a token that cannot read the record -- each is a ``ReleaseRefusal`` in
words.  Pure of the engine: the reader is a seam (tests inject a fake), the
verdict is data (``evidence``) the engine records on the release.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from typing import Any

from core.release.contract import ReleaseRefusal

#: an identity_map value meaning "this QueryStudio login is a system account, not a person"
NOT_A_PERSON = "-"
#: the ONE state a deployment may be in while its job verifies it
DEPLOYMENT_STATE = "running"
MR_MERGED = "merged"
SHA_LEN = 40


def gitlab_cfg(raw: dict | None = None) -> dict:
    """``feed_generation.governance.release.gitlab`` normalised (every key present)."""
    if raw is None:
        from core.release.engine import release_cfg
        raw = release_cfg().get("gitlab") or {}
    raw = dict(raw or {})
    imap = raw.get("identity_map") or {}
    return {
        "url": str(raw.get("url") or "").strip().rstrip("/"),
        "project_id": str(raw.get("project_id") or "").strip(),
        "system_account": str(raw.get("system_account") or "").strip(),
        "environment": str(raw.get("environment") or "").strip(),
        "identity_map": {str(k).strip().lower(): str(v).strip() for k, v in imap.items()} if isinstance(imap, dict) else {},
        "timeout_seconds": float(raw.get("timeout_seconds") or 30),
        "max_calls": int(raw.get("max_calls") or 200),
        "deadline_seconds": float(raw.get("deadline_seconds") or 120),
        "plan_job_name": str(raw.get("plan_job_name") or "release:plan").strip(),
    }


def is_configured(cfg: dict) -> bool:
    return bool(cfg.get("url") and cfg.get("project_id") and cfg.get("system_account"))


def read_token(cfg: dict) -> str:
    """The read_api token: the configured System Account's password (Vault when
    the account uses Vault) -- never a value in a request."""
    from core import qs_credentials as qc
    try:
        creds = qc.resolve_system_account(cfg["system_account"]) or {}
    except Exception as exc:  # the reason travels in words
        raise ReleaseRefusal(f"the GitLab read token could not be resolved from System Account "
                             f"{cfg['system_account']!r}: {exc}") from exc
    token = str(creds.get("password") or creds.get("token") or creds.get("secret_key") or "").strip()
    if not token:
        raise ReleaseRefusal(f"System Account {cfg['system_account']!r} holds no password / token for GitLab "
                             f"(governance.release.gitlab.system_account)")
    return token


class GitLabReader:
    """Read-only GET on <url>/api/v4 with PRIVATE-TOKEN, BOUNDED (calls, time);
    401 / 403, any transport failure, the page cap and the budget each become a
    ReleaseRefusal in words."""

    def __init__(self, url: str, project_id: str, token: str, timeout: float = 30.0, *,
                 max_calls: int = 200, deadline_seconds: float = 120.0):
        self.api = f"{url.rstrip('/')}/api/v4"
        self.proj = f"/projects/{urllib.parse.quote(str(project_id), safe='')}"
        self.token, self.timeout = token, timeout
        self.max_calls, self.deadline = max_calls, time.monotonic() + deadline_seconds
        self.calls = 0

    def _budget(self, path: str) -> None:
        self.calls += 1
        if self.calls > self.max_calls:
            raise ReleaseRefusal(f"the GitLab verification exceeded its budget of {self.max_calls} lookups at GET {path}; refused")
        if time.monotonic() > self.deadline:
            raise ReleaseRefusal(f"the GitLab verification exceeded its time budget at GET {path}; refused")

    def _page(self, path: str) -> tuple[Any, str]:
        self._budget(path)
        req = urllib.request.Request(self.api + path, method="GET")
        req.add_header("PRIVATE-TOKEN", self.token)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode("utf-8")
                return (json.loads(raw) if raw else None), str(resp.headers.get("X-Next-Page") or "")
        except urllib.error.HTTPError as exc:
            hint = " -- the System Account's token must have scope read_api on the project" if exc.code in (401, 403) else ""
            raise ReleaseRefusal(f"GitLab answered {exc.code} to GET {path}{hint}; the approval cannot be verified") from exc
        except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
            raise ReleaseRefusal(f"GitLab could not be read (GET {path}): {exc}; the approval cannot be verified") from exc

    def get(self, path: str) -> Any:
        return self._page(path)[0]

    def paged(self, path: str, limit_pages: int = 50) -> list:
        """Every page; a listing longer than ``limit_pages`` pages REFUSES (an
        unbounded walk proves nothing)."""
        out: list = []
        page, sep = "1", ("&" if "?" in path else "?")
        for _ in range(limit_pages):
            data, nxt = self._page(f"{path}{sep}per_page=100&page={page}")
            out += list(data or [])
            if not nxt:
                return out
            page = nxt
        raise ReleaseRefusal(f"GET {path} has more than {limit_pages} pages; the walk is unbounded -- refused")


def _user(u: Any) -> dict:
    u = u if isinstance(u, dict) else {}
    return {"id": u.get("id"), "username": str(u.get("username") or ""), "name": str(u.get("name") or ""),
            "email": str(u.get("email") or u.get("public_email") or "").lower()}


def _need(value: Any, what: str) -> Any:
    if value in (None, "", [], {}):
        raise ReleaseRefusal(f"GitLab's answer carries no {what}; the approval cannot be verified")
    return value


def _full_sha(value: Any, what: str) -> str:
    sha = str(value or "").strip().lower()
    if len(sha) != SHA_LEN or any(c not in "0123456789abcdef" for c in sha):
        raise ReleaseRefusal(f"{what} is not a full {SHA_LEN}-character commit sha: {sha[:12] or '(empty)'!r}")
    return sha


def _when(value: Any, what: str) -> datetime:
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    text = str(value or "").strip()
    if not text:
        raise ReleaseRefusal(f"GitLab's answer carries no {what}; the approval cannot be verified")
    try:
        dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ReleaseRefusal(f"{what} {text!r} is not an ISO date-time") from exc
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


class _Forbidden:
    def __init__(self):
        self.ids: dict[Any, str] = {}

    def add(self, uid: Any, role: str) -> None:
        if uid is None:
            raise ReleaseRefusal(f"cannot prove four-eyes: {role} has no GitLab user id")
        self.ids[uid] = role if uid not in self.ids else f"{self.ids[uid]} and {role}"


def _user_id(reader: GitLabReader, username: str) -> int | None:
    for u in reader.get(f"/users?username={urllib.parse.quote(username, safe='')}") or []:
        if str(u.get("username") or "").lower() == username.lower():
            return u.get("id")
    return None


def _user_by_email(reader: GitLabReader, email: str) -> dict | None:
    for u in reader.get(f"/users?search={urllib.parse.quote(email, safe='')}") or []:
        if email in {str(u.get("email") or "").lower(), str(u.get("public_email") or "").lower()}:
            return _user(u)
    return None


def _mapped_id(reader: GitLabReader, cfg: dict, login: str, what: str) -> int | None:
    """A QueryStudio login -> GitLab user id through the identity map; None = a
    declared system login; no entry / unknown user = refused."""
    key = str(login).strip().lower()
    mapped = (cfg.get("identity_map") or {}).get(key)
    if not mapped:
        raise ReleaseRefusal(f"cannot prove four-eyes: {what} {login!r} has no entry in "
                             f"governance.release.gitlab.identity_map (qs_login -> gitlab_username, or '{NOT_A_PERSON}' "
                             f"for a system account)")
    if mapped == NOT_A_PERSON:
        return None
    uid = _user_id(reader, mapped)
    if uid is None:
        raise ReleaseRefusal(f"cannot prove four-eyes: identity_map maps {what} {login!r} to GitLab user {mapped!r}, "
                             f"whom GitLab does not have")
    return uid


def verify_upload(reader: GitLabReader, *, pipeline_id: Any, job_id: Any, source_commit: str,
                  plan_job_name: str = "release:plan") -> dict:
    """The uploading pipeline ran on the package's commit and the uploading job
    belongs to it, is the RUNNING plan job: what the deployment must later match."""
    for k, v in (("pipeline_id", pipeline_id), ("job_id", job_id)):
        if v in (None, ""):
            raise ReleaseRefusal(f"the upload names no {k} (lookup keys: pipeline_id, job_id) -- this environment verifies "
                                 f"the uploading pipeline itself")
    commit = _full_sha(source_commit, "the package's source_commit")
    p = reader.get(f"{reader.proj}/pipelines/{urllib.parse.quote(str(pipeline_id), safe='')}") or {}
    _need(p.get("id"), f"pipeline {pipeline_id}")
    if _full_sha(p.get("sha"), f"the sha of pipeline {pipeline_id}") != commit:
        raise ReleaseRefusal(f"pipeline {pipeline_id} ran on {str(p.get('sha'))[:12]}, the package was exported from "
                             f"{commit[:12]} -- not the same code")
    j = reader.get(f"{reader.proj}/jobs/{urllib.parse.quote(str(job_id), safe='')}") or {}
    _need(j.get("id"), f"job {job_id}")
    if str(((j.get("pipeline") or {}).get("id")) or "") != str(pipeline_id):
        raise ReleaseRefusal(f"job {job_id} belongs to pipeline {(j.get('pipeline') or {}).get('id')!r}, not {pipeline_id}")
    if str(j.get("name") or "") != plan_job_name:
        raise ReleaseRefusal(f"job {job_id} is {j.get('name')!r}, not the plan job {plan_job_name!r} -- only the plan job uploads")
    if str(j.get("status") or "") != "running":
        raise ReleaseRefusal(f"job {job_id} is {j.get('status')!r}, not running -- only the job that is running its upload uploads")
    return {"pipeline_id": str(pipeline_id), "job_id": str(job_id), "job_name": str(j.get("name") or ""),
            "sha": commit, "ref": str(p.get("ref") or ""), "verified_at": datetime.now(timezone.utc).isoformat()}


def verify_deployment(reader: GitLabReader, cfg: dict, *, tag: str, commit: str, pipeline_id: Any, job_id: Any,
                      uat_authors: dict[str, list[str]], upload_pipeline_id: Any, previewed_at: Any,
                      uploaded_by: str, checksum: str) -> dict:
    """The server-side verdict; raises ReleaseRefusal in words, returns the evidence."""
    commit = _full_sha(commit, "the release's source_commit")
    for k, v in (("tag", tag), ("pipeline_id", pipeline_id), ("job_id", job_id)):
        if v in (None, ""):
            raise ReleaseRefusal(f"the approval request names no {k} (lookup keys: tag, pipeline_id, job_id)")
    if upload_pipeline_id in (None, ""):
        raise ReleaseRefusal("the release records no uploading pipeline -- it was not uploaded through a verified pipeline; "
                             "upload it again with the pipeline keys")
    if str(pipeline_id) != str(upload_pipeline_id):
        raise ReleaseRefusal(f"the approval names pipeline {pipeline_id} but the release was uploaded by pipeline "
                             f"{upload_pipeline_id} -- a deployment approves the release ITS pipeline uploaded")
    previewed = _when(previewed_at, "the release's previewed_at (preview it first)")
    forbidden = _Forbidden()
    # 1. the tag points at the release's commit (full equality)
    t = reader.get(f"{reader.proj}/repository/tags/{urllib.parse.quote(str(tag), safe='')}") or {}
    tag_sha = _full_sha((t.get("commit") or {}).get("id"), f"the commit of tag {tag}")
    if tag_sha != commit:
        raise ReleaseRefusal(f"tag {tag} points at {tag_sha[:12]}, the release was exported from {commit[:12]} -- not the same code")
    # 2. the pipeline ran on that commit for that tag; its user
    p = reader.get(f"{reader.proj}/pipelines/{urllib.parse.quote(str(pipeline_id), safe='')}") or {}
    _need(p.get("id"), f"pipeline {pipeline_id}")
    if _full_sha(p.get("sha"), f"the sha of pipeline {pipeline_id}") != commit or str(p.get("ref") or "") != str(tag):
        raise ReleaseRefusal(f"pipeline {pipeline_id} ran on {str(p.get('sha') or '')[:12]} for {p.get('ref')!r}, not on "
                             f"{commit[:12]} for tag {tag}")
    pipeline_user = _user(p.get("user"))
    forbidden.add(pipeline_user["id"], f"the pipeline's user ({pipeline_user['username']})")
    # 3. who pushed the tag (the push event, paged)
    pusher = None
    for ev in reader.paged(f"{reader.proj}/events?action=pushed", limit_pages=10):
        pd = ev.get("push_data") or {}
        if str(pd.get("ref_type") or "") == "tag" and str(pd.get("ref") or "") == str(tag):
            pusher = _user(ev.get("author"))
            if pusher["id"] is None:
                pusher["id"] = ev.get("author_id")
            break
    if not pusher or pusher.get("id") is None:
        raise ReleaseRefusal(f"no push event names who pushed tag {tag}; four-eyes cannot be proven")
    forbidden.add(pusher["id"], f"the tag's pusher ({pusher['username']})")
    # 4. the merged, approved merge request whose RESULT is the commit
    project = reader.get(reader.proj) or {}
    default_branch = str(_need(project.get("default_branch"), "default branch"))
    mrs = reader.get(f"{reader.proj}/repository/commits/{commit}/merge_requests") or []
    exact = [m for m in mrs if str(m.get("state")) == MR_MERGED and str(m.get("target_branch") or "") == default_branch
             and commit in {str(m.get(k) or "").lower() for k in ("merge_commit_sha", "squash_commit_sha", "sha")}]
    if not exact:
        raise ReleaseRefusal(f"commit {commit[:12]} is not the RESULT (merge / squash / head) of a merged merge request into "
                             f"{default_branch} -- an intermediate or reverted commit is not a release")
    mr = exact[0]
    author = _user(mr.get("author"))
    forbidden.add(author["id"], f"the merge request's author ({author['username']})")
    iid = urllib.parse.quote(str(mr.get("iid")), safe="")
    approvals = reader.get(f"{reader.proj}/merge_requests/{iid}/approvals") or {}
    mr_approvers = [_user(a.get("user")) for a in approvals.get("approved_by") or []]
    if not mr_approvers:
        raise ReleaseRefusal(f"merge request !{mr.get('iid')} has NO approval -- the default branch needs required approvals")
    for a in mr_approvers:
        if a["id"] is None or a["id"] == author["id"]:
            raise ReleaseRefusal(f"merge request !{mr.get('iid')} was approved by its own author {author['username']} (or by nobody identifiable)")
        if a["id"] == pusher["id"]:
            raise ReleaseRefusal(f"merge request !{mr.get('iid')} was approved by {a['username']}, who pushed the release tag")
    commit_people: dict[str, dict] = {}
    for c in reader.paged(f"{reader.proj}/merge_requests/{iid}/commits", limit_pages=5):
        for email in (str(c.get("author_email") or "").lower(), str(c.get("committer_email") or "").lower()):
            if email and email not in commit_people:
                u = _user_by_email(reader, email)
                if not u or u.get("id") is None:
                    raise ReleaseRefusal(f"cannot prove four-eyes: commit {str(c.get('id') or c.get('short_id') or '?')[:12]} of "
                                         f"merge request !{mr.get('iid')} by {email} is not a known GitLab user (the read token "
                                         f"must see e-mails, or the author must use their public e-mail)")
                commit_people[email] = u
                forbidden.add(u["id"], f"an author / committer of merge request !{mr.get('iid')} ({email})")
    # 5. the uploader and the UAT authors of the CHANGED rows, by the identity map (ids only)
    uid = _mapped_id(reader, cfg, uploaded_by, "the uploader") if uploaded_by else None
    if uid is not None:
        forbidden.add(uid, f"the uploader ({uploaded_by})")
    for obj, logins in sorted((uat_authors or {}).items()):
        for login in logins or []:
            uid = _mapped_id(reader, cfg, login, f"UAT author of {obj}")
            if uid is not None:
                forbidden.add(uid, f"a UAT author of a released row ({login} = {cfg['identity_map'][str(login).strip().lower()]})")
    # 6. the deployment of THIS job, of the UPLOADING pipeline, running, approved after the preview
    dep = None
    for d in reader.paged(f"{reader.proj}/deployments?environment={urllib.parse.quote(cfg['environment'])}&order_by=id&sort=desc"):
        if str((d.get("deployable") or {}).get("id")) == str(job_id):
            dep = d
            break
    if not dep or dep.get("id") is None:
        raise ReleaseRefusal(f"GitLab has no deployment of job {job_id} to {cfg['environment']!r}")
    record = reader.get(f"{reader.proj}/deployments/{urllib.parse.quote(str(dep['id']), safe='')}") or {}
    dep_pipeline = ((record.get("deployable") or {}).get("pipeline") or {}).get("id")
    if dep_pipeline is None:
        raise ReleaseRefusal(f"deployment {dep['id']} names no pipeline (deployable.pipeline.id) -- it cannot be bound to the release")
    if str(dep_pipeline) != str(upload_pipeline_id):
        raise ReleaseRefusal(f"deployment {dep['id']} belongs to pipeline {dep_pipeline}, the release was uploaded by pipeline "
                             f"{upload_pipeline_id} -- not the same pipeline")
    dep_sha = _full_sha(record.get("sha") or dep.get("sha"), f"the sha of deployment {dep['id']}")
    if dep_sha != commit:
        raise ReleaseRefusal(f"deployment {dep['id']} deploys {dep_sha[:12]}, the release was exported from {commit[:12]}")
    status = str(record.get("status") or "")
    if status != DEPLOYMENT_STATE:
        raise ReleaseRefusal(f"deployment {dep['id']} of job {job_id} is {status!r}, not {DEPLOYMENT_STATE!r} -- only the job "
                             f"that is running its deployment may approve")
    summary = str(((record.get("approval_summary") or {}).get("status")) or "").lower()
    if summary != "approved":
        raise ReleaseRefusal(f"deployment {dep['id']} of job {job_id} is not approved (approval_summary "
                             f"{summary or 'missing'!r}) -- the protected environment must REQUIRE an approval and a "
                             f"deployer must have given it")
    approvers: list[dict] = []
    for a in record.get("approvals") or []:
        if str(a.get("status") or "").lower() != "approved":
            continue
        created = _when(a.get("created_at"), f"the created_at of an approval of deployment {dep['id']}")
        if created <= previewed:
            raise ReleaseRefusal(f"an approval of deployment {dep['id']} ({created.isoformat()}) predates the release's preview "
                                 f"({previewed.isoformat()}) -- an approval covers the diff it was given")
        u = _user(a.get("user"))
        if u["id"] is None:
            raise ReleaseRefusal(f"an approval of deployment {dep['id']} names no GitLab user id; four-eyes cannot be proven")
        role = forbidden.ids.get(u["id"])
        if role:
            raise ReleaseRefusal(f"the deployment was approved by {u['username']} (GitLab user {u['id']}), who is {role} -- "
                                 f"four-eyes: another deployer approves")
        approvers.append(dict(u, created_at=created.isoformat()))
    if not approvers:
        raise ReleaseRefusal(f"deployment {dep['id']} carries no approval with status approved")
    return {"verified_at": datetime.now(timezone.utc).isoformat(), "environment": cfg["environment"], "tag": str(tag),
            "commit": commit, "pipeline_id": str(pipeline_id), "job_id": str(job_id), "deployment_id": dep["id"],
            "deployment_status": status, "approvers": approvers,
            "bound": {"deployment_id": dep["id"], "pipeline_id": str(upload_pipeline_id), "sha": commit, "checksum": checksum,
                      "previewed_at": previewed.isoformat()},
            "merge_request": {"iid": mr.get("iid"), "author": author, "approvers": mr_approvers,
                              "commit_people": sorted(commit_people)},
            "pipeline_user": pipeline_user, "tag_pusher": pusher, "uploader": uploaded_by,
            "forbidden": {str(k): v for k, v in forbidden.ids.items()},
            "uat_authors": {k: list(v) for k, v in (uat_authors or {}).items()}, "lookups": reader.calls}


def make_reader(cfg: dict) -> GitLabReader:
    return GitLabReader(cfg["url"], cfg["project_id"], read_token(cfg), timeout=cfg["timeout_seconds"],
                        max_calls=cfg["max_calls"], deadline_seconds=cfg["deadline_seconds"])


def verify_release_upload(cfg: dict, *, pipeline: dict, pkg: dict, reader: GitLabReader | None = None) -> dict:
    reader = reader or make_reader(cfg)
    return verify_upload(reader, pipeline_id=(pipeline or {}).get("pipeline_id"), job_id=(pipeline or {}).get("job_id"),
                         source_commit=pkg.get("source_commit") or "", plan_job_name=cfg.get("plan_job_name") or "release:plan")


def verify_release_approval(cfg: dict, *, deployment: dict, release: dict, uat_authors: dict[str, list[str]],
                            reader: GitLabReader | None = None) -> dict:
    """The engine's entry: build the reader from the configured System Account
    (or take the injected one) and verify."""
    reader = reader or make_reader(cfg)
    return verify_deployment(reader, cfg, tag=deployment.get("tag"), commit=release.get("source_commit") or "",
                             pipeline_id=deployment.get("pipeline_id"), job_id=deployment.get("job_id"),
                             uat_authors=uat_authors, upload_pipeline_id=release.get("upload_pipeline_id"),
                             previewed_at=release.get("previewed_at"), uploaded_by=str(release.get("uploaded_by") or ""),
                             checksum=str(release.get("package_checksum") or ""))
