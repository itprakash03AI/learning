"""ONE resolver: which application roles a person holds (2026-11-10).

The owner: "it can be mixed up" -- a person may hold several roles at once,
from more than one source, and access adds up.  Every source is read here and
nowhere else:

  1. the explicit per-user setting ``auth.user_roles`` (``jsmith:<role>`` --
     a data role name is accepted, not only the five built-ins; never
     ``api_consumer`` or ``super_admin``);
  2. the legacy AD group settings ``auth.ad_admin_groups`` /
     ``ad_analyst_groups`` / ``ad_support_groups`` (2026-11-10, the gap) /
     ``ad_viewer_groups``;
  3. the ``app_role_sources`` rows an admin authored: an AD group by its FULL
     DN (never a bare CN -- a same-named group in another OU would match), a
     person by username, a directory claim value (``auth.ad_role_claim_attribute``
     -- a claim source counts only while that setting names an attribute).

The answer carries what a login stamps on the session:

* ``roles``   -- every ACTIVE role name held (sorted);
* ``role``    -- the BUILT-IN floor: the highest ``based_on`` among the roles
                 held (admin > analyst > support > viewer > scheduler), what
                 every existing check (``is_admin_like``, ``is_support``, the
                 per-object rules, ``ROLE_ACCESS``) reads unchanged.  A union
                 can only widen: a read-only role never narrows someone who
                 also holds an editing one;
* ``unknown`` -- names a source named that no active role carries, or whose
                 base is not one a data role may have (security review
                 2026-11-10: a role "based on admin" would be a full admin);
                 they used to fall to ``viewer`` in silence; now they are SAID.

A person who holds nothing is a ``viewer``, as before -- and told so.

Revocation reaches a LIVE session on the person's next request:
:func:`refresh_roles` re-resolves the stamped fields through a short cache
keyed by the coherence epoch every roles / sources / grants write bumps
(``core.tool_entitlement.engine.invalidate``).
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Tuple

logger = logging.getLogger(__name__)

#: the built-ins by what they may do; a role based on a higher one wins the floor
BUILTIN_RANK: Dict[str, int] = {
    "admin": 50, "analyst": 40, "support": 30, "viewer": 20, "scheduler": 10, "api_consumer": 5,
}
BUILTINS: Tuple[str, ...] = tuple(BUILTIN_RANK)
#: the bases a DATA role may have (security review 2026-11-10): never admin /
#: super_admin (the floor would make every holder a full admin whatever the
#: role's capabilities say) and never scheduler (a scope, not a level)
ALLOWED_BASES: Tuple[str, ...] = ("viewer", "support", "analyst")
DEFAULT_ROLE = "viewer"
#: never handed out by a setting
#: every built-in name, super_admin included (it is a floor, never a catalogue row)
_EVERY_BUILTIN = frozenset(BUILTINS) | {"super_admin"}


def never_by_setting(name: str) -> bool:
    """A built-in a SETTING (``auth.user_roles``) may never hand out: every
    built-in outside ``core.roles.assignable_roles()`` -- today api_consumer (API
    keys only) and super_admin (break-glass only).  ONE vocabulary, declared
    beside the role constants; the support role's base name and its configured
    name both stand for the same built-in."""
    from core.roles import assignable_roles
    n = str(name or "").strip().lower()
    if not n or n not in _EVERY_BUILTIN:
        return False
    return n not in (set(assignable_roles()) | {"support", support_name()})

#: the legacy AD settings and the built-in each hands out
_LEGACY_AD_SETTINGS: Tuple[Tuple[str, str], ...] = (
    ("ad_admin_groups", "admin"), ("ad_analyst_groups", "analyst"),
    ("ad_support_groups", "support"), ("ad_viewer_groups", "viewer"),
)
_SOURCE_WORDS = {"ad_group": "AD group", "user": "set on the person:", "claim": "directory claim",
                 "api_key": "API key"}


def support_name() -> str:
    """The configured name of the support role (``roles.support_role_name``) --
    a renamed support role still resolves and ``is_support`` still holds."""
    try:
        from core.roles import _support_role_name
        return _support_role_name()
    except Exception:                                                    # noqa: BLE001
        return "support"


@dataclass(frozen=True)
class RoleResolution:
    roles: Tuple[str, ...]
    role: str
    unknown: Tuple[str, ...]
    #: role name -> the sources that gave it, in words ("auth.user_roles", "AD group CN=...", ...)
    sources: Dict[str, List[str]] = field(default_factory=dict)
    #: where the catalogue of roles came from: "store" or "built-ins" (the store could not be read)
    catalogue: str = "store"
    #: name -> why it counted for nothing (not set up / a base a role may not have);
    #: ``role_store`` / ``role_sources`` when the store could not be read (the
    #: person is at the floor the settings give, and this is the TRUE reason)
    problems: Dict[str, str] = field(default_factory=dict)
    #: review 2 (M4): every built-in UNDER the roles held -- each held role's base,
    #: the floor, and the role the settings alone gave -- as ``role:<base>``
    #: principals for RESTRICTIVE row-security policies only (never a grant)
    bases: Tuple[str, ...] = ()

    def as_login_fields(self) -> Dict[str, Any]:
        """The fields a login dict / session carries."""
        return {"role": self.role, "roles": list(self.roles), "roles_unknown": list(self.unknown),
                "role_sources": {k: list(v) for k, v in self.sources.items()},
                "role_problems": dict(self.problems), "role_bases": list(self.bases)}


# ── the catalogue ───────────────────────────────────────────────────────────

STORE_UNREADABLE_WORDS = ("only the built-in role the settings give counts until it can be read; "
                          "nothing from the role store is trusted meanwhile")


def _catalogue(db: Any) -> Tuple[Dict[str, str], str, Dict[str, str], Optional[str]]:
    """(active role name -> its built-in base, where it came from, the refused
    rows: name -> why, the store problem or None).  The store when it can be
    read, else the built-ins alone WITH the true reason (review 2, M3: never
    "not set up" for a store that is down)."""
    base = {b: b for b in BUILTINS}
    sup = support_name()
    if sup != "support":
        base[sup] = "support"
    if db is not None and hasattr(db, "list_app_roles"):
        try:
            rows = db.list_app_roles(active_only=True)
        except Exception as exc:                                         # noqa: BLE001
            logger.error("app_roles: the role store could not be read (%s) -- the floor only", exc)
            return base, "built-ins", {}, f"the role store could not be read ({exc}) -- {STORE_UNREADABLE_WORDS}"
        refused: Dict[str, str] = {}
        cat = dict(base)
        for r in rows:
            name = str(r["name"]).lower()
            b = str(r.get("based_on") or name).lower()
            if r.get("is_builtin"):
                cat[name] = name
            elif name in _EVERY_BUILTIN or name == sup:
                # review 2 (P3): a row spelled like a built-in (a hand-edited package,
                # a direct insert) never overrides the built-in
                refused[name] = "a role named like a built-in counts for nothing; the built-in stands"
            elif b in ALLOWED_BASES:
                cat[name] = b
            else:
                refused[name] = (f"its base '{b}' is not one a role may have ({', '.join(ALLOWED_BASES)}); "
                                 f"the role counts for nothing until an admin fixes it")
        return cat, "store", refused, None
    return base, "built-ins", {}, None


#: pass as ``db`` to resolve against the SETTINGS alone, never the store (the no-auth
#: guest: no person, no directory -- a store read on every request would be waste)
NO_STORE = object()


def _db_or_none(db: Any) -> Any:
    if db is NO_STORE:
        return None
    if db is not None:
        return db
    try:
        from core.database import resolve_db_manager
        return resolve_db_manager(None, required=False)
    except Exception:                                                    # noqa: BLE001
        return None


# ── matching ────────────────────────────────────────────────────────────────

def _group_matcher(groups: Iterable[str], group_dns: Iterable[str]):
    """The legacy settings' matcher (core/ad_auth.py's rule): a setting written
    as a bare name matches a group's CN; one written as a full DN matches ONLY
    the person's full memberOf DN."""
    from core.config import normalize_dn
    names = {str(g).lower() for g in (groups or ()) if g}
    dns = {normalize_dn(str(d)) for d in (group_dns or ()) if d}

    def member_of(entry: str) -> bool:
        e = str(entry or "")
        if not e:
            return False
        if "=" in e:
            return normalize_dn(e) in dns
        return e.lower() in names

    def member_of_dn(entry: str) -> bool:
        """An authored source: the FULL DN only."""
        e = str(entry or "")
        return bool(e) and "=" in e and normalize_dn(e) in dns
    return member_of, member_of_dn


# ── the resolver ────────────────────────────────────────────────────────────

def resolve_app_roles(username: str, groups: Iterable[str] = (), group_dns: Iterable[str] = (),
                      claims: Iterable[str] = (), db: Any = None, *,
                      given: Optional[str] = None, api_key_id: Optional[int] = None) -> RoleResolution:
    """Every role ``username`` holds, from every source, as one answer.

    ``given`` (review 3): a built-in held BY CONSTRUCTION, not by a setting --
    the no-auth guest is ``admin``, an API key is ``api_consumer`` -- so the one
    builder (core/app_roles/principal.py) never writes a role field itself.
    ``api_key_id``: the key's sources (kind ``api_key``, value the key's id)
    count, and the floor stays ``api_consumer`` whatever roles the key holds
    (every ``role == "api_consumer"`` check keeps reading a key as a key)."""
    from core.config import auth as _auth
    db = _db_or_none(db)
    catalogue, where, refused, store_problem = _catalogue(db)
    uname = str(username or "").strip().lower()
    member_of, member_of_dn = _group_matcher(groups, group_dns)
    candidates: List[Tuple[str, str]] = []            # (role name as named, the source in words)
    problems: Dict[str, str] = {}
    if store_problem:
        problems["role_store"] = store_problem
    settings_base = ""                                # the built-in the settings alone give (review 2, M4)
    if given:
        g = str(given).strip().lower()
        if g == "super_admin" or g in catalogue:
            candidates.append((g, "held by construction (the guest / an API key)"))
            if g != "super_admin":
                settings_base = catalogue[g]
            if g == "super_admin":
                catalogue = dict(catalogue, super_admin="super_admin")

    # 1 + 2. the SETTINGS keep today's precedence (the day-one property: a person
    # whose roles come from the settings alone gets exactly what they got):
    # an explicit ``auth.user_roles`` entry naming an ACTIVE role wins over the
    # AD group settings; otherwise the highest AD group setting wins; an
    # explicit name no role carries is said (unknown) and the groups decide.
    explicit = str((getattr(_auth, "user_roles", None) or {}).get(uname) or "").lower()
    never: List[str] = []
    if never_by_setting(explicit):
        problems[explicit] = "never handed out by a setting"
        never.append(explicit)                                  # said, never held
        explicit = ""
    if explicit and explicit in catalogue:
        candidates.append((explicit, "auth.user_roles"))
        settings_base = catalogue[explicit]
    else:
        if explicit:
            candidates.append((explicit, "auth.user_roles"))      # -> unknown, said below
        for setting, builtin in _LEGACY_AD_SETTINGS:
            if any(member_of(entry) for entry in (getattr(_auth, setting, None) or [])):
                candidates.append((builtin, f"auth.{setting}"))
                settings_base = builtin
                break

    # 3. the authored sources
    claim_attr = str(getattr(_auth, "ad_role_claim_attribute", "") or "").strip()
    claim_values = {str(c).strip().lower() for c in (claims or ()) if str(c or "").strip()} if claim_attr else set()
    if db is not None and not store_problem and hasattr(db, "list_app_role_sources"):
        try:
            for src in db.list_app_role_sources(active_only=True):
                kind, value = str(src.get("source_kind") or ""), str(src.get("source_value") or "")
                hit = False
                if kind == "user":
                    hit = value.strip().lower() == uname and bool(uname)
                elif kind == "ad_group":
                    hit = member_of_dn(value)
                elif kind == "claim":
                    hit = bool(claim_attr) and value.strip().lower() in claim_values
                elif kind == "api_key":
                    hit = api_key_id is not None and value.strip() == str(api_key_id)
                if hit:
                    candidates.append((str(src["role_name"]).lower(), f"{_SOURCE_WORDS.get(kind, kind)} {value}"))
        except Exception as exc:                                         # noqa: BLE001
            # review 2 (M3): the floor only, and the TRUE reason recorded -- never a silent viewer
            logger.error("app_roles: the role sources could not be read (%s) -- the floor only", exc)
            problems["role_sources"] = f"the role sources could not be read ({exc}) -- {STORE_UNREADABLE_WORDS}"

    held: Dict[str, List[str]] = {}
    unknown: List[str] = list(never)
    for name, source in candidates:
        if name in catalogue:
            held.setdefault(name, []).append(source)
            continue
        if store_problem and name not in _EVERY_BUILTIN:
            # a data role the settings name while the store is down: NOT "unknown"
            # (that is the wrong reason) -- unchecked, said as such, not held
            problems.setdefault(name, "could not be checked -- the role store could not be read")
            continue
        if name not in unknown:
            unknown.append(name)
        problems.setdefault(name, refused.get(name, "not set up -- no active role of that name"))

    floor = DEFAULT_ROLE
    best = -1
    for name in held:
        b = catalogue.get(name, "")
        rank = BUILTIN_RANK.get(b, -1)
        if rank > best:
            best, floor = rank, b
    if not held:
        held[DEFAULT_ROLE] = ["nothing named a role -- the default"]
        floor = DEFAULT_ROLE
    if api_key_id is not None:
        floor = "api_consumer"                        # a key is a key, whatever it also holds
    if str(given or "").lower() == "super_admin":
        floor = "super_admin"                         # break-glass: the floor is the account itself
    # review 2 (M4): the built-ins UNDER what is held -- a restrictive policy bound
    # to any of them keeps applying (never a permissive one: that would widen)
    bases = {catalogue[n] for n in held if n in catalogue} | {floor, settings_base or DEFAULT_ROLE}
    if "support" in bases:
        bases.add(support_name())
    bases -= set(held)
    bases.discard("")
    if floor == "support":
        floor = support_name()
    return RoleResolution(roles=tuple(sorted(held)), role=floor, unknown=tuple(unknown),
                          sources=held, catalogue=where, problems=problems, bases=tuple(sorted(bases)))


def login_roles(username: str, groups: Iterable[str] = (), group_dns: Iterable[str] = (),
                claims: Iterable[str] = (), db: Any = None) -> Dict[str, Any]:
    """The fields a login stamps: ``role``, ``roles``, ``roles_unknown``, ``role_sources``, ``role_problems``."""
    return resolve_app_roles(username, groups, group_dns, claims, db).as_login_fields()


def resolve_fields_cached(username: str, groups: Iterable[str], group_dns: Iterable[str], claims: Iterable[str],
                          db: Any, *, given: Optional[str] = None, api_key_id: Optional[int] = None) -> Dict[str, Any]:
    """``login_roles`` through the per-request memo (review 3): the one builder
    calls this, so a consumer road that builds its principal on every request
    (a cached published-API call, the guest) reads the role store once per
    ``cache_resolver_seconds`` and per role write, not on every call.  A
    store-unreadable answer is never memoised."""
    key = (str(username or "").lower(), tuple(sorted(str(g) for g in (groups or ()))),
           tuple(sorted(str(d) for d in (group_dns or ()))), tuple(sorted(str(c) for c in (claims or ()))),
           str(given or ""), api_key_id, "nostore" if db is NO_STORE else "")
    now = time.monotonic()
    with _refresh_lock:
        hit = _refresh_memo.get(key)
        if hit and hit[3] == _local_epoch and hit[1] == _epoch() and now - hit[0] < _ttl():
            return dict(hit[2])
    fields = resolve_app_roles(username, groups, group_dns, claims, db, given=given, api_key_id=api_key_id).as_login_fields()
    if not any(k in fields.get("role_problems", {}) for k in ("role_store", "role_sources")):
        with _refresh_lock:
            if len(_refresh_memo) >= _REFRESH_MEMO_MAX:
                _refresh_memo.clear()
            _refresh_memo[key] = (now, _epoch(), fields, _local_epoch)
    return dict(fields)


def roles_of(user: Optional[dict]) -> List[str]:
    """Every role name a principal dict carries: its ``roles`` list, else its one
    ``role`` (an older session, a test fixture) -- lower-cased, no repeats."""
    user = user or {}
    out: List[str] = []
    held = user.get("roles")
    if isinstance(held, (list, tuple, set)):
        for r in held:
            s = str(r or "").strip().lower()
            if s and s not in out:
                out.append(s)
    r = str(user.get("role") or "").strip().lower()
    if not out and r:
        out.append(r)
    return out


# ── per-request refresh: revocation reaches a live session ──────────────────

_refresh_lock = threading.RLock()
#: key -> (monotonic, epoch, fields)
_refresh_memo: Dict[Tuple, Tuple[float, Any, Dict[str, Any]]] = {}
_REFRESH_MEMO_MAX = 5000


def _epoch() -> Any:
    """The coherence epoch of role decisions as THIS pod last observed it --
    DB-free (review 4, M2): a memo on the event loop compares against it.
    ``_epoch_fresh`` (off the loop: the auth lane, the engine) re-reads it at
    most once per ``cache.coherence_poll_seconds``; so a revocation on another
    pod is seen here within one poll after any off-loop reader on this pod, and
    at the TTL (``cache_resolver_seconds``) at the latest."""
    try:
        from core.cache_coherence import get_bus
        return get_bus().cached_token("tool_entitlement")
    except Exception:                                                    # noqa: BLE001
        return None


def _epoch_fresh() -> Any:
    """``_epoch`` after the throttled DB read (off the event loop only)."""
    try:
        from core.cache_coherence import get_bus
        return get_bus().current_token("tool_entitlement")
    except Exception:                                                    # noqa: BLE001
        return None


def _ttl() -> float:
    try:
        from core.config import row_security as _rs
        return float(max(0, int(_rs.cache_resolver_seconds)))
    except Exception:                                                    # noqa: BLE001
        return 30.0


def refreshable(user: Optional[dict]) -> bool:
    """Only a PERSON whose login stamped ``roles`` is re-resolved: never a share /
    embed token, an API key, the no-auth guest, super_admin, or an older session
    the new code never stamped (it keeps exactly what it had)."""
    if not isinstance(user, dict) or not user.get("username"):
        return False
    if not isinstance(user.get("roles"), list):
        return False
    if user.get("auth_via") in ("share_token", "embed_token") or user.get("api_key_id") is not None:
        return False
    if str(user.get("role") or "").lower() == "super_admin" or user.get("acting_as"):
        return False
    return True


def _memo_key(user: dict) -> Tuple:
    return (str(user.get("username") or "").lower(),
            tuple(sorted(str(g) for g in (user.get("groups") or ()))),
            tuple(sorted(str(d) for d in (user.get("group_dns") or ()))),
            tuple(sorted(str(c) for c in (user.get("role_claims") or ()))))


def _with_fields(user: dict, fields: Dict[str, Any]) -> dict:
    out = dict(user)
    out.update(fields)
    if "is_admin" in user:
        from core.roles import ADMIN_TIER_ROLES
        out["is_admin"] = fields["role"] in ADMIN_TIER_ROLES
    return out


def refresh_roles_cached(user: Optional[dict], *, memory_only: bool = False) -> Optional[dict]:
    """The refreshed dict when the memo answers, None when it cannot; the dict
    itself when it is not refreshable.  The entry answers while the TTL holds,
    this pod's local epoch matches (a write HERE drops it at once) and the BUS
    epoch as this pod last observed it matches (review 4: ``_epoch`` is DB-free
    -- ``memory_only`` is honoured by construction -- and the observation is
    refreshed by every off-loop reader, ``refresh_roles`` among them, at most
    once per coherence poll).  So a write on ANOTHER pod is refused here within
    one poll after any off-loop reader, and at the TTL at the latest."""
    if not refreshable(user):
        return user
    key = _memo_key(user)
    now = time.monotonic()
    with _refresh_lock:
        hit = _refresh_memo.get(key)
        if hit and now - hit[0] < _ttl() and hit[3] == _local_epoch and hit[1] == _epoch():
            return _with_fields(user, hit[2])
    return None


def refresh_roles(user: Optional[dict], db: Any = None) -> Optional[dict]:
    """The dict with its role fields re-resolved (a NEW dict; the session's own
    is never mutated), memoised per (person, groups, claims, epoch) for
    ``row_security.cache_resolver_seconds``."""
    _epoch_fresh()                        # off the loop: refresh this pod's view of the bus epoch
    cached = refresh_roles_cached(user)
    if cached is not None:
        return cached
    assert isinstance(user, dict)
    fields = login_roles(user.get("username") or "", user.get("groups") or (), user.get("group_dns") or (),
                         user.get("role_claims") or (), db)
    key = _memo_key(user)
    unreadable = any(k in fields.get("role_problems", {}) for k in ("role_store", "role_sources"))
    if not unreadable:                    # a floor-only answer for a store that is down is never memoised
        with _refresh_lock:
            if len(_refresh_memo) >= _REFRESH_MEMO_MAX:
                _refresh_memo.clear()
            _refresh_memo[key] = (time.monotonic(), _epoch(), fields, _local_epoch)
    if fields["roles"] != list(user.get("roles") or []) or fields["role"] != user.get("role"):
        logger.info("roles: %s now holds %s (floor %s) -- was %s (%s)", user.get("username"),
                    fields["roles"], fields["role"], user.get("roles"), user.get("role"))
    return _with_fields(user, fields)


_local_epoch = 0


def local_epoch() -> int:
    """A counter this process bumps on every role write (``forget_refreshed``):
    with the bus epoch it keys every memo of a role decision, so a memo drops
    at once here even where no coherence bus answers (review 3, H2)."""
    return _local_epoch


def forget_refreshed() -> None:
    """Drop the per-request memo AT ONCE in this process: every write in
    ``core.app_roles.service`` calls it beside the epoch bump (the bump is what
    reaches the other pods); tests call it between stores."""
    global _local_epoch
    with _refresh_lock:
        _refresh_memo.clear()
        _local_epoch += 1
