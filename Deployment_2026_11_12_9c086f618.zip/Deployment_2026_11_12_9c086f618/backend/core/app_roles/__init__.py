"""Application roles as data (2026-11-10, docs/ENTITLEMENT_APP_ROLES_PLAN_2026_11_10.html).

* ``resolve.py`` -- ONE resolver: every role a person holds, from every
  source at once, and the built-in floor every existing check reads.
* ``service.py`` -- the rules of authoring: create a role from a built-in
  (its bundle copied), what it may do, who gets it, switch off, the names a
  report may be assigned.
"""
from core.app_roles.resolve import (  # noqa: F401
    BUILTIN_RANK, RoleResolution, login_roles, resolve_app_roles, roles_of,
)
