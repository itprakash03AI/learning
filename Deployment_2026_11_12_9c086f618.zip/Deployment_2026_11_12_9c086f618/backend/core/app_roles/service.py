"""The rules of authoring an application role (2026-11-10).

A role is a bundle of capabilities with a name, based on a built-in LEVEL --
viewer, support or analyst, never admin (security review 2026-11-10: the base
is the floor every check reads, so a role "based on admin" would be a full
admin whatever its capabilities say).  Creating one COPIES the built-in's
capability rows (``tool_capability_grants``, ``principal_type = role``) so a
holder of a role based on viewer starts with exactly what a viewer has; an
admin then adds or takes back capabilities on the role itself, and a change to
``viewer`` later never reaches it.  Roles are DATA with any name an admin gives
them -- nothing here names one (the owner, 2026-11-10: "we need generic roles,
not defined hardly").

NO SELF-ESCALATION (security review 2026-11-10): an actor may hand out only
what they hold themselves -- a base whose bundle they hold, capabilities they
hold, never a source naming themselves (super_admin excepted);
``entitlement.manage`` and ``admin.users`` are handed out by super_admin only.

Every write drops the decision memo (``core.tool_entitlement.engine.invalidate``),
whose coherence bump is also what makes a live session re-resolve its roles on
its next request (``core.app_roles.resolve.refresh_roles``), and drops this
process's role memo at once (``resolve.forget_refreshed``) -- see ``_changed``.
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from core.app_roles import resolve as _rs
from core.app_roles.resolve import ALLOWED_BASES, BUILTINS
from core.tool_entitlement import engine as _te
from core.tool_entitlement.vocabulary import CAPABILITIES, bundle

logger = logging.getLogger(__name__)

NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,59}$")
SOURCE_KINDS = ("ad_group", "user", "claim", "api_key")
#: handed out by super_admin only -- whoever holds them can hand out everything else
PROTECTED_CAPABILITIES = ("entitlement.manage", "admin.users")


class RoleRefused(ValueError):
    """A rule of this module, in plain words (the route answers its status)."""

    def __init__(self, message: str, status: int = 422):
        super().__init__(message)
        self.status = status


def normalize_name(name: str) -> str:
    return str(name or "").strip().lower()


def check_name(name: str) -> str:
    n = normalize_name(name)
    if not NAME_RE.match(n):
        raise RoleRefused("A role name is 2 to 60 characters: lower-case letters, digits and underscores, "
                          "starting with a letter.")
    if n == "super_admin":
        raise RoleRefused("super_admin is the break-glass account, not a role you can set up.")
    if n in BUILTINS or n == _rs.support_name():
        raise RoleRefused(f"'{n}' is a built-in role's name (whatever the spelling); pick another.")
    return n


def check_based_on(based_on: str) -> str:
    b = normalize_name(based_on)
    if b not in ALLOWED_BASES:
        raise RoleRefused(f"A role is based on one of: {', '.join(ALLOWED_BASES)}. "
                          f"It can never be based on admin: the base is what every screen treats its "
                          f"holders as, so that would make them full admins whatever the role says.")
    return b


# ── the actor's reach ───────────────────────────────────────────────────────

def is_super(actor: Optional[dict]) -> bool:
    return bool(actor) and str(actor.get("role") or "").lower() == "super_admin"


def actor_capabilities(actor: Optional[dict]) -> Set[str]:
    if is_super(actor):
        return set(CAPABILITIES)
    if not actor:
        return set()
    return set(_te.capabilities_of(actor))


def check_actor_may_grant(actor: Optional[dict], capabilities: Iterable[str]) -> None:
    """An actor hands out only what they hold; the protected two, super_admin only."""
    caps = {str(c) for c in capabilities}
    if is_super(actor):
        return
    protected = sorted(c for c in caps if c in PROTECTED_CAPABILITIES)
    if protected:
        raise RoleRefused(f"Only a super admin can hand out {', '.join(protected)}.", status=403)
    missing = sorted(caps - actor_capabilities(actor))
    if missing:
        raise RoleRefused("You can only hand out permissions you hold yourself. Not yours: "
                          + ", ".join(missing), status=403)


def check_actor_may_hand_out(db: Any, actor: Optional[dict], role_name: str, *,
                             target_username: Optional[str] = None) -> None:
    """THE ONE RULE for handing a ROLE to someone -- a built-in or a data role,
    through an authored source (``add_source``), a user's role setting
    (``admin_api._require_known_role``) or a switched-off source coming back
    (``check_source_switch_on``): the actor must hold every permission the role
    carries (``check_actor_may_grant``: a role carrying entitlement.manage /
    admin.users -- admin, super_admin -- is handed out by a super_admin only),
    and never to themselves.  ``actor`` None = an internal caller (seeding)."""
    if actor is None:
        return
    if target_username and str(target_username).lower() == str(actor.get("username") or "").lower() \
            and not is_super(actor):
        raise RoleRefused("You cannot change your own role. Ask another admin.", status=403)
    name = str(role_name or "").strip().lower()
    caps = set(role_capabilities(db, name)) if db is not None else set()
    if not caps:
        caps = set(bundle(name))                     # a built-in with no rows yet (seed pending)
    check_actor_may_grant(actor, caps)


def check_not_self_principal(db: Any, actor: Optional[dict], principal_type: str, principal_id: str) -> None:
    """A permission row an actor could hand to THEMSELVES is refused unless they
    are super_admin: their user, a group they are in, a role they hold, their
    own API key -- every principal the entitlement engine says they are."""
    if actor is None or is_super(actor):
        return
    mine = {(str(t), str(i).lower()) for t, i in _te.principals_of(actor, db)}
    if (str(principal_type).lower(), str(principal_id).lower()) in mine:
        raise RoleRefused("You cannot give a permission to yourself -- not to your user, a group you are in, "
                          "a role you hold or your own API key. Ask another admin.", status=403)


def check_actor_may_base(actor: Optional[dict], based_on: str) -> None:
    check_actor_may_grant(actor, bundle(based_on))


# ── create / change / switch off ────────────────────────────────────────────

def changed() -> None:
    """After EVERY write: the decision memo and its coherence bump (every pod),
    and this process's per-request role memo at once."""
    _te.invalidate()
    _rs.forget_refreshed()


_changed = changed


def create_role(db: Any, *, name: str, label: str, description: Optional[str], based_on: str,
                by_user: Optional[str], actor: Optional[dict] = None) -> Dict[str, Any]:
    n = check_name(name)
    b = check_based_on(based_on)
    if actor is not None:
        check_actor_may_base(actor, b)
    lbl = str(label or "").strip() or n.replace("_", " ").title()
    if db.get_app_role(n, active_only=True):
        raise RoleRefused(f"A role named '{n}' already exists.", status=409)
    row = db.create_app_role(name=n, label=lbl, description=description, based_on=b, by_user=by_user)
    copied = copy_bundle(db, n, b, by_user=by_user)
    _changed()
    logger.info("app_roles: role %r created on %r by %s (%d capabilities copied)", n, b, by_user, copied)
    row["capabilities"] = sorted(role_capabilities(db, n))
    return row


def copy_bundle(db: Any, name: str, based_on: str, *, by_user: Optional[str]) -> int:
    """The base bundle's ACTIVE capability rows copied onto ``name`` (rows that
    exist, on or off, are left as they are -- a re-run never undoes an admin)."""
    have = {r["capability"] for r in db.list_tool_capability_grants(active_only=False, principal_type="role",
                                                                     principal_id=name)}
    added = 0
    for r in db.list_tool_capability_grants(active_only=True, principal_type="role", principal_id=based_on):
        cap = r["capability"]
        if cap in have or cap not in CAPABILITIES:
            continue
        db.add_tool_capability_grant(cap, "role", name, by_user=by_user, source="seed",
                                     note=f"copied from {based_on}")
        added += 1
    return added


def role_capabilities(db: Any, name: str) -> List[str]:
    return sorted({r["capability"] for r in db.list_tool_capability_grants(
        active_only=True, principal_type="role", principal_id=name) if r["capability"] in CAPABILITIES})


def set_role_capabilities(db: Any, name: str, wanted: Iterable[str], *, by_user: Optional[str],
                          actor: Optional[dict] = None) -> Dict[str, Any]:
    """The WHOLE list for a role: names added, the rest switched off.  An unknown
    name refuses the whole change by name; the ADDED ones must be the actor's own."""
    want = {str(c).strip() for c in (wanted or ()) if str(c or "").strip()}
    unknown = sorted(c for c in want if c not in CAPABILITIES)
    if unknown:
        raise RoleRefused(f"These are not permissions QueryStudio knows: {', '.join(unknown)}.")
    rows = db.list_tool_capability_grants(active_only=True, principal_type="role", principal_id=name)
    have = {r["capability"]: r for r in rows}
    to_add = sorted(want - set(have))
    if actor is not None:
        check_actor_may_grant(actor, to_add)
    added, removed = [], []
    for cap in to_add:
        db.add_tool_capability_grant(cap, "role", name, by_user=by_user, source="manual")
        added.append(cap)
    for cap, r in sorted(have.items()):
        if cap not in want:
            db.switch_off_tool_capability_grant(int(r["id"]), by_user=by_user)
            removed.append(cap)
    _changed()
    return {"role": name, "added": added, "removed": removed, "capabilities": sorted(want)}


def in_use_problems(session: Any, name: str) -> List[str]:
    """What still names ``name`` (a switch-off refuses while any): the reports
    assigned to it, its active sources, the report grants.  On a SESSION, so the
    release apply (which holds one) and the routes share the rule."""
    from core.config_active import active_clause
    from core.db.models import AppRoleSource, BusinessReport, BusinessReportGrant
    problems = []
    reports = [rname for rid, rname, wl in session.query(BusinessReport.id, BusinessReport.name,
                                                         BusinessReport.role_whitelist)
               .filter(active_clause(BusinessReport)).all()
               if isinstance(wl, list) and any(str(x).lower() == name for x in wl)]
    if reports:
        problems.append(f"{len(reports)} report(s) are assigned to it: " + ", ".join(reports[:5])
                        + (" ..." if len(reports) > 5 else ""))
    sources = session.query(AppRoleSource).filter(AppRoleSource.role_name == name,
                                                   active_clause(AppRoleSource)).count()
    if sources:
        problems.append(f"{sources} source(s) still give it out (AD groups, people or claims)")
    grants = session.query(BusinessReportGrant).filter(BusinessReportGrant.role_name == name).count()
    if grants:
        problems.append(f"{grants} report grant(s) name it")
    return problems


def switch_off_role(db: Any, name: str, *, by_user: Optional[str]) -> Dict[str, Any]:
    """Switch a role off AND its capability rows (never deleted).  Refused while
    something still names it -- the refusal names them."""
    role = db.get_app_role(name, active_only=True)
    if role is None:
        raise RoleRefused(f"There is no role named '{name}'.", status=404)
    if role.get("is_builtin"):
        raise RoleRefused(f"'{name}' is a built-in role and stays.")
    with db.get_session(read_only=True) as session:
        problems = in_use_problems(session, name)
    if problems:
        raise RoleRefused(f"'{name}' is still in use -- " + "; ".join(problems)
                          + ". Take it off those first.", status=409)
    import uuid
    event = uuid.uuid4().hex                                 # ONE event: the role and its rows (review 3)
    ok = db.switch_off_app_role(name, by_user=by_user, event=event)
    grants_off = 0
    for r in db.list_tool_capability_grants(active_only=True, principal_type="role", principal_id=name):
        db.switch_off_tool_capability_grant(int(r["id"]), by_user=by_user, event=event)
        grants_off += 1
    _changed()
    return {"ok": bool(ok), "name": name, "permissions_switched_off": grants_off}


# ── who gets it ─────────────────────────────────────────────────────────────

def claim_attribute() -> str:
    try:
        from core.config import auth as _auth
        return str(getattr(_auth, "ad_role_claim_attribute", "") or "").strip()
    except Exception:                                                    # noqa: BLE001
        return ""


def _names_the_actor(kind: str, value: str, actor: Optional[dict]) -> bool:
    if not actor:
        return False
    if kind == "user":
        return value.lower() == str(actor.get("username") or "").lower()
    if kind == "api_key":
        return actor.get("api_key_id") is not None and str(actor.get("api_key_id")) == str(value).strip()
    if kind == "ad_group":
        from core.config import normalize_dn
        if "group_dns" not in actor:                 # an older session: it cannot tell -> refuse
            raise RoleRefused("Your sign-in does not carry your group list, so it cannot be checked that this "
                              "group is not one of yours. Sign in again and retry.", status=403)
        mine = {normalize_dn(str(d)) for d in (actor.get("group_dns") or ()) if d}
        return normalize_dn(value) in mine
    if kind == "claim":
        if "role_claims" not in actor:
            raise RoleRefused("Your sign-in does not carry your directory claims, so it cannot be checked that "
                              "this claim is not one of yours. Sign in again and retry.", status=403)
        return value.lower() in {str(c).lower() for c in (actor.get("role_claims") or ())}
    return False


def add_source(db: Any, name: str, kind: str, value: str, *, by_user: Optional[str],
               note: Optional[str] = None, actor: Optional[dict] = None) -> Dict[str, Any]:
    role = db.get_app_role(name, active_only=True)
    if role is None:
        raise RoleRefused(f"There is no role named '{name}'.", status=404)
    k = str(kind or "").strip().lower()
    if k not in SOURCE_KINDS:
        raise RoleRefused("A source is one of: ad_group (an AD group's full DN), user (a username), "
                          "claim (a directory claim value), api_key (an API key's id).")
    v = str(value or "").strip()
    if not v:
        raise RoleRefused("Say which group, person or claim value gets the role.")
    if k == "ad_group" and "=" not in v:
        raise RoleRefused("An AD group is its FULL DN (CN=...,OU=...,DC=...), never a bare name: a bare name "
                          "would match a same-named group in any OU.")
    if k == "claim" and not claim_attribute():
        raise RoleRefused("A claim counts only while auth.ad_role_claim_attribute names the directory "
                          "attribute to read -- set it first (an attribute people cannot edit themselves).")
    if k == "user":
        v = v.lower()
    if k == "api_key":
        if not v.isdigit() or not (hasattr(db, "get_api_key") and db.get_api_key(int(v))):
            raise RoleRefused("An API key source is the key's id (a number) of a key that exists.")
    if name == "api_consumer" and k != "api_key":
        # review 4 (M1): api_consumer is the KEYS' role -- a person, a group or a claim
        # never holds it (it would read every published API as a key does)
        raise RoleRefused("api_consumer is the role of API keys only. A person, a group or a claim cannot hold it; "
                          "give the key its own role through an API-key source instead.")
    if actor is not None and not is_super(actor) and _names_the_actor(k, v, actor):
        raise RoleRefused("You cannot give a role to yourself. Ask another admin.", status=403)
    check_actor_may_hand_out(db, actor, name)        # built-ins included (review 2, H1)
    row = db.add_app_role_source(role_name=name, source_kind=k, source_value=v, by_user=by_user, note=note)
    _changed()
    return row


def remove_source(db: Any, source_id: int, *, by_user: Optional[str]) -> bool:
    ok = db.switch_off_app_role_source(source_id, by_user=by_user)
    _changed()
    return ok


# ── what names a role ───────────────────────────────────────────────────────

def validate_role_names(db: Any, names: Iterable[str]) -> Tuple[List[str], List[str]]:
    """(the active names, the unknown ones) -- lower-cased, no repeats, order kept."""
    active = set(db.active_app_role_names())
    ok: List[str] = []
    unknown: List[str] = []
    for raw in (names or ()):
        n = normalize_name(raw)
        if not n or n in ok or n in unknown:
            continue
        (ok if n in active else unknown).append(n)
    return ok, unknown


def assigned_reports(db: Any, name: str) -> List[Dict[str, Any]]:
    """The ACTIVE reports whose role list names ``name`` (id, name, is_published)."""
    from core.config_active import active_clause
    from core.db.models import BusinessReport
    out: List[Dict[str, Any]] = []
    with db.get_session(read_only=True) as session:
        rows = (session.query(BusinessReport.id, BusinessReport.name, BusinessReport.is_published,
                              BusinessReport.role_whitelist)
                .filter(active_clause(BusinessReport)).all())
        for rid, rname, pub, wl in rows:
            if isinstance(wl, list) and any(str(x).lower() == name for x in wl):
                out.append({"id": rid, "name": rname, "is_published": bool(pub)})
    return out


# ── the admin screen's one answer ───────────────────────────────────────────

# ── the generic Switched Off page (api/config_active_api) -- review 2, H2 ──────
def grants_switched_off_with(db: Any, role_name: str) -> List[Dict[str, Any]]:
    """The capability rows ``switch_off_role`` switched off TOGETHER with the role:
    off, naming the role, and recorded (``config_switch_offs``) under the SAME
    EVENT ID as the role's own last switch-off (review 3, LOW: never a time
    window, never two unknown actors matching).  A role switched off without
    an event (an older pod, a direct store call) brings nothing back -- said."""
    from core.db.models import AppRole, ConfigSwitchOff, ToolCapabilityGrant
    name = str(role_name or "").strip().lower()
    with db.get_session(read_only=True) as session:
        role = session.query(AppRole).filter(AppRole.name == name).first()
        if role is None:
            return []
        last = (session.query(ConfigSwitchOff)
                .filter(ConfigSwitchOff.table_name == "app_roles", ConfigSwitchOff.row_id == role.id)
                .order_by(ConfigSwitchOff.id.desc()).first())
        if last is None or not last.event:
            return []
        ids = {int(r.row_id) for r in session.query(ConfigSwitchOff)
               .filter(ConfigSwitchOff.table_name == "tool_capability_grants", ConfigSwitchOff.event == last.event).all()}
        if not ids:
            return []
        return [g.to_dict() for g in (session.query(ToolCapabilityGrant)
                                      .filter(ToolCapabilityGrant.id.in_(ids),
                                              ToolCapabilityGrant.principal_type == "role",
                                              ToolCapabilityGrant.principal_id == name,
                                              ToolCapabilityGrant.is_active.is_(False)).all())]


def restore_grants_switched_off_with(db: Any, role_name: str, *, by_user: Optional[str]) -> int:
    """Bring back ONLY the rows ``grants_switched_off_with`` names (the role is
    back on; what went off with it comes back with it, nothing else)."""
    from datetime import datetime, timezone
    from core.db.models import ToolCapabilityGrant
    ids = [int(g["id"]) for g in grants_switched_off_with(db, role_name)]
    if not ids:
        return 0
    with db.get_session() as session:
        for row in session.query(ToolCapabilityGrant).filter(ToolCapabilityGrant.id.in_(ids)).all():
            row.is_active = True
            row.updated_by = by_user
            row.updated_at = datetime.now(timezone.utc)
        session.flush()
    changed()
    return len(ids)


def check_grant_switch_on(db: Any, actor: Optional[dict], row: Dict[str, Any]) -> None:
    """A permission row coming back = the same grant made again: the actor must
    hold it, never for themselves; a row naming a switched-off role waits for the role."""
    cap = str(row.get("capability") or "")
    check_actor_may_grant(actor, [cap])
    ptype, pid = str(row.get("principal_type") or "").lower(), str(row.get("principal_id") or "")
    check_not_self_principal(db, actor, ptype, pid)
    if ptype == "role" and db.get_app_role(pid.lower(), active_only=True) is None:
        raise RoleRefused(f"The role '{pid}' is switched off. Switch the role on first; its permissions "
                          f"come back with it.", status=409)


def check_role_switch_on(db: Any, actor: Optional[dict], row: Dict[str, Any]) -> None:
    """A role coming back brings back the permissions switched off WITH it: the
    actor must hold every one of them (a role carrying entitlement.manage /
    admin.users comes back by a super_admin only); the row obeys the name and
    base rules a new role does."""
    name = str(row.get("name") or "")
    if not row.get("is_builtin"):
        check_name(name)
        check_based_on(str(row.get("based_on") or ""))
    caps = {str(g["capability"]) for g in grants_switched_off_with(db, name)}
    check_actor_may_grant(actor, caps)


def check_source_switch_on(db: Any, actor: Optional[dict], row: Dict[str, Any]) -> None:
    """A source coming back = the role handed out again: the same rule as add_source."""
    name = str(row.get("role_name") or "").lower()
    if db.get_app_role(name, active_only=True) is None:
        raise RoleRefused(f"The role '{name}' is switched off. Switch the role on first.", status=409)
    kind, value = str(row.get("source_kind") or ""), str(row.get("source_value") or "")
    if actor is not None and not is_super(actor) and _names_the_actor(kind, value, actor):
        raise RoleRefused("You cannot give a role to yourself. Ask another admin.", status=403)
    check_actor_may_hand_out(db, actor, name)


def describe_roles(db: Any) -> Dict[str, Any]:
    roles = db.list_app_roles(active_only=True)
    sources = db.list_app_role_sources(active_only=True)
    by_role: Dict[str, List[Dict[str, Any]]] = {}
    for s in sources:
        by_role.setdefault(s["role_name"], []).append(s)
    caps = db.list_tool_capability_grants(active_only=True, principal_type="role")
    caps_by_role: Dict[str, List[str]] = {}
    for r in caps:
        if r["capability"] in CAPABILITIES:
            caps_by_role.setdefault(r["principal_id"], []).append(r["capability"])
    explicit = _explicit_people()
    out = []
    problems: List[Dict[str, str]] = []
    from core.db import mixin_app_roles as _m
    if _m.RESTAMP_PROBLEM:
        problems.append({"role_name": "(upgrade)", "problem": _m.RESTAMP_PROBLEM})
    for role in roles:
        n = role["name"]
        people = sorted(u for u, r in explicit.items() if r == n)
        bad = (not role.get("is_builtin")) and str(role.get("based_on") or "") not in ALLOWED_BASES
        if (not role.get("is_builtin")) and (str(n).lower() in BUILTINS or str(n).lower() == _rs.support_name()):
            bad = True                       # review 2 (P3): a stray row spelled like a built-in
            problems.append({"role_name": str(n).lower(), "problem": f"'{n}' is spelled like a built-in role: it counts "
                                                                      f"for nothing (the built-in stands); switch it off"})
        elif bad:
            problems.append({"role_name": n, "problem": f"based on '{role.get('based_on')}' -- a role may be based on "
                                                        f"{', '.join(ALLOWED_BASES)} only; it counts for nothing "
                                                        f"until fixed (switch it off and add it again)"})
        out.append({**role, "base_allowed": not bad,
                    "capabilities": sorted(set(caps_by_role.get(n, []))),
                    "sources": by_role.get(n, []),
                    "people_in_settings": people,
                    "reports": assigned_reports(db, n)})
    try:
        unknown = db.list_unknown_role_sightings()
    except Exception as exc:                                             # noqa: BLE001
        unknown = []
        logger.warning("app_roles: unknown-role sightings could not be read: %s", exc)
    return {"roles": out, "built_ins": list(BUILTINS), "allowed_bases": list(ALLOWED_BASES),
            "protected_capabilities": list(PROTECTED_CAPABILITIES),
            "claim_attribute": claim_attribute(), "problems": problems, "unknown_seen": unknown,
            "capabilities": [{"name": c.name, "label": c.label, "description": c.description, "area": c.area}
                             for c in CAPABILITIES.values()]}


def _explicit_people() -> Dict[str, str]:
    """``auth.user_roles`` as {username: role} -- the legacy per-person setting, shown beside the sources."""
    try:
        from core.config import auth as _auth
        return {str(u): str(r).lower() for u, r in (_auth.user_roles or {}).items()}
    except Exception:                                                    # noqa: BLE001
        return {}
