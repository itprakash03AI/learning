"""THE ONE builder of "who is acting" (third security review, 2026-11-10).

A principal dict used to be built in several places -- the interactive login,
the no-auth guest, the API-key consumer, the Basic / session consumer of a
published API, the headless schedule / burst / subscription / delivery scope
-- and only the interactive one carried the application roles.  A role
holder's schedule was then refused at every fire, a restrictive policy bound
to their role never reached the scheduled file, an existing API key lost
every report published to a role, and the API Explorer broke for role users.

``acting_principal`` is the one construction.  Every road calls it; it always
resolves through ``core.app_roles.resolve`` (the settings, the authored
sources, the key's own sources) and carries ``roles`` + ``role_bases`` +
``groups`` + ``group_dns`` + ``role_claims``.  A guard
(``tests/test_app_roles_security_review3_2026_11_10.py``) fails when a dict
with ``username`` + ``role`` is built anywhere else in ``api/`` or ``core/``.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Iterable, Optional

logger = logging.getLogger(__name__)

#: the auth_method words a principal carries (``auth_method``)
INTERACTIVE = "interactive"      # a signed-in person (AD / local)
SESSION = "session"              # the person's session token on a consumer road
API_KEY = "api_key"              # an API key
HEADLESS = "headless"            # a schedule, burst, subscription, delivery, instance refresh
GUEST = "none"                   # auth.type = none: the guest admin
SYSTEM = "system"                # a release apply, a daemon


def acting_principal(username: str = "", *, groups: Iterable[str] = (), group_dns: Iterable[str] = (),
                     claims: Iterable[str] = (), db: Any = None, auth_method: str = INTERACTIVE,
                     given: Optional[str] = None, api_key: Optional[dict] = None,
                     display_name: Optional[str] = None, email: str = "",
                     **extra: Any) -> Dict[str, Any]:
    """The dict every check reads: ``username``, ``display_name``, ``email``,
    ``groups``, ``group_dns``, ``role_claims``, ``auth_method``, ``is_admin``,
    and the role fields of ``RoleResolution.as_login_fields`` (``role`` the
    built-in floor, ``roles`` every application role held, ``roles_unknown``,
    ``role_sources``, ``role_problems``, ``role_bases``).

    ``given`` -- a built-in this principal holds BY CONSTRUCTION, not by a
    setting (the no-auth guest is ``admin``; an API key is ``api_consumer``).
    ``api_key`` -- the key row: the username is ``apikey:<prefix>``, its floor
    stays ``api_consumer``, its roles come from the sources of kind ``api_key``
    naming the key's id (plus ``api_consumer``); ``api_key_id``,
    ``scoped_view_ids``, ``rate_limit`` ride along.
    ``extra`` -- road-specific fields (``rls_unresolved``, ``acting_as``,
    ``ad_groups``, ...) copied as given.
    """
    from core.app_roles.resolve import NO_STORE, resolve_fields_cached
    from core.roles import ADMIN_TIER_ROLES
    api_key_id: Optional[int] = None
    if api_key is not None:
        username = f"apikey:{api_key.get('key_prefix', 'unknown')}"
        api_key_id = int(api_key["id"])
        given = "api_consumer"
        auth_method = API_KEY
        display_name = display_name or api_key.get("name", "API Consumer")
    groups_l = [str(g) for g in (groups or ()) if str(g or "").strip()]
    dns_l = [str(d) for d in (group_dns or ()) if str(d or "").strip()]
    claims_l = [str(c) for c in (claims or ()) if str(c or "").strip()]
    if auth_method == GUEST and db is None:
        db = NO_STORE                        # no person, no directory: the settings alone, no store read
    fields = resolve_fields_cached(username, groups_l, dns_l, claims_l, db, given=given, api_key_id=api_key_id)
    if fields.get("roles_unknown"):
        logger.warning("roles: %s was given role name(s) that are not set up: %s -- "
                       "they count for nothing until an admin adds them (Admin > Roles and permissions)",
                       username, ", ".join(fields["roles_unknown"]))
    out: Dict[str, Any] = {
        "username": username,
        "display_name": display_name or username,
        "email": email or "",
        "groups": groups_l,
        "group_dns": dns_l,
        "role_claims": claims_l,
        "auth_method": auth_method,
        **fields,
        "is_admin": fields["role"] in ADMIN_TIER_ROLES,
    }
    if auth_method == HEADLESS:
        # named fields only (core/scheduler.py, 2026-08): a headless principal carries
        # ``display_name`` / ``email`` only when the directory GAVE them, so ``${user.email}``
        # never renders an empty string the directory did not say
        if not email:
            out.pop("email", None)
        if not display_name:
            out.pop("display_name", None)
    if api_key is not None:
        out.update({"api_key_id": api_key_id,
                    "scoped_view_ids": api_key.get("scoped_view_ids") or [],
                    "rate_limit": api_key.get("rate_limit")})
    out.update(extra)
    return out


def native_store_principal(username: str, *, groups: Iterable[str] = ()) -> Dict[str, Any]:
    """A NON-AD deployment's headless scope for a person the login store does not
    list: the native group store is the only identity there, and master pinned
    the floor to viewer (core/scheduler.py, 2026-08) -- the groups ride along, no
    roles, no settings, NOT marked (resolved as far as that deployment can)."""
    from core.app_roles.resolve import NO_STORE
    out = acting_principal(username, groups=groups, db=NO_STORE, given="viewer", auth_method=HEADLESS)
    out.update({"role": "viewer", "roles": ["viewer"], "role_bases": [], "is_admin": False})
    return out


def unresolved_principal(username: str, *, groups: Iterable[str] = (), auth_method: str = HEADLESS,
                         **extra: Any) -> Dict[str, Any]:
    """A principal whose scope could NOT be established (no owner recorded, the
    directory did not answer): the least privilege, resolved against the
    settings alone, and MARKED ``rls_unresolved`` so a governed table is refused
    rather than read unfiltered (core/row_security/rewriter.py)."""
    from core.app_roles.resolve import NO_STORE
    out = acting_principal(username or "scheduled", groups=groups, db=NO_STORE, given="viewer",
                           auth_method=auth_method, rls_unresolved=True, **extra)
    # the LEAST privilege, pinned: whatever a setting says about the name (it may
    # name an admin), an unresolved scope is a viewer with no roles -- never admin
    out.update({"role": "viewer", "roles": ["viewer"], "role_bases": [], "is_admin": False})
    return out
