"""Access to THINGS by role, AD group, user group or person (2026-11-10).

docs/OBJECT_ACCESS_BY_ROLE_PLAN_2026_11_10.html.  Tool entitlement answers what a
person may DO (screens, actions); this answers WHICH THINGS they may use.  One
store (``access_grants``), one vocabulary (here), one decision
(``core/entitlements.py`` -- it reads ``granted_ids``).  A grant only ADDS access:
with no rows, every answer is the one before it existed.

The owner's rule for connections (2026-11-10): a connection is checked only while
someone BUILDS (the query builders, the SQL editor, browsing it, a dataset) --
never on a report, dashboard, feed, file or any run.  Those roads never ask.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Iterable, List, Mapping, Optional, Set, Tuple

logger = logging.getLogger(__name__)

ROLE = "role"
AD_GROUP = "ad_group"
USER_GROUP = "user_group"
USER = "user"
PRINCIPAL_TYPES: Tuple[str, ...] = (ROLE, AD_GROUP, USER_GROUP, USER)

#: words a person reads for each kind of "who"
PRINCIPAL_WORDS: Dict[str, str] = {ROLE: "Role", AD_GROUP: "AD group", USER_GROUP: "User group", USER: "Person"}

#: the things that can be granted, what a grant on each one allows, and the
#: capability that lets someone change who may use it
OBJECT_TYPES: Dict[str, Dict[str, Any]] = {
    "connection": {
        "levels": ("use",),
        # the owner, 2026-11-10: "connection entitlement is based group not individual ... one
        # connection can be shared to multiple groups" -- a person is never given a connection
        "principal_types": (ROLE, AD_GROUP, USER_GROUP),
        # the levels connection_access spelled (never enforced apart: any grant meant "may use")
        "legacy_levels": ("read", "execute", "manage"),
        "manage_capability": "connections.manage",
        "words": "connection",
    },
}


class GrantRefused(ValueError):
    """A grant that cannot be saved, in plain words."""


def object_type(name: str) -> Dict[str, Any]:
    spec = OBJECT_TYPES.get(str(name or "").strip().lower())
    if not spec:
        raise GrantRefused(f"Access cannot be set on '{name}': the things that can be shared are "
                           f"{', '.join(sorted(OBJECT_TYPES))}.")
    return spec


def normalize_name(principal_type: str, name: Any) -> str:
    """The stored spelling: lower-case and trimmed (AD and usernames compare
    without case everywhere else in QueryStudio); a user group by its id."""
    text = str(name if name is not None else "").strip()
    if principal_type == USER_GROUP:
        return str(int(text)) if text.lstrip("-").isdigit() else text
    return text.lower()


def principals_of(user: Optional[Mapping[str, Any]], db: Any = None) -> List[Tuple[str, str]]:
    """Every (kind, name) this person is: themselves, each application role they
    hold (``core.app_roles.resolve.roles_of`` -- the one reader), each AD group
    (short name and full DN), each QueryStudio user group they are a member of.
    A user-group lookup that fails is left out (grants only add: missing one can
    never widen access)."""
    user = user or {}
    out: List[Tuple[str, str]] = []

    def _add(kind: str, name: Any) -> None:
        n = normalize_name(kind, name)
        if n and (kind, n) not in out:
            out.append((kind, n))

    username = str(user.get("username") or "")
    if username:
        _add(USER, username)
    try:
        from core.app_roles.resolve import roles_of
        roles = roles_of(dict(user))
    except Exception:                                        # noqa: BLE001 -- an older build
        roles = [str(user.get("role") or "")]
    for r in roles:
        _add(ROLE, r)
    for g in list(user.get("groups") or []) + list(user.get("group_dns") or []):
        _add(AD_GROUP, g)
    if username and db is not None and hasattr(db, "list_groups_for_user"):
        try:
            for g in db.list_groups_for_user(username) or []:
                if g.get("id") is not None and g.get("is_active", True) is not False:
                    _add(USER_GROUP, g["id"])
        except Exception as exc:                             # noqa: BLE001
            logger.warning("object access: user groups of %s could not be read (left out): %s",
                           username, exc)
    return out


def granted_ids(user: Optional[Mapping[str, Any]], kind: str, db: Any) -> Set[str]:
    """The ids of every ``kind`` thing granted to this person, as strings.  A
    store that cannot be read answers the empty set and says so: grants only
    add, so the decision falls back to the rules before them -- never wider."""
    if db is None or not hasattr(db, "object_ids_granted"):
        return set()
    try:
        return set(db.object_ids_granted(kind, principals_of(user, db)) or set())
    except Exception as exc:                                 # noqa: BLE001
        logger.warning("object access: grants on %s for %s could not be read (only the owner / "
                       "shared rules apply this time): %s", kind, (user or {}).get("username"), exc)
        return set()


def check_grants(kind: str, grants: Iterable[Mapping[str, Any]], db: Any,
                 existing: Iterable[Mapping[str, Any]] = ()) -> List[Dict[str, str]]:
    """The grants as they are saved: kinds this thing may be given to, names that
    exist (an ACTIVE application role; a user group that exists), no repeats.
    A grant of a kind the thing no longer takes (a connection given to a PERSON,
    copied from ``connection_access``) may be KEPT -- it is in ``existing`` -- but
    never added.  Raises ``GrantRefused`` naming what is wrong."""
    spec = object_type(kind)
    allowed = tuple(spec.get("principal_types") or PRINCIPAL_TYPES)
    kept = {(str(e.get("principal_type") or ""), normalize_name(str(e.get("principal_type") or ""),
                                                                e.get("principal_name")))
            for e in existing or []}
    out: List[Dict[str, str]] = []
    unknown_roles: List[str] = []
    unknown_groups: List[str] = []
    active_roles: Optional[Set[str]] = None
    for g in grants or []:
        ptype = str((g or {}).get("principal_type") or "").strip().lower()
        if ptype not in PRINCIPAL_TYPES:
            raise GrantRefused(f"'{ptype}' is not someone a {spec['words']} can be shared with: use a role, "
                               "an AD group, a user group or a person.")
        name = normalize_name(ptype, (g or {}).get("principal_name"))
        if not name:
            raise GrantRefused(f"A {PRINCIPAL_WORDS[ptype].lower()} needs a name.")
        if ptype not in allowed and (ptype, name) not in kept:
            words = ", ".join(PRINCIPAL_WORDS[p].lower() + "s" for p in allowed)
            raise GrantRefused(f"A {spec['words']} is given to groups, never to one person: use {words}.")
        if ptype == ROLE:
            if active_roles is None:
                active_roles = {str(r.get("name") or "").lower() for r in (db.list_app_roles(active_only=True) or [])} \
                    if hasattr(db, "list_app_roles") else None
            if active_roles is not None and name not in active_roles:
                unknown_roles.append(name)
        if ptype == USER_GROUP:
            row = db.get_user_group(int(name)) if name.isdigit() and hasattr(db, "get_user_group") else None
            if not row:
                unknown_groups.append(name)
        item = {"principal_type": ptype, "principal_name": name}
        if item not in out:
            out.append(item)
    if unknown_roles:
        raise GrantRefused(f"These roles are not set up (or are switched off): {', '.join(sorted(set(unknown_roles)))}.")
    if unknown_groups:
        raise GrantRefused(f"These user groups do not exist: {', '.join(sorted(set(unknown_groups)))}.")
    return out


__all__ = ["ROLE", "AD_GROUP", "USER_GROUP", "USER", "PRINCIPAL_TYPES", "PRINCIPAL_WORDS", "OBJECT_TYPES",
           "GrantRefused", "object_type", "normalize_name", "principals_of", "granted_ids", "check_grants"]
