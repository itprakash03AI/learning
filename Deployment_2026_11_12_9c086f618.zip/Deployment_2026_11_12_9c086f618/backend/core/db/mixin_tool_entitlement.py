"""Tool-entitlement grants -- the thin DB layer (2026-10-31).

The decision lives in ``core/tool_entitlement/engine.py``; these methods only
read and write ``tool_capability_grants``.  A grant is a configuration row:
it is switched OFF, never erased (``core/config_active.switch_off``), and every
write is audited by the caller.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import ClassVar, Any, Dict, Iterable, List, Optional, Tuple

from core.db.models import ToolCapabilityGrant


class ToolEntitlementMixin:

    def list_tool_capability_grants(self, active_only: bool = True, capability: Optional[str] = None,
                                    principal_type: Optional[str] = None,
                                    principal_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Grant rows; ``active_only`` hides switched-off ones (the engine's read).
        Raises on a store error -- the engine refuses rather than read "no grants"."""
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            q = session.query(ToolCapabilityGrant)
            if active_only:
                q = q.filter(active_clause(ToolCapabilityGrant))
            if capability:
                q = q.filter(ToolCapabilityGrant.capability == capability)
            if principal_type:
                q = q.filter(ToolCapabilityGrant.principal_type == principal_type)
            if principal_id is not None:
                q = q.filter(ToolCapabilityGrant.principal_id == principal_id)
            return [r.to_dict() for r in q.order_by(ToolCapabilityGrant.capability,
                                                    ToolCapabilityGrant.principal_type,
                                                    ToolCapabilityGrant.principal_id,
                                                    ToolCapabilityGrant.id).all()]

    def get_tool_capability_grant(self, grant_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.get(ToolCapabilityGrant, int(grant_id))
            return row.to_dict() if row else None

    #: the two halves of a configuration release never meet on one principal
    _SEPARATED: ClassVar[dict] = {"releases.approve": "releases.manage", "releases.manage": "releases.approve"}

    def add_tool_capability_grant(self, capability: str, principal_type: str, principal_id: str,
                                  scope_kind: str = "", scope_id: str = "", by_user: Optional[str] = None,
                                  note: Optional[str] = None, source: str = "manual",
                                  by_role: Optional[str] = None) -> Dict[str, Any]:
        """Add a grant, or switch an identical switched-off one back ON (the
        natural key is unique whatever its state).

        2026-11-10 (the fifth review): ``releases.approve`` is granted only by a
        super_admin (``by_role``), only to a ``user`` principal, and never to one
        that holds ``releases.manage`` (nor the reverse): the account that uploads
        must not also approve.  Refused with ``ValueError`` in words."""
        if capability in self._SEPARATED and source == "manual":
            other = self._SEPARATED[capability]
            if capability == "releases.approve":
                if str(by_role or "").lower() != "super_admin":
                    raise ValueError("releases.approve is granted by a super_admin only")
                if principal_type != "user":
                    raise ValueError("releases.approve is granted to a user (a service account) only, never to a role, "
                                     "group or API key")
            principals = [(principal_type, str(principal_id))]
            through = ""
            if principal_type == "user":
                principals, through = self._principals_of_user(str(principal_id))
            with self.get_session(read_only=True) as session:
                clash = (session.query(ToolCapabilityGrant)
                         .filter(ToolCapabilityGrant.capability == other, ToolCapabilityGrant.is_active.is_(True)).all())
            held_by = [(c.principal_type, c.principal_id) for c in clash if (c.principal_type, str(c.principal_id)) in set(principals)]
            if held_by or through:
                raise ValueError(f"{principal_type} {principal_id!r} already holds {other}"
                                 f"{' through ' + through if through else ''}"
                                 f"{' (grant on ' + ', '.join(f'{t} {i}' for t, i in held_by) + ')' if held_by else ''}: the account "
                                 f"that uploads a release must not also approve it (and the reverse) -- use two accounts")
        with self.get_session() as session:
            row = (session.query(ToolCapabilityGrant)
                   .filter(ToolCapabilityGrant.capability == capability,
                           ToolCapabilityGrant.principal_type == principal_type,
                           ToolCapabilityGrant.principal_id == principal_id,
                           ToolCapabilityGrant.scope_kind == (scope_kind or ""),
                           ToolCapabilityGrant.scope_id == (scope_id or "")).first())
            if row is None:
                row = ToolCapabilityGrant(capability=capability, principal_type=principal_type,
                                          principal_id=principal_id, scope_kind=scope_kind or "",
                                          scope_id=scope_id or "", created_by=by_user, note=note,
                                          source=source)
                session.add(row)
            else:
                row.is_active = True
                row.updated_by = by_user
                row.updated_at = datetime.now(timezone.utc)
                if note is not None:
                    row.note = note
            session.flush()
            return row.to_dict()

    def _principals_of_user(self, username: str):
        """Every principal a grant may name for ``username`` (the user, its role bundle,
        its groups -- through the engine's ONE resolver) and, when its ROLE BUNDLE
        already carries the other half, that bundle's name."""
        from core.tool_entitlement.engine import bundle_role_of, principals_of
        from core.tool_entitlement.vocabulary import bundle
        user = {"username": username}
        finder = getattr(self, "get_user_by_username", None) or getattr(self, "get_user", None)
        try:
            row = finder(username) if callable(finder) else None
        except Exception:  # noqa: BLE001 -- an unknown user: only the direct principals count
            row = None
        if isinstance(row, dict):
            user["role"] = row.get("role")
            user["groups"] = row.get("groups") or ()
        try:
            principals = [(t, str(i)) for t, i in principals_of(user, self)]
        except Exception:  # noqa: BLE001 -- the resolver needs stores a bare test database lacks: the direct principals
            principals = [("user", username), ("role", bundle_role_of(user))]
        other_half = {"releases.manage": "releases.approve", "releases.approve": "releases.manage"}
        role = bundle_role_of(user)
        through = ""
        for other in other_half.values():
            if other in bundle(role) and ("role", role) in principals:
                through = f"its role bundle {role!r}"
        return principals, through

    def switch_off_tool_capability_grant(self, grant_id: int, by_user: Optional[str] = None,
                                         event: Optional[str] = None) -> bool:
        from core.config_active import switch_off
        with self.get_session() as session:
            row = session.get(ToolCapabilityGrant, int(grant_id))
            if row is None:
                return False
            row.updated_by = by_user
            switch_off(row, by_user=by_user, event=event)
            return True

    def seed_tool_capability_grants(self, pairs: Iterable[Tuple[str, str]]) -> int:
        """Insert a ``role`` grant for every (capability, role) pair that has NO
        row yet -- on or off.  Returns how many were inserted."""
        wanted = list(pairs)
        with self.get_session() as session:
            have = {(r.capability, r.principal_id) for r in
                    session.query(ToolCapabilityGrant.capability, ToolCapabilityGrant.principal_id)
                    .filter(ToolCapabilityGrant.principal_type == "role",
                            ToolCapabilityGrant.scope_kind == "").all()}
            added = 0
            for cap, role in wanted:
                if (cap, role) in have:
                    continue
                session.add(ToolCapabilityGrant(capability=cap, principal_type="role", principal_id=role,
                                                scope_kind="", scope_id="", source="seed",
                                                created_by="system"))
                have.add((cap, role))
                added += 1
            session.flush()
            return added
