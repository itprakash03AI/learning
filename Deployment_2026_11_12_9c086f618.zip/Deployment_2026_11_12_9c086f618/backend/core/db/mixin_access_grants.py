"""Who may use a thing -- the thin DB layer over ``access_grants`` (2026-11-10).

The rules live in ``core/object_access`` (vocabulary, who a person is, what a
grant may name) and ``core/entitlements.py`` (the one decision).  These methods
only read and write rows.  A grant is configuration: removing it switches it
off, never erases it.

``connection_access`` (Phase 102-E) is folded in here: its rows are copied once
at start-up (``copy_connection_access_grants``) and its six methods -- kept with
their names and shapes, the old routes and tests call them -- read and write
``access_grants`` with ``object_type = connection``.  One store, one answer.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from sqlalchemy import and_, or_

from core.db.models import AccessGrant, ConnectionAccess

logger = logging.getLogger(__name__)

_CONN = "connection"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _legacy_shape(row: AccessGrant) -> Dict[str, Any]:
    """A connection grant in the shape ``connection_access`` rows had."""
    return {"id": row.id, "connection_id": int(row.object_id), "grant_type": row.principal_type,
            "grantee": row.principal_name, "permission": row.level, "created_by": row.created_by,
            "created_at": row.created_at.isoformat() if row.created_at else None}


class AccessGrantsMixin:

    # ── the store ────────────────────────────────────────────────────────────

    def list_access_grants(self, object_type: str, object_id: Any,
                           include_inactive: bool = False) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(AccessGrant).filter(AccessGrant.object_type == object_type,
                                                  AccessGrant.object_id == str(object_id))
            if not include_inactive:
                q = q.filter(AccessGrant.is_active.isnot(False))
            rows = q.order_by(AccessGrant.principal_type, AccessGrant.principal_name).all()
            return [r.to_dict() for r in rows]

    def set_access_grants(self, object_type: str, object_id: Any, grants: Iterable[Dict[str, str]],
                          *, level: str = "use", by_user: Optional[str] = None) -> Dict[str, List[str]]:
        """Make the ACTIVE grants on this thing exactly ``grants`` (already checked
        by ``core.object_access.check_grants``): new ones added, switched-off ones
        switched back on, the rest switched off.  One transaction.  Returns what
        was added and what was switched off ("kind:name")."""
        wanted = {(g["principal_type"], g["principal_name"]) for g in grants}
        added: List[str] = []
        removed: List[str] = []
        with self.get_session() as session:
            rows = (session.query(AccessGrant)
                    .filter(AccessGrant.object_type == object_type,
                            AccessGrant.object_id == str(object_id)).all())
            have = {(r.principal_type, r.principal_name): r for r in rows}
            for key in sorted(wanted):
                row = have.get(key)
                if row is None:
                    session.add(AccessGrant(object_type=object_type, object_id=str(object_id),
                                            principal_type=key[0], principal_name=key[1], level=level,
                                            is_active=True, created_by=by_user, updated_by=by_user))
                    added.append(f"{key[0]}:{key[1]}")
                elif row.is_active is False:
                    row.is_active = True
                    row.level = level
                    row.updated_by = by_user
                    row.updated_at = _now()
                    added.append(f"{key[0]}:{key[1]}")
            for key, row in have.items():
                if key not in wanted and row.is_active is not False:
                    row.is_active = False
                    row.updated_by = by_user
                    row.updated_at = _now()
                    removed.append(f"{key[0]}:{key[1]}")
        return {"added": added, "removed": removed}

    def object_ids_granted(self, object_type: str, principals: Iterable[Tuple[str, str]]) -> Set[str]:
        """The ids of every ``object_type`` thing with an ACTIVE grant to any of
        these (kind, name) pairs -- ONE query."""
        pairs = [(k, n) for k, n in principals or [] if k and n]
        if not pairs:
            return set()
        conds = [and_(AccessGrant.principal_type == k, AccessGrant.principal_name == n) for k, n in pairs]
        with self.get_session(read_only=True) as session:
            rows = (session.query(AccessGrant.object_id)
                    .filter(AccessGrant.object_type == object_type,
                            AccessGrant.is_active.isnot(False), or_(*conds))
                    .distinct().all())
            return {str(r[0]) for r in rows}

    def object_ids_with_grants(self, object_type: str) -> Set[str]:
        """Every ``object_type`` thing granted to someone (an active row)."""
        with self.get_session(read_only=True) as session:
            rows = (session.query(AccessGrant.object_id)
                    .filter(AccessGrant.object_type == object_type, AccessGrant.is_active.isnot(False))
                    .distinct().all())
            return {str(r[0]) for r in rows}

    # ── connection_access, folded in ─────────────────────────────────────────

    def copy_connection_access_grants(self) -> int:
        """ONCE, idempotent: every ``connection_access`` row becomes an
        ``access_grants`` row (insert-missing by the unique key -- a row already
        copied, even one an admin switched off since, is never touched again).
        Rows that were COUNTED before (admin governance on) are copied switched
        on; rows that were dormant (governance off) are copied switched OFF, so
        nobody gains a connection on deploy (plan section 3).  One transaction."""
        try:
            from core.config import admin_governance as _gov
            counted = bool(_gov.enabled)
        except Exception:                                    # noqa: BLE001
            counted = False
        copied = 0
        with self.get_session() as session:
            old = session.query(ConnectionAccess).all()
            if not old:
                return 0
            have = {(r.object_id, r.principal_type, r.principal_name)
                    for r in session.query(AccessGrant).filter(AccessGrant.object_type == _CONN).all()}
            for r in old:
                ptype = str(r.grant_type or "").strip().lower()
                name = str(r.grantee or "").strip().lower()
                key = (str(r.connection_id), ptype, name)
                if ptype not in ("user", "role") or not name or key in have:
                    continue
                session.add(AccessGrant(
                    object_type=_CONN, object_id=str(r.connection_id), principal_type=ptype,
                    principal_name=name, level=str(r.permission or "read"), is_active=counted,
                    note=("copied from connection_access" + ("" if counted else
                          " switched off: admin governance was off, so this grant was not counted before")),
                    created_by=r.created_by, created_at=r.created_at or _now(), updated_by="upgrade"))
                have.add(key)
                copied += 1
        if copied:
            logger.warning("access grants: copied %d connection_access row(s) into access_grants (%s)",
                           copied, "switched on" if counted else "switched OFF -- admin governance was off")
        return copied

    def connection_ids_with_grants(self) -> set:
        """Every connection granted to someone (core/shared_connection_vault.py)."""
        return {int(i) for i in self.object_ids_with_grants(_CONN) if str(i).isdigit()}

    def grant_connection_access(self, connection_id: int, grant_type: str,
                                grantee: str, permission: str = "read",
                                created_by: Optional[str] = None) -> Dict[str, Any]:
        """Grant a user or role the use of a connection (upsert by who)."""
        if grant_type not in ("user", "role"):
            raise ValueError(f"grant_type must be 'user' or 'role', got {grant_type!r}")
        if permission not in ("read", "execute", "manage"):
            raise ValueError(f"permission must be read|execute|manage, got {permission!r}")
        name = str(grantee or "").strip().lower()
        with self.get_session() as session:
            row = (session.query(AccessGrant)
                   .filter(AccessGrant.object_type == _CONN, AccessGrant.object_id == str(connection_id),
                           AccessGrant.principal_type == grant_type, AccessGrant.principal_name == name)
                   .first())
            if row is None:
                row = AccessGrant(object_type=_CONN, object_id=str(connection_id), principal_type=grant_type,
                                  principal_name=name, created_by=created_by)
                session.add(row)
            row.level = permission
            row.is_active = True
            row.updated_by = created_by
            row.updated_at = _now()
            session.flush()
            session.refresh(row)
            return _legacy_shape(row)

    def revoke_connection_access(self, access_id: int) -> bool:
        """Switch off one connection grant by its id."""
        with self.get_session() as session:
            row = (session.query(AccessGrant)
                   .filter(AccessGrant.id == access_id, AccessGrant.object_type == _CONN,
                           AccessGrant.is_active.isnot(False)).first())
            if not row:
                return False
            row.is_active = False
            row.updated_at = _now()
            return True

    def list_connection_access(self, connection_id: int) -> List[Dict[str, Any]]:
        """The active grants on one connection (newest first), in the old shape;
        a role / AD group / user group grant made on the new screen is listed too."""
        with self.get_session(read_only=True) as session:
            rows = (session.query(AccessGrant)
                    .filter(AccessGrant.object_type == _CONN, AccessGrant.object_id == str(connection_id),
                            AccessGrant.is_active.isnot(False))
                    .order_by(AccessGrant.created_at.desc()).all())
            return [_legacy_shape(r) for r in rows]

    def list_connection_ids_for_user(self, username: str, roles: Optional[List[str]] = None) -> set:
        """Connection ids granted to this user name or one of these roles (the old
        reader; the decision itself asks ``core.object_access.granted_ids``)."""
        pairs = [("user", str(username or "").strip().lower())] + [("role", str(r).strip().lower())
                                                                    for r in roles or []]
        return {int(i) for i in self.object_ids_granted(_CONN, pairs) if str(i).isdigit()}

    def user_has_connection_access(self, username: str, connection_id: int,
                                   roles: Optional[List[str]] = None) -> bool:
        return int(connection_id) in self.list_connection_ids_for_user(username, roles)
