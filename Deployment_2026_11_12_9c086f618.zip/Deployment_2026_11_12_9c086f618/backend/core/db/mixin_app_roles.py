"""Application roles as data -- the thin DB layer (2026-11-10).

The rules live in ``core/app_roles/`` (the resolver and the service); these
methods only read and write ``app_roles`` / ``app_role_sources`` and run the
two one-time migrations.  A role is configuration: it is switched OFF, never
erased (``core/config_active.switch_off``); a built-in is never switched off.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional

from sqlalchemy import or_

from core.db.models import AppRole, AppRoleSource, BusinessReportGrant

logger = logging.getLogger(__name__)

#: the six built-ins (core/tool_entitlement/vocabulary.BUNDLE_ROLES) as rows, in the
#: words a person reads; based_on = itself
BUILTIN_ROLES: tuple = (
    ("admin", "Admin", "Everything: settings, users, every screen and action."),
    ("analyst", "Analyst", "Builds datasets, queries, reports and feeds."),
    ("viewer", "Viewer", "Opens and runs the reports assigned to them."),
    ("support", "Support", "Reads everything, changes nothing: the support desk's role."),
    ("api_consumer", "API consumer", "An API key calling published APIs."),
    ("scheduler", "Scheduler", "Sees the scheduler screens and nothing else."),
)

RESTAMP_MARKER = "app_roles.view_grants_restamped"
#: when THIS process started: the restamp never touches a grant written after it
#: (a ``view`` grant the new code writes is always later -- idempotent on a retry)
#: review 2 (M2): the upgrade MOMENT, written to the store ONCE before the first
#: restamp and read back on every retry -- never "when this process started"
#: (a retry after a marker-write failure would then widen a later view-only grant)
RESTAMP_CUTOFF = "app_roles.view_grants_restamp_cutoff"
#: why the restamp did not run on this pod (None = it ran, or had run); shown on
#: the admin screen's problems list (core/app_roles/service.py::describe_roles)
RESTAMP_PROBLEM: Optional[str] = None


class AppRolesMixin:

    # ── roles ──────────────────────────────────────────────────────────────

    def list_app_roles(self, active_only: bool = True) -> List[Dict[str, Any]]:
        """Every role row (the built-ins first, then by name).  Raises on a store
        error: the resolver falls back to the built-ins and says so."""
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            q = session.query(AppRole)
            if active_only:
                q = q.filter(active_clause(AppRole))
            rows = q.order_by(AppRole.is_builtin.desc(), AppRole.name).all()
            return [r.to_dict() for r in rows]

    def get_app_role(self, name: str, active_only: bool = False) -> Optional[Dict[str, Any]]:
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            q = session.query(AppRole).filter(AppRole.name == str(name or "").strip().lower())
            if active_only:
                q = q.filter(active_clause(AppRole))
            row = q.first()
            return row.to_dict() if row else None

    def active_app_role_names(self) -> List[str]:
        return [r["name"] for r in self.list_app_roles(active_only=True)]

    def create_app_role(self, *, name: str, label: str, description: Optional[str], based_on: str,
                        by_user: Optional[str] = None, source: str = "manual",
                        is_builtin: bool = False) -> Dict[str, Any]:
        """Insert a role; a switched-off row of the same name REFUSES (NameHeld, 409)."""
        from core.config_active import refuse_if_held
        with self.get_session() as session:
            refuse_if_held(session, AppRole, "role", "name", name)
            row = AppRole(name=name, label=label, description=description or "", based_on=based_on,
                          is_builtin=is_builtin, source=source, created_by=by_user, updated_by=by_user)
            session.add(row)
            session.flush()
            return row.to_dict()

    def update_app_role(self, name: str, *, label: Optional[str] = None,
                        description: Optional[str] = None,
                        by_user: Optional[str] = None) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(AppRole).filter(AppRole.name == name).first()
            if row is None:
                return None
            if label is not None:
                row.label = label
            if description is not None:
                row.description = description
            row.updated_by = by_user
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            return row.to_dict()

    def switch_off_app_role(self, name: str, by_user: Optional[str] = None, event: Optional[str] = None) -> bool:
        from core.config_active import switch_off
        with self.get_session() as session:
            row = session.query(AppRole).filter(AppRole.name == name).first()
            if row is None or row.is_builtin:
                return False
            row.updated_by = by_user
            switch_off(row, by_user=by_user, event=event)
            return True

    def seed_app_roles(self) -> int:
        """The built-ins as rows, ONCE: a row that exists -- on or off -- is never
        touched.  Returns how many were inserted.  NOTHING else is seeded: every
        other role is DATA an admin creates with any name (the owner, 2026-11-10:
        "we need generic roles, not defined hardly")."""
        added = 0
        with self.get_session() as session:
            have = {r[0] for r in session.query(AppRole.name).all()}
            for name, label, desc in BUILTIN_ROLES:
                if name in have:
                    continue
                session.add(AppRole(name=name, label=label, description=desc, based_on=name,
                                    is_builtin=True, source="seed", created_by="system"))
                have.add(name)
                added += 1
            session.flush()
        if added:
            logger.info("app_roles: seeded %d role row(s)", added)
        return added

    # ── sources: who holds a role ──────────────────────────────────────────

    def list_app_role_sources(self, role_name: Optional[str] = None,
                              active_only: bool = True) -> List[Dict[str, Any]]:
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            q = session.query(AppRoleSource)
            if active_only:
                q = q.filter(active_clause(AppRoleSource))
            if role_name:
                q = q.filter(AppRoleSource.role_name == str(role_name).strip().lower())
            rows = q.order_by(AppRoleSource.role_name, AppRoleSource.source_kind,
                              AppRoleSource.source_value).all()
            return [r.to_dict() for r in rows]

    def add_app_role_source(self, *, role_name: str, source_kind: str, source_value: str,
                            by_user: Optional[str] = None, note: Optional[str] = None) -> Dict[str, Any]:
        """Add a source, or switch an identical switched-off one back ON."""
        with self.get_session() as session:
            row = (session.query(AppRoleSource)
                   .filter(AppRoleSource.role_name == role_name,
                           AppRoleSource.source_kind == source_kind,
                           AppRoleSource.source_value == source_value).first())
            if row is None:
                row = AppRoleSource(role_name=role_name, source_kind=source_kind,
                                    source_value=source_value, note=note,
                                    created_by=by_user, updated_by=by_user)
                session.add(row)
            else:
                row.is_active = True
                row.updated_by = by_user
                row.updated_at = datetime.now(timezone.utc)
                if note is not None:
                    row.note = note
            session.flush()
            return row.to_dict()

    def switch_off_app_role_source(self, source_id: int, by_user: Optional[str] = None) -> bool:
        from core.config_active import switch_off
        with self.get_session() as session:
            row = session.get(AppRoleSource, int(source_id))
            if row is None:
                return False
            row.updated_by = by_user
            switch_off(row, by_user=by_user)
            return True

    def app_role_sources_naming(self, role_name: str) -> int:
        """How many ACTIVE sources still hand out ``role_name`` (a switch-off refuses while > 0)."""
        from core.config_active import active_clause
        with self.get_session(read_only=True) as session:
            return int(session.query(AppRoleSource)
                       .filter(AppRoleSource.role_name == role_name, active_clause(AppRoleSource))
                       .count())

    # ── the one-time restamp (plan section 4) ──────────────────────────────

    def _migrate_br_view_grants_to_runner(self) -> int:
        """ONCE: every report grant at level ``view`` from BEFORE THE UPGRADE becomes
        ``runner``.  Before 2026-11-10 nothing read ``can_run``, so a ``view`` grant
        always ran the report; now the execute roads ask it, and this keeps every
        holder exactly where they were.

        Review 2 (M2) -- the rules:
          * the upgrade moment is the STORED cutoff (``RESTAMP_CUTOFF``), written
            once before the first restamp and read back on a retry; a ``view``
            grant made after it (the new meaning: open the saved result, no run)
            is never restamped, whatever pod retries and whenever;
          * the restamp and its marker (``RESTAMP_MARKER``) are ONE transaction:
            either every row moved and the marker says so, or nothing changed;
          * a marker or cutoff that cannot be read or written = REFUSE to
            restamp, and say so (``RESTAMP_PROBLEM``, on the admin screen).
        Journaled per row in the report's permission audit (``grant_level_restamped``)."""
        global RESTAMP_PROBLEM
        try:
            if self.get_system_setting(RESTAMP_MARKER, default=None):
                RESTAMP_PROBLEM = None
                return 0
            cutoff_raw = self.get_system_setting(RESTAMP_CUTOFF, default=None)
        except Exception as exc:                                         # noqa: BLE001
            RESTAMP_PROBLEM = (f"the one-time view -> runner restamp of report grants did not run on this pod: "
                               f"its marker could not be read ({exc}). Nothing was changed; it runs on the next "
                               f"start once the database answers.")
            logger.error("app_roles: %s", RESTAMP_PROBLEM)
            return 0
        if cutoff_raw:
            cutoff = datetime.fromisoformat(str(cutoff_raw))
        else:
            try:
                cutoff = datetime.fromisoformat(self._write_restamp_cutoff_if_absent())
            except Exception as exc:                                     # noqa: BLE001
                RESTAMP_PROBLEM = (f"the one-time view -> runner restamp of report grants did not run on this pod: "
                                   f"its cutoff could not be written ({exc}). Nothing was changed.")
                logger.error("app_roles: %s", RESTAMP_PROBLEM)
                return 0
        if cutoff.tzinfo is None:
            cutoff = cutoff.replace(tzinfo=timezone.utc)
        moved = 0
        journal: List[tuple] = []
        try:
            with self.get_session() as session:
                rows = (session.query(BusinessReportGrant)
                        .filter(BusinessReportGrant.level == "view",
                                or_(BusinessReportGrant.granted_at.is_(None),
                                    BusinessReportGrant.granted_at < cutoff.replace(tzinfo=None),
                                    BusinessReportGrant.granted_at < cutoff)).all())
                for g in rows:
                    g.level = "runner"
                    moved += 1
                from core.db.models import SystemSetting
                stamp = datetime.now(timezone.utc).isoformat()
                marker = session.get(SystemSetting, RESTAMP_MARKER)
                if marker is None:
                    session.add(SystemSetting(key=RESTAMP_MARKER, value=stamp, updated_by="system",
                                              description="report grants at level view restamped runner (one-time)"))
                else:
                    marker.value = stamp
                    marker.updated_by = "system"
                session.flush()
                journal = [(int(g.report_id), int(g.id),
                            g.username or (f"group:{g.group_id}" if g.group_id else g.role_name)) for g in rows]
        except Exception as exc:                                         # noqa: BLE001
            RESTAMP_PROBLEM = (f"the one-time view -> runner restamp of report grants did not complete on this pod "
                               f"({exc}). It is one transaction, so nothing was changed; it runs on the next start.")
            logger.error("app_roles: %s", RESTAMP_PROBLEM)
            return 0
        RESTAMP_PROBLEM = None
        for report_id, grant_id, subject in journal:
            try:
                self.add_br_permission_event(report_id=report_id, event_type="grant_level_restamped",
                                             actor="system", subject=subject,
                                             metadata={"grant_id": grant_id, "from": "view", "to": "runner",
                                                       "why": "can_run is enforced from 2026-11-10; nobody loses the run they had"})
            except Exception as exc:                                     # noqa: BLE001
                logger.warning("app_roles: restamp journal for grant %s failed: %s", grant_id, exc)
        if moved:
            logger.info("app_roles: restamped %d report grant(s) view -> runner (one-time, cutoff %s)", moved, cutoff)
        return moved

    def _write_restamp_cutoff_if_absent(self) -> str:
        """The upgrade moment, INSERT-IF-ABSENT: two pods starting together both
        try; the first insert wins and the second reads it back (review 3, LOW)
        -- the cutoff is written once and never moves."""
        from sqlalchemy.exc import IntegrityError
        from core.db.models import SystemSetting
        mine = datetime.now(timezone.utc).isoformat()
        with self.get_session() as session:
            row = session.get(SystemSetting, RESTAMP_CUTOFF)
            if row is not None and row.value:
                return str(row.value)
            if row is not None:                       # an empty row (a test, a cleared setting): fill it
                row.value, row.updated_by = mine, "system"
                session.flush()
                return mine
            session.add(SystemSetting(key=RESTAMP_CUTOFF, value=mine, updated_by="system",
                                      description="the moment report grants at level view were last meant to run"))
            try:
                session.flush()
                return mine
            except IntegrityError:
                session.rollback()
        with self.get_session(read_only=True) as session:
            row = session.get(SystemSetting, RESTAMP_CUTOFF)
            if row is None or not row.value:
                raise RuntimeError("the cutoff was neither written nor found")
            return str(row.value)

    def _undo_api_consumer_restamp(self) -> int:
        """Review 4 (M1): an EARLIER build of this branch added ``api_consumer`` to the
        role list of every published report at the upgrade.  The rule is replaced
        (a key is admitted on the published-view road by the view's own scoping,
        as on master; a role list is never touched by an upgrade), so a database
        that build wrote is put back: every ``api_consumer`` entry that build's own
        journal row (``roles_changed`` by ``system``, subject ``api_consumer``)
        accounts for is removed, journaled.  Idempotent; nothing else is touched.
        A database no such build ever ran on has no such rows: nothing to do."""
        from core.db.models import BusinessReport, BusinessReportPermissionEvent
        undone: List[int] = []
        try:
            with self.get_session() as session:
                rows = (session.query(BusinessReportPermissionEvent)
                        .filter(BusinessReportPermissionEvent.event_type == "roles_changed",
                                BusinessReportPermissionEvent.actor == "system",
                                BusinessReportPermissionEvent.subject == "api_consumer").all())
                for ev in rows:
                    rpt = session.get(BusinessReport, int(ev.report_id))
                    if rpt is None:
                        ev.subject = "api_consumer (undone)"
                        continue
                    # review 5: a PERSON changed this report's role list after the stamp --
                    # their list is the truth now (an api_consumer they kept is theirs); never
                    # second-guess it.  The stamp is marked handled either way.
                    later_human = (session.query(BusinessReportPermissionEvent.id)
                                   .filter(BusinessReportPermissionEvent.report_id == ev.report_id,
                                           BusinessReportPermissionEvent.event_type == "roles_changed",
                                           BusinessReportPermissionEvent.actor != "system",
                                           BusinessReportPermissionEvent.id > ev.id)
                                   .first())
                    wl = [str(x) for x in (rpt.role_whitelist or [])]
                    if later_human is None and "api_consumer" in {x.lower() for x in wl}:
                        rpt.role_whitelist = [x for x in wl if x.lower() != "api_consumer"]
                        undone.append(int(rpt.id))
                        # the journal row rides in the SAME transaction as the removal
                        session.add(BusinessReportPermissionEvent(
                            report_id=int(rpt.id), event_type="roles_changed", actor="system",
                            subject="api_consumer removed",
                            metadata_json={"why": "an earlier build added api_consumer at the upgrade; the rule "
                                                  "is replaced (review 4): a key is admitted on the published-view "
                                                  "road by the view's own scoping"}))
                    ev.subject = "api_consumer (undone)"
                session.flush()
        except Exception as exc:                                         # noqa: BLE001
            logger.error("app_roles: the api_consumer undo did not run (%s); nothing was changed", exc)
            return 0
        if undone:
            logger.info("app_roles: api_consumer removed from %d report role list(s) an earlier build added it to", len(undone))
        return len(undone)

    # ── sightings of unknown role names (the admin screen's list) ──────────

    def list_unknown_role_sightings(self, days: int = 30, limit: int = 500) -> List[Dict[str, Any]]:
        """Who signed in with a role name that is not set up, from the audit log
        (``login_role_unknown`` rows written by the login)."""
        from datetime import timedelta
        from core.db.models import AuditLog
        since = datetime.now(timezone.utc) - timedelta(days=max(1, int(days)))
        out: Dict[str, Dict[str, Any]] = {}
        with self.get_session(read_only=True) as session:
            rows = (session.query(AuditLog)
                    .filter(AuditLog.action == "login_role_unknown", AuditLog.timestamp >= since)
                    .order_by(AuditLog.timestamp.desc()).limit(int(limit)).all())
            for r in rows:
                names = list((r.details or {}).get("unknown") or [])
                for n in names:
                    key = f"{r.username}\x00{n}"
                    if key in out:
                        continue
                    out[key] = {"username": r.username, "role_name": n,
                                "seen_at": r.timestamp.isoformat() if r.timestamp else None}
        return list(out.values())
