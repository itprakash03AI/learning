"""A ready-to-copy Python client for ONE published API (2026-11-11).

The owner: "is there any way to share python code to [a] client whoever wants to consume ...
using efficient ways of pagination, proper error handling, if it's AD based authentication we
should give full code base to the team ... so they will just copy when they publish or from api
management ... [it] should be able to write [a] file or show on [the] UI".

:func:`render_python_client` writes ONE self-contained file (Python 3.8+, ``requests``; optional
``cryptography`` / ``pandas`` / ``pyarrow``) for one view, with that view's address, parameters
and filter columns filled in.  It is served by ``GET /api/v1/views/{slug}/client.py``
(``api/published_views_api.py``), behind the SAME access check as the view's meta, and shown on
the publish dialog / Published APIs page ("Python client" tab, Copy / Download).

The rules the client follows are the SERVER's own -- each one named where the server decides it:

* sign-in: ``X-API-Key``; or the person's AD login posted ONCE to ``/auth/login``
  (RSA-OAEP-SHA256 under ``/auth/public-key``, ``core/login_crypto.py``; a
  ``login_crypto_stale_key`` 400 refetches the key) and the session reused as ``Bearer``; a 401
  on a later call signs in again once.  A pod with no ``/auth/login`` (404) is called with HTTP
  Basic -- the API's own AD road (``api/deps.py::_resolve_api_key_or_ad_user``).
* paging: ``?limit=&offset=`` with the first page's ``pagination.dataset_version`` on every next
  page (``api/published_views/helpers.py``); 409 = the data was refreshed, start again; 416 =
  past the paged ceiling (``envelope.PagedCeiling.refusal_detail``), read ``continue_with``
  (``/bulk``) instead.
* retry: 429 and a 503 / 502 / 504 that carries ``Retry-After`` are waited out (the server's
  seconds, else exponential back-off with jitter); a 503 WITHOUT ``Retry-After`` is "switched
  off" and is not retried; a connection error is retried.  Every call is a GET (a read).
* bulk: ``/bulk?format=csv|jsonl`` streamed to a ``.part`` file and resumed after a broken
  read at ``X-QS-Row-Offset + rows written`` with ``dataset_version`` -- the headers' own rule.

Values reach the generated text ONLY through :func:`repr` (a name or slug is data, never code),
and comment text is reduced to one printable line.
"""
from __future__ import annotations

import datetime as _dt
import re
from typing import Any, Dict, List, Optional

#: The server's reserved query names (``api/published_views/helpers.py::_RESERVED_QUERY_NAMES``):
#: a parameter with one of these names is sent as ``param[name]``.
def _reserved_names() -> List[str]:
    try:
        from api.published_views.helpers import _RESERVED_QUERY_NAMES
        return sorted(str(n) for n in _RESERVED_QUERY_NAMES)
    except Exception:  # noqa: BLE001 -- the route imports it; a bare core import keeps the list
        return sorted({"limit", "offset", "sort", "columns", "format", "cache", "snapshot_id",
                       "as_of_timestamp", "as_of", "engine", "cursor", "max_rows", "batch_rows",
                       "received", "dataset_version", "allow_partial", "filter"})


_SAFE_FILE = re.compile(r"[^A-Za-z0-9_]+")


def client_file_name(slug: str) -> str:
    """``qs_<slug>.py`` -- importable (letters, digits, ``_``)."""
    stem = _SAFE_FILE.sub("_", str(slug or "view")).strip("_").lower() or "view"
    if stem[0].isdigit():
        stem = "v_" + stem
    return f"qs_{stem}.py"


_BASE_URL = re.compile(r"https?://[A-Za-z0-9._~:/?#@!$&()*+,;=%\[\]-]+")


def valid_base_url(value: str) -> bool:
    """An http(s) address with no spaces or quotes -- the only base a caller may name."""
    return bool(_BASE_URL.fullmatch(str(value or "")))


def _one_line(text: Any, limit: int = 160) -> str:
    s = " ".join(str(text or "").split())
    s = "".join(ch for ch in s if ch.isprintable()).replace('"""', "'''")
    return s[:limit]


def _params_of(meta: Dict[str, Any]) -> List[Dict[str, Any]]:
    out = []
    for pd in (meta.get("param_definitions") or []):
        if isinstance(pd, dict) and pd.get("name"):
            out.append({"name": str(pd["name"]), "type": str(pd.get("type") or "string"),
                        "required": bool(pd.get("required"))})
    return out


def _filters_of(meta: Dict[str, Any]) -> List[str]:
    out: List[str] = []
    for f in (meta.get("allowed_filters") or []):
        name = (f.get("column") or f.get("name")) if isinstance(f, dict) else f
        if name and str(name) not in out:
            out.append(str(name))
    return out


def _sample(ptype: str) -> str:
    t = (ptype or "").lower()
    if t == "date":
        return "2026-10-31"
    if t in ("number", "integer", "int", "float", "decimal"):
        return "100"
    return "VALUE"


def render_python_client(meta: Dict[str, Any], *, base_url: str,
                         generated_at: Optional[_dt.datetime] = None) -> str:
    """The client file for the view whose meta answer is ``meta``."""
    slug = str(meta.get("slug") or "")
    base = str(base_url or "").rstrip("/")
    params = _params_of(meta)
    filters = _filters_of(meta)
    fname = client_file_name(slug)
    module = fname[:-3]
    when = (generated_at or _dt.datetime.now(_dt.timezone.utc)).strftime("%Y-%m-%d %H:%M UTC")
    max_limit = meta.get("max_limit")
    page_size = 10_000
    if isinstance(max_limit, int) and 0 < max_limit < page_size:
        page_size = max_limit

    req = [p for p in params if p["required"]]
    ex_params = " ".join(f"--param {p['name']}={_sample(p['type'])}" for p in req)
    ex_code_params = ", ".join(f"{p['name']!r}: {_sample(p['type'])!r}" for p in req)
    ex_filter = f"--filter {filters[0]}=eq:VALUE " if filters else ""
    param_lines = "\n".join(
        f"#   {_one_line(p['name'], 60):<28} {_one_line(p['type'], 20):<12}"
        f"{'required' if p['required'] else 'optional'}" for p in params) or "#   (none)"
    filter_lines = "\n".join(f"#   {_one_line(c, 80)}" for c in filters) or "#   (none -- this API takes no filters)"

    head = f'''#!/usr/bin/env python3
"""QueryStudio published API client -- {_one_line(meta.get("name") or slug)} ({_one_line(slug, 80)}).

Made by QueryStudio on {when} for {_one_line(base, 200)}.
Copy this file as {fname}.  Needs Python 3.8+ and `requests`
(pip install requests).  Optional: `cryptography` (sends your AD password encrypted, as the
web page does), `pandas` (DataFrames), `pyarrow` (Parquet files).

SIGN IN -- set ONE of these in the environment (never write a password in a file):
    QS_API_KEY=<key>                              an API key for this API
    QS_USERNAME=<DOMAIN\\\\user>  QS_PASSWORD=<password>   your AD login: signed in once,
                                                  the session is reused for every page
Optional: QS_BASE_URL (another server), QS_CA_BUNDLE (your company's CA file for HTTPS).

FROM THE COMMAND LINE
    python {fname} --out rows.csv {ex_params}
    python {fname} {ex_filter}--out rows.parquet {ex_params}
    python {fname} --bulk --out all.csv {ex_params}   (the whole result in one download, any size)
    python {fname} --help

IN YOUR CODE
    from {module} import QueryStudioClient
    qs = QueryStudioClient.from_env()
    rows = qs.rows(params={{{ex_code_params}}})           # a list of dicts
    df = qs.dataframe(params={{{ex_code_params}}})        # needs pandas
    qs.to_file("rows.csv", params={{{ex_code_params}}})   # .csv / .jsonl / .parquet, page by page
    for page in qs.pages(params={{{ex_code_params}}}):    # your own loop, one page at a time
        ...

WHAT IT HANDLES FOR YOU
    * paging: every page is pinned to the SAME data (dataset_version); if the data is
      refreshed while you read, it starts again (409) so you never mix two versions
    * past the paging limit (416): rows() / to_file() switch to the bulk download
    * 429 (too many calls) and 503 "being prepared": waits the seconds the server asks
    * dropped connections: retried with back-off; a bulk download resumes where it stopped
    * an expired sign-in (401): signs in again once
"""
# Parameters of this API (send with params={{...}} or --param name=value):
{param_lines}
# Columns this API can be filtered on (filters={{"column": "operator:value"}}, or --filter):
{filter_lines}
#   operators: eq, ne, gt, gte, lt, lte, in, not_in, contains, between   e.g. "in:A,B"
from __future__ import annotations

BASE_URL = {base!r}
SLUG = {slug!r}
PARAMETERS = {[(p["name"], p["type"], p["required"]) for p in params]!r}
FILTER_COLUMNS = {filters!r}
PAGE_SIZE = {page_size!r}
#: names the server keeps for itself: a parameter with one of these names is sent as param[name]
RESERVED_NAMES = frozenset({_reserved_names()!r})
'''
    return head + _BODY


# The part of the file that is the same for every API.  Kept as ONE string so a test can
# compile it and run it against a fake server (backend/tests/test_published_api_python_client_2026_11_11.py).
_BODY = r'''
import argparse
import base64
import csv
import json
import os
import random
import sys
import time
from typing import Any, Dict, Iterator, List, Optional, Tuple

import requests

__all__ = ["QueryStudioClient", "QueryStudioError", "DataChanged", "PastPagingLimit"]


class QueryStudioError(Exception):
    """The server refused the call.  ``status`` is the HTTP status, ``detail`` its answer."""

    def __init__(self, status: int, message: str, detail: Any = None, request_id: str = ""):
        self.status, self.detail, self.request_id = status, detail, request_id
        super().__init__(f"HTTP {status}: {message}" + (f" (request id {request_id})" if request_id else ""))


class DataChanged(QueryStudioError):
    """409: the data was refreshed while the pages were being read."""


class PastPagingLimit(QueryStudioError):
    """416: past the rows the paged API serves.  ``continue_with`` is the bulk address."""

    @property
    def continue_with(self) -> str:
        d = self.detail if isinstance(self.detail, dict) else {}
        return str(d.get("continue_with") or "")


def _message_of(resp: "requests.Response") -> Tuple[str, Any]:
    try:
        body = resp.json()
    except ValueError:
        return (resp.text or resp.reason or "")[:500], None
    detail = body.get("detail", body) if isinstance(body, dict) else body
    if isinstance(detail, dict):
        return str(detail.get("message") or detail.get("error") or detail)[:500], detail
    return str(detail)[:500], detail


class QueryStudioClient:
    """One published API.  Thread-safe for reading; one instance per thread is simplest."""

    RETRY_STATUSES = (429, 502, 503, 504)

    def __init__(self, base_url: str = BASE_URL, *, api_key: Optional[str] = None,
                 username: Optional[str] = None, password: Optional[str] = None,
                 slug: str = SLUG, verify: Any = True, timeout: float = 300.0,
                 page_size: int = PAGE_SIZE, max_retries: int = 6, max_restarts: int = 3,
                 session: Optional["requests.Session"] = None, log=None):
        if not api_key and not (username and password):
            raise ValueError("Sign in with an API key (QS_API_KEY) or an AD username and "
                             "password (QS_USERNAME / QS_PASSWORD).")
        self.base_url = (base_url or "").rstrip("/")
        self.slug = slug
        self.api_key, self.username, self._password = api_key, username, password
        self.verify, self.timeout = verify, timeout
        self.page_size, self.max_retries, self.max_restarts = page_size, max_retries, max_restarts
        self.http = session or requests.Session()
        self._token: Optional[str] = None
        self._basic = False             # this server has no /auth/login: AD by HTTP Basic
        self._log = log or (lambda msg: print(msg, file=sys.stderr))

    @classmethod
    def from_env(cls, **kw) -> "QueryStudioClient":
        kw.setdefault("base_url", os.environ.get("QS_BASE_URL") or BASE_URL)
        kw.setdefault("api_key", os.environ.get("QS_API_KEY") or None)
        kw.setdefault("username", os.environ.get("QS_USERNAME") or None)
        kw.setdefault("password", os.environ.get("QS_PASSWORD") or None)
        if os.environ.get("QS_CA_BUNDLE"):
            kw.setdefault("verify", os.environ["QS_CA_BUNDLE"])
        return cls(**kw)

    # ── sign-in ──────────────────────────────────────────────────────────────
    def _auth_headers(self) -> Dict[str, str]:
        if self.api_key:
            return {"X-API-Key": self.api_key}
        if self._basic:
            raw = f"{self.username}:{self._password}".encode("utf-8")
            return {"Authorization": "Basic " + base64.b64encode(raw).decode("ascii")}
        if not self._token:
            self._sign_in()
        if self._basic:
            return self._auth_headers()
        return {"Authorization": f"Bearer {self._token}"}

    def _encrypted(self, fresh: bool = False) -> Optional[Dict[str, str]]:
        """The password encrypted under the server's login key, or None (no `cryptography`,
        or the server has no key) -- then it is sent as typed, over HTTPS."""
        try:
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import padding
        except ImportError:
            return None
        r = self.http.get(f"{self.base_url}/auth/public-key", timeout=self.timeout, verify=self.verify,
                          headers={"Cache-Control": "no-cache"} if fresh else {})
        if r.status_code != 200:
            return None
        body = r.json()
        key = serialization.load_pem_public_key(body["public_key_pem"].encode("ascii"))
        cipher = key.encrypt(self._password.encode("utf-8"), padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
        return {"password_encrypted": base64.b64encode(cipher).decode("ascii"),
                "key_fingerprint": body.get("fingerprint") or ""}

    def _sign_in(self) -> None:
        for attempt in range(3):
            enc = self._encrypted(fresh=attempt > 0)
            body: Dict[str, Any] = {"username": self.username}
            body.update(enc or {"password": self._password})
            r = self._send("POST", f"{self.base_url}/auth/login", json=body, auth=False)
            if r.status_code == 404:
                self._basic = True          # this pod has no sign-in route: the API takes AD by Basic
                return
            if r.status_code == 400 and "login_crypto_stale_key" in r.text:
                continue                    # the server's key changed (a restart): fetch it again
            if r.status_code == 401:
                raise QueryStudioError(401, "the username or password was not accepted")
            if r.status_code >= 400:
                msg, detail = _message_of(r)
                raise QueryStudioError(r.status_code, f"sign-in failed: {msg}", detail)
            self._token = r.json()["session_token"]
            return
        raise QueryStudioError(400, "sign-in failed: the server's login key kept changing")

    def close(self) -> None:
        """Sign out (an AD session) and close the connection pool."""
        if self._token:
            try:
                self.http.post(f"{self.base_url}/auth/logout", timeout=30, verify=self.verify,
                               headers={"Authorization": f"Bearer {self._token}"})
            except requests.RequestException:
                pass
            self._token = None
        self.http.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # ── one call, with the server's retry rules ─────────────────────────────
    def _wait(self, attempt: int, retry_after: Optional[str]) -> None:
        try:
            secs = float(retry_after) if retry_after else None
        except ValueError:
            secs = None
        if secs is None:
            secs = min(60.0, 2.0 ** attempt) + random.uniform(0, 1)
        time.sleep(max(0.0, min(secs, 600.0)))

    def _send(self, method: str, url: str, *, params=None, json=None, stream=False,
              auth=True, headers=None) -> "requests.Response":
        relogged = False
        attempt = 0
        while True:
            hdrs = dict(headers or {})
            if auth:
                hdrs.update(self._auth_headers())
            try:
                r = self.http.request(method, url, params=params, json=json, headers=hdrs,
                                      stream=stream, timeout=self.timeout, verify=self.verify)
            except (requests.ConnectionError, requests.Timeout) as exc:
                if attempt >= self.max_retries:
                    raise
                self._log(f"[qs] {type(exc).__name__}; retrying ({attempt + 1}/{self.max_retries})")
                self._wait(attempt, None)
                attempt += 1
                continue
            if r.status_code == 401 and auth and self._token and not relogged:
                r.close()
                self._token, relogged = None, True      # the session expired: sign in again, once
                continue
            if r.status_code in self.RETRY_STATUSES and attempt < self.max_retries:
                ra = r.headers.get("Retry-After")
                if r.status_code == 429 or ra:          # a 503 with no Retry-After is "switched off"
                    self._log(f"[qs] HTTP {r.status_code}; waiting {ra or 'a little'} s and trying again")
                    r.close()
                    self._wait(attempt, ra)
                    attempt += 1
                    continue
            return r

    def _check(self, r: "requests.Response") -> "requests.Response":
        if r.status_code < 400:
            return r
        msg, detail = _message_of(r)
        rid = r.headers.get("X-QS-Request-ID") or r.headers.get("X-Request-ID") or ""
        if r.status_code == 409:
            raise DataChanged(409, msg, detail, rid)
        if r.status_code == 416:
            raise PastPagingLimit(416, msg, detail, rid)
        if r.status_code == 401:
            msg = "not signed in, or the API key is not valid: " + msg
        elif r.status_code == 403:
            msg = "you may not use this API (ask its owner for access): " + msg
        elif r.status_code == 404:
            msg = "this API was not found, or it is switched off: " + msg
        raise QueryStudioError(r.status_code, msg, detail, rid)

    # ── the question ────────────────────────────────────────────────────────
    @staticmethod
    def build_query(params: Optional[Dict[str, Any]] = None, filters: Optional[Dict[str, Any]] = None,
                    columns: Optional[List[str]] = None, sort: Optional[str] = None) -> List[Tuple[str, str]]:
        """The query string: parameters by name (a list = several values), filter.<col>=op:value."""
        q: List[Tuple[str, str]] = []
        for name, value in (params or {}).items():
            key = f"param[{name}]" if name in RESERVED_NAMES else str(name)
            values = value if isinstance(value, (list, tuple, set)) else [value]
            for v in values:
                q.append((key, "" if v is None else str(v)))
        for col, cond in (filters or {}).items():
            q.append((f"filter.{col}", str(cond)))
        if columns:
            q.append(("columns", ",".join(columns)))
        if sort:
            q.append(("sort", sort))
        return q

    def meta(self) -> Dict[str, Any]:
        """What this API is: its columns, parameters, filters and limits."""
        return self._check(self._send("GET", f"{self.base_url}/api/v1/views/{self.slug}")).json()

    def pages(self, params=None, filters=None, columns=None, sort=None,
              page_size: Optional[int] = None) -> Iterator[Dict[str, Any]]:
        """Each page's answer (``data``, ``columns``, ``pagination``), in order, all from the
        SAME data.  Raises DataChanged (409) or PastPagingLimit (416) -- rows() / to_file()
        handle both; your own loop may catch them."""
        url = f"{self.base_url}/api/v1/views/{self.slug}/data"
        base_q = self.build_query(params, filters, columns, sort)
        size = int(page_size or self.page_size)
        offset, version = 0, None
        while True:
            q = base_q + [("limit", str(size)), ("offset", str(offset))]
            if version:
                q.append(("dataset_version", version))
            body = self._check(self._send("GET", url, params=q)).json()
            yield body
            page = body.get("pagination") or {}
            version = version or page.get("dataset_version")
            if not page.get("has_more"):
                return
            nxt = page.get("next_offset")
            offset = int(nxt) if nxt is not None else offset + len(body.get("data") or [])

    def _restarting(self, run, what: str):
        """run() again from the first page when the data changes mid-read (409)."""
        for attempt in range(self.max_restarts + 1):
            try:
                return run()
            except DataChanged:
                if attempt >= self.max_restarts:
                    raise
                self._log(f"[qs] the data was refreshed while reading {what}; starting again")

    def rows(self, params=None, filters=None, columns=None, sort=None) -> List[Dict[str, Any]]:
        """Every row as a list of dicts (past the paging limit: through the bulk download)."""
        def run():
            out: List[Dict[str, Any]] = []
            try:
                for page in self.pages(params, filters, columns, sort):
                    out.extend(_as_dicts(page))
            except PastPagingLimit:
                self._log("[qs] more rows than pages can serve; reading the bulk download")
                return list(self.bulk_rows(params, filters, columns))
            return out
        return self._restarting(run, "pages")

    def dataframe(self, params=None, filters=None, columns=None, sort=None):
        """Every row as a pandas DataFrame (needs pandas)."""
        import pandas as pd
        return pd.DataFrame(self.rows(params, filters, columns, sort))

    # ── the whole result in one download ────────────────────────────────────
    def bulk_rows(self, params=None, filters=None, columns=None) -> Iterator[Dict[str, Any]]:
        """Every row from /bulk as JSON lines, streamed (memory stays one row deep); resumes
        after a dropped connection where it stopped."""
        url = f"{self.base_url}/api/v1/views/{self.slug}/bulk"
        base_q = self.build_query(params, filters, columns) + [("format", "jsonl")]
        got, version, tries = 0, None, 0
        while True:
            q = list(base_q)
            if got:
                q += [("offset", str(got)), ("dataset_version", version or "")]
            r = self._check(self._send("GET", url, params=q, stream=True))
            version = version or r.headers.get("X-QS-Dataset-Version")
            start = int(r.headers.get("X-QS-Row-Offset") or got)
            expected = r.headers.get("X-QS-Expected-Rows")
            n = 0
            try:
                for line in r.iter_lines():
                    if line:
                        n += 1
                        yield json.loads(line)
            except (requests.ConnectionError, requests.exceptions.ChunkedEncodingError) as exc:
                tries += 1
                if tries > self.max_retries:
                    raise
                got = start + n
                self._log(f"[qs] the download stopped at row {got:,} ({type(exc).__name__}); resuming")
                continue
            finally:
                r.close()
            if expected is not None and n < int(expected):
                tries += 1
                if tries > self.max_retries:
                    raise QueryStudioError(200, f"the download ended early: {n:,} of {expected} rows")
                got = start + n
                continue
            return

    def bulk_to_file(self, path: str, params=None, filters=None, columns=None, fmt: Optional[str] = None) -> int:
        """The whole result straight to a file (csv / jsonl / parquet / arrow) -- the server writes
        it, nothing is held in memory.  Returns the bytes written."""
        fmt = (fmt or os.path.splitext(path)[1].lstrip(".") or "csv").lower()
        url = f"{self.base_url}/api/v1/views/{self.slug}/bulk"
        q = self.build_query(params, filters, columns) + [("format", fmt)]
        part = path + ".part"
        for attempt in range(self.max_retries + 1):
            r = self._check(self._send("GET", url, params=q, stream=True))
            try:
                size = 0
                with open(part, "wb") as fh:
                    for chunk in r.iter_content(chunk_size=1 << 20):
                        if chunk:
                            fh.write(chunk)
                            size += len(chunk)
                os.replace(part, path)
                return size
            except (requests.ConnectionError, requests.exceptions.ChunkedEncodingError) as exc:
                if attempt >= self.max_retries:
                    raise
                self._log(f"[qs] the download stopped ({type(exc).__name__}); starting it again")
                self._wait(attempt, None)
            finally:
                r.close()
        raise QueryStudioError(0, "the download did not finish")

    # ── page by page to a file ──────────────────────────────────────────────
    def to_file(self, path: str, params=None, filters=None, columns=None, sort=None) -> int:
        """Every row to ``path`` (.csv / .jsonl / .parquet), one page in memory at a time;
        written to ``path.part`` and renamed when complete.  Returns the rows written."""
        ext = os.path.splitext(path)[1].lower()
        if ext not in (".csv", ".jsonl", ".parquet"):
            raise ValueError("write .csv, .jsonl or .parquet (or use bulk_to_file for .arrow)")
        part = path + ".part"

        def run() -> int:
            writer = _Writer(part, ext)
            try:
                for page in self.pages(params, filters, columns, sort):
                    writer.write(page)
                    self._log(f"[qs] {writer.rows:,} rows")
            except PastPagingLimit:
                writer.close()
                os.remove(part)
                self._log("[qs] more rows than pages can serve; downloading the whole result")
                self.bulk_to_file(path, params, filters, columns,
                                  fmt={".csv": "csv", ".jsonl": "jsonl", ".parquet": "parquet"}[ext])
                return -1
            writer.close()
            os.replace(part, path)
            return writer.rows
        return self._restarting(run, "pages")


def _as_dicts(page: Dict[str, Any]) -> List[Dict[str, Any]]:
    data = page.get("data") or []
    if data and not isinstance(data[0], dict):
        names = [c.get("name") if isinstance(c, dict) else c for c in page.get("columns") or []]
        return [dict(zip(names, row)) for row in data]
    return data


class _Writer:
    """Appends pages to one file.  Opening truncates, so a restart (409) begins clean."""

    def __init__(self, path: str, ext: str):
        self.path, self.ext, self.rows = path, ext, 0
        self._fh = open(path, "w", newline="", encoding="utf-8") if ext != ".parquet" else None
        self._csv = None
        self._pq = None
        self._schema = None

    def write(self, page: Dict[str, Any]) -> None:
        rows = _as_dicts(page)
        if self.ext == ".jsonl":
            for row in rows:
                self._fh.write(json.dumps(row, default=str) + "\n")
        elif self.ext == ".csv":
            if self._csv is None:
                names = [c.get("name") if isinstance(c, dict) else c for c in page.get("columns") or []]
                names = names or (list(rows[0].keys()) if rows else [])
                self._csv = csv.DictWriter(self._fh, fieldnames=names, extrasaction="ignore")
                self._csv.writeheader()
            self._csv.writerows(rows)
        elif rows:
            import pyarrow as pa
            import pyarrow.parquet as pq
            if self._schema is None:
                t = pa.Table.from_pylist(rows)
                # a column that is empty on the first page is typed by nothing: keep it text
                self._schema = pa.schema([pa.field(f.name, pa.string() if pa.types.is_null(f.type) else f.type)
                                          for f in t.schema])
                self._pq = pq.ParquetWriter(self.path, self._schema)
            self._pq.write_table(pa.Table.from_pylist(rows, schema=self._schema))
        self.rows += len(rows)

    def close(self) -> None:
        if self._fh:
            self._fh.close()
            self._fh = None
        if self._pq:
            self._pq.close()
            self._pq = None
        elif self.ext == ".parquet" and self._schema is None and not os.path.exists(self.path):
            open(self.path, "wb").close()


# ── command line ────────────────────────────────────────────────────────────
def _pairs(items: List[str], what: str) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for item in items or []:
        name, sep, value = item.partition("=")
        if not sep or not name:
            raise SystemExit(f"--{what} takes name=value, got {item!r}")
        if name in out:                      # repeated: several values
            out[name] = (out[name] if isinstance(out[name], list) else [out[name]]) + [value]
        else:
            out[name] = value
    return out


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=f"Read the QueryStudio published API {SLUG!r}.")
    ap.add_argument("--out", required=True, help="file to write: .csv, .jsonl or .parquet (with --bulk also .arrow)")
    ap.add_argument("--param", action="append", default=[], metavar="NAME=VALUE",
                    help="a parameter; repeat a name for several values")
    ap.add_argument("--filter", action="append", default=[], metavar="COLUMN=OP:VALUE",
                    help="e.g. region=eq:EMEA, amount=gt:100, book=in:B1,B2")
    ap.add_argument("--columns", help="comma-separated columns to return")
    ap.add_argument("--sort", help="e.g. -amount (pages only)")
    ap.add_argument("--bulk", action="store_true", help="one download of the whole result (any size)")
    ap.add_argument("--page-size", type=int, default=PAGE_SIZE)
    ap.add_argument("--base-url", default=os.environ.get("QS_BASE_URL") or BASE_URL)
    a = ap.parse_args(argv)
    try:
        qs = QueryStudioClient.from_env(base_url=a.base_url, page_size=a.page_size)
    except ValueError as exc:
        print(exc, file=sys.stderr)
        return 2
    cols = [c.strip() for c in a.columns.split(",")] if a.columns else None
    params, filters = _pairs(a.param, "param"), _pairs(a.filter, "filter")
    started = time.time()
    try:
        with qs:
            if a.bulk:
                size = qs.bulk_to_file(a.out, params, filters, cols)
                print(f"wrote {a.out} ({size:,} bytes) in {time.time() - started:.1f}s")
            else:
                n = qs.to_file(a.out, params, filters, cols, a.sort)
                print(f"wrote {a.out}" + (f" ({n:,} rows)" if n >= 0 else "") + f" in {time.time() - started:.1f}s")
    except QueryStudioError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
'''
