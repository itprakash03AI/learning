"""THE Jira connection (2026-10-31) -- one REST client for the change check
(core/feed/jira_link.py ``get_ticket``) and for alerts (core/feed/jira_sender.py).

REST API v2 on both flavours: Jira Server / Data Center and Jira Cloud both
accept ``/rest/api/2`` with a plain-text description and comment (v3 would
need Atlassian Document Format on Cloud only -- two shapes for one call).

The login is a System Account (``feed_generation.governance.jira.system_account``),
resolved through ``core.qs_credentials`` -- the one chokepoint every source
uses, Vault included.  ``auth``: ``bearer`` = a Server / Data Center personal
access token (the account's password); ``basic`` = Cloud (username = the
account's e-mail, password = an API token).  A 401 re-reads the account from
Vault ONCE (a rotated token heals on the next call, not after the cache TTL).

Every failure raises :class:`JiraError` with the words a support person can
act on; callers decide what a failure means (the change check: an OUTAGE
value; the sender: a retry).  Nothing here retries in a loop.
"""
from __future__ import annotations

import base64
from collections.abc import Callable, Mapping
from typing import Any

AUTH_BEARER = "bearer"
AUTH_BASIC = "basic"


class JiraError(RuntimeError):
    """Jira could not do what was asked; ``status`` is the HTTP code (None = no answer)."""

    def __init__(self, message: str, status: int | None = None) -> None:
        super().__init__(message)
        self.status = status


def load_config() -> dict:
    """The declared ``feed_generation.governance.jira`` block (every key read
    here is declared in core/config.py)."""
    from core import config as _config
    gov = _config.get("feed_generation", "governance", {}) or {}
    raw = gov.get("jira", {}) or {}
    alerts = raw.get("alerts", {}) or {}
    return {
        "enabled": bool(raw.get("enabled", False)),
        "base_url": str(raw.get("base_url") or "").rstrip("/"),
        "auth": str(raw.get("auth") or AUTH_BEARER).strip().lower(),
        "system_account": str(raw.get("system_account") or "").strip(),
        "timeout_seconds": float(raw.get("timeout_seconds", 10)),
        "alerts": {
            "enabled": bool(alerts.get("enabled", False)),
            "project": str(alerts.get("project") or "").strip(),
            "issue_type": str(alerts.get("issue_type") or "Task"),
            "priority_by_severity": {str(k): str(v) for k, v in
                                     (alerts.get("priority_by_severity") or {}).items()},
            "labels": [str(x) for x in (alerts.get("labels") or [])],
            "resolve_transition": str(alerts.get("resolve_transition") or ""),
            "reopen_transition": str(alerts.get("reopen_transition") or ""),
            "poll_interval_seconds": float(alerts.get("poll_interval_seconds", 15)),
            "batch_size": max(1, int(alerts.get("batch_size", 50))),
            "max_attempts": max(1, int(alerts.get("max_attempts", 6))),
            "retry_backoff_seconds": float(alerts.get("retry_backoff_seconds", 60)),
        },
    }


def connection_refusal(cfg: Mapping[str, Any]) -> str | None:
    """Why no client can be built from this config, in plain words; None = it can."""
    if not cfg.get("base_url"):
        return "Jira is not set up: no address (feed_generation.governance.jira.base_url)."
    if cfg.get("auth") not in (AUTH_BEARER, AUTH_BASIC):
        return (f"Jira login type {cfg.get('auth')!r} is not known: use 'bearer' (Jira Server / "
                f"Data Center token) or 'basic' (Jira Cloud e-mail + API token).")
    if not cfg.get("system_account"):
        return ("Jira has no login: choose the System Account that holds it "
                "(feed_generation.governance.jira.system_account).")
    return None


def _account_creds(name: str, *, fresh: bool = False) -> dict:
    from core import qs_credentials as qc
    return qc.refresh(name) if fresh else qc.resolve_system_account(name)


class JiraRestClient:
    """``get_ticket`` / ``create_issue`` / ``add_comment`` / ``transition``.

    ``creds_fn(fresh: bool) -> {"username", "password"}`` and
    ``client_factory() -> httpx.Client`` are seams (tests inject fakes; the
    rig points ``base_url`` at its Jira stand-in)."""

    def __init__(self, base_url: str, *, auth: str, creds_fn: Callable[[bool], Mapping[str, Any]],
                 timeout: float = 10.0, client_factory: Callable | None = None) -> None:
        self._base = base_url.rstrip("/")
        self._auth = auth
        self._creds_fn = creds_fn
        self._timeout = timeout
        self._client_factory = client_factory

    # ── HTTP ──────────────────────────────────────────────────────────────
    def _headers(self, creds: Mapping[str, Any]) -> dict:
        h = {"Accept": "application/json", "Content-Type": "application/json"}
        if self._auth == AUTH_BASIC:
            raw = f"{creds.get('username') or ''}:{creds.get('password') or ''}".encode()
            h["Authorization"] = "Basic " + base64.b64encode(raw).decode()
        else:
            h["Authorization"] = f"Bearer {creds.get('password') or ''}"
        return h

    def _call(self, method: str, path: str, body: Mapping[str, Any] | None = None, *,
              files: Mapping[str, Any] | None = None):
        import httpx
        factory = self._client_factory or (lambda: httpx.Client(timeout=self._timeout))
        url = f"{self._base}{path}"
        for fresh in (False, True):
            try:
                creds = self._creds_fn(fresh)
            except Exception as exc:                    # noqa: BLE001 -- a missing account is words
                raise JiraError(f"the Jira login could not be read: {exc}") from exc
            if not (creds or {}).get("password"):
                # an unreadable secret comes back EMPTY (core.crypto.decrypt_value
                # returns "" on a key mismatch); sending "Bearer " is a call that
                # cannot log in -- read it again once, then refuse in words
                if not fresh:
                    continue
                raise JiraError("the Jira login could not be read: the System Account holds no readable "
                                "token or password (empty, or it could not be decrypted with this pod's key) "
                                "-- nothing was sent to Jira")
            try:
                with factory() as client:
                    resp = self._send(client, method, url, creds, body, files)
            except Exception as exc:                    # noqa: BLE001 -- network: no answer
                raise JiraError(f"Jira did not answer ({type(exc).__name__}: {exc})") from exc
            if resp.status_code != 401:
                return resp
            # a 401: the token may have been rotated -- read it from Vault again, once
        raise JiraError("Jira refused the login (401) twice -- the token in the System Account "
                        "is wrong or expired", 401)

    def _send(self, client, method: str, url: str, creds: Mapping[str, Any],
              body: Mapping[str, Any] | None, files: Mapping[str, Any] | None):
        if files is None:
            return client.request(method, url, headers=self._headers(creds),
                                  json=dict(body) if body is not None else None)
        # an attachment: multipart (the encoder sets its own Content-Type), and
        # Jira's XSRF check wants X-Atlassian-Token on every multipart POST
        headers = {k: v for k, v in self._headers(creds).items() if k != "Content-Type"}
        headers["X-Atlassian-Token"] = "no-check"
        return client.request(method, url, headers=headers, files=dict(files))

    @staticmethod
    def _detail(resp) -> str:
        try:
            j = resp.json()
            msgs = list(j.get("errorMessages") or []) + [f"{k}: {v}" for k, v in
                                                         (j.get("errors") or {}).items()]
            return "; ".join(msgs)[:300] or resp.text[:300]
        except Exception:                               # noqa: BLE001
            return (resp.text or "")[:300]

    def _ok(self, resp, what: str):
        if 200 <= resp.status_code < 300:
            return resp
        raise JiraError(f"Jira answered {resp.status_code} to {what}: {self._detail(resp)}",
                        resp.status_code)

    # ── the four calls ────────────────────────────────────────────────────
    def get_ticket(self, key: str) -> dict | None:
        """{"key", "status"} or None when Jira says it does not exist (the
        change check's contract); any other failure raises (= an outage)."""
        resp = self._call("GET", f"/rest/api/2/issue/{key}?fields=status")
        if resp.status_code == 404:
            return None
        j = self._ok(resp, f"reading {key}").json()
        return {"key": j.get("key") or key,
                "status": ((j.get("fields") or {}).get("status") or {}).get("name")}

    def create_issue(self, *, project: str, issue_type: str, summary: str, description: str,
                     priority: str | None = None, labels: list[str] | None = None) -> str:
        fields: dict[str, Any] = {"project": {"key": project}, "issuetype": {"name": issue_type},
                                  "summary": summary[:250], "description": description}
        if priority:
            fields["priority"] = {"name": priority}
        if labels:
            fields["labels"] = [str(x).replace(" ", "_") for x in labels]
        resp = self._ok(self._call("POST", "/rest/api/2/issue", {"fields": fields}),
                        f"opening an issue in {project}")
        key = (resp.json() or {}).get("key")
        if not key:
            raise JiraError("Jira opened an issue but did not say its key")
        return str(key)

    def find_by_label(self, label: str) -> str | None:
        """The key of the issue carrying ``label`` (the alert's own label), or
        None.  What makes a retried "open the issue" safe: an issue Jira opened
        whose key we failed to store is FOUND, never opened twice."""
        from urllib.parse import quote
        jql = quote(f'labels = "{label}" ORDER BY created ASC')
        # 2026-11-08, found on the owner's real Jira Cloud site: Atlassian REMOVED
        # /rest/api/2/search there (410 "migrate to /rest/api/3/search/jql"), so every
        # retried open raised instead of finding the issue.  Cloud's search is asked
        # first; a server that does not have it (404: Jira Data Center / Server) is
        # asked the v2 search it does have.  Any other answer is the failure it is.
        resp = self._call("GET", f"/rest/api/3/search/jql?jql={jql}&maxResults=1&fields=key")
        if resp.status_code == 404:
            resp = self._call("GET", f"/rest/api/2/search?jql={jql}&maxResults=1&fields=key")
        resp = self._ok(resp, f"searching for the issue labelled {label}")
        issues = (resp.json() or {}).get("issues") or []
        return str(issues[0]["key"]) if issues else None

    def add_comment(self, key: str, text: str) -> None:
        self._ok(self._call("POST", f"/rest/api/2/issue/{key}/comment", {"body": text}),
                 f"commenting on {key}")

    # ── the release pipeline's three (2026-11-10, scripts/release_pipeline.py) ──
    def get_issue(self, key: str, *, fields: str = "status,attachment", expand: str = "") -> dict | None:
        """The issue's ``fields`` (+ ``changelog`` when expanded), or None when
        Jira says it does not exist; any other failure raises."""
        q = f"?fields={fields}" + (f"&expand={expand}" if expand else "")
        resp = self._call("GET", f"/rest/api/2/issue/{key}{q}")
        if resp.status_code == 404:
            return None
        return self._ok(resp, f"reading {key}").json() or {}

    def attachment_names(self, key: str) -> list[str]:
        """The file names already attached -- what makes a retried attach safe."""
        j = self.get_issue(key, fields="attachment")
        if j is None:
            raise JiraError(f"issue {key} does not exist", 404)
        return [str(a.get("filename") or "") for a in ((j.get("fields") or {}).get("attachment") or [])]

    def attach(self, key: str, filename: str, content: bytes) -> None:
        """Attach ``content`` as ``filename`` (multipart; Jira's ``X-Atlassian-Token: no-check``)."""
        self._ok(self._call("POST", f"/rest/api/2/issue/{key}/attachments",
                            files={"file": (filename, content, "application/octet-stream")}),
                 f"attaching {filename} to {key}")

    def status_history(self, key: str) -> list[dict]:
        """Every status change of the issue, oldest first:
        ``{"to": status, "by": who, "at": when}`` -- ``by`` is the author's
        account name, e-mail or display name, whichever Jira gives (Cloud hides
        the name, Server hides the account id).  A release approval that must
        be a PERSON's reads this (RELEASE_APPROVAL_MODE=jira)."""
        j = self.get_issue(key, fields="status", expand="changelog")
        if j is None:
            raise JiraError(f"issue {key} does not exist", 404)
        out: list[dict] = []
        for h in ((j.get("changelog") or {}).get("histories") or []):
            a = h.get("author") or {}
            who = a.get("name") or a.get("emailAddress") or a.get("displayName") or a.get("accountId") or ""
            for it in h.get("items") or []:
                if str(it.get("field", "")).lower() == "status":
                    out.append({"to": str(it.get("toString") or ""), "by": str(who), "at": str(h.get("created") or ""),
                                # the IDENTITY, for a comparison a display name cannot carry: Cloud's
                                # accountId (it hides name and e-mail), Server's key / name
                                "by_id": str(a.get("accountId") or a.get("key") or a.get("name") or ""),
                                "by_email": str(a.get("emailAddress") or "")})
        return out

    def myself(self) -> dict:
        """Who this client logs in as: ``{"account_id", "name", "email", "display_name"}``
        (``/rest/api/2/myself``) -- the ids a self-approval check compares against."""
        j = self._ok(self._call("GET", "/rest/api/2/myself"), "reading who the Jira login is").json() or {}
        return {"account_id": str(j.get("accountId") or ""), "name": str(j.get("name") or j.get("key") or ""),
                "email": str(j.get("emailAddress") or ""), "display_name": str(j.get("displayName") or "")}

    def transition(self, key: str, name: str) -> bool:
        """Move ``key`` through the transition called ``name`` (case-insensitive).
        False = the issue's workflow offers no such transition now (already
        done, or another workflow) -- a fact, not an error."""
        resp = self._ok(self._call("GET", f"/rest/api/2/issue/{key}/transitions"),
                        f"reading the transitions of {key}")
        want = name.strip().lower()
        tid = next((t.get("id") for t in (resp.json() or {}).get("transitions") or []
                    if str(t.get("name", "")).strip().lower() == want), None)
        if tid is None:
            return False
        self._ok(self._call("POST", f"/rest/api/2/issue/{key}/transitions",
                            {"transition": {"id": str(tid)}}), f"moving {key} to {name!r}")
        return True


def client_from_config(cfg: Mapping[str, Any] | None = None) -> JiraRestClient:
    """The deployment's client, or :class:`JiraError` with the refusal."""
    cfg = cfg if cfg is not None else load_config()
    reason = connection_refusal(cfg)
    if reason:
        raise JiraError(reason)
    account = cfg["system_account"]
    return JiraRestClient(cfg["base_url"], auth=cfg["auth"],
                          creds_fn=lambda fresh: _account_creds(account, fresh=fresh),
                          timeout=cfg["timeout_seconds"])
