"""A template's MEMBER LIST comes from the table's PARTITIONS (2026-11-10).

The owner (2026-11-09): "i have 2 query on fact_tetb and fact_tetb_ext ...
these two table has 3 partitions so per business date, code and business
event i have around 6000 files on Month end basis.  now clone one by one
very time consuming ... you dont have to read 40 million".

A template may DECLARE a partition source (``feed_templates.partition_source``):

    {"connection_id": 7, "table": "fact_tetb",
     "member_columns": {"SYSTEM_ENTITY": "code", "EventCode": "business_event"},
     "date_column": "business_close_date"}

At each SOD pass (``core/feed/sod_generator.py``), for every such template in
the pass's scope, the (code, business_event) values that EXIST for the
template's business date are read from the Iceberg METADATA of the declared
table -- metadata.json, the manifest list, and only the data manifests whose
partition summary cannot rule the date out; never a data file -- and:

  * a pair with NO ACTIVE MEMBER FEED is created through the template's
    ordinary apply (the auto-onboarding road: every authoring rule, the
    dependency declarations, the group rule) and THEN joins the matrix --
    never a matrix row without its feed (a killed apply is healed by the
    next pass);
  * SOD's own per-feed decision asks :func:`gate`: a member whose pair HAS a
    partition for the date gets its run (born WAITING on its dependencies as
    every run is); a member THE SCAN PRODUCED whose pair has none gets no run,
    said on the per-(template, date, run date) record
    (``feed_template_partition_scans``); a member a person or a message
    produced keeps the ordinary schedule rules -- the scan GROWS and ADMITS,
    it never suppresses what it did not make;
  * any file OF the date the metadata cannot judge -- an undecodable date, a
    member value that is neither an identity partition value nor equal
    bounds, a manifest whose partition spec cannot be resolved -- makes the
    scan UNREADABLE: nothing made for that template, the record says why, the
    SOD result counts an error, the template creator's bell rings.  Unknown
    is never "no partitions".

The RESTATEMENT window (``core/feed/restatement.py``, a policy row the
template MUST have) decides how long a date's member set is re-read: inside
it the set can only grow.  Growth is done under ONE per-template claim
(``template_claim`` / ``try_claim``) that every producer of members takes.
"""
from __future__ import annotations

import logging
import re
import threading
import time
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any, Callable, Dict, Iterator, List, Mapping, Optional, Sequence, Tuple

from core.feed import iceberg_commit_source as _ics
from core.feed.feed_template import member_key
from core.feed.iceberg_commit_source import CommitUnreadable, _current_schema
from core.feed.sql_tokens import UnsafeTokenValue, validate_token_value

logger = logging.getLogger(__name__)

DECLARATION_FIELD = "partition_source"

STATUS_FOUND, STATUS_NONE, STATUS_UNREADABLE, STATUS_IN_PROGRESS = "found", "none", "unreadable", "in_progress"
#: the gate's three words, read by SOD
PRESENT, ABSENT, UNREADABLE = "present", "absent", "unreadable"
#: who produced a member (feed_configs.member_origin)
ORIGIN_SCAN, ORIGIN_MESSAGE, ORIGIN_AUTHORED = "partition_scan", "message", "authored"

#: member keys kept on the record per list -- a SAMPLE; the counts are exact
KEYS_KEPT = 200
#: the walk's ceiling comes from the commit source's declared key
MAX_FILES_KEY = ("feed_generation", "dependency_iceberg_commit", "max_files_inspected")
DEFAULT_MAX_FILES = 200000
#: the transforms under which a partition value IS the column's date
DATE_TRANSFORMS = ("identity", "day")
#: the windows a partition-driven template may declare (a computable close)
EXPLICIT_WINDOWS = ("workdays", "days", "next_business_date")

#: the per-template growth claim (system_settings): one producer at a time
CLAIM_KEY_PREFIX = "feed_template.grow.claim."
CLAIM_STALE_SECONDS = 900.0
#: a long apply refreshes its claim this often (``refresh_claim``), so a
#: 6,000-member apply past CLAIM_STALE_SECONDS is never taken over mid-way
CLAIM_HEARTBEAT_SECONDS = 60.0
#: the holder record when the claim row could not be READ: unknown is not free
CLAIM_UNKNOWN_OWNER = "unknown"
#: "not given" for an optional argument whose None means something
_ABSENT = object()
#: 2026-11-10 (third review) -- the TOKEN of the claim THIS context holds.
#: ``owner_id()`` is host:pid:thread and every request on a pod runs on the
#: one event-loop thread, so an owner string cannot tell two requests apart:
#: identity is the per-holder token (uuid in the claim row); re-entry, the
#: heartbeat and the release are token-checked.  Set by the holder in ITS
#: context (``template_claim`` in a thread; the route's ``_hold_claim`` in a
#: coroutine) -- asyncio copies it into tasks and ``to_thread`` workers, so a
#: nested apply re-enters and a background apply INHERITS it.
_claim_token: ContextVar = ContextVar("feed_template_claim_token", default=None)
_EPOCH = date(1970, 1, 1)
_COMPACT_DATE = re.compile(r"^\d{8}$")

#: a file's verdict for the business date (``_file_date``)
OF_DATE, NOT_OF_DATE, DATE_UNKNOWN, DATE_SPANS = "of", "not", "unknown", "spans"


class _Null:
    """A partition value the metadata KNOWS is NULL (the key is present, the
    value is null) -- judged, never 'could not be read' (2026-11-10 review)."""
    __slots__ = ()

    def __repr__(self) -> str:
        return "NULL"


NULL = _Null()


class ClaimUnreadable(RuntimeError):
    """The growth claim row could not be read: the claim's state is UNKNOWN,
    which is never 'free'."""


# ── the declaration ───────────────────────────────────────────────────────

def declaration_problem(template: Mapping[str, Any]) -> Optional[str]:
    """Why the template's ``partition_source`` cannot be used, or None.
    Shape only; :func:`registration_problem` and :func:`check_declaration`
    ask the connection and the table."""
    ps = template.get(DECLARATION_FIELD)
    if not ps:
        return "no partition_source declaration"
    if not isinstance(ps, Mapping):
        return "partition_source must be an object"
    try:
        cid = int(ps.get("connection_id"))
    except (TypeError, ValueError):
        return "partition_source.connection_id must be the id of an S3 connection"
    if cid <= 0:
        return "partition_source.connection_id must be the id of an S3 connection"
    if not str(ps.get("table") or "").strip():
        return "partition_source.table must name a table registered as Iceberg on that connection"
    cols = ps.get("member_columns")
    if not isinstance(cols, Mapping) or not cols:
        return ("partition_source.member_columns must map each template parameter to a "
                "partition column, e.g. {\"SYSTEM_ENTITY\": \"code\"}")
    params = list(template.get("parameters") or [])
    missing = [p for p in params if p not in cols]
    if missing:
        return f"partition_source.member_columns does not say which column gives {missing}"
    extra = [p for p in cols if p not in params]
    if extra:
        return f"partition_source.member_columns names {extra}, which are not template parameters"
    for p, c in cols.items():
        if not isinstance(c, str) or not c.strip():
            return f"partition_source.member_columns[{p!r}] must be a column name"
    if not str(ps.get("date_column") or "").strip():
        return "partition_source.date_column must name the column the business date binds"
    return None


def registration_problem(db: Any, declaration: Mapping[str, Any]) -> Optional[str]:
    """The table must be registered as Iceberg on the connection (the same
    rule an ``iceberg_commit`` dependency declaration takes)."""
    from core.iceberg_watch_registry import resolve_registered_iceberg_table
    entry, reason = resolve_registered_iceberg_table(
        db, int(declaration["connection_id"]), str(declaration["table"]))
    return None if entry else (reason or "the table is not registered as Iceberg")


def normalised(declaration: Mapping[str, Any]) -> Dict[str, Any]:
    """The declaration as stored: ints and stripped names."""
    return {"connection_id": int(declaration["connection_id"]),
            "table": str(declaration["table"]).strip(),
            "member_columns": {str(p): str(c).strip() for p, c in declaration["member_columns"].items()},
            "date_column": str(declaration["date_column"]).strip()}


def check_declaration(db: Any, declaration: Mapping[str, Any], *,
                      s3_client_factory: Optional[Callable[[int], Any]] = None) -> Optional[str]:
    """2026-11-10 (review) -- the table's CURRENT metadata, read at create /
    PUT: every named column must be in the schema, and the date column, when
    it is a partition source, must be partitioned by ``identity`` or ``day``
    (a ``month(...)`` / ``year(...)`` / bucket transform cannot say which
    files hold ONE date -- refused in words, never guessed).  Metadata that
    cannot be read refuses the declaration too: unknown is not accepted."""
    decl = normalised(declaration)
    from core.iceberg_watch_registry import resolve_registered_iceberg_table
    entry, reason = resolve_registered_iceberg_table(db, decl["connection_id"], decl["table"])
    if entry is None:
        return reason or f"table {decl['table']!r} is not registered as Iceberg"
    try:
        client = (s3_client_factory(decl["connection_id"]) if s3_client_factory is not None
                  else _default_s3_client(db, decl["connection_id"]))
        if client is None:
            return f"the S3 client for connection {decl['connection_id']} could not be built"
        metadata = _ics._load_metadata(client, entry["bucket"], entry["table_prefix"])
    except Exception as exc:  # noqa: BLE001
        return f"the table's metadata could not be read ({exc}) -- the declaration is not accepted unread"
    schema = _current_schema(metadata)
    for col in [decl["date_column"], *decl["member_columns"].values()]:
        if _field_of(schema, col) is None:
            return f"column {col!r} is not in the table's current schema"
    specs = _all_specs(metadata)
    if not specs:
        return "the table's partition specs could not be read"
    date_fid = _fid(_field_of(schema, decl["date_column"]))
    # 2026-11-10 (second review): EVERY listed spec is judged, not only the
    # default -- a manifest written under an old spec is read under THAT spec,
    # so an old month(date) spec, or one that never partitioned the date,
    # would leave its files judged by bounds alone (unknown, the scan held)
    for s in specs:
        sid = s.get("spec-id", 0)
        date_pf = next((pf for pf in (s.get("fields") or [])
                        if (pf.get("source-id") if pf.get("source-id") is not None else pf.get("source_id")) == date_fid),
                       None)
        if date_pf is None:
            return (f"under partition spec {sid} the date column {decl['date_column']!r} is not a "
                    f"partition column -- files written under that spec hold many dates and the metadata "
                    f"cannot say which of them hold ONE business date; the member list cannot come from "
                    f"this table's partitions until every spec partitions the date (identity or day)")
        if str(date_pf.get("transform") or "").lower() not in DATE_TRANSFORMS:
            return (f"under partition spec {sid} the date column {decl['date_column']!r} is partitioned by "
                    f"{date_pf.get('transform')}(...) -- only an identity or day partition says which "
                    f"files hold ONE business date; declare a column partitioned that way")
    return None


def _all_specs(metadata: Mapping[str, Any]) -> List[Mapping[str, Any]]:
    """Every partition spec the metadata lists (v1 single spec = id 0)."""
    specs = metadata.get("partition-specs") or []
    if not specs and "partition-spec" in metadata:
        ps = metadata["partition-spec"]
        specs = [{"spec-id": 0, "fields": ps}] if isinstance(ps, list) else [ps]
    return [s for s in specs if isinstance(s, Mapping)]


def window_problem(db: Any, template_like: Mapping[str, Any]) -> Optional[str]:
    """2026-11-10 (review) -- a partition-driven template REQUIRES an explicit
    restatement window on its scope chain (template / feed group / global):
    ``workdays`` N, ``days`` N or ``next_business_date``.  ``open`` or no row
    is refused in words: the window is what decides how long a month end's
    member set is re-read, and "until the next WD1" by default would re-read
    for a month."""
    from core.feed import restatement
    fc = template_feed_shape(template_like)
    policy = restatement.policy_for(db, fc)
    w = str(policy.get("window") or "open")
    if policy.get("id") is None or w not in EXPLICIT_WINDOWS:
        return ("a template whose members come from the table's partitions needs an explicit "
                "re-send window: in Feed Run Status -> Alerts & re-sends, map a re-send policy to "
                "this template (or its feed group, or globally) with window 'For work days WD1..WDn' "
                "(workdays), 'Days' or 'Until the next business date' -- 'open' is not a window")
    if w == "workdays" and not int(policy.get("window_workdays") or 0):
        return "the re-send policy's window is 'workdays' but window_workdays is not set"
    if w == "days" and not int(policy.get("window_days") or 0):
        return "the re-send policy's window is 'days' but window_days is not set"
    return None


# ── the read: partition values from the metadata, no data read ────────────

@dataclass
class PartitionRead:
    snapshot_id: Optional[str]
    #: {tuple of column values (member column order): {"files": n, "rows": n | None}}
    pairs: Dict[Tuple[str, ...], Dict[str, Any]]
    files_seen: int = 0
    manifests_total: int = 0
    manifests_read: int = 0
    manifests_skipped: int = 0
    #: data manifests whose partition spec could not be resolved (read whole; their
    #: files' partition values cannot be decoded -> judged by bounds or unjudged)
    unresolved_spec_manifests: int = 0
    #: delete manifests in the snapshot: a pair's row count is then an upper bound
    delete_manifests: int = 0
    #: files whose DATE could not be decoded (they may be of the date: unknown)
    unjudged: int = 0
    #: files whose date BOUNDS contain the date among other dates (unknown too:
    #: the metadata cannot say which of their rows are of the date)
    spanning: int = 0
    #: files OF the date whose member value could not be read
    unverifiable: int = 0
    #: files OF the date whose member value the metadata KNOWS is NULL -- judged,
    #: never a member (a null cannot name one); {tuple with None: files}
    null_pairs: Dict[Tuple[Optional[str], ...], int] = field(default_factory=dict)
    #: files whose DATE is NULL: known not of the date
    null_dates: int = 0
    seconds: float = 0.0

    @property
    def judged_whole(self) -> bool:
        return self.unjudged == 0 and self.unverifiable == 0 and self.spanning == 0

    @property
    def null_members(self) -> int:
        return sum(self.null_pairs.values())

    def unjudged_reason(self) -> Optional[str]:
        parts = []
        if self.unjudged:
            parts.append(f"{self.unjudged} file(s) whose date could not be decoded")
        if self.spanning:
            parts.append(f"{self.spanning} file(s) whose date bounds span the date among other dates "
                         f"(the metadata cannot say which rows are of the date)")
        if self.unverifiable:
            parts.append(f"{self.unverifiable} file(s) of the date whose member value could not be read "
                         f"(no identity partition value and no equal bounds)")
        if self.unresolved_spec_manifests:
            parts.append(f"{self.unresolved_spec_manifests} manifest(s) under a partition spec the metadata "
                         f"does not list")
        if not parts:
            return None
        return ("the metadata cannot say which partitions hold the date: " + "; ".join(parts)
                + " -- nothing was made; the files must be judged whole or not at all")

    def rows_words(self, key: Tuple[str, ...]) -> str:
        slot = self.pairs.get(key) or {}
        rows = slot.get("rows")
        if rows is None:
            return "row count unknown"
        if self.delete_manifests:
            return f"up to {rows} (delete files exist)"
        return str(rows)


def _field_of(schema: Mapping[str, Any], column: str) -> Optional[Mapping[str, Any]]:
    col_lower = str(column).strip().lower()
    return next((f for f in (schema.get("fields") or [])
                 if isinstance(f, dict) and str(f.get("name", "")).lower() == col_lower), None)


def _fid(fld: Mapping[str, Any]) -> int:
    return int(fld.get("id") if fld.get("id") is not None else fld.get("field-id"))


def _spec_fields(metadata: Mapping[str, Any], spec_id: Any) -> Optional[List[Mapping[str, Any]]]:
    """The partition fields of ONE spec by id (v1 single spec = id 0), or
    None when the metadata does not list it."""
    specs = metadata.get("partition-specs") or []
    if not specs and "partition-spec" in metadata:
        ps = metadata["partition-spec"]
        specs = [{"spec-id": 0, "fields": ps}] if isinstance(ps, list) else [ps]
    for s in specs:
        if s.get("spec-id") == spec_id:
            return list(s.get("fields") or [])
    return None


def _spec_types(metadata: Mapping[str, Any], spec_id: Any) -> Dict[str, str]:
    from core.iceberg_reader import _extract_partition_spec
    try:
        return dict(_extract_partition_spec(metadata, spec_id=spec_id) or {})
    except Exception:  # noqa: BLE001
        return {}


def _bounds_reader(schema: Mapping[str, Any], column: str) -> Dict[str, Any]:
    fld = _field_of(schema, column)
    if fld is None:
        raise CommitUnreadable(f"column {column!r} is not in the table's current schema")
    return {"column": column, "fid": _fid(fld), "ctype": fld.get("type"), "part_name": None, "ptype": None}


def _reader(metadata: Mapping[str, Any], schema: Mapping[str, Any], column: str,
            spec_id: Any, *, transforms: Sequence[str]) -> Dict[str, Any]:
    """How a live data file written under spec ``spec_id`` gives its value of
    ``column``: the partition value when the column is a partition source
    under one of ``transforms`` IN THAT SPEC, else the file's equal
    lower/upper bounds."""
    rd = _bounds_reader(schema, column)
    for pf in (_spec_fields(metadata, spec_id) or []):
        src = pf.get("source-id") if pf.get("source-id") is not None else pf.get("source_id")
        if src == rd["fid"] and str(pf.get("transform") or "").lower() in transforms:
            rd["part_name"] = pf.get("name")
            break
    if rd["part_name"]:
        rd["ptype"] = _spec_types(metadata, spec_id).get(rd["part_name"])
    return rd


def _partition_raw(data_file: Mapping[str, Any], part_name: Optional[str]) -> Any:
    """The file's raw partition value for ``part_name``: ``NULL`` when the key
    is present and null (a KNOWN null), None when the key is absent."""
    if not part_name:
        return None
    part = data_file.get("partition") or {}
    if part_name in part:
        return NULL if part[part_name] is None else part[part_name]
    return None


def _decode_date_bound(raw: Optional[bytes], ctype: Any) -> Any:
    """A bound of the date column by its declared type; v3 ``timestamp_ns``
    (nanoseconds, int64) decoded here -- the reader's decoder predates it."""
    t = str(ctype or "").lower()
    if t.startswith("timestamp_ns") or t.startswith("timestamptz_ns"):
        if not raw or len(raw) < 8:
            return None
        import struct
        return struct.unpack_from("<q", raw)[0]
    from core.iceberg_reader import _decode_bound
    return _decode_bound(raw, ctype)


def _file_value(data_file: Mapping[str, Any], rd: Mapping[str, Any]) -> Any:
    """The decoded value: the partition value under the file's spec (``NULL``
    when the metadata says the value IS null), else the equal lower/upper
    bounds; None when neither can be read."""
    from core.iceberg_reader import _avro_kv_map, _decode_bound, _decode_partition_value
    raw = _partition_raw(data_file, rd["part_name"])
    if raw is NULL:
        return NULL
    if raw is not None:
        return _decode_partition_value(raw, rd["ptype"] or "string")
    lo = _ics._bound_for(_avro_kv_map(data_file.get("lower_bounds")), rd["fid"])
    hi = _ics._bound_for(_avro_kv_map(data_file.get("upper_bounds")), rd["fid"])
    if lo is None or hi is None:
        return None
    lo_v, hi_v = _decode_bound(lo, rd["ctype"]), _decode_bound(hi, rd["ctype"])
    if lo_v is None or lo_v != hi_v:
        return None
    return lo_v


def _file_date(data_file: Mapping[str, Any], rd: Mapping[str, Any], business_date: date) -> str:
    """2026-11-10 (second review) -- whether the file is OF the business date:
    the identity / day partition value when the spec has one (a KNOWN null is
    NOT of the date); else the date column's BOUNDS by range containment --
    bounds that EXCLUDE the date are ``not`` (judged, never 'unjudged'), equal
    bounds on the date are ``of`` (a timestamp column's one-day file has
    lo 00:00:01 / hi 23:59:59: the same calendar date), bounds that contain
    the date among others are ``spans`` (the metadata cannot say which rows),
    anything undecodable is ``unknown``."""
    from core.iceberg_reader import _avro_kv_map, _decode_partition_value
    raw = _partition_raw(data_file, rd["part_name"])
    if raw is NULL:
        return NOT_OF_DATE
    if raw is not None:
        d = date_of(_decode_partition_value(raw, rd["ptype"] or "string"), rd["ctype"])
        if d is None:
            return DATE_UNKNOWN
        return OF_DATE if d == business_date else NOT_OF_DATE
    lo = _ics._bound_for(_avro_kv_map(data_file.get("lower_bounds")), rd["fid"])
    hi = _ics._bound_for(_avro_kv_map(data_file.get("upper_bounds")), rd["fid"])
    if lo is None or hi is None:
        return DATE_UNKNOWN
    lo_d = date_of(_decode_date_bound(lo, rd["ctype"]), rd["ctype"])
    hi_d = date_of(_decode_date_bound(hi, rd["ctype"]), rd["ctype"])
    if lo_d is None or hi_d is None:
        return DATE_UNKNOWN
    if hi_d < business_date or lo_d > business_date:
        return NOT_OF_DATE
    if lo_d == hi_d == business_date:
        return OF_DATE
    return DATE_SPANS


def date_of(value: Any, ctype: Any) -> Optional[date]:
    """2026-11-10 (review) -- the calendar date a stored value means, by the
    column's declared type: a date / datetime object; an int (days since the
    epoch for a date column, microseconds for a timestamp, NANOSECONDS for a
    v3 ``timestamp_ns``); ISO text (``2026-10-31``, ``2026-10-31T00:00:00``);
    compact ``20261031``.  None = cannot be decoded (the file is then
    UNJUDGED, never skipped)."""
    if value is None or value is NULL or isinstance(value, bool):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    t = str(ctype or "").lower()
    if isinstance(value, int):
        try:
            if t == "date":
                return _EPOCH + timedelta(days=value)
            if t.startswith("timestamp_ns") or t.startswith("timestamptz_ns"):
                return (datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=value // 1000)).date()
            if t.startswith("timestamp"):
                return (datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=value)).date()
        except (OverflowError, ValueError):
            return None
        return None
    text = str(value).strip()
    if _COMPACT_DATE.match(text):
        try:
            return date(int(text[:4]), int(text[4:6]), int(text[6:8]))
        except ValueError:
            return None
    if len(text) >= 10:
        try:
            return date.fromisoformat(text[:10])
        except ValueError:
            return None
    return None


def _value_text(v: Any) -> Optional[str]:
    if v is None:
        return None
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    return str(v).strip()


def _manifest_spec_id(m: Mapping[str, Any], metadata: Mapping[str, Any]) -> Any:
    sid = m.get("partition_spec_id", m.get("partition-spec-id"))
    return metadata.get("default-spec-id", 0) if sid is None else sid


def _summary_can_hold(manifest: Mapping[str, Any], spec_types: Optional[Dict[str, str]],
                      date_column: str, business_date: date, src_to_part: Mapping[str, str]) -> bool:
    """Whether the manifest-list PARTITION SUMMARY can hold the date -- THE
    reader's own matcher (``iceberg_reader._manifest_matches_filters``) with
    THE MANIFEST'S OWN spec (its summaries are ordered by the spec it was
    written under; 2026-08-03's data-loss fix).  No resolvable spec, no
    summary, undecodable, unsupported = read the body (fail-open, as the
    reader does)."""
    if not spec_types:
        return True
    from core.iceberg_reader import _manifest_matches_filters
    try:
        return bool(_manifest_matches_filters(
            dict(manifest), dict(spec_types),
            [{"col": date_column, "op": "equals", "val": business_date.isoformat()}],
            src_to_part=dict(src_to_part)))
    except Exception:  # noqa: BLE001 -- unknown = must read
        return True


def read_partitions(s3_client, *, bucket: str, table_prefix: str, date_column: str,
                    member_columns: Sequence[str], business_date: date,
                    max_files: int = DEFAULT_MAX_FILES) -> PartitionRead:
    """The distinct ``member_columns`` value tuples of the live data files
    whose ``date_column`` IS ``business_date``, read from the CURRENT
    snapshot's metadata -- each file under ITS manifest's partition spec.
    Raises :class:`CommitUnreadable` for anything that cannot be read; a file
    that cannot be JUDGED is counted (``unjudged`` / ``unverifiable``), never
    skipped -- the caller turns a non-zero count into an UNREADABLE scan.
    """
    from core.iceberg_reader import _s3_uri_to_key, build_source_to_partition_field_map
    t0 = time.monotonic()
    try:
        metadata = _ics._load_metadata(s3_client, bucket, table_prefix)
    except CommitUnreadable:
        raise
    except Exception as exc:  # noqa: BLE001
        raise CommitUnreadable(f"metadata.json could not be read: {exc}") from exc
    snapshot_id = metadata.get("current-snapshot-id")
    if snapshot_id in (None, -1):
        return PartitionRead(snapshot_id=None, pairs={}, seconds=time.monotonic() - t0)
    snapshot = next((s for s in (metadata.get("snapshots") or [])
                     if str(s.get("snapshot-id")) == str(snapshot_id)), None)
    if snapshot is None:
        raise CommitUnreadable(f"current snapshot {snapshot_id} is not listed in the metadata")
    schema = _current_schema(metadata)
    bounds_only = (_bounds_reader(schema, date_column),
                   [_bounds_reader(schema, c) for c in member_columns])
    # a STRING date column stores the date in a spelling the metadata does not
    # declare (20261031, 2026-10-31, ...): its manifest summaries cannot be
    # judged against the ISO date -- every body is read (the files decide)
    summaries_judge = str(bounds_only[0]["ctype"] or "").lower().startswith(("date", "timestamp"))
    try:
        src_to_part = build_source_to_partition_field_map(metadata)
    except Exception:  # noqa: BLE001
        src_to_part = {}
    try:
        manifests = _ics._load_manifest_list(s3_client, bucket, snapshot)
    except CommitUnreadable:
        raise
    except Exception as exc:  # noqa: BLE001
        raise CommitUnreadable(f"manifest list could not be read: {exc}") from exc

    out = PartitionRead(snapshot_id=str(snapshot_id), pairs={})
    readers: Dict[Any, Optional[Tuple[dict, List[dict]]]] = {}
    spec_types_cache: Dict[Any, Optional[Dict[str, str]]] = {}
    for m in manifests:
        if int(m.get("content") or 0) != 0:
            out.delete_manifests += 1
            continue                               # delete manifests carry no data
        mpath = m.get("manifest_path")
        if not mpath:
            continue
        out.manifests_total += 1
        sid = _manifest_spec_id(m, metadata)
        if sid not in spec_types_cache:
            fields = _spec_fields(metadata, sid)
            if fields is None:
                spec_types_cache[sid] = None
                readers[sid] = None
            else:
                spec_types_cache[sid] = _spec_types(metadata, sid)
                readers[sid] = (_reader(metadata, schema, date_column, sid, transforms=DATE_TRANSFORMS),
                                [_reader(metadata, schema, c, sid, transforms=("identity",)) for c in member_columns])
        if spec_types_cache[sid] is None:
            out.unresolved_spec_manifests += 1
        if summaries_judge and not _summary_can_hold(m, spec_types_cache[sid], date_column, business_date, src_to_part):
            out.manifests_skipped += 1
            continue
        try:
            entries = _ics._load_manifest_entries(s3_client, bucket, _s3_uri_to_key(mpath))
        except CommitUnreadable:
            raise
        except Exception as exc:  # noqa: BLE001
            raise CommitUnreadable(f"manifest {mpath} could not be read: {exc}") from exc
        out.manifests_read += 1
        date_rd, member_rds = readers.get(sid) or bounds_only
        for entry in entries:
            if int(entry.get("status") or 0) == 2:
                continue                           # deleted in this snapshot
            data_file = entry.get("data_file") or {}
            out.files_seen += 1
            if out.files_seen > max_files:
                raise CommitUnreadable(
                    f"the snapshot holds more than {max_files} data files "
                    f"(feed_generation.dependency_iceberg_commit.max_files_inspected) "
                    f"-- the read was refused rather than run unbounded")
            verdict = _file_date(data_file, date_rd, business_date)
            if verdict == DATE_UNKNOWN:
                out.unjudged += 1                 # may be of the date: unknown, counted
                continue
            if verdict == DATE_SPANS:
                out.spanning += 1                 # holds the date among others: unknown, counted
                continue
            if verdict == NOT_OF_DATE:
                if _partition_raw(data_file, date_rd["part_name"]) is NULL:
                    out.null_dates += 1           # a KNOWN null date: judged, not of the date
                continue
            values: List[Optional[str]] = []
            unreadable = False
            for rd in member_rds:
                v = _file_value(data_file, rd)
                if v is NULL:
                    values.append(None)           # a KNOWN null: judged, never a member
                    continue
                v = _value_text(v)
                if v is None or v == "":
                    unreadable = True
                    break
                values.append(v)
            if unreadable:
                out.unverifiable += 1
                continue
            if any(v is None for v in values):
                k = tuple(values)
                out.null_pairs[k] = out.null_pairs.get(k, 0) + 1
                continue
            slot = out.pairs.setdefault(tuple(values), {"files": 0, "rows": 0})
            slot["files"] += 1
            rc = data_file.get("record_count")
            slot["rows"] = (slot["rows"] + int(rc)) if (slot["rows"] is not None and rc is not None) else None
    out.seconds = time.monotonic() - t0
    return out


# ── the scan: the read classified against the template ────────────────────

@dataclass
class Scan:
    template_id: Optional[int]
    business_date: date
    status: str
    reason: Optional[str] = None
    source: Dict[str, Any] = field(default_factory=dict)
    read: Optional[PartitionRead] = None
    #: member key -> parameter values, every pair of the date the renderer accepts
    found: Dict[str, Dict[str, str]] = field(default_factory=dict)
    #: keys among ``found`` with NO ACTIVE MEMBER FEED yet
    new: List[str] = field(default_factory=list)
    #: scan-produced members with no partition for the date (the matrix's keys for a preview)
    missing: List[str] = field(default_factory=list)
    #: pairs the SQL renderer would refuse: [{"values": {...}, "reason": ...}]
    refused: List[Dict[str, Any]] = field(default_factory=list)
    #: keys among ``found`` whose member feed a person SWITCHED OFF -- never
    #: re-created by a pass; only an explicit Switch on brings one back
    switched_off: List[str] = field(default_factory=list)
    # filled by the pass
    members_created: List[str] = field(default_factory=list)
    members_refused: List[Dict[str, Any]] = field(default_factory=list)
    grew: bool = False
    claim_held_by: Optional[str] = None
    runs_created: int = 0
    skipped: List[str] = field(default_factory=list)
    held: int = 0

    @property
    def found_keys(self) -> set:
        return set(self.found)

    def rows_words(self, key: str) -> str:
        if self.read is None or key not in self.found:
            return "row count unknown"
        return self.read.rows_words(tuple(self.found[key].values()))

    def summary(self) -> Dict[str, Any]:
        """One plain dict for the SOD result / a route."""
        rd = self.read
        return {"template_id": self.template_id, "business_date": self.business_date.isoformat(),
                "status": self.status, "reason": self.reason, "source": dict(self.source),
                "found": len(self.found), "new": len(self.new), "missing": len(self.missing),
                "refused": len(self.refused), "switched_off": len(self.switched_off),
                "members_created": len(self.members_created),
                "members_refused": len(self.members_refused), "grew": self.grew,
                "claim_held_by": self.claim_held_by,
                "runs_created": self.runs_created, "skipped_no_data": len(self.skipped),
                "members_not_judged": self.held,
                "files_seen": rd.files_seen if rd else 0,
                "manifests_read": rd.manifests_read if rd else 0,
                "manifests_skipped": rd.manifests_skipped if rd else 0,
                "unresolved_spec_manifests": rd.unresolved_spec_manifests if rd else 0,
                "unjudged_files": rd.unjudged if rd else 0,
                "spanning_files": rd.spanning if rd else 0,
                "unverifiable_files": rd.unverifiable if rd else 0,
                "null_member_files": rd.null_members if rd else 0,
                "delete_manifests": rd.delete_manifests if rd else 0,
                "row_counts_exact": bool(rd and rd.delete_manifests == 0),
                "row_count_note": ("row counts are upper bounds: delete files exist (an exact count "
                                   "needs a data read)" if rd and rd.delete_manifests else None),
                "seconds": round(rd.seconds, 3) if rd else None}


def _default_s3_client(db: Any, connection_id: int):
    from core.iceberg_manifest_watcher import _build_s3_client
    return _build_s3_client(db, int(connection_id))


def _max_files() -> int:
    try:
        from core.config import get as _get
        return max(1, int(_get(*MAX_FILES_KEY, DEFAULT_MAX_FILES)))
    except Exception:  # noqa: BLE001 -- the declared default
        return DEFAULT_MAX_FILES


def active_member_keys(db: Any, template: Mapping[str, Any]) -> Tuple[set, Dict[str, str], Dict[str, str]]:
    """``(active keys, {key: origin}, {switched-off key: when})`` of the
    template's member feeds.  A key with an ACTIVE feed is active; a key whose
    only feeds are SWITCHED OFF is in the third answer -- a pass must know
    them and skip them (2026-11-10, second review: a switched-off member read
    as NEW and was switched back on by every start of day; an owner's
    switch-off sticks until an explicit Switch on, core/config_active).  A
    template with no id (a preview) has none: its matrix stands in."""
    tid = template.get("id")
    params = list(template.get("parameters") or [])
    if tid is None:
        keys = {member_key(params, row) for row in (template.get("matrix") or []) if all(p in row for p in params)}
        return keys, dict.fromkeys(keys, ORIGIN_AUTHORED), {}
    keys, origins, off, off_ids = set(), {}, {}, {}
    for m in db.list_template_members(int(tid)) or []:
        if not m.get("template_member_key"):
            continue
        k = str(m["template_member_key"])
        if m.get("is_active", True):
            keys.add(k)
            origins[k] = m.get("member_origin") or ORIGIN_AUTHORED
        else:
            off[k] = f"on {str(m.get('updated_at') or '')[:19] or 'an unknown time'}"
            off_ids[int(m["id"])] = k
    for k in keys:
        off.pop(k, None)                            # an active feed for the key wins
    # 2026-11-10 (third review): WHO switched it off and WHEN, from the
    # switch-off record (config_switch_offs), not the row's updated_at
    if off and hasattr(db, "last_switch_offs"):
        try:
            for fid, (who, at) in (db.last_switch_offs("feed_configs", list(off_ids)) or {}).items():
                k = off_ids.get(int(fid))
                if k in off:
                    off[k] = switched_off_words(who, at)
        except Exception:  # noqa: BLE001 -- the row's time stands
            logger.debug("[partition_members] switch-off records not read", exc_info=True)
    return keys, origins, off


def switched_off_words(who: Optional[str], at: Any) -> str:
    """``by <who> on <when>`` from a switch-off record."""
    when = at.isoformat(timespec="seconds") if hasattr(at, "isoformat") else str(at or "")
    return f"by {who} on {when}" if who else f"on {when}"


def switched_off_reason(key: str, when: str) -> str:
    """The words every road says for a member a person switched off."""
    return (f"member {key} is switched off ({when}); an apply, a start of day or a request from SQL "
            f"never switches it back on -- switch it on in QueryStudio: Feed template -> Switch on members, "
            f"or POST /api/feed-templates/{{id}}/members/switch-on (admins), or the member itself under "
            f"Admin -> Switched off")


def scan_for_date(db: Any, template: Mapping[str, Any], business_date: date, *,
                  s3_client_factory: Optional[Callable[[int], Any]] = None,
                  reader: Optional[Callable[..., PartitionRead]] = None,
                  max_files: Optional[int] = None) -> Scan:
    """Read the template's table for ``business_date`` and classify what it
    holds against the template's ACTIVE members.  Never raises: every failure
    -- and every file the metadata cannot judge -- is ``status == unreadable``
    with its reason."""
    tid = template.get("id")
    params = list(template.get("parameters") or [])
    scan = Scan(template_id=int(tid) if tid is not None else None, business_date=business_date,
                status=STATUS_UNREADABLE)
    problem = declaration_problem(template)
    if problem:
        scan.reason = problem
        return scan
    decl = normalised(template[DECLARATION_FIELD])
    scan.source = {"connection_id": decl["connection_id"], "table": decl["table"]}
    from core.iceberg_watch_registry import resolve_registered_iceberg_table
    entry, reason = resolve_registered_iceberg_table(db, decl["connection_id"], decl["table"])
    if entry is None:
        scan.reason = reason or f"table {decl['table']!r} is not registered as Iceberg"
        return scan
    scan.source.update({"bucket": entry["bucket"], "table_prefix": entry["table_prefix"]})
    try:
        if s3_client_factory is not None:
            client = s3_client_factory(decl["connection_id"])
        else:
            client = _default_s3_client(db, decl["connection_id"])
    except Exception as exc:  # noqa: BLE001
        client = None
        scan.reason = f"the S3 client for connection {decl['connection_id']} could not be built: {exc}"
    if client is None:
        scan.reason = scan.reason or f"the S3 client for connection {decl['connection_id']} could not be built"
        return scan
    columns = [decl["member_columns"][p] for p in params]
    try:
        rd = (reader or read_partitions)(
            client, bucket=entry["bucket"], table_prefix=entry["table_prefix"],
            date_column=decl["date_column"], member_columns=columns,
            business_date=business_date, max_files=max_files or _max_files())
    except CommitUnreadable as exc:
        scan.reason = str(exc)
        return scan
    except Exception as exc:  # noqa: BLE001 -- same verdict, different cause
        scan.reason = f"{type(exc).__name__}: {exc}"
        return scan
    scan.read = rd
    scan.source["snapshot_id"] = rd.snapshot_id
    try:
        active, origins, off = active_member_keys(db, template)
    except Exception as exc:  # noqa: BLE001
        scan.reason = f"the template's members could not be listed: {exc}"
        return scan
    for values_t in sorted(rd.pairs):
        values = dict(zip(params, values_t))
        try:
            values = {p: validate_token_value(p, v) for p, v in values.items()}
        except UnsafeTokenValue as exc:
            scan.refused.append({"values": dict(zip(params, values_t)), "reason": str(exc)})
            continue
        key = member_key(params, values)
        scan.found[key] = values
        if key in off:
            scan.switched_off.append(key)           # known, skipped, said -- never NEW
        elif key not in active:
            scan.new.append(key)
    # a KNOWN null member value is judged: no member can be named by it (said)
    for values_t, files in sorted(rd.null_pairs.items(), key=lambda kv: tuple(v or "" for v in kv[0])):
        cols = [decl["member_columns"][p] for p, v in zip(params, values_t) if v is None]
        scan.refused.append({"values": dict(zip(params, values_t)),
                             "reason": f"the partition value of {', '.join(cols)} is NULL in {files} file(s) of "
                                       f"the date -- a member cannot be named by a null value; these files are "
                                       f"excluded (judged, not unknown)"})
    # 2026-11-10 (review): only a member THE SCAN PRODUCED is "missing" when its
    # partition is absent; authored / message members keep the ordinary rules
    scan.missing = sorted(k for k in active if k not in scan.found
                          and (origins.get(k) == ORIGIN_SCAN or tid is None))
    if not rd.judged_whole:
        scan.reason = rd.unjudged_reason()
        return scan                                 # status stays UNREADABLE
    scan.status = STATUS_FOUND if scan.found else STATUS_NONE
    if scan.status == STATUS_NONE:
        read = f"the metadata was read ({rd.files_seen} live file(s), snapshot {rd.snapshot_id})"
        if scan.refused:
            # 2026-11-10 (second review): pairs WERE found and every one was
            # refused -- "holds no partition" would be false
            scan.reason = (f"{read}: {len(scan.refused)} partition value(s) for {business_date.isoformat()} "
                           f"were found and every one was refused as a member value -- "
                           + "; ".join(f"{r['values']}: {r['reason']}" for r in scan.refused[:5])
                           + (" ..." if len(scan.refused) > 5 else ""))
        else:
            scan.reason = f"{read} and holds no partition for {business_date.isoformat()}"
    return scan


# ── the per-template growth claim ─────────────────────────────────────────

def _claim_key(template_id: int) -> str:
    return f"{CLAIM_KEY_PREFIX}{int(template_id)}"


def owner_id() -> str:
    """This producer FOR DISPLAY: host, process and thread.  Not an identity
    (every request on a pod shares the event-loop thread, 2026-11-10 third
    review): the claim's identity is its TOKEN (``current_token``)."""
    import os
    import socket
    return f"{socket.gethostname()}:{os.getpid()}:{threading.get_ident()}"


def current_token() -> Optional[str]:
    """The token of the claim THIS context holds (set by the holder; copied
    into its tasks and thread-pool calls), or None."""
    return _claim_token.get()


def _read_claim_row(db: Any, template_id: int) -> Optional[Dict[str, Any]]:
    """The claim row AS STORED, read on the PRIMARY (a replica can miss a
    claim written a moment ago -- 2026-11-10, second review).  Raises
    :class:`ClaimUnreadable` when it cannot be read: unknown is not free.
    A row whose value is not an object is answered as ``{"_malformed": ...}``;
    every answer carries the row's own ``_updated_at`` (the compare-and-set
    key for a malformed row, third review)."""
    from core.db.models import SystemSetting
    try:
        with db.get_session() as session:                # never read_only: the primary
            row = session.query(SystemSetting).filter(SystemSetting.key == _claim_key(template_id)).first()
            if row is None:
                return None
            value, updated_at = row.value, row.updated_at
    except Exception as exc:  # noqa: BLE001
        raise ClaimUnreadable(f"the growth claim on template {template_id} could not be read: "
                              f"{type(exc).__name__}: {exc}") from exc
    out = dict(value) if isinstance(value, dict) else {"_malformed": repr(value)[:200]}
    out["_updated_at"] = updated_at.isoformat() if hasattr(updated_at, "isoformat") else updated_at
    return out


def _claimed_at(row: Mapping[str, Any]) -> Optional[datetime]:
    try:
        then = datetime.fromisoformat(str(row.get("claimed_at")))
    except (TypeError, ValueError):
        return None
    return then if then.tzinfo is not None else then.replace(tzinfo=timezone.utc)


def _is_live(row: Optional[Mapping[str, Any]], now: datetime) -> bool:
    if not row or not row.get("owner"):
        return False
    then = _claimed_at(row)
    return then is not None and (now - then).total_seconds() <= CLAIM_STALE_SECONDS


def _is_malformed(row: Mapping[str, Any]) -> bool:
    """A row that can never be judged live: no object, no owner, or a
    ``claimed_at`` that does not parse (``value->>'claimed_at' = 'None'``
    never matches a JSON null -- it used to block the template for ever)."""
    return "_malformed" in row or not row.get("owner") or _claimed_at(row) is None


def _row_updated_at(row: Mapping[str, Any]) -> Optional[datetime]:
    v = row.get("_updated_at")
    if not v:
        return None
    try:
        then = datetime.fromisoformat(str(v))
    except (TypeError, ValueError):
        return None
    return then if then.tzinfo is not None else then.replace(tzinfo=timezone.utc)


def _public(row: Mapping[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in row.items() if not k.startswith("_")}


def unknown_holder(reason: str) -> Dict[str, Any]:
    """The holder record for a claim whose state could not be read."""
    return {"owner": CLAIM_UNKNOWN_OWNER, "claimed_at": None, "reason": reason}


def claim_holder(db: Any, template_id: int, *, now: Optional[datetime] = None) -> Optional[Dict[str, Any]]:
    """The live claim on this template's growth, or None (free / stale /
    malformed).  Raises :class:`ClaimUnreadable` when the row cannot be read
    -- a caller must never treat that as free."""
    now = now or datetime.now(timezone.utc)
    row = _read_claim_row(db, template_id)
    return _public(row) if _is_live(row, now) else None


def _claim_statement(template_id: int, *, kind: str, token: Optional[str] = None,
                     owner: Optional[str] = None, claimed_at: Optional[str] = None,
                     updated_at: Any = _ABSENT, new_value: Optional[Dict[str, Any]] = None,
                     now: Optional[datetime] = None, older_than: Optional[Tuple[str, float]] = None):
    """The one UPDATE / DELETE each claim write runs, keyed on what the writer
    SAW so a stale view matches nothing: the row's JSON ``token`` (a release /
    heartbeat / re-entry), or ``owner`` + ``claimed_at`` (a stale takeover),
    or the row's own ``updated_at`` (a malformed row's takeover).  ``value
    ->> 'x'`` on PostgreSQL, ``JSON_EXTRACT`` on SQLite (the test compiles
    both; built here so it can be compiled without a server)."""
    from sqlalchemy import delete, update
    from core.db.models import SystemSetting
    key = _claim_key(template_id)
    if kind == "delete":
        stmt = delete(SystemSetting).where(SystemSetting.key == key)
    else:
        stmt = (update(SystemSetting).where(SystemSetting.key == key)
                .values(value=new_value, updated_at=now or datetime.now(timezone.utc),
                        updated_by="partition_members"))
    if token is not None:
        stmt = stmt.where(SystemSetting.value["token"].as_string() == str(token))
    if owner is not None:
        stmt = stmt.where(SystemSetting.value["owner"].as_string() == str(owner))
    if claimed_at is not None:
        stmt = stmt.where(SystemSetting.value["claimed_at"].as_string() == str(claimed_at))
    if updated_at is not _ABSENT:
        stmt = stmt.where(SystemSetting.updated_at.is_(None) if updated_at is None
                          else SystemSetting.updated_at == updated_at)
    if older_than is not None:
        stmt = stmt.where(_older_than_sql(*older_than))
    return stmt


def _older_than_sql(dialect: str, seconds: float):
    """2026-11-10 (fourth review): "the row's ``updated_at`` is older than
    ``seconds``" judged IN THE DATABASE, timezone-independent -- the column
    holds naive UTC (``datetime.now(timezone.utc)`` stripped by the driver):
    PostgreSQL compares against ``now() AT TIME ZONE 'UTC'`` (never the
    session's time zone), SQLite against ``datetime('now', '-N seconds')``
    (always UTC); any other dialect against a UTC cutoff computed here.  A
    NULL ``updated_at`` counts as old (nothing says when it was written)."""
    from sqlalchemy import bindparam, or_, text
    from core.db.models import SystemSetting
    secs = int(seconds)
    if dialect == "postgresql":
        age = text("system_settings.updated_at < (now() AT TIME ZONE 'UTC') - make_interval(secs => :stale_secs)"
                   ).bindparams(bindparam("stale_secs", secs))
    elif dialect == "sqlite":
        age = text("system_settings.updated_at < datetime('now', :stale_mod)"
                   ).bindparams(bindparam("stale_mod", f"-{secs} seconds"))
    else:
        age = SystemSetting.updated_at < (datetime.now(timezone.utc) - timedelta(seconds=secs)).replace(tzinfo=None)
    return or_(SystemSetting.updated_at.is_(None), age)


def _new_value(owner: str, token: str, now: datetime) -> Dict[str, Any]:
    return {"owner": owner, "token": token, "claimed_at": now.isoformat()}


def _take_over_stale(db: Any, template_id: int, stale: Mapping[str, Any], owner: str, token: str,
                     now: datetime) -> bool:
    """COMPARE-AND-SET: the stale row becomes ours only if it is STILL the
    row we judged stale -- same owner, same claimed_at.  Two producers that
    both saw the stale claim can never both win: the second's UPDATE matches
    nothing (2026-11-10, second review: the old delete + insert let B's delete
    remove A's fresh claim).  Returns whether this producer now holds it."""
    stmt = _claim_statement(template_id, kind="update", owner=str(stale.get("owner")),
                            claimed_at=str(stale.get("claimed_at")),
                            new_value=_new_value(owner, token, now), now=now)
    with db.get_session() as session:
        return int(session.execute(stmt).rowcount or 0) == 1


def _take_over_malformed(db: Any, template_id: int, row: Mapping[str, Any], owner: str, token: str,
                         now: datetime) -> Tuple[bool, Optional[str]]:
    """A MALFORMED row (no claimed_at, no owner, not an object) is taken over
    by compare-and-set on the row's own ``updated_at`` once that is older than
    the stale window -- said in the log.  Younger: held by ``unknown`` until
    then (the words say so).  Returns ``(taken, why_not)``."""
    seen = _row_updated_at(row)
    # the AGE is judged in the database (fourth review: never Python's clock
    # against a column a PostgreSQL session time zone could render differently)
    # AND the row must still be the one we saw (compare-and-set on updated_at)
    stmt = _claim_statement(template_id, kind="update",
                            updated_at=(seen.replace(tzinfo=None) if seen is not None else None),
                            older_than=(_dialect_name(db), CLAIM_STALE_SECONDS),
                            new_value=_new_value(owner, token, now), now=now)
    with db.get_session() as session:
        taken = int(session.execute(stmt).rowcount or 0) == 1
    if taken:
        logger.warning("[partition_members] MALFORMED growth claim on template %s (%s, written %s) taken "
                       "over by %s -- the row could never have been judged live", template_id,
                       _public(row) or row.get("_malformed"), row.get("_updated_at"), owner)
        return True, None
    again = _read_claim_row(db, template_id)
    if again is None or not _is_malformed(again) or again.get("_updated_at") != row.get("_updated_at"):
        return False, None                      # the row changed hands meanwhile: the caller re-reads
    return False, (f"the claim row is malformed ({_public(row) or row.get('_malformed')}) and was "
                   f"written at {row.get('_updated_at')} -- held until it is {int(CLAIM_STALE_SECONDS)}s old")


def _dialect_name(db: Any) -> str:
    try:
        return str(db.engine.dialect.name)
    except Exception:  # noqa: BLE001 -- a double without an engine
        return "other"


def try_claim(db: Any, template_id: int, owner: str, *,
              held: Any = _ABSENT) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
    """``(claimed, holder, token)``: insert-first on a ``system_settings``
    row; the context that HOLDS the claim (``held`` = its token, by default
    ``current_token()``) re-enters it (``claimed`` False, ``holder`` None,
    the same ``token`` -- nothing to release); a STALE holder is taken over
    by compare-and-set on (owner, claimed_at), a MALFORMED one on its
    ``updated_at`` once old enough; a row that cannot be READ is a holder
    named ``unknown`` (never free).  ``claimed`` True = this call took it
    (``token`` is new) and must release it -- or hand it on.  A db without
    sessions (a test double) is always claimed."""
    if not hasattr(db, "get_session"):
        return True, None, uuid.uuid4().hex
    from sqlalchemy.exc import IntegrityError
    from core.db.models import SystemSetting
    held = current_token() if held is _ABSENT else held
    key = _claim_key(template_id)
    now = datetime.now(timezone.utc)
    token = uuid.uuid4().hex
    for _attempt in range(3):
        try:
            with db.get_session() as session:
                session.add(SystemSetting(key=key, value=_new_value(owner, token, now),
                                          description="feed template growth: one producer at a time",
                                          updated_by="partition_members", updated_at=now))
                session.flush()
            return True, None, token
        except IntegrityError:
            try:
                row = _read_claim_row(db, template_id)
            except ClaimUnreadable as exc:
                logger.error("[partition_members] %s -- treated as HELD, not free", exc)
                return False, unknown_holder(str(exc)), None
            if row is None:
                continue                            # released between the insert and the read: insert again
            if held and row.get("token") == held:
                return False, None, held           # re-entered by the context that holds it
            if _is_live(row, now):
                return False, _public(row), None
            try:
                if _is_malformed(row):
                    taken, why = _take_over_malformed(db, template_id, row, owner, token, now)
                    if taken:
                        return True, None, token
                    if why:
                        return False, unknown_holder(why), None
                elif _take_over_stale(db, template_id, row, owner, token, now):
                    logger.warning("[partition_members] stale growth claim on template %s (held by %s since %s) "
                                   "taken over by %s", template_id, row.get("owner"), row.get("claimed_at"), owner)
                    return True, None, token
            except Exception as exc:  # noqa: BLE001 -- the next attempt re-reads
                logger.warning("[partition_members] growth claim on template %s not taken over: %s",
                               template_id, exc)
    try:
        return False, claim_holder(db, template_id, now=now) or unknown_holder("the claim changed hands three times"), None
    except ClaimUnreadable as exc:
        return False, unknown_holder(str(exc)), None


def refresh_claim(db: Any, template_id: int, token: str) -> bool:
    """The HEARTBEAT: ``claimed_at`` = now on the row THIS TOKEN holds (one
    UPDATE, token-checked, on the primary), so a long apply is never judged
    stale and taken over mid-way.  False = the claim is NOT this holder's any
    more (taken over, released, malformed): the apply must STOP."""
    now = datetime.now(timezone.utc)
    try:
        row = _read_claim_row(db, template_id)
        if row is None or row.get("token") != token:
            return False
        stmt = _claim_statement(template_id, kind="update", token=token,
                                new_value=_new_value(str(row.get("owner") or ""), token, now), now=now)
        with db.get_session() as session:
            return int(session.execute(stmt).rowcount or 0) == 1
    except Exception as exc:  # noqa: BLE001
        logger.warning("[partition_members] growth claim on template %s not refreshed: %s", template_id, exc)
        return False


def release_claim(db: Any, template_id: int, token: str) -> None:
    """ONE token-checked DELETE on the primary -- never a read on a replica
    followed by an unconditional delete, never by the (shared) owner string."""
    if not token:
        return
    try:
        with db.get_session() as session:
            session.execute(_claim_statement(template_id, kind="delete", token=token))
    except Exception:  # noqa: BLE001
        logger.warning("[partition_members] growth claim on template %s not released; a stale "
                       "claim is taken over after %ss", template_id, CLAIM_STALE_SECONDS)


@contextmanager
def template_claim(db: Any, template_id: int, owner: str) -> Iterator[Optional[Dict[str, Any]]]:
    """ONE producer of members per template at a time.  Yields None when this
    caller holds (or re-enters) the claim -- its token is set on the context
    for the duration, so a nested apply re-enters it -- else the holder's
    record (a live holder, or ``unknown`` when the claim could not be read):
    the caller then makes nothing and says who holds it."""
    claimed, holder, token = try_claim(db, template_id, owner)
    if holder is not None:
        yield holder
        return
    reset = _claim_token.set(token)
    try:
        yield None
    finally:
        _claim_token.reset(reset)
        if claimed:
            release_claim(db, template_id, token)


# ── growth: new pairs become members through the ordinary apply ───────────

ApplyFn = Callable[..., Dict[str, Any]]


def add_members(db: Any, template: Mapping[str, Any], rows: List[Dict[str, str]], *,
                origin: str, apply_fn: Optional[ApplyFn] = None) -> Dict[str, Any]:
    """THE way a producer adds members (2026-11-10, review): under the
    template's claim, the rows go through the template's ordinary apply
    FIRST (``auto_onboard._default_apply``: every authoring rule, the origin
    stamped on the member) and the matrix is written AFTER, with the rows
    whose feed exists -- a failed or killed apply leaves no matrix row
    without its feed, so the pair is "new" again on the next pass.  Returns
    ``{"members": {key: feed_id}, "refused": [{key, reason}], "claim_held_by",
    "template"}``.  Never raises."""
    from core.feed.auto_onboard import _default_apply, _member_feed_id
    params = list(template.get("parameters") or [])
    out: Dict[str, Any] = {"members": {}, "refused": [], "claim_held_by": None, "template": template}
    if not rows:
        return out
    tid = int(template["id"])
    with template_claim(db, tid, owner_id()) as holder:
        if holder is not None:
            out["claim_held_by"] = str(holder.get("owner"))
            out["refused"] = [{"key": member_key(params, r),
                               "reason": f"another apply of this template is in progress "
                                         f"(held by {holder.get('owner')} since {holder.get('claimed_at')}); "
                                         f"nothing added -- the next pass adds it"} for r in rows]
            return out
        # 2026-11-10 (second review): the template AS IT IS NOW, read INSIDE the
        # claim -- the dict the pass started with may predate another producer's
        # matrix write; the matrix and its hash are computed from this row
        try:
            fresh = db.get_feed_template(tid)
        except AttributeError:
            fresh = None                            # a seam without templates: the dict stands
        if fresh is None and hasattr(db, "get_feed_template"):
            out["refused"] = [{"key": member_key(params, r),
                               "reason": "the template is switched off or gone; nothing added"} for r in rows]
            return out
        template = fresh or template
        out["template"] = template
        params = list(template.get("parameters") or [])
        # a member a person SWITCHED OFF is never re-created or switched back on
        # by a producer (an owner's switch-off sticks); said, not applied
        try:
            _active, _origins, off = active_member_keys(db, template)
        except Exception:  # noqa: BLE001 -- the apply's own stored-member check still refuses it
            off = {}
        kept: List[Dict[str, str]] = []
        for r in rows:
            k = member_key(params, r)
            if k in off:
                out["refused"].append({"key": k, "reason": switched_off_reason(k, off[k]), "switched_off": True})
            else:
                kept.append(r)
        rows = kept
        if not rows:
            return out
        try:
            report = (apply_fn or _default_apply)(template, rows, member_origin=origin)
        except Exception as exc:  # noqa: BLE001
            out["refused"] += [{"key": member_key(params, r),
                                "reason": f"the apply failed: {type(exc).__name__}: {exc}"[:500]} for r in rows]
            logger.exception("[partition_members] template %s: apply of %d member(s) failed",
                             template.get("name"), len(rows))
            return out
        present_rows: List[Dict[str, str]] = []
        for r in rows:
            k = member_key(params, r)
            fid, refusal = _member_feed_id(report, k)
            if fid is None:
                out["refused"].append({"key": k, "reason": refusal or "no feed was created"})
            else:
                out["members"][k] = int(fid)
                present_rows.append(dict(r))
        if present_rows:
            matrix = list(template.get("matrix") or [])
            have = {member_key(params, m) for m in matrix if all(p in m for p in params)}
            added = [r for r in present_rows if member_key(params, r) not in have]
            if added:
                try:
                    from api.feed_template_api import _hash
                    matrix = matrix + added
                    out["template"] = db.update_feed_template(tid, {
                        "matrix": matrix,
                        "definition_hash": _hash(params, template.get("definition"), matrix)}) or template
                except Exception as exc:  # noqa: BLE001 -- the feeds exist; the matrix heals on the next apply
                    logger.error("[partition_members] template %s: the matrix could not be written after "
                                 "%d member(s) were created (%s) -- the feeds exist; a later apply or scan "
                                 "writes the rows", template.get("name"), len(added), exc)
    return out


def grow(db: Any, template: Mapping[str, Any], scan: Scan) -> Mapping[str, Any]:
    """The scan's NEW pairs become members (origin ``partition_scan``) through
    :func:`add_members`.  Fills ``scan.members_created`` / ``members_refused``
    / ``claim_held_by``; returns the template row as it is afterwards."""
    scan.grew = True
    if not scan.new:
        return template
    rows = [dict(scan.found[k]) for k in scan.new]
    out = add_members(db, template, rows, origin=ORIGIN_SCAN)
    scan.members_created = [k for k in scan.new if k in out["members"]]
    scan.members_refused = list(out["refused"])
    scan.claim_held_by = out.get("claim_held_by")
    if scan.claim_held_by:
        scan.grew = False
        logger.warning("[partition_members] template %s: %d new partition(s) for %s NOT added -- another "
                       "apply holds the template (%s); the next pass adds them", template.get("name"),
                       len(scan.new), scan.business_date.isoformat(), scan.claim_held_by)
        return out["template"]
    if scan.members_refused:
        logger.error("[partition_members] template %s: %d new member(s) refused: %s",
                     template.get("name"), len(scan.members_refused),
                     "; ".join(f"{r['key']}: {r['reason']}" for r in scan.members_refused[:5]))
    logger.warning("[partition_members] template %s: %d new partition(s) for %s -> %d member(s) created",
                   template.get("name"), len(scan.new), scan.business_date.isoformat(),
                   len(scan.members_created))
    return out["template"]


# ── the record and the bell ───────────────────────────────────────────────

def _capped(keys: Sequence[Any]) -> Tuple[list, bool]:
    keys = list(keys)
    return keys[:KEYS_KEPT], len(keys) > KEYS_KEPT


def record(db: Any, scan: Scan, run_date: date, *, status: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """The per-(template, business date, run date) row -- written at the scan's
    START (``in_progress``) and again at the end, so a killed pass leaves a
    visible record and the next pass resumes.  Key lists hold the first
    ``KEYS_KEPT`` keys (said in ``lists_note``); counts are exact.  A db seam
    without the DAO (a test double) records nothing and says so at DEBUG."""
    if scan.template_id is None:
        return None
    rd = scan.read
    found, c1 = _capped(sorted(scan.found))
    created, c2 = _capped(scan.members_created)
    missing, c3 = _capped(sorted(scan.skipped or scan.missing))
    refused, c4 = _capped(list(scan.refused) + list(scan.members_refused))
    off, c5 = _capped(sorted(scan.switched_off))
    note = (f"the key lists hold the first {KEYS_KEPT} of each; the counts are exact"
            if any((c1, c2, c3, c4, c5)) else None)
    row = {
        "template_id": int(scan.template_id), "business_date": scan.business_date,
        "run_date": run_date, "status": status or scan.status,
        "connection_id": scan.source.get("connection_id"), "table_name": scan.source.get("table"),
        "bucket": scan.source.get("bucket"), "table_prefix": scan.source.get("table_prefix"),
        "snapshot_id": (str(rd.snapshot_id) if rd and rd.snapshot_id else None),
        "files_seen": rd.files_seen if rd else 0,
        "manifests_read": rd.manifests_read if rd else 0,
        "manifests_skipped": rd.manifests_skipped if rd else 0,
        "found_count": len(scan.found), "new_count": len(scan.new),
        "members_created": len(scan.members_created), "runs_created": int(scan.runs_created),
        "skipped_count": len(scan.skipped or scan.missing), "unverifiable_files": rd.unverifiable if rd else 0,
        "delete_manifests": rd.delete_manifests if rd else 0,
        "found": found, "created": created, "missing": missing, "refused": refused,
        "switched_off": off, "switched_off_count": len(scan.switched_off),
        "reason": scan.reason, "grew": bool(scan.grew), "lists_note": note,
    }
    try:
        return db.record_template_partition_scan(row)
    except AttributeError:
        logger.debug("[partition_members] no scan record on this db seam")
        return None
    except Exception as exc:  # noqa: BLE001 -- the record is observation; the pass said it
        logger.error("[partition_members] scan record for template %s @ %s not written: %s",
                     scan.template_id, scan.business_date, exc)
        return None


def bell_unreadable(db: Any, template: Mapping[str, Any], scan: Scan, run_date: date) -> None:
    """ONE bell row for the template's creator: nothing was made for the date
    because the table's partitions could not be judged.  Best effort."""
    owner = template.get("created_by")
    if not owner:
        return
    try:
        db.log_notification(
            event_type="feed_partition_scan_unreadable", channel="websocket",
            recipient=str(owner), status="sent",
            title=f"No feed runs made for {template.get('name')}: the table could not be read",
            message=(f"Start of day on {run_date.isoformat()} could not read the partitions of "
                     f"{scan.source.get('table') or 'the table'} for {scan.business_date.isoformat()}: "
                     f"{scan.reason}.  No member was created and no run was made for this template; "
                     f"fix the cause and run start of day again for the template."),
            payload={"template_id": scan.template_id, "business_date": scan.business_date.isoformat(),
                     "href": "/feeds/sod"})
    except Exception:  # noqa: BLE001 -- advisory
        logger.debug("[partition_members] unreadable bell not recorded", exc_info=True)


def gate(scan: Optional[Scan], feed: Mapping[str, Any]) -> Optional[str]:
    """THE verdict for one member on one date.  PRESENT for ANY member whose
    pair the table holds (the scan ADMITS); ABSENT / UNREADABLE only for a
    member THE SCAN PRODUCED (``member_origin == partition_scan``) -- an
    authored or message-onboarded member the scan did not make is never
    suppressed by it: None, SOD's ordinary rules.  None too when there is no
    scan (the date is outside the window)."""
    if scan is None:
        return None
    key = feed.get("template_member_key")
    if scan.status != STATUS_UNREADABLE and key is not None and str(key) in scan.found:
        return PRESENT
    if (feed.get("member_origin") or ORIGIN_AUTHORED) != ORIGIN_SCAN:
        return None
    return UNREADABLE if scan.status == STATUS_UNREADABLE else ABSENT


def template_feed_shape(template: Mapping[str, Any]) -> Dict[str, Any]:
    """The template's feed body as the feed-shaped dict the calendar, schedule
    and policy readers take (``template_id`` set so a template-scoped policy
    applies); no id -- it is not a feed."""
    body = dict(((template.get("definition") or {}).get("feed")) or {})
    body["template_id"] = template.get("id")
    body["name"] = template.get("name")
    body.pop("id", None)
    return body


WINDOW_OPEN, WINDOW_CLOSED, WINDOW_UNREADABLE = "open", "closed", "unreadable"


def window_state(db: Any, template: Mapping[str, Any], business_date: date, run_date: date) -> Tuple[str, str]:
    """Whether ``business_date``'s member set is still RE-READ on ``run_date``:
    THE restatement window of the template's scope (``restatement.policy_for``
    + ``window_closes``).  ``open`` / ``closed`` / ``unreadable`` -- a window
    that cannot be computed (no calendar, a raise, no explicit window) is
    UNREADABLE: the pass makes nothing for the date and says so, never
    "closed, then the ordinary rules" (2026-11-10, review)."""
    from core.feed import restatement
    fc = template_feed_shape(template)
    try:
        policy = restatement.policy_for(db, fc)
        if str(policy.get("window") or "open") not in EXPLICIT_WINDOWS or policy.get("id") is None:
            return WINDOW_UNREADABLE, ("the template has no explicit re-send window (policy "
                                       f"{policy.get('name')!r}, window {policy.get('window')!r})")
        closes = restatement.window_closes(db, fc, policy, business_date)
    except Exception as exc:  # noqa: BLE001
        return WINDOW_UNREADABLE, f"the re-send window could not be computed: {exc}"
    if closes is None:
        return WINDOW_UNREADABLE, f"the re-send window has no closing date (policy {policy.get('name')!r})"
    if run_date < closes:
        return WINDOW_OPEN, f"open until {closes.isoformat()} (policy {policy.get('name')!r})"
    return WINDOW_CLOSED, f"closed since {closes.isoformat()} (policy {policy.get('name')!r})"


def templates_with_source(templates: Sequence[Mapping[str, Any]]) -> Dict[int, Mapping[str, Any]]:
    """{id: template} for every ACTIVE template with a usable declaration."""
    out: Dict[int, Mapping[str, Any]] = {}
    for t in templates:
        if not t.get("is_active", True) or t.get("id") is None:
            continue
        if declaration_problem(t):
            continue
        out[int(t["id"])] = t
    return out


__all__ = [
    "DECLARATION_FIELD", "STATUS_FOUND", "STATUS_NONE", "STATUS_UNREADABLE", "STATUS_IN_PROGRESS",
    "PRESENT", "ABSENT", "UNREADABLE", "ORIGIN_SCAN", "ORIGIN_MESSAGE", "ORIGIN_AUTHORED",
    "KEYS_KEPT", "PartitionRead", "Scan", "date_of", "NULL",
    "OF_DATE", "NOT_OF_DATE", "DATE_UNKNOWN", "DATE_SPANS",
    "declaration_problem", "registration_problem", "normalised", "check_declaration", "window_problem",
    "read_partitions", "scan_for_date", "active_member_keys", "switched_off_reason",
    "owner_id", "current_token", "try_claim", "release_claim", "refresh_claim", "template_claim", "claim_holder",
    "ClaimUnreadable", "CLAIM_HEARTBEAT_SECONDS", "CLAIM_UNKNOWN_OWNER", "unknown_holder",
    "add_members", "grow", "record", "bell_unreadable", "gate",
    "template_feed_shape", "window_state", "templates_with_source",
    "WINDOW_OPEN", "WINDOW_CLOSED", "WINDOW_UNREADABLE",
]
