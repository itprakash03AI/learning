"""Feed templates -- authoring at scale (2026-10-10, the owner's ~4,000
monthly (SYSTEM_ENTITY, EventCode) feeds).

ONE template (``core/feed/feed_template.py``) + a matrix of parameter rows
-> N ``feed_configs`` rows, created and kept current THROUGH THE ordinary
authoring routes (``feed_api.create_feed`` / ``update_feed`` /
``replace_feed_dependencies`` called in-process, the way the version
restore calls the update), so every rule they enforce applies to a member
exactly as to a hand-authored feed.  Idempotent: a member is found by
(``template_id``, ``template_member_key``), compared and left alone /
updated / created; the report names every row's outcome (created /
updated / unchanged / conflict / refused / retired / orphaned) -- never one
aggregate "done".  A template edit (PUT) or a new matrix (apply)
propagates to every member.

Routes (any signed-in author may create; modifying, applying and deleting
a template is its creator's or an admin's):

    POST   /api/feed-templates                 create + apply (201)
    GET    /api/feed-templates                 list
    GET    /api/feed-templates/{id}            one, with member counts
    GET    /api/feed-templates/{id}/members    the members
    PUT    /api/feed-templates/{id}            edit + apply
    POST   /api/feed-templates/{id}/apply      (re)apply, optional new matrix
    DELETE /api/feed-templates/{id}            detach (default) or retire members
"""
from __future__ import annotations

import asyncio
import logging
import os
import socket
import time
import uuid
from contextlib import asynccontextmanager
from datetime import date, datetime, timezone
from typing import Any, Awaitable, Callable, Dict, List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, Response, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy.exc import IntegrityError

from api.deps import get_current_user, require_capability
from core.db_async import adb
from core.feed import feed_template as _ft

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/feed-templates", tags=["feed-templates"])

_db_manager: Any = None


def set_feed_template_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


def _db() -> Any:
    if _db_manager is None:  # pragma: no cover - wiring guard
        raise HTTPException(status_code=503,
                            detail="feed templates not wired to a database")
    return _db_manager


def _feed_api():
    from api import feed_api
    return feed_api


# ── bodies ───────────────────────────────────────────────────────────────

class FeedTemplateCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    parameters: List[str]
    feed: Dict[str, Any]
    dependencies: List[Dict[str, Any]] = Field(default_factory=list)
    matrix: List[Dict[str, Any]] = Field(default_factory=list)
    #: 2026-10-11 -- a NEW system entity named by a COMPLETE message onboards
    #: itself from this template (core/feed/auto_onboard.py): {"match":
    #: {"DATA_SOURCE": ...}, "params": {PARAM: message field}, "events": [...]}
    auto_onboard: Optional[Dict[str, Any]] = None
    #: 2026-11-10 -- the MEMBER LIST FROM THE TABLE'S PARTITIONS
    #: (core/feed/partition_members.py): {"connection_id", "table",
    #: "member_columns": {PARAM: partition column}, "date_column"}
    partition_source: Optional[Dict[str, Any]] = None
    #: plan only: nothing is written, the report says what WOULD happen
    dry_run: bool = False
    #: a member whose row left the matrix is RETIRED (soft-deleted); the
    #: default leaves it alone and reports it ``orphaned``
    retire_missing: bool = False
    #: run the apply as a background JOB (202 + ``job``; poll
    #: ``GET /api/feed-templates/{id}/apply-status``).  None = the route
    #: decides: a matrix over ``SYNC_APPLY_MAX_ROWS`` rows goes to the
    #: background, a smaller one answers with the report inline.  A dry
    #: run is always inline.
    background: Optional[bool] = None


class FeedTemplateUpdate(BaseModel):
    description: Optional[str] = None
    parameters: Optional[List[str]] = None
    feed: Optional[Dict[str, Any]] = None
    dependencies: Optional[List[Dict[str, Any]]] = None
    matrix: Optional[List[Dict[str, Any]]] = None
    dry_run: bool = False
    retire_missing: bool = False
    background: Optional[bool] = None
    #: {} switches auto-onboarding OFF; omitted leaves it as it is
    auto_onboard: Optional[Dict[str, Any]] = None
    #: {} switches the partition source OFF; omitted leaves it as it is
    partition_source: Optional[Dict[str, Any]] = None


class FeedTemplateApply(BaseModel):
    matrix: Optional[List[Dict[str, Any]]] = None
    dry_run: bool = False
    retire_missing: bool = False
    background: Optional[bool] = None


class PartitionPreview(BaseModel):
    """2026-11-10 -- "what would a month end make from the table": the
    declaration, the parameters and (optionally) the matrix to compare with,
    for a business date (default: the previous month end).  Writes nothing."""
    partition_source: Dict[str, Any]
    parameters: List[str]
    matrix: List[Dict[str, Any]] = Field(default_factory=list)
    business_date: Optional[str] = None


# ── guards ───────────────────────────────────────────────────────────────

async def _checked_partition_source(declaration: Optional[Dict[str, Any]],
                                    parameters: List[str], user: dict, *,
                                    feed: Optional[Dict[str, Any]] = None,
                                    template_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """The declaration as stored ({} / None -> None), or a refusal naming the
    fault: the shape (422); the CONNECTION through THE connection access rule
    (404 "Connection not found" -- never an oracle for a connection the caller
    cannot see; 2026-11-10 review); the table's registration; the table's
    current metadata (the date column's partition transform must be identity
    or day; every column in the schema); an explicit re-send window on the
    template's scope."""
    if not declaration:
        return None
    from core.feed import partition_members as pm
    probe = {"partition_source": declaration, "parameters": parameters}
    problem = pm.declaration_problem(probe)
    if problem:
        raise HTTPException(status_code=422, detail=f"partition_source: {problem}")
    from api.connections_api import _require_connection_access
    await _require_connection_access(int(declaration["connection_id"]), user)
    problem = (await adb(pm.registration_problem, _db(), declaration)
               or await adb(pm.check_declaration, _db(), declaration)
               or await adb(pm.window_problem, _db(),
                            {"id": template_id, "definition": {"feed": dict(feed or {})}}))
    if problem:
        raise HTTPException(status_code=422, detail=f"partition_source: {problem}")
    return pm.normalised(declaration)



def _checked_auto_onboard(declaration: Optional[Dict[str, Any]],
                          parameters: List[str]) -> Optional[Dict[str, Any]]:
    """The declaration as stored ({} / None -> None), or 422 naming the fault
    -- a declaration that cannot say where a parameter comes from would onboard
    nothing, silently."""
    if not declaration:
        return None
    from core.feed.auto_onboard import declaration_problem
    problem = declaration_problem({"auto_onboard": declaration, "parameters": parameters})
    if problem:
        raise HTTPException(status_code=422, detail=f"auto_onboard: {problem}")
    return dict(declaration)

def _may_manage(template: dict, user: dict) -> None:
    fa = _feed_api()
    if not fa._auth_on():
        return
    from core.roles import is_admin_like
    if is_admin_like(user):
        return
    if str(template.get("created_by") or "") == str(user.get("username") or ""):
        return
    raise HTTPException(status_code=403,
                        detail="only the template's creator or an admin may "
                               "change or apply it")


async def _require_template(template_id: int, user: dict, *, manage: bool) -> dict:
    row = await adb(_db().get_feed_template, int(template_id))
    if not row:
        raise HTTPException(status_code=404, detail=f"feed template {template_id} not found")
    if manage:
        _may_manage(row, user)
    return row


def _spec_of(row: dict) -> _ft.TemplateSpec:
    d = row.get("definition") or {}
    try:
        return _ft.parse_template(row.get("parameters"), d.get("feed"),
                                  d.get("dependencies"))
    except _ft.FeedTemplateRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


def _rows_of(spec: _ft.TemplateSpec, matrix: Any) -> List[Dict[str, str]]:
    try:
        return _ft.parse_matrix(spec, matrix)
    except _ft.FeedTemplateRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


def _hash(parameters, definition, matrix) -> str:
    from core.feed.pinning import definition_hash
    return definition_hash({"parameters": parameters, "definition": definition,
                            "matrix": matrix})


# ── the apply ────────────────────────────────────────────────────────────

def _entry(key: str, values: Dict[str, str], name: str, **extra) -> Dict[str, Any]:
    out = {"member_key": key, "values": values, "name": name}
    out.update(extra)
    return out


async def _declare_dependencies(fid: int, rendered: _ft.RenderedMember,
                                type_ids: Dict[str, int], user: dict) -> None:
    fa = _feed_api()
    rows = []
    for d in rendered.dependencies:
        d = dict(d)
        if d.get("dependency_type_id") is None:
            tname = str(d.pop("dependency_type", "") or "").upper()
            if tname not in type_ids:
                raise HTTPException(
                    status_code=422,
                    detail=f"dependency type {tname!r} is not in the catalogue "
                           f"({sorted(type_ids)})")
            d["dependency_type_id"] = type_ids[tname]
        else:
            d.pop("dependency_type", None)
        rows.append(fa.FeedDependencyRow(**d))
    await fa.replace_feed_dependencies(
        fid, fa.FeedDependenciesReplace(dependencies=rows), user)


async def _apply(template: dict, spec: _ft.TemplateSpec, rows: List[Dict[str, str]],
                 user: dict, *, dry_run: bool, retire_missing: bool,
                 member_origin: Optional[str] = None) -> _ft.ApplyReport:
    """Apply the matrix under ONE snapshot of the estate (2026-10-10).

    Every member still goes through ``feed_api.create_feed`` / ``update_feed``
    / ``replace_feed_dependencies``, so every authoring rule holds -- but the
    two rules that need "every feed" (FR-ART-10 filename collision, FR-DEP-22
    dependency cycle) read ``core.feed.authoring_index.AuthoringIndex``,
    loaded here once (two queries) and kept current by the routes as each
    member lands, instead of listing the database per member.  That listing
    made the apply quadratic: 0.56 s/feed at N=50, 0.98 s/feed at N=400,
    ~3 h for the owner's 4,000 -- found live.  A collision between two
    members of the SAME matrix is still refused (member 2 against member 1,
    which the index already holds).  A dry run writes nothing and so needs
    no snapshot.
    """
    if dry_run:
        return await _apply_members(template, spec, rows, user, dry_run=True,
                                    retire_missing=retire_missing)
    return await _under_snapshot(
        lambda on_progress: _apply_members(template, spec, rows, user, dry_run=False,
                                           retire_missing=retire_missing,
                                           on_progress=on_progress, member_origin=member_origin))


async def _under_snapshot(run: Callable[[Any], Awaitable[Any]],
                          on_progress: Any = None) -> Any:
    """Run ``run(on_progress)`` with ONE ``AuthoringIndex`` in force for
    the duration (``feed_api._authoring_index``), loaded here (two queries)."""
    fa = _feed_api()
    from core.feed.authoring_index import AuthoringIndex
    index = await adb(AuthoringIndex.load, _db())
    token = fa._authoring_index.set(index)
    try:
        return await run(on_progress)
    finally:
        fa._authoring_index.reset(token)


# ── the apply as a JOB (2026-10-10, later) ───────────────────────────────

def _owner_id() -> str:
    return f"{socket.gethostname()}:{os.getpid()}"


def _now() -> datetime:
    return datetime.now(timezone.utc)


#: the background tasks this process is running (a reference keeps them alive)
_background_tasks: set = set()


def _background_default(rows: List[Any], requested: Optional[bool]) -> bool:
    """The route's decision when the body does not say: a matrix over
    ``SYNC_APPLY_MAX_ROWS`` rows is applied in the background."""
    if requested is not None:
        return bool(requested)
    return len(rows) > _ft.SYNC_APPLY_MAX_ROWS


async def _claim_apply_job(template: dict, rows: List[Any], user: dict, *,
                           background: bool) -> Dict[str, Any]:
    """ONE apply at a time per template.  A live job (fresh heartbeat) is a
    409 naming it; a dead owner's job (stale heartbeat) is superseded.  The
    claim itself is the compare-and-swap on ``feed_templates.apply_job_id``,
    so two requests racing here get exactly one claim."""
    db = _db()
    now = _now()
    live = _ft.apply_job_view(template.get("apply_status"), now=now)
    if live and live["state"] in _ft.JOB_LIVE_STATES:
        raise HTTPException(
            status_code=409,
            detail=f"template {template['name']!r} is being applied already "
                   f"(job {live['job_id']}, {live.get('done', 0)}/{live.get('total')} "
                   f"members, started {live.get('started_at')} by {live.get('by')}); "
                   f"poll GET /api/feed-templates/{template['id']}/apply-status "
                   f"and apply again when it has finished")
    job_id = uuid.uuid4().hex
    claimed = await adb(db.claim_feed_template_apply, int(template["id"]), job_id,
                        template.get("apply_job_id"))
    if not claimed:
        raise HTTPException(
            status_code=409,
            detail=f"template {template['name']!r} was claimed by another apply "
                   f"a moment ago; poll GET /api/feed-templates/{template['id']}"
                   f"/apply-status")
    job = _ft.new_apply_job(job_id, total=len(rows), by=user.get("username"),
                            owner=_owner_id(), background=background, now=now)
    await adb(db.set_feed_template_apply_status, int(template["id"]), job_id, job)
    return job


async def _run_apply_job(template: dict, spec: _ft.TemplateSpec, rows: List[Dict[str, str]],
                         user: dict, job: Dict[str, Any], *, retire_missing: bool
                         ) -> _ft.ApplyReport:
    """The claimed job: the SAME ``_apply_members`` pass, under one snapshot,
    with progress + heartbeat written to the row every
    ``APPLY_PROGRESS_EVERY_SECONDS`` and the report written when done."""
    db = _db()
    tid, job_id = int(template["id"]), job["job_id"]
    last_write = [time.monotonic()]

    async def _write() -> None:
        job["heartbeat_at"] = _now().isoformat()
        await adb(db.set_feed_template_apply_status, tid, job_id, job)
        last_write[0] = time.monotonic()

    async def on_progress(done: int, report: _ft.ApplyReport) -> None:
        if time.monotonic() - last_write[0] >= _ft.APPLY_PROGRESS_EVERY_SECONDS:
            job["done"] = int(done)
            job["counts"] = report.to_dict()["counts"]
            await _write()

    job["state"] = _ft.JOB_RUNNING
    await _write()
    try:
        report = await _under_snapshot(
            lambda cb: _apply_members(template, spec, rows, user, dry_run=False,
                                      retire_missing=retire_missing, on_progress=cb),
            on_progress)
    except Exception as exc:  # noqa: BLE001 -- recorded on the job, then re-raised
        job.update(state=_ft.JOB_FAILED, finished_at=_now().isoformat(),
                   error=f"{type(exc).__name__}: {exc}"[:2000])
        await _write()
        raise
    rep = report.to_dict()
    if report.stopped:
        # third review: a lost claim is a FAILED job with the reason and the
        # report so far -- never "completed" over rows that were not applied
        job.update(state=_ft.JOB_FAILED, done=len(rows) - len([r for r in rep["refused"] if r.get("status") == 409
                                                                   and str(r.get("reason", "")).startswith("not applied")]),
                   counts=rep["counts"], finished_at=_now().isoformat(), report=rep,
                   error=f"stopped: {report.stopped}"[:2000])
    else:
        job.update(state=_ft.JOB_COMPLETED, done=len(rows), counts=rep["counts"],
                   finished_at=_now().isoformat(), report=rep)
    await _write()
    return report


async def _apply_or_schedule(template: dict, spec: _ft.TemplateSpec,
                             rows: List[Dict[str, str]], user: dict, *,
                             dry_run: bool, retire_missing: bool,
                             background: Optional[bool],
                             lease: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """What a route answers: ``{"report": ...}`` for an inline apply (and
    every dry run), ``{"job": ..., "report": None}`` for a background one
    (the caller answers 202 and the client polls).  ``lease`` -- the growth
    claim the route holds (``_hold_claim``): a background apply INHERITS it
    (the task is created in the route's context, so the claim token is its
    too) and becomes the one that RELEASES it when it finishes; the route
    then leaves ``_hold_claim`` without releasing (2026-11-10, third review:
    the route's release used to free the claim while the 6,000-row apply
    ran on unclaimed)."""
    if dry_run:
        report = await _apply(template, spec, rows, user, dry_run=True,
                              retire_missing=retire_missing)
        return {"report": report.to_dict(), "job": None}
    bg = _background_default(rows, background)
    job = await _claim_apply_job(template, rows, user, background=bg)
    if not bg:
        report = await _run_apply_job(template, spec, rows, user, job,
                                      retire_missing=retire_missing)
        return {"report": report.to_dict(),
                "job": {k: v for k, v in job.items() if k != "report"}}

    handed = None
    if lease and lease.get("token") and lease.get("release"):
        lease["release"] = False                   # handed on: the task releases it
        handed = {"template_id": int(template["id"]), "token": lease["token"]}

    async def _runner() -> None:
        try:
            await _run_apply_job(template, spec, rows, user, job,
                                 retire_missing=retire_missing)
        except Exception:  # noqa: BLE001 -- the job row carries it
            logger.exception("[feed_template] background apply of %s (job %s) failed",
                             template.get("name"), job["job_id"])
        finally:
            if handed is not None:
                from core.feed import partition_members as _pm
                await adb(_pm.release_claim, _db(), handed["template_id"], handed["token"])

    task = asyncio.create_task(_runner(), name=f"feed-template-apply-{job['job_id']}")
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)
    logger.info("[feed_template] %s: %d rows applied in the BACKGROUND (job %s) by %s",
                template.get("name"), len(rows), job["job_id"], user.get("username"))
    return {"report": None, "job": dict(job)}


def _job_status(row: dict) -> Optional[Dict[str, Any]]:
    return _ft.apply_job_view(row.get("apply_status"), now=_now())


def _member_group_id(db, gname: str, cache: dict, user: dict, dry_run: bool) -> Optional[int]:
    """The Feed Group a member's rendered group rule names: an existing group
    (active or not -- the operator's state stands), else created ONCE per
    apply.  A dry run creates nothing (None: the plan does not set it)."""
    if gname in cache:
        return cache[gname]
    if not gname or len(gname) > 100:
        raise ValueError(f"group rule rendered {gname!r}: a Feed Group name must be "
                         f"1-100 characters")
    g = db.get_feed_group_by_name(gname)
    if g is None and not dry_run:
        try:
            g = db.create_feed_group({"name": gname, "display_label": gname,
                                      "description": "created by a feed template's group rule",
                                      "created_by": (user or {}).get("username")})
        except Exception:                               # noqa: BLE001 -- a racing apply made it
            g = db.get_feed_group_by_name(gname)
    cache[gname] = int(g["id"]) if g else None
    return cache[gname]


async def _apply_members(template: dict, spec: _ft.TemplateSpec,
                         rows: List[Dict[str, str]], user: dict, *,
                         dry_run: bool, retire_missing: bool,
                         on_progress: Optional[Callable[[int, _ft.ApplyReport],
                                                        Awaitable[None]]] = None,
                         member_origin: Optional[str] = None
                         ) -> _ft.ApplyReport:
    """2026-11-10 (review): every producer of members -- the routes (hand /
    Excel / SQL), auto-onboarding, the partition scan -- lands here, so the
    ONE per-template growth claim (core/feed/partition_members.py) is taken
    here: a live holder is a 409 naming it; the same producer re-enters its
    own claim.  ``member_origin`` is stamped on every member created."""
    from core.feed import partition_members as _pm
    claimed, holder, token, reset = False, None, None, None
    beat = on_progress
    if not dry_run and template.get("id") is not None:
        _owner = _pm.owner_id()
        tid = int(template["id"])
        # the token of the claim THIS context holds (a route's _hold_claim, a
        # SOD thread's template_claim, a background task's inherited one) --
        # read here, in the coroutine, and handed to the worker explicitly
        claimed, holder, token = await adb(_pm.try_claim, _db(), tid, _owner, held=_pm.current_token())
        if holder is not None:
            raise HTTPException(status_code=409, detail=_held_detail(template, holder))
        if claimed:
            reset = _pm._claim_token.set(token)
        # 2026-11-10 (second review): the HEARTBEAT -- a 6,000-member apply runs
        # past CLAIM_STALE_SECONDS; without it another pass judges the claim
        # stale mid-way and takes it over.  Third review: a heartbeat that
        # FAILS means the claim is not ours any more -- the apply STOPS.
        last_beat = [time.monotonic()]

        async def beat(done: int, report: _ft.ApplyReport) -> None:
            if time.monotonic() - last_beat[0] >= _pm.CLAIM_HEARTBEAT_SECONDS:
                if not await adb(_pm.refresh_claim, _db(), tid, token):
                    try:
                        now_holder = await adb(_pm.claim_holder, _db(), tid)
                    except Exception as exc:  # noqa: BLE001
                        now_holder = _pm.unknown_holder(str(exc))
                    raise ClaimLost(
                        f"the growth claim on template {template.get('name')!r} was lost after {done} of "
                        f"{len(rows)} row(s): it is now "
                        + (f"held by {now_holder.get('owner')} since {now_holder.get('claimed_at')}"
                           if now_holder else "free (released or taken over and released)")
                        + " -- the apply stopped; the rows not applied are refused below")
                last_beat[0] = time.monotonic()
            if on_progress is not None:
                await on_progress(done, report)
    try:
        return await _apply_members_body(template, spec, rows, user, dry_run=dry_run,
                                         retire_missing=retire_missing, on_progress=beat,
                                         member_origin=member_origin or _pm.ORIGIN_AUTHORED)
    finally:
        if reset is not None:
            _pm._claim_token.reset(reset)
        if claimed:
            await adb(_pm.release_claim, _db(), int(template["id"]), token)


class ClaimLost(RuntimeError):
    """The apply's heartbeat found the growth claim is no longer its own:
    the apply stops (recorded on the report as ``stopped``, on a job as its
    error) rather than run on unclaimed beside another producer."""


def _held_detail(template: dict, holder: dict) -> str:
    from core.feed import partition_members as _pm
    if holder.get("owner") == _pm.CLAIM_UNKNOWN_OWNER:
        return (f"template {template.get('name')!r}: whether another pass is applying it could not be "
                f"read ({holder.get('reason')}) -- unknown is not free; nothing was changed, try again")
    return (f"template {template.get('name')!r} is being applied by another pass "
            f"({holder.get('owner')} since {holder.get('claimed_at')}) -- a start of day, "
            f"an onboarding or another request; apply again when it has finished")


@asynccontextmanager
async def _hold_claim(template: dict):
    """2026-11-10 (second review): a route that WRITES THE MATRIX (PUT, apply
    with a new matrix) holds the template's growth claim around the write and
    its apply, so a scan or an onboarding cannot grow the matrix between the
    two; the nested ``_apply_members`` re-enters it (by TOKEN -- the claim's
    identity; an owner string is shared by every request on a pod).  A live
    holder is a 409 and NOTHING is written.  Yields the lease ``{"token",
    "release"}``: ``_apply_or_schedule`` hands it on to a background apply,
    which then releases it; otherwise this releases it on exit."""
    from core.feed import partition_members as _pm
    if template.get("id") is None:
        yield {"token": None, "release": False}
        return
    _owner = _pm.owner_id()
    tid = int(template["id"])
    claimed, holder, token = await adb(_pm.try_claim, _db(), tid, _owner, held=_pm.current_token())
    if holder is not None:
        raise HTTPException(status_code=409, detail=_held_detail(template, holder))
    lease = {"token": token, "release": bool(claimed)}
    reset = _pm._claim_token.set(token) if claimed else None
    try:
        yield lease
    finally:
        if reset is not None:
            _pm._claim_token.reset(reset)
        if lease["release"]:
            await adb(_pm.release_claim, _db(), tid, token)


async def _apply_members_body(template: dict, spec: _ft.TemplateSpec,
                              rows: List[Dict[str, str]], user: dict, *,
                              dry_run: bool, retire_missing: bool,
                              on_progress: Optional[Callable[[int, _ft.ApplyReport],
                                                             Awaitable[None]]],
                              member_origin: str) -> _ft.ApplyReport:
    fa = _feed_api()
    db = _db()
    t0 = time.monotonic()
    report = _ft.ApplyReport(template_id=template["id"], dry_run=dry_run)
    types = await adb(db.list_etl_dependency_types, None)
    type_ids = {str(t["dependency_type"]).upper(): int(t["id"]) for t in types}
    members = ({} if template.get("id") is None else
               {m["template_member_key"]: m
                for m in (await adb(db.list_template_members, template["id"]))})
    seen_keys = set()

    groups: Dict[str, Optional[int]] = {}
    for done, values in enumerate(rows):
        if on_progress is not None and done:
            try:
                await on_progress(done, report)
            except ClaimLost as exc:
                # third review: the heartbeat found the claim is not ours --
                # STOP here; every row not applied is said, the report records why
                report.stopped = str(exc)
                for left in rows[done:]:
                    r = _ft.render_member(spec, left)
                    report.refused.append(_entry(r.member_key, left, r.name, status=409,
                                                 reason=f"not applied: {exc}"[:1000]))
                logger.error("[feed_template] %s: %s", template.get("name"), exc)
                break
        rendered = _ft.render_member(spec, values)
        key, name = rendered.member_key, rendered.name
        seen_keys.add(key)
        stored = members.get(key)
        # 2026-10-12 (owner R1) -- the group RULE: the rendered name is a
        # DEFINED Feed Group (created on first use); the member stores its id.
        gname = rendered.feed.pop(_ft.FEED_GROUP_RULE_FIELD, None)
        if gname is not None:
            try:
                gid = await adb(_member_group_id, db, str(gname).strip(), groups,
                                user, dry_run)
            except ValueError as exc:
                report.refused.append(_entry(key, values, name, status=422, reason=str(exc)))
                continue
            if gid is not None:
                rendered.feed["feed_group_id"] = gid
        if stored is None:
            dup = await adb(db.get_feed_ids_by_name, name)
            if dup:
                report.conflicts.append(_entry(
                    key, values, name, feed_id=dup[0],
                    reason=f"feed {name!r} already exists (id {dup[0]}) and is "
                           f"not a member of this template; rename it or the "
                           f"template -- nothing is adopted silently"))
                continue
            if dry_run:
                report.created.append(_entry(key, values, name, planned=True))
                continue
            # 2026-11-10 (second review): the member AS OF NOW, on the primary --
            # the ``members`` dict above is a snapshot from the apply's start
            if template.get("id") is not None:
                other = await adb(db.active_member_feed_id, int(template["id"]), key)
                if other is not None:
                    report.conflicts.append(_entry(
                        key, values, name, feed_id=int(other),
                        reason=f"another pass created this member a moment ago (feed {other}); "
                               f"nothing was created -- the next apply finds the member unchanged"))
                    continue
            # the stamp rides the INSERT (feed_api._member_stamp): the unique
            # index on ACTIVE (template, key) then refuses the duplicate ROW --
            # no copy ever exists to be retired
            stamp = ({"template_id": int(template["id"]), "template_member_key": key,
                      "member_origin": member_origin} if template.get("id") is not None else None)
            token = fa._member_stamp.set(stamp)
            try:
                created = await fa.create_feed(fa.FeedConfigCreate(**rendered.feed), user)
            except HTTPException as exc:
                report.refused.append(_entry(key, values, name, status=exc.status_code,
                                             reason=str(exc.detail)[:1000]))
                continue
            except IntegrityError as exc:
                # the unique index: another pass made this member between the
                # check above and the INSERT; the row was never written
                report.conflicts.append(_entry(
                    key, values, name,
                    reason=f"another pass created this member a moment ago ({type(exc).__name__}); "
                           f"nothing was created -- the next apply finds the member unchanged"))
                continue
            except Exception as exc:  # noqa: BLE001 -- a pydantic shape error is a per-row refusal
                report.refused.append(_entry(key, values, name, status=422,
                                             reason=f"{type(exc).__name__}: {exc}"[:1000]))
                continue
            finally:
                fa._member_stamp.reset(token)
            fid = int(created["id"])
            try:
                await _declare_dependencies(fid, rendered, type_ids, user)
            except HTTPException as exc:
                # keep the apply atomic per member: a feed without its gate
                # is not a member, it is a feed that would run ungated.
                await adb(db.deactivate_feed_config, fid)
                await adb(db.stamp_template_member, fid, None, None)
                report.refused.append(_entry(
                    key, values, name, status=exc.status_code,
                    reason=f"dependencies refused, member retired again: "
                           f"{exc.detail}"[:1000]))
                continue
            report.created.append(_entry(key, values, name, feed_id=fid))
            continue

        fid = int(stored["id"])
        if not stored.get("is_active", True):
            # 2026-11-10 (second review): a member a person SWITCHED OFF stays
            # off -- an apply (hand, Excel, SQL, a scan, an onboarding) never
            # switches it back on; only Switch on (core/config_active) does.
            # It used to set is_active = True here, and every start of day
            # re-lit the owner's switch-off.
            from core.feed import partition_members as _pm
            when = f"on {str(stored.get('updated_at') or '')[:19] or 'an unknown time'}"
            try:                                     # third review: WHO and WHEN from the switch-off record
                rec = (await adb(db.last_switch_offs, "feed_configs", [fid])).get(fid)
                if rec:
                    when = _pm.switched_off_words(rec[0], rec[1])
            except Exception:  # noqa: BLE001 -- the row's time stands
                pass
            report.refused.append(_entry(key, values, name, feed_id=fid, status=409,
                                         switched_off=True,
                                         reason=_pm.switched_off_reason(key, when)))
            continue
        changes = _ft.changed_fields(stored, rendered.feed)
        etl_id = fa._resolve_etl_id_for_feed(stored)
        current_deps = await adb(db.list_etl_dependency_mappings, etl_id)
        deps_changed = _ft.dependencies_differ(current_deps, rendered.dependencies, type_ids)
        if not changes and not deps_changed:
            report.unchanged.append(_entry(key, values, name, feed_id=fid))
            continue
        if dry_run:
            report.updated.append(_entry(key, values, name, feed_id=fid, planned=True,
                                         fields=sorted(changes),
                                         dependencies=deps_changed))
            continue
        try:
            if changes:
                await fa.update_feed(fid, fa.FeedConfigUpdate(**changes), user)
            if deps_changed:
                await _declare_dependencies(fid, rendered, type_ids, user)
        except HTTPException as exc:
            report.refused.append(_entry(key, values, name, feed_id=fid,
                                         status=exc.status_code,
                                         reason=str(exc.detail)[:1000]))
            continue
        except Exception as exc:  # noqa: BLE001
            report.refused.append(_entry(key, values, name, feed_id=fid, status=422,
                                         reason=f"{type(exc).__name__}: {exc}"[:1000]))
            continue
        report.updated.append(_entry(key, values, name, feed_id=fid,
                                     fields=sorted(changes), dependencies=deps_changed))
    if on_progress is not None and rows and not report.stopped:
        try:
            await on_progress(len(rows), report)
        except ClaimLost as exc:
            report.stopped = str(exc)               # every row is applied; nothing is retired below

    for key, m in members.items():
        if report.stopped or key in seen_keys or not m.get("is_active", True):
            continue
        entry = _entry(key, {}, m["name"], feed_id=int(m["id"]))
        if not retire_missing:
            report.orphaned.append(entry)
            continue
        if dry_run:
            entry["planned"] = True
            report.retired.append(entry)
            continue
        try:
            await fa.delete_feed(int(m["id"]), True, user)
            report.retired.append(entry)
        except HTTPException as exc:
            entry.update(status=exc.status_code, reason=str(exc.detail)[:1000])
            report.refused.append(entry)

    report.seconds = time.monotonic() - t0
    if not dry_run:
        await adb(db.update_feed_template, template["id"], {
            "last_applied_at": datetime.now(timezone.utc),
            "last_apply_report": {"counts": report.to_dict()["counts"],
                                  "seconds": round(report.seconds, 3),
                                  "by": user.get("username")},
        })
    logger.info("[feed_template] %s applied by %s: %s in %.1fs%s", template["name"],
                user.get("username"), report.to_dict()["counts"], report.seconds,
                " (dry run)" if dry_run else "")
    return report


# ── routes ───────────────────────────────────────────────────────────────

@router.post("", status_code=201)
async def create_feed_template(body: FeedTemplateCreate, response: Response,
                               user: dict = Depends(require_capability("feeds.author"))):
    """Create + apply.  201 with the report; 202 with ``job`` when the apply
    runs in the background (``background: true``, or a matrix over
    ``SYNC_APPLY_MAX_ROWS`` rows) -- poll ``GET .../{id}/apply-status``."""
    db = _db()
    try:
        spec = _ft.parse_template(body.parameters, body.feed, body.dependencies)
        rows = _ft.parse_matrix(spec, body.matrix)
    except _ft.FeedTemplateRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    same = await adb(db.get_feed_template_by_name, body.name, include_inactive=True)
    if same and same.get("is_active") is False:
        # 2026-10-30 -- a deleted template is switched off and keeps its name
        from core.config_active import name_held_message
        raise HTTPException(status_code=409,
                            detail=name_held_message("feed template", same["name"]))
    if same:
        raise HTTPException(status_code=409,
                            detail=f"feed template {body.name!r} already exists; "
                                   f"PUT or apply it instead")
    definition = spec.to_definition()
    data = {"name": body.name.strip(), "description": body.description,
            "parameters": spec.parameters, "definition": definition,
            "matrix": rows, "definition_hash": _hash(spec.parameters, definition, rows),
            "created_by": user.get("username", "unknown"), "is_active": True,
            "auto_onboard": _checked_auto_onboard(body.auto_onboard, spec.parameters),
            "partition_source": await _checked_partition_source(body.partition_source, spec.parameters, user,
                                                                feed=body.feed)}
    if body.dry_run:
        template = dict(data, id=None)
        report = await _apply(template, spec, rows, user, dry_run=True,
                              retire_missing=body.retire_missing)
        return {"template": None, "report": report.to_dict(), "job": None}
    template = await adb(db.create_feed_template, data)
    outcome = await _apply_or_schedule(template, spec, rows, user, dry_run=False,
                                       retire_missing=body.retire_missing,
                                       background=body.background)
    if outcome["report"] is None:
        response.status_code = 202
    return {"template": await adb(db.get_feed_template, template["id"]),
            "report": outcome["report"], "job": outcome["job"]}


# ── the matrix as an Excel file (2026-10-28, core/feed/template_matrix_file.py) ──
# The owner: "onboard 4000 jobs ... if they upload excel file ... if we provide
# template".  Declared before "/{template_id}" so the path parameter does not
# swallow them.

def _parameter_list(parameters: str) -> List[str]:
    return [p.strip() for p in str(parameters or "").split(",") if p.strip()]


@router.get("/matrix-file-template")
async def download_matrix_template(parameters: str = Query(..., description="the template's parameters, comma-separated"),
                                   name: str = Query("feeds", max_length=80),
                                   user: dict = Depends(require_capability("feeds.view"))):
    """The Excel file to fill in: header row = the parameters, one example row."""
    from core.feed.template_matrix_file import MatrixFileRefused, matrix_template_xlsx
    try:
        data = await asyncio.to_thread(matrix_template_xlsx, _parameter_list(parameters))
    except MatrixFileRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    safe = "".join(ch for ch in name if ch.isalnum() or ch in "-_") or "feeds"
    return Response(content=data,
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="{safe}_template.xlsx"'})


@router.post("/matrix-file")
async def read_matrix_upload(parameters: str = Query(...),
                             file: UploadFile = File(...),
                             user: dict = Depends(require_capability("feeds.author"))):
    """An uploaded .xlsx / .csv as the matrix rows, with every problem named by
    row and column.  Writes nothing -- Plan / Apply do."""
    from core.feed.template_matrix_file import MAX_BYTES, MatrixFileRefused, read_matrix_file
    data = await file.read(MAX_BYTES + 1)
    try:
        return await asyncio.to_thread(read_matrix_file, file.filename or "", data, _parameter_list(parameters))
    except MatrixFileRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get("/onboarding")
async def list_onboarding_requests(status: Optional[str] = Query(None),
                                   limit: Optional[int] = Query(None, ge=1, le=5000),
                                   page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=500),
                                   user: dict = Depends(require_capability("feeds.view"))):
    """2026-10-11 -- every NEW system entity a COMPLETE message named and what
    became of it (pending / onboarded / refused / failed), newest first, with
    the feed it became and what SOD did for its business date
    (core/feed/auto_onboard.py).  PAGED (2026-10-12, core/feed/paging.py):
    the counts are over every request, never the page's."""
    from core.feed.paging import block, paging
    p = paging(page, limit if limit is not None else page_size)
    rows = await adb(_db().list_onboarding_requests, status, p.page_size, p.offset)
    counts = await adb(_db().onboarding_request_counts)
    total = counts.get(status, 0) if status else sum(counts.values())
    return {"requests": rows, "counts": counts, "paging": block(total, p, len(rows))}


@router.post("/partition-preview")
async def preview_partition_members(body: PartitionPreview,
                                    user: dict = Depends(require_capability("feeds.author"))):
    """2026-11-10 -- what a start of day WOULD make from the table's partitions
    for a business date (default: the previous month end): the pairs found,
    which are new against the matrix, which matrix members have no data,
    which values the SQL renderer refuses -- or ``unreadable`` with the reason.
    Reads the Iceberg metadata only (no data file); writes nothing.  The
    form's "Check the table" button (core/feed/partition_members.py)."""
    from core.feed import partition_members as pm
    probe = {"id": None, "parameters": list(body.parameters), "matrix": list(body.matrix),
             "partition_source": body.partition_source}
    problem = pm.declaration_problem(probe)
    if problem:
        raise HTTPException(status_code=422, detail=f"partition_source: {problem}")
    from api.connections_api import _require_connection_access
    await _require_connection_access(int(body.partition_source["connection_id"]), user)   # 404, never an oracle
    if body.business_date:
        try:
            bd = date.fromisoformat(body.business_date)
        except ValueError:
            raise HTTPException(status_code=422, detail="business_date must be YYYY-MM-DD")
    else:
        from core.feed.calendar import BusinessCalendar
        bd = BusinessCalendar(None).previous_eom(datetime.now(timezone.utc).date())
    scan = await asyncio.to_thread(pm.scan_for_date, _db(), probe, bd)
    out = scan.summary()
    out.update({"found_keys": sorted(scan.found)[:pm.KEYS_KEPT], "new_keys": list(scan.new)[:pm.KEYS_KEPT],
                "found_rows": {k: scan.rows_words(k) for k in sorted(scan.found)[:pm.KEYS_KEPT]},
                "missing_keys": list(scan.missing)[:pm.KEYS_KEPT], "refused_values": list(scan.refused)[:200],
                "note": ("Nothing was written. Start of day creates the new members and their runs "
                         "for the date when the template is saved with this declaration.")})
    return out


@router.get("")
async def list_feed_templates(user: dict = Depends(require_capability("feeds.view"))):
    db = _db()
    out = []
    for t in await adb(db.list_feed_templates):
        members = await adb(db.list_template_members, t["id"])
        t = dict(t)
        t.pop("definition", None)
        t["matrix_rows"] = len(t.pop("matrix", []) or [])
        t["members"] = len(members)
        t["active_members"] = sum(1 for m in members if m.get("is_active", True))
        if t.get("partition_source"):
            t["partition_scan"] = await adb(db.latest_template_partition_scan, t["id"])
        out.append(t)
    return {"items": out, "count": len(out)}


@router.get("/{template_id}/partition-scans")
async def list_partition_scans(template_id: int, days: int = Query(45, ge=0, le=3660),
                               user: dict = Depends(require_capability("feeds.view"))):
    """2026-11-10 -- what each start of day found in the template's table per
    business date: found / none / unreadable, the pairs, who was created, who
    had no data, the reason (core/feed/partition_members.py)."""
    row = await _require_template(template_id, user, manage=False)
    items = await adb(_db().list_template_partition_scans, row["id"], days=days)
    return {"template_id": row["id"], "partition_source": row.get("partition_source"),
            "items": items, "count": len(items)}


@router.get("/{template_id}")
async def get_feed_template(template_id: int, user: dict = Depends(require_capability("feeds.view"))):
    row = await _require_template(template_id, user, manage=False)
    members = await adb(_db().list_template_members, row["id"])
    row = dict(row)
    row["members"] = len(members)
    row["active_members"] = sum(1 for m in members if m.get("is_active", True))
    row["definition"] = {"feed": _feed_api()._mask_feed_secrets(
        dict((row.get("definition") or {}).get("feed") or {})),
        "dependencies": (row.get("definition") or {}).get("dependencies") or []}
    row["apply_status"] = _job_status(row)
    if row.get("partition_source"):
        row["partition_scan"] = await adb(_db().latest_template_partition_scan, row["id"])
    return row


@router.get("/{template_id}/apply-status")
async def get_feed_template_apply_status(template_id: int,
                                         user: dict = Depends(require_capability("feeds.view"))):
    """The current / last apply as a JOB: state (queued / running /
    completed / failed), done / total, counts so far, heartbeat, and the
    full report once completed -- read from the template row, so any pod
    answers.  A running job whose owner stopped (stale heartbeat) is
    reported ``failed`` with the reason, never in flight for ever.
    ``job`` is null for a template never applied."""
    row = await _require_template(template_id, user, manage=False)
    return {"template_id": row["id"], "job": _job_status(row)}


@router.get("/{template_id}/members")
async def list_feed_template_members(template_id: int,
                                     user: dict = Depends(require_capability("feeds.view"))):
    row = await _require_template(template_id, user, manage=False)
    members = await adb(_db().list_template_members, row["id"])
    return {"template_id": row["id"], "count": len(members),
            "items": [{"id": m["id"], "name": m["name"],
                       "member_key": m["template_member_key"],
                       "is_active": m.get("is_active", True),
                       "schedule_enabled": m.get("schedule_enabled")} for m in members]}


@router.put("/{template_id}")
async def update_feed_template(template_id: int, body: FeedTemplateUpdate,
                               response: Response,
                               user: dict = Depends(require_capability("feeds.author"))):
    db = _db()
    row = await _require_template(template_id, user, manage=True)
    d = row.get("definition") or {}
    parameters = body.parameters if body.parameters is not None else row.get("parameters")
    feed = body.feed if body.feed is not None else d.get("feed")
    dependencies = (body.dependencies if body.dependencies is not None
                    else d.get("dependencies"))
    matrix = body.matrix if body.matrix is not None else row.get("matrix")
    try:
        spec = _ft.parse_template(parameters, feed, dependencies)
        rows = _ft.parse_matrix(spec, matrix)
    except _ft.FeedTemplateRefused as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    definition = spec.to_definition()
    if body.dry_run:
        probe = dict(row, parameters=spec.parameters, definition=definition, matrix=rows)
        report = await _apply(probe, spec, rows, user, dry_run=True,
                              retire_missing=body.retire_missing)
        return {"template": row, "report": report.to_dict()}
    partition_source = (await _checked_partition_source(body.partition_source, spec.parameters, user,
                                                        feed=feed, template_id=row["id"])
                        if body.partition_source is not None else row.get("partition_source"))
    # the matrix write and its apply under the template's ONE growth claim
    # (2026-11-10, second review): a live holder is a 409 before anything lands
    async with _hold_claim(row) as lease:
        updated = await adb(db.update_feed_template, row["id"], {
            "description": body.description if body.description is not None else row.get("description"),
            "parameters": spec.parameters, "definition": definition, "matrix": rows,
            "definition_hash": _hash(spec.parameters, definition, rows),
            "auto_onboard": (_checked_auto_onboard(body.auto_onboard, spec.parameters)
                             if body.auto_onboard is not None else row.get("auto_onboard")),
            "partition_source": partition_source})
        outcome = await _apply_or_schedule(updated, spec, rows, user, dry_run=False,
                                           retire_missing=body.retire_missing,
                                           background=body.background, lease=lease)
    if outcome["report"] is None:
        response.status_code = 202
    return {"template": await adb(db.get_feed_template, row["id"]),
            "report": outcome["report"], "job": outcome["job"]}


@router.post("/{template_id}/apply")
async def apply_feed_template(template_id: int, response: Response,
                              body: Optional[FeedTemplateApply] = None,
                              user: dict = Depends(require_capability("feeds.author"))):
    db = _db()
    body = body or FeedTemplateApply()
    row = await _require_template(template_id, user, manage=True)
    spec = _spec_of(row)
    matrix = body.matrix if body.matrix is not None else row.get("matrix")
    rows = _rows_of(spec, matrix)
    async with _hold_claim(row if (body.matrix is not None and not body.dry_run) else {"id": None}) as lease:
        if body.matrix is not None and not body.dry_run:
            row = await adb(db.update_feed_template, row["id"], {
                "matrix": rows,
                "definition_hash": _hash(spec.parameters, row.get("definition"), rows)})
        outcome = await _apply_or_schedule(row, spec, rows, user, dry_run=body.dry_run,
                                           retire_missing=body.retire_missing,
                                           background=body.background, lease=lease)
    if outcome["report"] is None:
        response.status_code = 202
    return {"template_id": row["id"], "report": outcome["report"], "job": outcome["job"]}


@router.delete("/{template_id}")
async def delete_feed_template(template_id: int,
                               delete_members: bool = Query(default=False),
                               user: dict = Depends(require_capability("feeds.author"))):
    """Remove the template.  ``delete_members=true`` RETIRES every member
    (the ordinary soft delete, dependents acknowledged); the default leaves
    them running as ordinary feeds.

    2026-10-30 (owner): the template is SWITCHED OFF, never erased
    (core/config_active.py).  Its members KEEP their link (``template_id``)
    so "Switch on" (Admin -> Switched off) brings the template back with its
    members; while it is off nothing manages them -- no apply, no
    auto-onboarding, no template-scoped SOD (every read hides it).  The link
    used to be cut here ("detached"); a switched-on template would then have
    lost its members and its next apply would have re-created every one."""
    db = _db()
    row = await _require_template(template_id, user, manage=True)
    members = await adb(db.list_template_members, row["id"])
    retired, failed = [], []
    # 2026-11-10 (third review): the members retired WITH the template share
    # its switch-off EVENT (config_switch_offs.event), so switching the
    # template back on brings exactly those members with it
    event = f"feed_template:{row['id']}:{uuid.uuid4().hex[:12]}"
    if delete_members:
        fa = _feed_api()

        async def _retire_all(_cb) -> None:
            # under ONE snapshot: delete_feed's downstream check used to
            # list every feed and query each one's mappings per member
            token = fa._switch_off_event.set(event)
            try:
                for m in members:
                    try:
                        if m.get("is_active", True):
                            await fa.delete_feed(int(m["id"]), True, user)
                        retired.append(int(m["id"]))
                    except HTTPException as exc:
                        failed.append({"feed_id": int(m["id"]), "status": exc.status_code,
                                       "reason": str(exc.detail)[:500]})
            finally:
                fa._switch_off_event.reset(token)
        await _under_snapshot(_retire_all)
    await adb(db.delete_feed_template, row["id"], user.get("username") or None, event)
    return {"deleted": row["id"], "switched_off": True, "members": len(members),
            "retired": retired, "detached": 0, "failed": failed, "event": event}


# ── the road BACK after "a switch-off sticks" (2026-11-10, third review) ──
# An apply never switches a retired member on.  The explicit, admin, audited
# way is here: ONE transaction for the template's switched-off members, under
# the template's growth claim, through core/config_active's actor rule
# (feed_configs: admins only) and feed_api's BEFORE / ON switch-on hooks.

class MembersSwitchOn(BaseModel):
    keys: Optional[List[str]] = None
    all_switched_off: bool = False


async def switch_on_members(template: dict, user: dict, *, keys: Optional[List[str]] = None,
                            all_switched_off: bool = False) -> Dict[str, Any]:
    """THE members switch-on (the route and the template's own switch-on land
    here; the SQL road never does -- fourth review).  Only members whose row
    is still in the template's matrix come back (``not_in_template`` says the
    others); and inside the SAME claim, right after they are on, the template
    is APPLIED to exactly those rows, so no member runs under the
    configuration it was switched off with (``applied`` carries that report)."""
    from api.config_active_api import BEFORE_SWITCH_ON, ON_SWITCH_ON, _may_act
    db = _db()
    if not all_switched_off and not keys:
        raise HTTPException(status_code=422, detail="name the members to switch on (keys) or all_switched_off: true")
    wanted = None if all_switched_off else [str(k) for k in keys]
    before = BEFORE_SWITCH_ON.get("feed_configs") or (lambda row, u: None)
    spec = _spec_of(template)
    rows_by_key = {_ft.member_key(spec.parameters, r): r for r in _rows_of(spec, template.get("matrix"))}

    auth_on = _feed_api()._auth_on()                 # no-auth deployments are never locked out (feed_api's posture)
    async with _hold_claim(template):
        out = await adb(db.switch_on_template_members, int(template["id"]), wanted,
                        may_act=lambda row, session: (not auth_on) or _may_act(user, row, "feed_configs", session),
                        before_check=lambda row: before(row, user),
                        allowed_keys=list(rows_by_key))
        on_keys = [str(r.get("template_member_key")) for r in out["switched_on"]]
        applied = None
        if on_keys:
            # the current definition onto the members just switched on -- same
            # claim, no gap where they are on under the old configuration
            report = await _apply(template, spec, [rows_by_key[k] for k in on_keys], user,
                                  dry_run=False, retire_missing=False)
            applied = report.to_dict()

    hook = ON_SWITCH_ON.get("feed_configs")
    notes: List[str] = []
    if hook is not None and out["switched_on"]:
        def _follow_ups() -> List[str]:              # off the event loop: 6,000 schedule registrations
            got = []
            for row in out["switched_on"]:
                try:
                    note = hook(row, user)
                    if note:
                        got.append(f"{row.get('name')}: {note}")
                except Exception as exc:  # noqa: BLE001 -- the member IS on; say what did not follow
                    got.append(f"{row.get('name')}: on, but this did not follow: {exc}")
            return got
        notes = await adb(_follow_ups)
    if out["switched_on"]:
        try:
            from core.audit import audit_event
            await adb(lambda: audit_event(
                db, user or {}, action="feed_template_members_switched_on",
                resource_type="feed_templates", resource_id=int(template["id"]),
                details={"name": template.get("name"), "keys": on_keys,
                         "feed_ids": [int(r["id"]) for r in out["switched_on"]]}))
        except Exception as exc:  # noqa: BLE001
            logger.warning("[feed_template] audit of members switch-on on %s NOT recorded: %s",
                           template.get("name"), exc, exc_info=True)
    logger.warning("[feed_template] %s: %d member(s) switched on by %s (%d refused, %d not in the matrix)",
                   template.get("name"), len(out["switched_on"]), user.get("username"), len(out["refused"]),
                   len(out["not_in_template"]))
    return {"template_id": int(template["id"]),
            "switched_on": [{"key": r.get("template_member_key"), "feed_id": int(r["id"]), "name": r.get("name")}
                            for r in out["switched_on"]],
            "refused": out["refused"], "not_switched_off": out["not_switched_off"],
            "not_found": out["not_found"], "not_in_template": out["not_in_template"],
            "applied": applied, "notes": notes}


@router.post("/{template_id}/members/switch-on")
async def switch_on_feed_template_members(template_id: int, body: MembersSwitchOn,
                                          user: dict = Depends(require_capability("feeds.author"))):
    """Switch a template's SWITCHED-OFF members back on: ``{"keys": [...]}``
    or ``{"all_switched_off": true}``.  Admins only (the config_active rule
    for feeds); each member goes through the feed's own switch-on checks (a
    calendar that is gone refuses it, in words); audited; one transaction."""
    row = await _require_template(template_id, user, manage=True)
    from core.roles import is_admin_like
    if _feed_api()._auth_on() and not is_admin_like(user):
        raise HTTPException(status_code=403, detail="Only an admin can switch a template's members on.")
    return await switch_on_members(row, user, keys=body.keys, all_switched_off=body.all_switched_off)


def _template_on_switch_on(row: dict, user: dict) -> Optional[str]:
    """2026-11-10 (third review): switching a TEMPLATE back on brings back the
    members switched off WITH it (the same switch-off event -- delete with
    delete_members) -- not members a person switched off on their own."""
    from core.config_active import last_switch_off
    db = _db()
    with db.get_session(read_only=True) as session:
        last = last_switch_off(session, "feed_templates", int(row["id"]))
        event = None
        if last:
            from core.db.models import ConfigSwitchOff as C
            ev = (session.query(C.event).filter(C.table_name == "feed_templates", C.row_id == int(row["id"]))
                  .order_by(C.id.desc()).first())
            event = ev[0] if ev else None
    if not event:
        return None
    ids = set(db.switch_off_event_rows("feed_configs", event))
    if not ids:
        return None
    keys = [str(m["template_member_key"]) for m in db.list_template_members(int(row["id"]))
            if int(m["id"]) in ids and m.get("template_member_key") and not m.get("is_active", True)]
    if not keys:
        return None
    out = asyncio.run(switch_on_members(dict(row), user, keys=keys))
    n, refused = len(out["switched_on"]), len(out["refused"])
    return (f"{n} member(s) switched off with it are back on."
            + (f" {refused} could not be switched on: " + "; ".join(
                f"{r['key']}: {r['reason']}" for r in out["refused"][:5]) if refused else ""))


def _register_switch_on_hooks() -> None:
    from api.config_active_api import ON_SWITCH_ON
    ON_SWITCH_ON["feed_templates"] = _template_on_switch_on


_register_switch_on_hooks()
