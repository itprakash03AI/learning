"""What the signed-in person may do (tool entitlement, 2026-10-31).

  GET /api/me/capabilities     the caller's capabilities -- the ONE question the
                               UI asks to show menus and enable buttons (E4);
                               a hidden button is convenience, the route is the gate.

Login-only by declaration (core/tool_entitlement/declarations.py): a person who
holds nothing must still be able to learn that.
"""
from __future__ import annotations

import asyncio
import logging

from api.deps import get_current_user, require_capability
from core.tool_entitlement import engine as _te
from core.tool_entitlement.vocabulary import AREAS, CAPABILITIES
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/me", tags=["tool-entitlement"])
#: 2026-11-10 (the release pipeline, sixth review): the grant road -- the ONLY way a
#: principal receives releases.approve (seeded to no role); the writer
#: (core/db/mixin_tool_entitlement.add_tool_capability_grant) enforces the rules
admin_router = APIRouter(prefix="/api/admin/tool-capability-grants", tags=["tool-entitlement"])


class GrantRequest(BaseModel):
    capability: str
    principal_type: str = "user"
    principal_id: str
    note: str | None = None


@admin_router.get("")
async def list_grants(capability: str | None = None,
                      user: dict = Depends(require_capability("entitlement.manage"))):  # noqa: B008
    """Every active grant (optionally of one capability)."""
    db = _te._db()
    return {"grants": db.list_tool_capability_grants(active_only=True, capability=capability)}


@admin_router.post("")
async def grant(req: GrantRequest, user: dict = Depends(require_capability("entitlement.manage"))):  # noqa: B008
    """Give a capability to a principal.  ``releases.approve``: a super_admin only, to a
    user only, never to one that holds ``releases.manage`` (and the reverse) -- the
    account that uploads a release must not also approve it."""
    if req.capability not in CAPABILITIES:
        raise HTTPException(status_code=422, detail=f"unknown capability {req.capability!r}")
    db = _te._db()
    try:
        row = db.add_tool_capability_grant(req.capability, req.principal_type, req.principal_id,
                                           by_user=user.get("username"), note=req.note,
                                           by_role=str(user.get("role") or ""))
    except ValueError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from None
    _te.invalidate() if hasattr(_te, "invalidate") else None
    return {"grant": row}


@admin_router.delete("/{grant_id}")
async def revoke(grant_id: int, user: dict = Depends(require_capability("entitlement.manage"))):  # noqa: B008
    db = _te._db()
    ok = db.switch_off_tool_capability_grant(int(grant_id), by_user=user.get("username"))
    if not ok:
        raise HTTPException(status_code=404, detail=f"grant {grant_id} does not exist")
    _te.invalidate() if hasattr(_te, "invalidate") else None
    return {"switched_off": grant_id}


@router.get("/capabilities")
async def my_capabilities(user: dict = Depends(get_current_user)):  # noqa: B008
    """``{"username", "role", "capabilities": [...], "areas": {...}, "all": [...]}``.

    ``capabilities`` are the names the caller holds unscoped; ``all`` is the
    vocabulary with labels, so the UI can say what a missing one is called."""
    try:
        held = await asyncio.to_thread(_te.capabilities_of, user)
    except _te.PermissionCheckUnavailable as exc:
        logger.error("tool_entitlement: /api/me/capabilities unavailable: %s", exc)
        raise HTTPException(status_code=503,
                            detail="Your permissions could not be checked right now. Try again shortly.") from None
    return {
        "username": user.get("username"),
        "role": user.get("role"),
        "super_admin": str(user.get("role") or "").lower() == "super_admin",
        "capabilities": sorted(held),
        "areas": AREAS,
        "all": [{"name": c.name, "label": c.label, "description": c.description, "area": c.area}
                for c in CAPABILITIES.values()],
    }
