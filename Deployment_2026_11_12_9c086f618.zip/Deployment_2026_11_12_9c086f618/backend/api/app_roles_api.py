"""Application roles and permissions -- the admin's routes (2026-11-10,
docs/ENTITLEMENT_APP_ROLES_PLAN_2026_11_10.html).  The rules live in
``core/app_roles/service.py``; every write is audited and drops the decision
memo (``core.tool_entitlement.engine.invalidate``).

  GET    /api/app-roles                                   the active roles, for pickers (every signed-in person)
  GET    /api/admin/app-roles                             every role: what it may do, who gets it, the reports assigned, the unknown names seen
  POST   /api/admin/app-roles                             create a role based on a built-in (its bundle copied)
  PUT    /api/admin/app-roles/{name}                      label / description
  DELETE /api/admin/app-roles/{name}                      switch off (never a built-in; refused while something names it)
  PUT    /api/admin/app-roles/{name}/capabilities         the whole list of what the role may do
  GET    /api/admin/app-roles/{name}/sources              who gets it
  POST   /api/admin/app-roles/{name}/sources              an AD group / a person / a claim value
  DELETE /api/admin/app-roles/sources/{source_id}         switch a source off
  GET    /api/admin/permissions/grants                    E3: the general grant rows (role / group / user / api_key)
  POST   /api/admin/permissions/grants
  DELETE /api/admin/permissions/grants/{grant_id}
  GET    /api/admin/permissions/who-can/{capability}      who can do X
  GET    /api/admin/permissions/what-can/{ptype}/{pid}    what can Y do
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from api.deps import require_capability
from core.app_roles import service as svc
from core.audit import audit_event
from core.tool_entitlement import engine as _te
from core.tool_entitlement.vocabulary import AREAS, CAPABILITIES

logger = logging.getLogger(__name__)

router = APIRouter(tags=["app-roles"])

_db_manager = None
MANAGE = "entitlement.manage"
GRANT_PRINCIPAL_TYPES = ("role", "group", "user", "api_key")


# ── the generic Switched Off page (review 2, H2): a permission row, a role or a
# role source coming back on is the same act as granting it -- the same actor
# rule, the same self refusal; and the decision memo drops on every switch-on
def _hook(check):
    def before(row: Dict[str, Any], user: dict, db) -> None:
        try:
            check(db, user, row)
        except svc.RoleRefused as exc:
            raise HTTPException(status_code=exc.status, detail=str(exc)) from None
    return before


def _after_switch_on(row: Dict[str, Any], user: dict, db) -> Optional[str]:
    svc.changed()
    return None


def _after_role_switch_on(row: Dict[str, Any], user: dict, db) -> Optional[str]:
    n = svc.restore_grants_switched_off_with(db, str(row.get("name") or ""), by_user=user.get("username"))
    svc.changed()
    return (f"{n} permission(s) that were switched off with it are back on." if n
            else "No permission was switched off with it, so none came back.")


def _register_switch_on_hooks() -> None:
    from api.config_active_api import BEFORE_SWITCH_ON, ON_SWITCH_ON
    BEFORE_SWITCH_ON["tool_capability_grants"] = _hook(svc.check_grant_switch_on)
    BEFORE_SWITCH_ON["app_roles"] = _hook(svc.check_role_switch_on)
    BEFORE_SWITCH_ON["app_role_sources"] = _hook(svc.check_source_switch_on)
    ON_SWITCH_ON["tool_capability_grants"] = _after_switch_on
    ON_SWITCH_ON["app_role_sources"] = _after_switch_on
    ON_SWITCH_ON["app_roles"] = _after_role_switch_on


_register_switch_on_hooks()


def set_app_roles_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not ready")
    return _db_manager


async def _adb(fn, *args, **kwargs):
    return await asyncio.to_thread(fn, *args, **kwargs)


def _refused(exc: svc.RoleRefused) -> HTTPException:
    return HTTPException(status_code=exc.status, detail=str(exc))


# ── schemas ─────────────────────────────────────────────────────────────────

class RoleCreate(BaseModel):
    name: str
    label: Optional[str] = None
    description: Optional[str] = None
    based_on: str


class RoleUpdate(BaseModel):
    label: Optional[str] = None
    description: Optional[str] = None


class RoleCapabilities(BaseModel):
    capabilities: List[str]


class SourceCreate(BaseModel):
    source_kind: str            # ad_group | user | claim
    source_value: str
    note: Optional[str] = None


class GrantCreate(BaseModel):
    capability: str
    principal_type: str         # role | group | user | api_key
    principal_id: str
    note: Optional[str] = None


# ── the pickers' list ───────────────────────────────────────────────────────

@router.get("/api/app-roles")
async def list_roles_for_pickers(user: dict = Depends(require_capability("reports.view"))):
    """The ACTIVE roles a report may be assigned to and a person may be set to
    (name, label, what it is based on).  Every signed-in person: the Publish
    dialog needs it."""
    rows = await _adb(_db().list_app_roles, True)
    return {"roles": [{"name": r["name"], "label": r["label"], "based_on": r["based_on"],
                       "is_builtin": r["is_builtin"], "description": r.get("description") or ""}
                      for r in rows if r["name"] not in ("api_consumer",)]}


# ── roles ───────────────────────────────────────────────────────────────────

@router.get("/api/admin/app-roles")
async def admin_list_roles(user: dict = Depends(require_capability(MANAGE))):
    return await _adb(svc.describe_roles, _db())


@router.post("/api/admin/app-roles", status_code=201)
async def admin_create_role(body: RoleCreate, request: Request,
                            user: dict = Depends(require_capability(MANAGE, rate_limited=True))):
    try:
        row = await _adb(svc.create_role, _db(), name=body.name, label=body.label or "",
                         description=body.description, based_on=body.based_on,
                         by_user=user.get("username"), actor=user)
    except svc.RoleRefused as exc:
        raise _refused(exc) from None
    audit_event(_db(), user, request, "app_role_created", "app_role", row["name"],
                details={"based_on": row["based_on"], "capabilities": len(row.get("capabilities") or [])})
    return row


@router.put("/api/admin/app-roles/{name}")
async def admin_update_role(name: str, body: RoleUpdate, request: Request,
                            user: dict = Depends(require_capability(MANAGE))):
    n = svc.normalize_name(name)
    if body.label is not None and not str(body.label).strip():
        raise HTTPException(status_code=422, detail="A role needs a label people can read.")
    row = await _adb(_db().update_app_role, n, label=(body.label.strip() if body.label else None),
                     description=body.description, by_user=user.get("username"))
    if row is None:
        raise HTTPException(status_code=404, detail=f"There is no role named '{n}'.")
    audit_event(_db(), user, request, "app_role_updated", "app_role", n,
                details={"label": body.label, "description": body.description})
    return row


@router.delete("/api/admin/app-roles/{name}")
async def admin_switch_off_role(name: str, request: Request,
                                user: dict = Depends(require_capability(MANAGE, rate_limited=True))):
    n = svc.normalize_name(name)
    try:
        out = await _adb(svc.switch_off_role, _db(), n, by_user=user.get("username"))
    except svc.RoleRefused as exc:
        raise _refused(exc) from None
    audit_event(_db(), user, request, "app_role_switched_off", "app_role", n)
    return out


@router.put("/api/admin/app-roles/{name}/capabilities")
async def admin_set_role_capabilities(name: str, body: RoleCapabilities, request: Request,
                                      user: dict = Depends(require_capability(MANAGE))):
    n = svc.normalize_name(name)
    if await _adb(_db().get_app_role, n, True) is None:
        raise HTTPException(status_code=404, detail=f"There is no role named '{n}'.")
    try:
        out = await _adb(svc.set_role_capabilities, _db(), n, body.capabilities, by_user=user.get("username"),
                         actor=user)
    except svc.RoleRefused as exc:
        raise _refused(exc) from None
    audit_event(_db(), user, request, "app_role_capabilities_set", "app_role", n,
                details={"added": out["added"], "removed": out["removed"]})
    return out


# ── who gets a role ─────────────────────────────────────────────────────────

@router.get("/api/admin/app-roles/{name}/sources")
async def admin_list_sources(name: str, user: dict = Depends(require_capability(MANAGE))):
    n = svc.normalize_name(name)
    if await _adb(_db().get_app_role, n, True) is None:
        raise HTTPException(status_code=404, detail=f"There is no role named '{n}'.")
    return {"role": n, "sources": await _adb(_db().list_app_role_sources, n, True)}


@router.post("/api/admin/app-roles/{name}/sources", status_code=201)
async def admin_add_source(name: str, body: SourceCreate, request: Request,
                           user: dict = Depends(require_capability(MANAGE))):
    n = svc.normalize_name(name)
    try:
        row = await _adb(svc.add_source, _db(), n, body.source_kind, body.source_value,
                         by_user=user.get("username"), note=body.note, actor=user)
    except svc.RoleRefused as exc:
        raise _refused(exc) from None
    audit_event(_db(), user, request, "app_role_source_added", "app_role", n,
                details={"source_kind": row["source_kind"], "source_value": row["source_value"]})
    return row


@router.delete("/api/admin/app-roles/sources/{source_id}")
async def admin_remove_source(source_id: int, request: Request,
                              user: dict = Depends(require_capability(MANAGE))):
    ok = await _adb(svc.remove_source, _db(), int(source_id), by_user=user.get("username"))
    if not ok:
        raise HTTPException(status_code=404, detail="That source is not there.")
    audit_event(_db(), user, request, "app_role_source_removed", "app_role_source", source_id)
    return {"ok": True}


# ── E3: the general grants ──────────────────────────────────────────────────

def _cap_face(name: str) -> Dict[str, Any]:
    c = CAPABILITIES.get(name)
    return {"name": name, "label": c.label if c else name, "area": AREAS.get(c.area, c.area) if c else ""}


@router.get("/api/admin/permissions/grants")
async def admin_list_grants(capability: Optional[str] = None, principal_type: Optional[str] = None,
                            principal_id: Optional[str] = None, include_inactive: bool = False,
                            user: dict = Depends(require_capability(MANAGE))):
    rows = await _adb(_db().list_tool_capability_grants, not include_inactive, capability, principal_type, principal_id)
    return {"grants": rows, "capabilities": [_cap_face(n) for n in CAPABILITIES],
            "principal_types": list(GRANT_PRINCIPAL_TYPES), "areas": AREAS}


@router.post("/api/admin/permissions/grants", status_code=201)
async def admin_add_grant(body: GrantCreate, request: Request,
                          user: dict = Depends(require_capability(MANAGE))):
    cap = str(body.capability or "").strip()
    if cap not in CAPABILITIES:
        raise HTTPException(status_code=422, detail=f"'{cap}' is not a permission QueryStudio knows.")
    ptype = str(body.principal_type or "").strip().lower()
    if ptype not in GRANT_PRINCIPAL_TYPES:
        raise HTTPException(status_code=422, detail=f"The principal type is one of: {', '.join(GRANT_PRINCIPAL_TYPES)}.")
    pid = str(body.principal_id or "").strip()
    if not pid:
        raise HTTPException(status_code=422, detail="Say who gets it: a role name, a group name, a username or an API key id.")
    if ptype == "role":
        pid = pid.lower()
        if await _adb(_db().get_app_role, pid, True) is None:
            raise HTTPException(status_code=422, detail=f"There is no role named '{pid}'.")
    # 2026-11-10 (security review): an actor hands out only what they hold, never to themselves
    try:
        svc.check_actor_may_grant(user, [cap])
    except svc.RoleRefused as exc:
        raise _refused(exc) from None
    try:                              # review 2 (LOW): not to a group they are in, a role they hold, their key
        await _adb(svc.check_not_self_principal, _db(), user, ptype, pid)       # off the loop (review 3)
    except svc.RoleRefused as exc:
        raise _refused(exc) from None
    except Exception as exc:                                                 # noqa: BLE001
        raise HTTPException(status_code=503, detail=f"Could not check who you are right now: {exc}") from exc
    row = await _adb(_db().add_tool_capability_grant, cap, ptype, pid, "", "", user.get("username"), body.note, "manual")
    _te.invalidate()
    audit_event(_db(), user, request, "permission_granted", "tool_capability_grant", row["id"],
                details={"capability": cap, "principal_type": ptype, "principal_id": pid})
    return row


@router.delete("/api/admin/permissions/grants/{grant_id}")
async def admin_switch_off_grant(grant_id: int, request: Request,
                                 user: dict = Depends(require_capability(MANAGE))):
    row = await _adb(_db().get_tool_capability_grant, int(grant_id))
    if row is None:
        raise HTTPException(status_code=404, detail="That permission row is not there.")
    ok = await _adb(_db().switch_off_tool_capability_grant, int(grant_id), user.get("username"))
    _te.invalidate()
    audit_event(_db(), user, request, "permission_switched_off", "tool_capability_grant", grant_id,
                details={"capability": row["capability"], "principal_type": row["principal_type"],
                         "principal_id": row["principal_id"]})
    return {"ok": bool(ok)}


@router.get("/api/admin/permissions/who-can/{capability}")
async def admin_who_can(capability: str, user: dict = Depends(require_capability(MANAGE))):
    if capability not in CAPABILITIES:
        raise HTTPException(status_code=404, detail=f"'{capability}' is not a permission QueryStudio knows.")
    rows = await _adb(_db().list_tool_capability_grants, True, capability)
    return {"capability": _cap_face(capability), "holders": rows}


@router.get("/api/admin/permissions/what-can/{principal_type}/{principal_id}")
async def admin_what_can(principal_type: str, principal_id: str, user: dict = Depends(require_capability(MANAGE))):
    ptype = str(principal_type or "").strip().lower()
    if ptype not in GRANT_PRINCIPAL_TYPES:
        raise HTTPException(status_code=422, detail=f"The principal type is one of: {', '.join(GRANT_PRINCIPAL_TYPES)}.")
    rows = await _adb(_db().list_tool_capability_grants, True, None, ptype, principal_id)
    return {"principal_type": ptype, "principal_id": principal_id,
            "capabilities": [_cap_face(r["capability"]) for r in rows if r["capability"] in CAPABILITIES]}
