import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * A side panel the person can make wider or narrower (owner, 2026-11-10:
 * "object pannel is so fix we cant change width").  ONE hook for every page
 * with a side panel -- the query builder's Objects panel, the Complete Query
 * Builder's sidebar, the SQL page's schema panel -- so they all resize the
 * same way and remember the width the same way.
 *
 * The width is remembered per panel in this browser only (a per-viewer
 * convenience): ``localStorage`` may be missing or throw (private window,
 * blocked storage), and then the panel simply opens at its default.
 */
export interface ResizableWidthOptions {
  /** localStorage key; one per panel. */
  storageKey: string;
  defaultWidth: number;
  minWidth: number;
  maxWidth: number;
  /** Which edge the handle sits on: 'right' for a left-hand panel. */
  edge?: 'right' | 'left';
}

export interface ResizableWidth {
  width: number;
  /** True while the person is dragging: turn width transitions off. */
  dragging: boolean;
  /** Props for the handle element (see PanelResizeHandle). */
  handleProps: {
    onPointerDown: (e: React.PointerEvent) => void;
    onKeyDown: (e: React.KeyboardEvent) => void;
    onDoubleClick: () => void;
    role: 'separator';
    'aria-orientation': 'vertical';
    'aria-valuenow': number;
    'aria-valuemin': number;
    'aria-valuemax': number;
    tabIndex: number;
  };
  setWidth: (w: number) => void;
}

const KEY_STEP = 16;

export const clampWidth = (w: number, min: number, max: number): number =>
  Math.round(Math.min(max, Math.max(min, w)));

const readStored = (key: string): number | null => {
  try {
    const raw = window.localStorage.getItem(key);
    if (raw == null) return null;
    const n = Number(raw);
    return Number.isFinite(n) ? n : null;
  } catch {
    return null;
  }
};

const writeStored = (key: string, w: number): void => {
  try {
    window.localStorage.setItem(key, String(w));
  } catch {
    /* storage blocked: the width lasts for this visit only */
  }
};

export function useResizableWidth(opts: ResizableWidthOptions): ResizableWidth {
  const { storageKey, defaultWidth, minWidth, maxWidth, edge = 'right' } = opts;
  const [width, setWidthState] = useState<number>(() =>
    clampWidth(readStored(storageKey) ?? defaultWidth, minWidth, maxWidth));
  const [dragging, setDragging] = useState(false);
  const drag = useRef<{ startX: number; startW: number } | null>(null);
  const widthRef = useRef(width);
  widthRef.current = width;

  const setWidth = useCallback((w: number) => {
    const c = clampWidth(w, minWidth, maxWidth);
    setWidthState(c);
    writeStored(storageKey, c);
  }, [storageKey, minWidth, maxWidth]);

  useEffect(() => {
    if (!dragging) return undefined;
    const sign = edge === 'right' ? 1 : -1;
    const move = (e: PointerEvent) => {
      if (!drag.current) return;
      setWidthState(clampWidth(drag.current.startW + sign * (e.clientX - drag.current.startX),
                               minWidth, maxWidth));
    };
    const up = () => {
      drag.current = null;
      setDragging(false);
      writeStored(storageKey, widthRef.current);
    };
    const prevCursor = document.body.style.cursor;
    const prevSelect = document.body.style.userSelect;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      document.body.style.cursor = prevCursor;
      document.body.style.userSelect = prevSelect;
    };
  }, [dragging, edge, minWidth, maxWidth, storageKey]);

  const onPointerDown = useCallback((e: React.PointerEvent) => {
    if (e.button !== 0) return;
    e.preventDefault();
    drag.current = { startX: e.clientX, startW: widthRef.current };
    setDragging(true);
  }, []);

  const onKeyDown = useCallback((e: React.KeyboardEvent) => {
    const grow = edge === 'right' ? 'ArrowRight' : 'ArrowLeft';
    const shrink = edge === 'right' ? 'ArrowLeft' : 'ArrowRight';
    if (e.key === grow) { e.preventDefault(); setWidth(widthRef.current + KEY_STEP); }
    else if (e.key === shrink) { e.preventDefault(); setWidth(widthRef.current - KEY_STEP); }
    else if (e.key === 'Home') { e.preventDefault(); setWidth(minWidth); }
    else if (e.key === 'End') { e.preventDefault(); setWidth(maxWidth); }
  }, [edge, setWidth, minWidth, maxWidth]);

  const onDoubleClick = useCallback(() => setWidth(defaultWidth), [setWidth, defaultWidth]);

  return {
    width,
    dragging,
    setWidth,
    handleProps: {
      onPointerDown, onKeyDown, onDoubleClick,
      role: 'separator',
      'aria-orientation': 'vertical',
      'aria-valuenow': width,
      'aria-valuemin': minWidth,
      'aria-valuemax': maxWidth,
      tabIndex: 0,
    },
  };
}
