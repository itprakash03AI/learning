/**
 * Application roles and permissions (2026-11-10, docs/ENTITLEMENT_APP_ROLES_PLAN_2026_11_10.html).
 *
 * A role is DATA an admin creates with any name, based on one built-in permission
 * level (viewer / support / analyst / admin ...).  The server decides everything;
 * these calls only carry the screens' words.  Nothing here names a role.
 */
import { safeFetch } from './core';

export interface AppRolePick {
  name: string;
  label: string;
  based_on: string;
  is_builtin: boolean;
  description?: string;
}

export interface AppRoleSource {
  id: number;
  role_name: string;
  source_kind: 'ad_group' | 'user' | 'claim' | string;
  source_value: string;
  is_active: boolean;
  note?: string | null;
}

export interface AppRoleAdmin extends AppRolePick {
  id: number;
  is_active: boolean;
  source: string;
  capabilities: string[];
  sources: AppRoleSource[];
  people_in_settings: string[];
  reports: { id: number; name: string; is_published: boolean }[];
}

export interface CapabilityFace {
  name: string;
  label: string;
  description: string;
  area: string;
}

export interface AppRolesAdminPage {
  roles: AppRoleAdmin[];
  built_ins: string[];
  /** The bases a role may have (never admin): the server's list. */
  allowed_bases?: string[];
  /** Handed out by a super admin only. */
  protected_capabilities?: string[];
  /** The directory attribute read as role claims ('' = claims are off). */
  claim_attribute?: string;
  /** Roles stored with a base they may not have: they count for nothing. */
  problems?: { role_name: string; problem: string }[];
  unknown_seen: { username: string; role_name: string; seen_at: string | null }[];
  capabilities: CapabilityFace[];
}

const JSON_HEADERS = { 'Content-Type': 'application/json' };

const appRoles = {
  /** The active roles for pickers (every signed-in person). */
  listAppRoles: (): Promise<{ roles: AppRolePick[] }> => safeFetch('/api/app-roles'),

  adminListAppRoles: (): Promise<AppRolesAdminPage> => safeFetch('/api/admin/app-roles'),
  adminCreateAppRole: (body: { name: string; label?: string; description?: string; based_on: string }) =>
    safeFetch('/api/admin/app-roles', { method: 'POST', headers: JSON_HEADERS, body: JSON.stringify(body) }),
  adminUpdateAppRole: (name: string, body: { label?: string; description?: string }) =>
    safeFetch(`/api/admin/app-roles/${encodeURIComponent(name)}`, { method: 'PUT', headers: JSON_HEADERS, body: JSON.stringify(body) }),
  adminSwitchOffAppRole: (name: string) =>
    safeFetch(`/api/admin/app-roles/${encodeURIComponent(name)}`, { method: 'DELETE' }),
  adminSetAppRoleCapabilities: (name: string, capabilities: string[]) =>
    safeFetch(`/api/admin/app-roles/${encodeURIComponent(name)}/capabilities`,
      { method: 'PUT', headers: JSON_HEADERS, body: JSON.stringify({ capabilities }) }),
  adminAddAppRoleSource: (name: string, body: { source_kind: string; source_value: string; note?: string }) =>
    safeFetch(`/api/admin/app-roles/${encodeURIComponent(name)}/sources`,
      { method: 'POST', headers: JSON_HEADERS, body: JSON.stringify(body) }),
  adminRemoveAppRoleSource: (sourceId: number) =>
    safeFetch(`/api/admin/app-roles/sources/${sourceId}`, { method: 'DELETE' }),

  /** The report's assigned roles ([] = every signed-in person). */
  setReportRoles: (reportId: number, roles: string[]) =>
    safeFetch(`/api/business-reports/${reportId}/roles`, { method: 'PUT', headers: JSON_HEADERS, body: JSON.stringify({ roles }) }),
};

export default appRoles;

/** The words a source row reads as. */
export const sourceWords = (s: { source_kind: string; source_value: string }): string => {
  if (s.source_kind === 'ad_group') return `AD group ${s.source_value}`;
  if (s.source_kind === 'user') return `Person ${s.source_value}`;
  if (s.source_kind === 'claim') return `Directory claim ${s.source_value}`;
  return `${s.source_kind} ${s.source_value}`;
};
