/**
 * The ready-to-copy Python client of ONE published API (2026-11-11; owner: "share
 * python code to [a] client ... pagination, proper error handling, AD based authentication ...
 * so they will just copy when they publish or from api management ... show on ui").
 *
 * The file is the SERVER's (GET /api/v1/views/{slug}/client.py, backend
 * core/published_api/python_client.py) -- one text, never rebuilt here, so the screen and a
 * download can never disagree.  Loaded when asked (it is a few hundred lines).
 */
import React, { useState } from 'react';
import { Alert, Box, Button, Stack, Typography } from '@mui/material';
import { safeFetch } from '../../services/api';

export interface PythonClientPanelProps {
  slug: string;
  /** The address the consumer calls (the screen's published-API address). */
  baseUrl?: string;
  /** False while the API is not saved yet (the publish dialog before Publish). */
  saved?: boolean;
}

export function clientUrl(slug: string, baseUrl?: string): string {
  const q = new URLSearchParams({ as: 'json' });
  let base = baseUrl || '';
  while (base.endsWith('/')) base = base.slice(0, -1);
  if (/^https?:\/\//.test(base)) q.set('base_url', base);
  return `/api/v1/views/${encodeURIComponent(slug)}/client.py?${q.toString()}`;
}

const PythonClientPanel: React.FC<PythonClientPanelProps> = ({ slug, baseUrl, saved = true }) => {
  const [code, setCode] = useState<string | null>(null);
  const [fileName, setFileName] = useState('client.py');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!saved || !slug) {
    return (
      <Typography variant="body2" color="text.secondary" data-testid="python-client-not-saved">
        Publish this API first. Its Python client appears here.
      </Typography>
    );
  }

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const body = await safeFetch<{ file_name: string; code: string }>(clientUrl(slug, baseUrl));
      setCode(body.code);
      setFileName(body.file_name || 'client.py');
    } catch (e: any) {
      setError(e?.status === 404
        ? 'This API is not published yet, or it is switched off.'
        : `The Python client could not be loaded: ${e?.message || e}`);
    } finally {
      setLoading(false);
    }
  };

  const copy = () => {
    if (!code) return;
    navigator.clipboard?.writeText(code).catch(() => undefined);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const download = () => {
    if (!code) return;
    const url = URL.createObjectURL(new Blob([code], { type: 'text/x-python' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <Box data-testid="python-client-panel">
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1 }}>
        One file for the team that reads this API. It signs in with an API key or their AD login
        (signed in once), reads every page from the same copy of the data, starts again if the data
        is refreshed, waits when the server says so, and writes CSV, JSON lines or Parquet.
        Passwords come from the environment, never from the file.
      </Typography>
      {!code && (
        <Button size="small" variant="outlined" onClick={load} disabled={loading} data-testid="python-client-show">
          {loading ? 'Loading...' : 'Show the Python client'}
        </Button>
      )}
      {error && <Alert severity="warning" sx={{ mt: 1 }} data-testid="python-client-error">{error}</Alert>}
      {code && (
        <>
          <Stack direction="row" spacing={1} sx={{ mb: 1 }}>
            <Button size="small" variant="contained" onClick={copy} data-testid="python-client-copy">
              {copied ? 'Copied' : 'Copy'}
            </Button>
            <Button size="small" variant="outlined" onClick={download} data-testid="python-client-download">
              Download {fileName}
            </Button>
          </Stack>
          <Box component="pre" data-testid="python-client-code" sx={{
            m: 0, p: 1.5, maxHeight: 420, overflow: 'auto', bgcolor: 'action.hover', borderRadius: 1,
            fontFamily: 'monospace', fontSize: 11, whiteSpace: 'pre' }}>
            {code}
          </Box>
        </>
      )}
    </Box>
  );
};

export default PythonClientPanel;
