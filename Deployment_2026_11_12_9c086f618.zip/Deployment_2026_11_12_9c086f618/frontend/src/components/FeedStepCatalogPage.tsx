/**
 * FeedStepCatalogPage — every registered feed step type, AND every one
 * that failed to load.
 *
 * GET /api/feeds/step-types returns three things, and this page shows all
 * three:
 *
 *   step_types  — the registry, with each step's parameter schema.
 *   refused     — step types whose module failed to IMPORT, by name, with
 *                 the reason.  "We have no such step" and "that step is
 *                 broken" lead to opposite investigations, so a refused
 *                 step is never silently missing from the list.
 *   boot_report — what the registry did at boot.
 *
 * REGISTERED IS NOT RUNNABLE.  DataFlow has 49 registered stage types of
 * which several are ETL bridges that cannot import in this image; the same
 * shape is possible here, and an administrator has to be able to see it.
 * The refused list is at the TOP of the page and is not collapsed away.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Card, CardContent, Chip, CircularProgress, Collapse,
  IconButton, MenuItem, Paper, Select, Stack, TextField, Typography,
} from '@mui/material';
import {
  Search as SearchIcon, ExpandMore as ExpandIcon,
  ExpandLess as CollapseIcon, Refresh as RefreshIcon,
  Replay as RetryIcon,
} from '@mui/icons-material';
import api from '../services/api';
import type { FeedStepManifest, FeedStepTypesResponse } from '../services/api/feedSteps';
import { describeLoadError, type LoadErrorInfo } from '../utils/loadError';

const CATEGORY_COLOURS: Record<string, 'primary' | 'info' | 'warning' | 'secondary' | 'success' | 'default'> = {
  source: 'primary', extract: 'primary', transform: 'info', format: 'info',
  delivery: 'warning', sink: 'warning', control: 'secondary',
  lifecycle: 'secondary', quality: 'success', integrity: 'success',
  notify: 'default',
};

/** Re-run safety is TRI-STATE and is rendered as three states.  `null` is
 *  "never declared", which refuses with that reason — it is NOT the same
 *  finding as "declared unsafe", and OG defaulting the unknown case to
 *  SAFE is what retried a non-idempotent step into 50M duplicate rows. */
const rerunLabel = (v: boolean | null): string =>
  v === true ? 're-runnable'
  : v === false ? 'declared NOT re-runnable'
  : 're-run safety never declared';

function StepCard({ s }: { s: FeedStepManifest }) {
  const [open, setOpen] = useState(false);
  const schemaKeys = Object.keys(s.config_schema || {});
  const applies = Object.keys(s.applies_when || {});
  return (
    <Card variant="outlined" data-testid={`feed-step-type-${s.name}`}>
      <CardContent>
        <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
          <Box sx={{ minWidth: 0 }}>
            <Typography variant="h6" sx={{ fontSize: 16, fontWeight: 600 }}>
              {s.display_name || s.name}
            </Typography>
            <Typography variant="caption" color="text.secondary"
                        sx={{ display: 'block', fontFamily: 'monospace', fontSize: 11 }}>
              {s.name}
            </Typography>
            <Stack direction="row" spacing={0.5} sx={{ mt: 0.5 }} flexWrap="wrap">
              <Chip label={s.category} size="small"
                    color={CATEGORY_COLOURS[s.category] || 'default'}
                    variant="outlined" sx={{ fontSize: 10, height: 20 }} />
              <Chip
                label={s.executor === 'engine' ? 'engine spine' : 'runner'}
                size="small" variant="outlined" sx={{ fontSize: 10, height: 20 }} />
              <Chip label={`idempotency: ${s.idempotency}`} size="small"
                    variant="outlined" sx={{ fontSize: 10, height: 20 }} />
              <Chip
                label={rerunLabel(s.rerunnable)} size="small"
                color={s.rerunnable === true ? 'success' : 'default'}
                variant="outlined" sx={{ fontSize: 10, height: 20 }} />
            </Stack>
          </Box>
          <IconButton size="small" aria-label={`details for ${s.name}`}
                      onClick={() => setOpen(o => !o)}>
            {open ? <CollapseIcon /> : <ExpandIcon />}
          </IconButton>
        </Stack>

        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          {s.description || 'No description.'}
        </Typography>

        <Collapse in={open}>
          <Box sx={{ mt: 2, pt: 2, borderTop: 1, borderColor: 'divider' }}>
            <Typography variant="caption" sx={{
              color: 'text.secondary', display: 'block', mb: 1,
              textTransform: 'uppercase', letterSpacing: 0.5,
            }}>Parameters</Typography>
            {schemaKeys.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                Takes no parameters.
              </Typography>
            ) : (
              <Stack spacing={0.5}>
                {schemaKeys.map(k => {
                  const def = s.config_schema?.[k] || {};
                  const choices = def.choices || def.enum;
                  const t = def.type
                    || (Array.isArray(choices) ? `choice(${choices.join('|')})` : 'any');
                  return (
                    <Box key={k} sx={{ display: 'flex', gap: 1, fontSize: 13, flexWrap: 'wrap' }}>
                      <Typography component="span"
                                  sx={{ fontFamily: 'monospace', fontWeight: 500,
                                        minWidth: 180, color: 'primary.main' }}>
                        {k}{def.required ? ' *' : ''}
                      </Typography>
                      <Typography component="span"
                                  sx={{ fontFamily: 'monospace', color: 'text.secondary' }}>
                        {t}
                      </Typography>
                      {(def.help || def.description) && (
                        <Typography component="span" color="text.secondary" sx={{ fontSize: 12 }}>
                          — {def.help || def.description}
                        </Typography>
                      )}
                    </Box>
                  );
                })}
              </Stack>
            )}

            <Stack direction="row" spacing={3} sx={{ mt: 2 }} flexWrap="wrap">
              <Box>
                <Typography variant="caption" color="text.secondary">requires</Typography>
                <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                  {s.requires.length ? s.requires.join(', ') : '—'}
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">produces</Typography>
                <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                  {s.produces.length ? s.produces.join(', ') : '—'}
                </Typography>
              </Box>
              <Box>
                <Typography variant="caption" color="text.secondary">applies when</Typography>
                <Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: 12 }}>
                  {applies.length ? JSON.stringify(s.applies_when) : 'always'}
                </Typography>
              </Box>
            </Stack>

            <Typography variant="caption" color="text.secondary"
                        sx={{ mt: 2, display: 'block', fontFamily: 'monospace' }}>
              class_path: {s.class_path}
              {s.origin ? `  ·  origin: ${s.origin}` : ''}
            </Typography>
          </Box>
        </Collapse>
      </CardContent>
    </Card>
  );
}

export default function FeedStepCatalogPage() {
  const [data, setData] = useState<FeedStepTypesResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<LoadErrorInfo | null>(null);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [bootOpen, setBootOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const resp = await api.feedSteps.listStepTypes();
      setData(resp);
    } catch (e: any) {
      // A catalogue that could not be READ is not an empty catalogue.
      setData(null);
      // "Could not reach the server" (no response) vs "HTTP <status>"
      // (the server answered) -- two different investigations.
      setError(describeLoadError(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const stepTypes = data?.step_types || [];
  const refused = data?.refused || [];
  const bootReport = data?.boot_report || [];

  const categories = useMemo(
    () => Array.from(new Set(stepTypes.map(s => s.category))).sort(),
    [stepTypes]);

  const filtered = useMemo(() => {
    let out = stepTypes;
    if (category) out = out.filter(s => s.category === category);
    if (search) {
      const q = search.toLowerCase();
      out = out.filter(s =>
        s.name.toLowerCase().includes(q)
        || (s.display_name || '').toLowerCase().includes(q)
        || (s.description || '').toLowerCase().includes(q));
    }
    return out;
  }, [stepTypes, search, category]);

  const grouped = useMemo(() => {
    const g: Record<string, FeedStepManifest[]> = {};
    filtered.forEach(s => {
      g[s.category] = g[s.category] || [];
      g[s.category].push(s);
    });
    return g;
  }, [filtered]);

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5">Feed Step Catalogue</Typography>
          <Typography variant="caption" color="text.secondary">
            Every step type the feed engine can plan, with its parameters —
            and every one that failed to load. Registered is not the same as
            runnable.
          </Typography>
        </Box>
        <Button startIcon={<RefreshIcon />} onClick={() => void load()}>Refresh</Button>
      </Stack>

      {loading && (
        <Stack direction="row" spacing={1} alignItems="center" sx={{ py: 2 }}>
          <CircularProgress size={18} />
          <Typography variant="body2">Reading the step registry…</Typography>
        </Stack>
      )}

      {!loading && error && (
        <Alert
          severity="error"
          data-testid="feed-step-catalogue-error"
          action={(
            <Button size="small" color="inherit" startIcon={<RetryIcon />}
                    onClick={() => void load()}>Retry</Button>
          )}
        >
          Could not read the step catalogue — that is NOT the same as there
          being no step types. {error.message}
        </Alert>
      )}

      {!loading && !error && data && (
        <>
          {/* The refused list, first and uncollapsed. */}
          {refused.length > 0 && (
            <Alert severity="warning" sx={{ mb: 2 }} data-testid="feed-step-refused">
              <Typography variant="body2" sx={{ fontWeight: 700 }}>
                {refused.length} step type{refused.length === 1 ? '' : 's'} could
                not be loaded. They are registered by name and cannot run:
              </Typography>
              <Stack spacing={0.5} sx={{ mt: 1 }}>
                {refused.map(r => (
                  <Box key={r.name} data-testid={`feed-step-refused-${r.name}`}>
                    <Typography variant="body2" sx={{ fontFamily: 'monospace', fontWeight: 600 }}>
                      {r.name}
                    </Typography>
                    <Typography variant="caption" sx={{ display: 'block' }}>
                      {r.where} — {r.reason}
                    </Typography>
                  </Box>
                ))}
              </Stack>
            </Alert>
          )}
          {refused.length === 0 && (
            <Alert severity="success" sx={{ mb: 2 }} data-testid="feed-step-refused-none">
              No step type failed to load.
            </Alert>
          )}

          <Paper sx={{ p: 2, mb: 2 }}>
            <Stack direction="row" spacing={2} alignItems="center">
              <TextField
                fullWidth size="small" placeholder="Search by name or description…"
                value={search} onChange={e => setSearch(e.target.value)}
                inputProps={{ 'aria-label': 'search step types' }}
                InputProps={{ startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.disabled' }} /> }}
              />
              <Select
                size="small" displayEmpty value={category}
                inputProps={{ 'aria-label': 'category filter' }}
                onChange={e => setCategory(String(e.target.value))}
                sx={{ minWidth: 200 }}
              >
                <MenuItem value="">All categories</MenuItem>
                {categories.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
              </Select>
            </Stack>
          </Paper>

          {stepTypes.length === 0 ? (
            <Alert severity="info">
              The registry reported no step types at all.
            </Alert>
          ) : filtered.length === 0 ? (
            <Paper sx={{ p: 4, textAlign: 'center' }}>
              <Typography color="text.secondary">
                No step type matches this filter. {stepTypes.length} are registered.
              </Typography>
            </Paper>
          ) : (
            Object.entries(grouped).map(([cat, items]) => (
              <Box key={cat} sx={{ mb: 3 }}>
                <Typography variant="overline" sx={{
                  display: 'block', mb: 1, color: 'text.secondary', letterSpacing: 1.2,
                }}>
                  {cat} · {items.length} step{items.length === 1 ? '' : 's'}
                </Typography>
                <Box sx={{
                  display: 'grid', gap: 2,
                  gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' },
                }}>
                  {items.map(s => <StepCard key={s.name} s={s} />)}
                </Box>
              </Box>
            ))
          )}

          <Paper variant="outlined" sx={{ p: 1.5, mt: 2 }}>
            <Stack direction="row" alignItems="center" spacing={1}>
              <Typography variant="body2" sx={{ flex: 1 }}>
                Registry boot report · {bootReport.length} line
                {bootReport.length === 1 ? '' : 's'}
              </Typography>
              <IconButton size="small" aria-label="boot report"
                          onClick={() => setBootOpen(o => !o)}>
                {bootOpen ? <CollapseIcon /> : <ExpandIcon />}
              </IconButton>
            </Stack>
            <Collapse in={bootOpen}>
              {bootReport.length === 0 ? (
                <Typography variant="caption" color="text.secondary">
                  The registry reported nothing about its boot.
                </Typography>
              ) : (
                <Box component="pre" sx={{
                  m: 0, mt: 1, fontSize: 12, whiteSpace: 'pre-wrap',
                  fontFamily: 'monospace', color: 'text.secondary',
                }}>
                  {bootReport.join('\n')}
                </Box>
              )}
            </Collapse>
          </Paper>
        </>
      )}
    </Box>
  );
}
