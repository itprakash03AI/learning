/**
 * FeedTemplateBulkDialog -- N feeds from ONE parameterised template and a
 * matrix (2026-10-10; backend POST /api/feed-templates, the owner's ~4,000
 * monthly (SYSTEM_ENTITY, EventCode) feeds).
 *
 * The author pastes the feed body as JSON (its string fields may carry
 * {PARAM} tokens; its SQL keeps {SYSTEM_ENTITY} / {BUSINESSDATE} for run
 * time), the dependencies every member declares, and the matrix as CSV
 * (header = the parameter names) or JSON.  "Plan" is a dry run that writes
 * nothing; "Apply" creates / updates / leaves alone, and the report names
 * every row's outcome -- never one aggregate "done".
 */
import React, { useMemo, useState } from 'react';
import {
  Alert, Button, Checkbox, CircularProgress, FormControlLabel, Stack, Table, TableBody, TableCell, TableHead,
  TableRow, TextField, Typography,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import { PlaylistAdd as BulkIcon } from '@mui/icons-material';
import api from '../services/api';

const DEFAULT_FEED = JSON.stringify({
  name: 'TETB_{SYSTEM_ENTITY}_{EventCode}',
  display_name: 'TETB {SYSTEM_ENTITY} / {EventCode}',
  source_type: 'saved_query',
  source_id: 0,
  connection_id: 0,
  secondary_connection_id: 0,
  secondary_source_id: 0,
  combine_mode: 'union',
  output_format: 'csv',
  output_filename_template: 'TETB_{SYSTEM_ENTITY}_{EventCode}_{business_date:YYYYMMDD}.csv',
  destination_type: 'sftp',
  destination_config: { host: '', port: 22, username: '', password: '', remote_dir: '/inbox' },
  schedule_declaration: { kind: 'month_end' },
  execution_backend: 'auto',
}, null, 2);

const DEFAULT_DEPS = JSON.stringify([{
  dependency_type: 'KAFKA',
  dependency_key: 'TETB_{SYSTEM_ENTITY}_{EventCode}',
  description: 'partition ready for {SYSTEM_ENTITY}/{EventCode}',
  arrival_sources: [{ kind: 'kafka', topic: 'tetb.partition.ready' }],
  require_mode: 'all',
}], null, 2);

/** CSV (header = parameter names) or a JSON list of objects -> rows. */
export function parseMatrix(text: string, parameters: string[]): Record<string, string>[] {
  const t = text.trim();
  if (!t) return [];
  if (t.startsWith('[')) {
    const parsed = JSON.parse(t);
    if (!Array.isArray(parsed)) throw new Error('matrix JSON must be a list of objects');
    return parsed;
  }
  const lines = t.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const header = lines[0].split(',').map(h => h.trim());
  const missing = parameters.filter(p => !header.includes(p));
  if (missing.length) throw new Error(`CSV header lacks parameter(s) ${missing.join(', ')}`);
  return lines.slice(1).map((line, i) => {
    const cells = line.split(',').map(c => c.trim());
    if (cells.length !== header.length) {
      throw new Error(`CSV row ${i + 1} has ${cells.length} cells, the header ${header.length}`);
    }
    const row: Record<string, string> = {};
    header.forEach((h, j) => { row[h] = cells[j]; });
    return row;
  });
}

/**
 * 2026-11-10 -- members FROM THE TABLE'S PARTITIONS: the declaration the
 * template carries, built from the form's four fields.  "SYSTEM_ENTITY=code,
 * EventCode=business_event" maps each parameter to the partition column that
 * gives its value.  Null when no table is named (an ordinary template).
 * Exported for the test.
 */
export function partitionSourceOf(connection: string, table: string, columns: string,
                                  dateColumn: string): Record<string, any> | null {
  if (!table.trim()) return null;
  const memberColumns: Record<string, string> = {};
  columns.split(',').map(s => s.trim()).filter(Boolean).forEach(pair => {
    const [param, column] = pair.split('=').map(s => s.trim());
    if (param && column) memberColumns[param] = column;
  });
  const cid = Number(connection);
  return { connection_id: Number.isFinite(cid) && connection.trim() ? cid : connection.trim(),
           table: table.trim(), member_columns: memberColumns, date_column: dateColumn.trim() };
}

/** Poll a background apply (202) to its terminal job.  Exported for the test. */
export async function pollApplyJob(
  templateId: number,
  onProgress: (job: any) => void,
  opts: { everyMs?: number; fetchStatus?: (id: number) => Promise<any> } = {},
): Promise<any> {
  const every = opts.everyMs ?? 1500;
  const fetchStatus = opts.fetchStatus ?? ((id: number) => api.getFeedTemplateApplyStatus(id));
  for (;;) {
    const st = await fetchStatus(templateId);
    const job = st?.job;
    if (job && (job.state === 'completed' || job.state === 'failed')) return job;
    if (job) onProgress(job);
    await new Promise(res => setTimeout(res, every));
  }
}

const FeedTemplateBulkDialog: React.FC<{
  open: boolean;
  onClose: () => void;
  onApplied?: () => void;
}> = ({ open, onClose, onApplied }) => {
  const [name, setName] = useState('TETB_MONTHLY');
  const [parametersText, setParametersText] = useState('SYSTEM_ENTITY,EventCode');
  const [feedText, setFeedText] = useState(DEFAULT_FEED);
  const [depsText, setDepsText] = useState(DEFAULT_DEPS);
  const [matrixText, setMatrixText] = useState('SYSTEM_ENTITY,EventCode\nGB01,EOM\nUS01,EOM');
  const [retireMissing, setRetireMissing] = useState(false);
  // 2026-11-10 -- members from the table's partitions (optional)
  const [psConnection, setPsConnection] = useState('');
  const [psTable, setPsTable] = useState('');
  const [psColumns, setPsColumns] = useState('SYSTEM_ENTITY=code, EventCode=business_event');
  const [psDateColumn, setPsDateColumn] = useState('business_close_date');
  const [psCheck, setPsCheck] = useState<any | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState<any | null>(null);
  // 2026-10-10: a big matrix is applied as a background JOB (202 + job);
  // this is what the poll last said -- "Applying 1,200 / 4,000 ..."
  const [progress, setProgress] = useState<any | null>(null);
  // 2026-10-28 (the owner: "if they upload excel file ... if we provide template"):
  // what the server found in an uploaded file -- every problem by row and column;
  // while there is one, Plan and Apply stay off
  const [fileProblems, setFileProblems] = useState<{ row: number | null; message: string }[]>([]);
  const [fileNote, setFileNote] = useState<string | null>(null);

  const parameters = useMemo(
    () => parametersText.split(',').map(p => p.trim()).filter(Boolean), [parametersText]);

  const build = (dryRun: boolean) => {
    const feed = JSON.parse(feedText);
    const dependencies = depsText.trim() ? JSON.parse(depsText) : [];
    const matrix = parseMatrix(matrixText, parameters);
    const partitionSource = partitionSourceOf(psConnection, psTable, psColumns, psDateColumn);
    return { name: name.trim(), parameters, feed, dependencies, matrix,
             dry_run: dryRun, retire_missing: retireMissing,
             ...(partitionSource ? { partition_source: partitionSource } : {}) };
  };

  const checkTable = async () => {
    setError(null);
    setPsCheck(null);
    const partitionSource = partitionSourceOf(psConnection, psTable, psColumns, psDateColumn);
    if (!partitionSource) { setError('Name the table first.'); return; }
    try {
      const matrix = matrixText.trim() ? parseMatrix(matrixText, parameters) : [];
      setPsCheck(await api.previewFeedTemplatePartitions({ partition_source: partitionSource, parameters, matrix }));
    } catch (e: any) {
      setError(e?.message || String(e));
    }
  };

  const onFile = async (file: File | null) => {
    if (!file) return;
    setError(null);
    setFileProblems([]);
    setFileNote(null);
    if (/\.json$/i.test(file.name)) {
      setMatrixText(await file.text());
      return;
    }
    // Excel (.xlsx) and CSV are read by the server: dates and numbers as the template renders them
    try {
      const out = await api.readFeedTemplateMatrixFile(parameters, file);
      setMatrixText(JSON.stringify(out.rows, null, 2));
      setFileProblems(out.problems || []);
      setFileNote(`${file.name}: ${out.total.toLocaleString()} feed${out.total === 1 ? '' : 's'}`
        + (out.ignored_columns?.length ? ` (columns not used: ${out.ignored_columns.join(', ')})` : ''));
    } catch (e: any) {
      setError(e?.message || String(e));
    }
  };

  // the rows as they stand (typed or uploaded): the preview and the count
  const preview = useMemo(() => {
    try { return { rows: parseMatrix(matrixText, parameters), error: null as string | null }; }
    catch (e: any) { return { rows: [] as Record<string, string>[], error: e?.message || String(e) }; }
  }, [matrixText, parameters]);
  const blocked = fileProblems.length > 0;

  const run = async (dryRun: boolean) => {
    setBusy(true);
    setError(null);
    setReport(null);
    try {
      const body = build(dryRun);
      const existing = await api.listFeedTemplates();
      const items: any[] = existing?.items || [];
      const mine = items.find((t: any) => String(t.name).toLowerCase() === body.name.toLowerCase());
      const resp = mine
        ? await api.updateFeedTemplate(mine.id, body)
        : await api.createFeedTemplate(body);
      if (resp?.job && !resp?.report) {
        // 202: the apply runs in the background; poll it to the report
        const tid = resp?.template?.id ?? mine?.id;
        const done = await pollApplyJob(tid, setProgress);
        setProgress(null);
        if (done.state === 'failed') {
          throw new Error(done.error || 'the apply failed');
        }
        setReport(done.report);
      } else {
        setReport(resp?.report || resp);
      }
      if (!dryRun) onApplied?.();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const counts = report?.counts || {};
  const rows = (key: string) => (Array.isArray(report?.[key]) ? report[key] : []);

  return (
    <AppDialog open={open}
      onClose={busy ? undefined : onClose}
      size="md"
      title="Bulk feeds from a template"
      actions={<>
        <Button onClick={onClose} disabled={busy}>Close</Button>
        <Button onClick={() => void run(true)} disabled={busy || !name.trim() || blocked} variant="outlined"
                data-testid="tpl-plan">Plan (dry run)</Button>
        <Button onClick={() => void run(false)} disabled={busy || !name.trim() || blocked} variant="contained"
                startIcon={busy ? <CircularProgress size={14} /> : <BulkIcon />}
                data-testid="tpl-apply">Apply</Button>
      </>}>
        <Alert severity="info" sx={{ mb: 2 }}>
          One template, one feed per matrix row. Every string field may carry a
          <code> {'{PARAM}'}</code> token; the SQL keeps its <code>{'{SYSTEM_ENTITY}'}</code> /
          <code> {'{BUSINESSDATE}'}</code> tokens for run time. Re-applying the same matrix
          changes nothing; editing the template propagates to every member. A template with
          this name is updated in place.
        </Alert>
        <Stack spacing={1.5}>
          <Stack direction="row" spacing={1.5}>
            <TextField label="Template name" value={name} fullWidth disabled={busy}
                       onChange={e => setName(e.target.value)}
                       inputProps={{ 'data-testid': 'tpl-name' }} />
            <TextField label="Parameters (comma-separated)" value={parametersText} fullWidth
                       disabled={busy} onChange={e => setParametersText(e.target.value)}
                       inputProps={{ 'data-testid': 'tpl-parameters' }} />
          </Stack>
          <TextField label="Feed body (JSON, tokens allowed)" value={feedText} multiline
                     minRows={6} maxRows={14} fullWidth disabled={busy}
                     onChange={e => setFeedText(e.target.value)}
                     inputProps={{ 'data-testid': 'tpl-feed', style: { fontFamily: 'monospace', fontSize: 12 } }} />
          <TextField label="Dependencies every member declares (JSON list)" value={depsText}
                     multiline minRows={3} maxRows={8} fullWidth disabled={busy}
                     onChange={e => setDepsText(e.target.value)}
                     inputProps={{ 'data-testid': 'tpl-deps', style: { fontFamily: 'monospace', fontSize: 12 } }} />
          <Stack direction="row" spacing={1.5} alignItems="flex-start">
            <TextField label="Feeds: one row each (CSV with a header row, or a JSON list)" value={matrixText}
                       multiline minRows={4} maxRows={10} fullWidth disabled={busy}
                       onChange={e => { setMatrixText(e.target.value); setFileProblems([]); setFileNote(null); }}
                       inputProps={{ 'data-testid': 'tpl-matrix', style: { fontFamily: 'monospace', fontSize: 12 } }} />
            <Stack spacing={1}>
              <Button variant="outlined" disabled={busy || parameters.length === 0} sx={{ whiteSpace: 'nowrap' }}
                      onClick={() => void api.downloadFeedTemplateMatrix(parameters, name.trim() || 'feeds')
                        .catch((e: any) => setError(e?.message || String(e)))}
                      data-testid="tpl-download-template">
                Download Excel template
              </Button>
              <Button component="label" variant="outlined" disabled={busy} sx={{ whiteSpace: 'nowrap' }}>
                Upload Excel / CSV
                <input type="file" hidden
                       accept=".xlsx,.csv,.json,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv,application/json"
                       onChange={e => { void onFile(e.target.files?.[0] || null); e.target.value = ''; }}
                       data-testid="tpl-upload" />
              </Button>
            </Stack>
          </Stack>
          {fileNote && <Typography variant="body2" color="text.secondary" data-testid="tpl-file-note">{fileNote}</Typography>}
          {fileProblems.length > 0 && (
            <Alert severity="warning" data-testid="tpl-file-problems">
              Fix the file and upload it again -- {fileProblems.length} problem{fileProblems.length === 1 ? '' : 's'}:
              {fileProblems.slice(0, 15).map((p, i) => (
                <Typography key={i} variant="caption" component="div">{p.message}</Typography>
              ))}
              {fileProblems.length > 15 && (
                <Typography variant="caption" component="div">... and {fileProblems.length - 15} more</Typography>
              )}
            </Alert>
          )}
          {!preview.error && preview.rows.length > 0 && (
            <Stack spacing={0.5} data-testid="tpl-preview">
              <Typography variant="subtitle2">
                {preview.rows.length.toLocaleString()} feed{preview.rows.length === 1 ? '' : 's'}
                {preview.rows.length > 20 ? ' (the first 20 shown)' : ''}
              </Typography>
              <Table size="small">
                <TableHead>
                  <TableRow>{parameters.map(p => <TableCell key={p}>{p}</TableCell>)}</TableRow>
                </TableHead>
                <TableBody>
                  {preview.rows.slice(0, 20).map((r, i) => (
                    <TableRow key={i}>{parameters.map(p => <TableCell key={p}>{String(r[p] ?? '')}</TableCell>)}</TableRow>
                  ))}
                </TableBody>
              </Table>
            </Stack>
          )}
          {preview.error && matrixText.trim() && (
            <Alert severity="warning" data-testid="tpl-preview-error">{preview.error}</Alert>
          )}
          <Typography variant="subtitle2" sx={{ mt: 1 }}>Members from the table's partitions (optional)</Typography>
          <Typography variant="caption" color="text.secondary">
            At each start of day the (code, event) values that exist in the table for the month end become the
            members: a new code appears by itself; a member with no data that month gets no run, and the record
            says so. Only the table's Iceberg metadata is read, never the data. The restatement window decides
            how long a month end is re-read.
          </Typography>
          <Stack direction="row" spacing={1.5}>
            <TextField label="Connection id (S3)" value={psConnection} disabled={busy} sx={{ width: 180 }}
                       onChange={e => setPsConnection(e.target.value)}
                       inputProps={{ 'data-testid': 'tpl-ps-connection' }} />
            <TextField label="Table (registered as Iceberg on that connection)" value={psTable} fullWidth
                       disabled={busy} onChange={e => setPsTable(e.target.value)}
                       inputProps={{ 'data-testid': 'tpl-ps-table' }} />
          </Stack>
          <Stack direction="row" spacing={1.5} alignItems="flex-start">
            <TextField label="Parameter = partition column (one per parameter)" value={psColumns} fullWidth
                       disabled={busy} onChange={e => setPsColumns(e.target.value)}
                       inputProps={{ 'data-testid': 'tpl-ps-columns' }} />
            <TextField label="Date column" value={psDateColumn} disabled={busy} sx={{ width: 220 }}
                       onChange={e => setPsDateColumn(e.target.value)}
                       inputProps={{ 'data-testid': 'tpl-ps-date' }} />
            <Button variant="outlined" disabled={busy || !psTable.trim()} sx={{ whiteSpace: 'nowrap' }}
                    onClick={() => void checkTable()} data-testid="tpl-ps-check">Check the table</Button>
          </Stack>
          {psCheck && (
            <Alert severity={psCheck.status === 'unreadable' ? 'error' : 'info'} data-testid="tpl-ps-check-result">
              {psCheck.status === 'unreadable'
                ? `The table could not be read: ${psCheck.reason}`
                : psCheck.status === 'none'
                  ? `No partition for ${psCheck.business_date}: ${psCheck.reason}`
                  : `For ${psCheck.business_date}: ${psCheck.found} partition(s) found, ${psCheck.new} new `
                    + `(would become members), ${psCheck.missing} matrix member(s) with no data, `
                    + `${psCheck.refused} value(s) refused. ${psCheck.note}`}
            </Alert>
          )}
          <FormControlLabel
            control={<Checkbox checked={retireMissing} disabled={busy}
                               onChange={e => setRetireMissing(e.target.checked)} />}
            label="Retire members whose row left the matrix (otherwise they are reported as orphaned)" />
          {error && (
            <Alert severity="error" data-testid="tpl-error">Refused — nothing was written. {error}</Alert>
          )}
          {progress && (
            <Alert severity="info" data-testid="tpl-progress">
              Applying in the background (job {progress.job_id}): {progress.done ?? 0} / {progress.total}
              {progress.counts ? ` — created ${progress.counts.created ?? 0}, updated ${progress.counts.updated ?? 0}, `
                + `unchanged ${progress.counts.unchanged ?? 0}, refused ${progress.counts.refused ?? 0}` : ''}
              . You may close this dialog; the apply continues on the server.
            </Alert>
          )}
          {report && (
            <Alert severity={counts.refused || counts.conflicts ? 'warning' : 'success'}
                   data-testid="tpl-report">
              {report.dry_run ? 'Plan' : 'Applied'}: created {counts.created ?? 0},
              updated {counts.updated ?? 0}, unchanged {counts.unchanged ?? 0},
              conflicts {counts.conflicts ?? 0}, refused {counts.refused ?? 0},
              retired {counts.retired ?? 0}, orphaned {counts.orphaned ?? 0}
              {typeof report.seconds === 'number' ? ` in ${report.seconds}s` : ''}.
              {['conflicts', 'refused'].map(k => rows(k).slice(0, 10).map((r: any, i: number) => (
                <Typography key={`${k}-${i}`} variant="caption" sx={{ display: 'block', fontFamily: 'monospace' }}>
                  {k}: {r.name} — {r.reason}
                </Typography>
              )))}
            </Alert>
          )}
        </Stack>
    </AppDialog>
  );
};

export default FeedTemplateBulkDialog;
