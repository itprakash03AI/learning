/**
 * Report publish-lifecycle controls (2026-08-17).
 *
 * The one component that makes publishing REACHABLE from the product.  Before
 * it, `publishBusinessReport` had zero callers — no screen could publish a
 * report, so the consumer portal (which lists published_only) was empty by
 * construction.
 *
 * Renders in a report header:
 *   - the lifecycle state chip (Draft / Published · vN / Archived /
 *     Deprecated) with the published-at time consumers are reading;
 *   - an "Unpublished changes" indicator when the author's draft differs
 *     from the live version (explicit Republish mints a new version);
 *   - Publish / Republish / Unpublish / Archive / Deprecate / Restore
 *     actions gated to users who may EDIT the report;
 *   - admin-only Certify / Remove certification.
 *
 * Degrades gracefully against the pre-lifecycle backend: GET /versions
 * 404/405 → no version detail is shown (never a crash); POST /unpublish
 * missing → falls back to the legacy POST /publish TOGGLE; archive /
 * deprecate / restore missing → an honest "needs a newer backend" notice.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, IconButton, ListItemIcon, ListItemText,
  Menu, MenuItem, TextField, Tooltip,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import PublishRolesDialog from './reports/PublishRolesDialog';
import { structuredDetail } from '../services/api/core';
import {
  CloudUpload as PublishIcon,
  CloudOff as UnpublishIcon,
  Inventory2 as ArchiveIcon,
  ReportProblem as DeprecateIcon,
  RestartAlt as RestoreIcon,
  Verified as CertifyIcon,
  MoreVert as MoreIcon,
} from '@mui/icons-material';
import api from '../services/api';
import {
  ReportVersion, getLifecycleState, normalizeVersionsResponse,
  hasUnpublishedChanges, isEndpointMissing,
} from '../utils/reportLifecycle';

interface VersionsState {
  /** false = the /versions endpoint does not exist on this backend. */
  supported: boolean;
  versions: ReportVersion[];
  live: ReportVersion | null;
}

interface Props {
  report: any;
  /** Owner / admin / draft-visible — computed by the caller via canEditReport. */
  canEdit: boolean;
  /** admin or super_admin — unlocks Certify / Uncertify. */
  isAdmin: boolean;
  /** Called with the freshly re-fetched report after every action. */
  onReportChange: (report: any) => void;
  /** Toast / notice sink (viewer passes setToast; list passes setError-ish). */
  onNotify?: (message: string) => void;
  /** 2026-11-01 -- the page has ONE More menu: given this, the publishing actions
   *  are handed to the page (it draws them in its menu) and no menu of its own is drawn. */
  onMenuItems?: (items: LifecycleMenuAction[]) => void;
}

/** One publishing action, for a page that draws it in its own menu. */
export interface LifecycleMenuAction {
  key: string;
  label: string;
  secondary?: string;
  icon: React.ReactNode;
  onSelect: () => void;
  disabled?: boolean;
}

const fmtWhen = (iso?: string | null): string => {
  if (!iso) return '';
  const t = Date.parse(iso);
  return Number.isNaN(t) ? '' : new Date(t).toLocaleString();
};

const ReportLifecycleControls: React.FC<Props> = ({
  report, canEdit, isAdmin, onReportChange, onNotify, onMenuItems,
}) => {
  const reportId: number | undefined = report?.id;
  const [versions, setVersions] = useState<VersionsState | null>(null);
  const [versionsTick, setVersionsTick] = useState(0);
  const [busy, setBusy] = useState<string | null>(null);
  const [menuAnchor, setMenuAnchor] = useState<null | HTMLElement>(null);
  const [confirm, setConfirm] = useState<null | 'unpublish' | 'archive' | 'deprecate'>(null);
  const [deprecateReason, setDeprecateReason] = useState('');
  const [certOpen, setCertOpen] = useState(false);
  // 2026-11-10 -- "Who may see this report?": asked before the first publish, or
  // when the server answers 422 roles_required (a report never published)
  const [rolesOpen, setRolesOpen] = useState(false);
  const [certCategories, setCertCategories] = useState<string[]>([]);
  const [certCategory, setCertCategory] = useState('');

  const state = getLifecycleState(report);
  const live = versions?.live ?? null;
  const dirty = state === 'published' ? hasUnpublishedChanges(report, live) : null;

  // ── Version history (lifecycle backend only) ─────────────────────────────
  useEffect(() => {
    if (!reportId) return;
    let cancelled = false;
    api.listBusinessReportVersions(reportId)
      .then((resp: any) => {
        if (cancelled) return;
        setVersions({ supported: true, ...normalizeVersionsResponse(resp) });
      })
      .catch((e: any) => {
        if (cancelled) return;
        // Older backend: no /versions — the chip simply shows no version
        // detail.  Any OTHER failure also must not blank the header; the
        // state chip still renders from the report row itself.
        setVersions({ supported: !isEndpointMissing(e), versions: [], live: null });
      });
    return () => { cancelled = true; };
  }, [reportId, report?.updated_at, report?.is_published, report?.lifecycle_state, versionsTick]);

  const refreshReport = useCallback(async () => {
    if (!reportId) return;
    const fresh = await api.getBusinessReport(reportId);
    onReportChange(fresh);
    setVersionsTick(t => t + 1);
  }, [reportId, onReportChange]);

  const runAction = useCallback(async (
    name: string, fn: () => Promise<any>, successMsg: string,
    opts: { degradeMsg?: string } = {},
  ) => {
    if (!reportId) return;
    setBusy(name);
    setMenuAnchor(null);
    try {
      await fn();
      await refreshReport();
      onNotify?.(successMsg);
    } catch (e: any) {
      if (opts.degradeMsg && isEndpointMissing(e)) {
        onNotify?.(opts.degradeMsg);
      } else {
        onNotify?.(`${name} failed: ${e?.message || 'unknown error'}`);
      }
    } finally {
      setBusy(null);
    }
  }, [reportId, refreshReport, onNotify]);

  // ── Actions ──────────────────────────────────────────────────────────────

  const publishWith = (who?: { roles?: string[]; everyone?: boolean }) => runAction(
    'Publish',
    async () => {
      try {
        await api.publishBusinessReport(reportId!, 'publish', who);
      } catch (e: any) {
        if (structuredDetail(e)?.error === 'roles_required') { setRolesOpen(true); return; }
        throw e;
      }
    },
    state === 'published'
      ? 'Republished — a new version is now live for consumers.'
      : 'Report published — consumers can now see it in the portal.',
  );

  const neverPublished = state !== 'published' && !(report?.role_whitelist || []).length
    && !(versions?.versions?.length);
  const doPublish = () => {
    setMenuAnchor(null);
    if (neverPublished) { setRolesOpen(true); return; }
    return publishWith();
  };

  const doUnpublish = () => {
    setConfirm(null);
    return runAction(
      'Unpublish',
      async () => {
        try {
          await api.unpublishBusinessReport(reportId!);
        } catch (e: any) {
          // Pre-lifecycle backend: POST /publish is a TOGGLE.  Only safe as
          // an unpublish while the report is currently published — which is
          // the only state this action is offered in.
          if (isEndpointMissing(e)) await api.publishBusinessReport(reportId!, 'unpublish');
          else throw e;
        }
      },
      'Report unpublished — it is no longer visible to consumers.',
    );
  };

  const doArchive = () => {
    setConfirm(null);
    return runAction(
      'Archive',
      () => api.archiveBusinessReport(reportId!),
      'Report archived.',
      { degradeMsg: 'Archiving needs a newer backend — this deployment does not support lifecycle states yet.' },
    );
  };

  const doDeprecate = () => {
    setConfirm(null);
    const reason = deprecateReason.trim();
    setDeprecateReason('');
    return runAction(
      'Deprecate',
      () => api.deprecateBusinessReport(reportId!, reason || undefined),
      'Report marked as deprecated — viewers will see a warning banner.',
      { degradeMsg: 'Deprecation needs a newer backend — this deployment does not support lifecycle states yet.' },
    );
  };

  const doRestore = () => runAction(
    'Restore',
    // The caller supplies the target state: archived/deprecated deliberately
    // leave is_published alone, so restoring means returning to whatever it
    // already implies rather than the API inventing a "clear" transition.
    () => api.restoreBusinessReport(reportId!, !!report?.is_published),
    'Report restored.',
    { degradeMsg: 'Restore needs a newer backend — this deployment does not support lifecycle states yet.' },
  );

  const openCertify = async () => {
    setMenuAnchor(null);
    setCertCategory('');
    setCertOpen(true);
    try {
      const resp: any = await api.listTemplateCategories();
      const cats = Array.isArray(resp) ? resp : (resp?.categories || []);
      setCertCategories(cats.map((c: any) => (typeof c === 'string' ? c : c?.name)).filter(Boolean));
    } catch {
      setCertCategories([]);  // free-text entry still works
    }
  };

  const doCertify = () => {
    setCertOpen(false);
    return runAction(
      'Certify',
      () => api.certifyBusinessReport(reportId!, certCategory.trim()),
      'Report certified.',
    );
  };

  const doUncertify = () => runAction(
    'Uncertify',
    () => api.uncertifyBusinessReport(reportId!),
    'Certification removed.',
  );

  // ── The publishing actions (one list: this component's menu, or the page's) ──
  const menuActions: LifecycleMenuAction[] = [];
  if (report && (canEdit || isAdmin)) {
    if (canEdit && state === 'published' && dirty !== true) menuActions.push({ key: 'republish', label: 'Republish',
      secondary: 'Snapshot the current draft as a new live version', icon: <PublishIcon fontSize="small" />, onSelect: doPublish });
    if (canEdit && state === 'published') menuActions.push({ key: 'unpublish', label: 'Unpublish',
      secondary: 'Remove from the consumer portal', icon: <UnpublishIcon fontSize="small" />, onSelect: () => { setMenuAnchor(null); setConfirm('unpublish'); } });
    if (canEdit && (state === 'draft' || state === 'published')) menuActions.push({ key: 'archive', label: 'Archive',
      secondary: 'Retire it — hidden from consumers, kept for reference', icon: <ArchiveIcon fontSize="small" />, onSelect: () => { setMenuAnchor(null); setConfirm('archive'); } });
    if (canEdit && state === 'published') menuActions.push({ key: 'deprecate', label: 'Deprecate',
      secondary: 'Keep it readable but warn viewers it is on the way out', icon: <DeprecateIcon fontSize="small" />, onSelect: () => { setMenuAnchor(null); setConfirm('deprecate'); } });
    if (canEdit && (state === 'archived' || state === 'deprecated')) menuActions.push({ key: 'restore', label: 'Restore',
      icon: <RestoreIcon fontSize="small" />, onSelect: () => { setMenuAnchor(null); doRestore(); } });
    if (isAdmin && !report.is_certified) menuActions.push({ key: 'certify', label: 'Certify…',
      secondary: 'Mark as an org-vetted, trusted report', icon: <CertifyIcon fontSize="small" />, onSelect: openCertify });
    if (isAdmin && report.is_certified) menuActions.push({ key: 'uncertify', label: 'Remove certification',
      icon: <CertifyIcon fontSize="small" />, onSelect: () => { setMenuAnchor(null); doUncertify(); } });
  }
  for (const a of menuActions) a.disabled = busy !== null;
  const actionsKey = menuActions.map(a => `${a.key}:${a.disabled ? 1 : 0}`).join('|');
  const actionsRef = React.useRef(menuActions);
  actionsRef.current = menuActions;
  useEffect(() => {
    // hand the CURRENT closures to the page whenever the set of actions changes
    if (onMenuItems) onMenuItems(actionsRef.current.map(a => ({ ...a, onSelect: () => {
      const now = actionsRef.current.find(x => x.key === a.key); now?.onSelect(); } })));
  }, [actionsKey, onMenuItems]);   // eslint-disable-line react-hooks/exhaustive-deps

  if (!report) return null;

  // ── State chip ───────────────────────────────────────────────────────────
  const liveVersionLabel = live?.version != null ? ` · v${live.version}` : '';
  const publishedAt = fmtWhen(live?.published_at) ||
    (state === 'published' ? fmtWhen(report.published_at) : '');
  const stateChip = state === 'published' ? (
    <Tooltip title={
      `You are viewing the published version${live?.version != null ? ` v${live.version}` : ''}` +
      `${publishedAt ? `, published ${publishedAt}` : ''}` +
      `${live?.published_by ? ` by ${live.published_by}` : ''}.`}>
      <Chip size="small" color="success" label={`Published${liveVersionLabel}`}
        data-testid="lifecycle-state-chip" />
    </Tooltip>
  ) : state === 'deprecated' ? (
    <Chip size="small" color="warning" label="Deprecated" data-testid="lifecycle-state-chip" />
  ) : state === 'archived' ? (
    <Chip size="small" variant="outlined" label="Archived" data-testid="lifecycle-state-chip" />
  ) : (
    // Drafts are only ever served to people who can edit them.
    <Tooltip title="Only you (and admins) can see this report until it is published.">
      <Chip size="small" variant="outlined" label="Draft" data-testid="lifecycle-state-chip" />
    </Tooltip>
  );

  const showActions = canEdit || isAdmin;

  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, flexWrap: 'wrap' }}>
      {stateChip}

      {canEdit && dirty === true && (
        <Tooltip title={
          `The draft has changed since ${live?.version != null ? `v${live.version}` : 'the live version'} ` +
          'was published. Consumers still see the published version — Republish to make your changes live.'}>
          <Chip size="small" color="warning" variant="outlined" label="Unpublished changes"
            data-testid="unpublished-changes-chip" />
        </Tooltip>
      )}

      {showActions && (
        <>
          {canEdit && state === 'draft' && (
            <Button size="small" variant="contained" startIcon={
              busy === 'Publish' ? <CircularProgress size={14} color="inherit" /> : <PublishIcon />}
              disabled={busy !== null} onClick={doPublish}>
              Publish
            </Button>
          )}
          {canEdit && state === 'published' && dirty === true && (
            <Button size="small" variant="contained" startIcon={
              busy === 'Publish' ? <CircularProgress size={14} color="inherit" /> : <PublishIcon />}
              disabled={busy !== null} onClick={doPublish}>
              Republish
            </Button>
          )}
          {!onMenuItems && menuActions.length > 0 && (<>
          <Tooltip title="Publishing & lifecycle">
            <span>
              <IconButton size="small" aria-label="Report lifecycle actions"
                disabled={busy !== null}
                onClick={e => setMenuAnchor(e.currentTarget)}>
                <MoreIcon fontSize="small" />
              </IconButton>
            </span>
          </Tooltip>
          <Menu anchorEl={menuAnchor} open={Boolean(menuAnchor)}
            onClose={() => setMenuAnchor(null)}>
            {menuActions.map(a => (
              <MenuItem key={a.key} onClick={a.onSelect}>
                <ListItemIcon>{a.icon}</ListItemIcon>
                <ListItemText primary={a.label} secondary={a.secondary} />
              </MenuItem>
            ))}
          </Menu>
          </>)}
        </>
      )}

      {/* ── Who may see it (2026-11-10): asked before the first publish ─────── */}
      <PublishRolesDialog open={rolesOpen} busy={busy !== null}
        onClose={() => setRolesOpen(false)}
        onConfirm={(roles, everyone) => { setRolesOpen(false); publishWith(everyone ? { everyone: true } : { roles }); }} />

      {/* ── Confirmations ─────────────────────────────────────────────────── */}
      <AppDialog open={confirm === 'unpublish'}
        onClose={() => setConfirm(null)}
        size="xs"
        dividers={false}
        title="Unpublish this report?"
        actions={<>
          <Button onClick={() => setConfirm(null)}>Cancel</Button>
          <Button color="warning" variant="contained" onClick={doUnpublish}>Unpublish</Button>
        </>}>
          Consumers will no longer see it in the portal, and anyone opening a
          link to it will lose access until it is published again.
      </AppDialog>

      <AppDialog open={confirm === 'archive'}
        onClose={() => setConfirm(null)}
        size="xs"
        dividers={false}
        title="Archive this report?"
        actions={<>
          <Button onClick={() => setConfirm(null)}>Cancel</Button>
          <Button color="warning" variant="contained" onClick={doArchive}>Archive</Button>
        </>}>
          Archiving retires the report: it disappears from the consumer portal
          but is kept for reference and can be restored later.
      </AppDialog>

      <AppDialog open={confirm === 'deprecate'}
        onClose={() => setConfirm(null)}
        size="sm"
        title="Deprecate this report?"
        actions={<>
          <Button onClick={() => { setConfirm(null); setDeprecateReason(''); }}>Cancel</Button>
          <Button color="warning" variant="contained" onClick={doDeprecate}>Deprecate</Button>
        </>}>
          <Box sx={{ mb: 2 }}>
            The report stays readable, but every viewer will see a deprecation
            warning. Use this when a replacement exists or the data is being
            retired.
          </Box>
          <TextField fullWidth size="small" label="Reason shown to viewers (optional)"
            value={deprecateReason} onChange={e => setDeprecateReason(e.target.value)}
            placeholder="e.g. Superseded by 'Sales Daily v2'" />
      </AppDialog>

      {/* ── Certify dialog (admin) ────────────────────────────────────────── */}
      <AppDialog open={certOpen}
        onClose={() => setCertOpen(false)}
        size="sm"
        title="Certify report"
        actions={<>
          <Button onClick={() => setCertOpen(false)}>Cancel</Button>
          <Button variant="contained" disabled={!certCategory.trim()} onClick={doCertify}>
            Certify
          </Button>
        </>}>
          <Box sx={{ mb: 2 }}>
            Certification marks this report as reviewed and authoritative; it
            appears with the Certified badge everywhere it is listed.
          </Box>
          <TextField
            select={certCategories.length > 0}
            fullWidth size="small" label="Template category"
            value={certCategory} onChange={e => setCertCategory(e.target.value)}
            helperText={certCategories.length === 0
              ? 'Enter the template category for this certification.' : undefined}
          >
            {certCategories.map(c => (
              <MenuItem key={c} value={c}>{c}</MenuItem>
            ))}
          </TextField>
      </AppDialog>
    </Box>
  );
};

/**
 * Banner rendered ABOVE a report's content when its lifecycle state warrants
 * a disclosure.  Deprecated must warn loudly; archived is informational.
 */
export const ReportLifecycleBanner: React.FC<{ report: any }> = ({ report }) => {
  const state = getLifecycleState(report);
  if (state === 'deprecated') {
    const reason = report?.deprecated_reason || report?.lifecycle_reason || '';
    return (
      <Alert severity="warning" sx={{ mb: 2 }} data-testid="deprecated-banner">
        This report is deprecated{reason ? ` — ${reason}` : ''}. It may stop
        being maintained or be removed;
        {report?.owner ? ` contact ${report.owner}` : ' contact the owner'} for
        its replacement.
      </Alert>
    );
  }
  if (state === 'archived') {
    return (
      <Alert severity="info" sx={{ mb: 2 }} data-testid="archived-banner">
        This report is archived — it is no longer published to consumers.
      </Alert>
    );
  }
  return null;
};

export default ReportLifecycleControls;
