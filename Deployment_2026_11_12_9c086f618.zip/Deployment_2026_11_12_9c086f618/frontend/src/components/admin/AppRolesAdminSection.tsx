/**
 * Admin -> Security & Access -> Roles and permissions (2026-11-10,
 * docs/ENTITLEMENT_APP_ROLES_PLAN_2026_11_10.html).
 *
 * The roles (the built-ins and the ones an admin added), and for each: what it
 * may do (the permissions by area), who gets it (AD groups, people, directory
 * claim values), the reports assigned to it; plus the role names people were
 * given that are not set up.  The server decides and refuses in its own words;
 * this page only authors rows.  Nothing here names a role.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, Chip, CircularProgress, Divider, FormControlLabel, IconButton,
  MenuItem, Paper, Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import RefreshIcon from '@mui/icons-material/Refresh';
import AppDialog from '../common/AppDialog';
import { appConfirm } from '../common/appDialogs';
import appRoles, { AppRoleAdmin, AppRolesAdminPage, CapabilityFace, sourceWords } from '../../services/api/appRoles';

interface Props { addNotification?: (n: { type: string; title: string; message: string }) => void }

const SOURCE_KINDS = [
  { value: 'ad_group', label: 'An AD group (its full DN)' },
  { value: 'user', label: 'A person (username)' },
  { value: 'claim', label: 'A directory claim value' },
  { value: 'api_key', label: 'An API key (its id)' },
];
/** The words under the source box (2026-11-10 security review): a full DN, never a bare name;
 *  a claim only while the attribute is set, and only an attribute people cannot edit themselves. */
export const sourceHelp = (kind: string, claimAttribute: string): string => {
  if (kind === 'ad_group') return 'The full DN, e.g. CN=Team-A,OU=Groups,DC=example,DC=com -- a bare name would match a same-named group in any OU, so it is refused.';
  if (kind === 'claim') return claimAttribute
    ? `Read from the directory attribute ${claimAttribute} at sign-in. That attribute must be one people cannot edit themselves.`
    : 'Claims are OFF: set auth.ad_role_claim_attribute to a directory attribute people cannot edit themselves first.';
  if (kind === 'api_key') return 'The id of an API key (Admin > API keys). The key then holds this role beside api_consumer: a report published to the role is readable through an API over it.';
  return 'The username, as it signs in.';
};

export const unknownWords = (u: { username: string; role_name: string }): string =>
  `${u.username} was given the role '${u.role_name}', which is not set up -- it counts for nothing until you add it here.`;

const AppRolesAdminSection: React.FC<Props> = ({ addNotification }) => {
  const [page, setPage] = useState<AppRolesAdminPage | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [picked, setPicked] = useState<string>('');
  const [createOpen, setCreateOpen] = useState(false);
  const [draft, setDraft] = useState({ name: '', label: '', description: '', based_on: 'viewer' });
  const [saving, setSaving] = useState(false);
  const [capDraft, setCapDraft] = useState<Set<string> | null>(null);
  const [src, setSrc] = useState({ source_kind: 'ad_group', source_value: '' });

  const load = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const data = await appRoles.adminListAppRoles();
      setPage(data);
      setPicked(p => p && data.roles.some(r => r.name === p) ? p : (data.roles[0]?.name || ''));
    } catch (e: any) {
      setError(e?.message || 'The roles could not be read');
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const role: AppRoleAdmin | undefined = useMemo(() => page?.roles.find(r => r.name === picked), [page, picked]);
  useEffect(() => { setCapDraft(null); }, [picked]);

  const byArea = useMemo(() => {
    const out: Record<string, CapabilityFace[]> = {};
    for (const c of page?.capabilities || []) (out[c.area] ||= []).push(c);
    return out;
  }, [page]);

  const notify = (type: string, title: string, message = '') => addNotification?.({ type, title, message });
  const refuse = (e: any) => notify('error', 'Not saved', e?.message || 'Unknown');

  const create = async () => {
    setSaving(true);
    try {
      const row = await appRoles.adminCreateAppRole({
        name: draft.name.trim(), label: draft.label.trim() || undefined,
        description: draft.description.trim() || undefined, based_on: draft.based_on,
      });
      notify('success', 'Role added', `${row.label} starts with what ${row.based_on} may do`);
      setCreateOpen(false); setDraft({ name: '', label: '', description: '', based_on: 'viewer' });
      await load(); setPicked(row.name);
    } catch (e: any) { refuse(e); } finally { setSaving(false); }
  };

  const saveCaps = async () => {
    if (!role || !capDraft) return;
    setSaving(true);
    try {
      const out = await appRoles.adminSetAppRoleCapabilities(role.name, Array.from(capDraft));
      notify('success', 'Saved', `${out.added.length} added, ${out.removed.length} taken back`);
      setCapDraft(null); await load();
    } catch (e: any) { refuse(e); } finally { setSaving(false); }
  };

  const addSource = async () => {
    if (!role) return;
    setSaving(true);
    try {
      await appRoles.adminAddAppRoleSource(role.name, { source_kind: src.source_kind, source_value: src.source_value.trim() });
      notify('success', 'Added', sourceWords(src));
      setSrc(s => ({ ...s, source_value: '' })); await load();
    } catch (e: any) { refuse(e); } finally { setSaving(false); }
  };

  const removeSource = async (id: number, words: string) => {
    if (!await appConfirm(`Stop giving this role through ${words}? Nobody loses the role until their next sign-in.`)) return;
    try { await appRoles.adminRemoveAppRoleSource(id); await load(); } catch (e: any) { refuse(e); }
  };

  const switchOff = async () => {
    if (!role) return;
    if (!await appConfirm(`Switch off the role '${role.label}'? It is switched off, not erased -- an admin can switch it back on under Admin -> Switched off. Refused while a report, a grant or a source still names it.`)) return;
    try { await appRoles.adminSwitchOffAppRole(role.name); notify('success', 'Switched off', role.label); setPicked(''); await load(); }
    catch (e: any) { refuse(e); }
  };

  const caps = capDraft ?? new Set(role?.capabilities || []);
  const dirty = capDraft !== null;

  return (
    <Box data-testid="app-roles-admin">
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
        <Typography variant="h6" sx={{ flex: 1 }}>Roles and permissions</Typography>
        <Button size="small" startIcon={<AddIcon />} variant="contained" onClick={() => setCreateOpen(true)} data-testid="app-role-add">Add a role</Button>
        <Tooltip title="Read again"><IconButton size="small" onClick={load} aria-label="Read again">{loading ? <CircularProgress size={16} /> : <RefreshIcon fontSize="small" />}</IconButton></Tooltip>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        A role is a name people hold and reports are assigned to. Every role is based on one built-in level and starts with what that level may do; you can change it afterwards. A person may hold several roles -- what they may do adds up.
      </Typography>
      {error && <Alert severity="error" sx={{ mb: 2 }} data-testid="app-roles-error">{error}</Alert>}

      {!!page?.problems?.length && (
        <Alert severity="error" sx={{ mb: 2 }} data-testid="app-roles-problems">
          <Typography variant="subtitle2">Roles that count for nothing</Typography>
          {page.problems.map((p, i) => <Typography key={i} variant="body2">{p.role_name}: {p.problem}</Typography>)}
        </Alert>
      )}
      {!!page?.unknown_seen?.length && (
        <Alert severity="warning" sx={{ mb: 2 }} data-testid="app-roles-unknown">
          <Typography variant="subtitle2">Role names that are not set up</Typography>
          {page.unknown_seen.map((u, i) => <Typography key={i} variant="body2">{unknownWords(u)}</Typography>)}
        </Alert>
      )}

      <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems="flex-start">
        <Paper variant="outlined" sx={{ p: 1, minWidth: 240 }}>
          <Typography variant="overline" color="text.secondary">Roles</Typography>
          {(page?.roles || []).map(r => (
            <Box key={r.name} role="button" tabIndex={0} data-testid={`app-role-${r.name}`} aria-pressed={r.name === picked}
              onClick={() => setPicked(r.name)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') setPicked(r.name); }}
              sx={{ px: 1, py: 0.5, borderRadius: 1, cursor: 'pointer', bgcolor: r.name === picked ? 'action.selected' : undefined }}>
              <Typography variant="body2">{r.label} {r.is_builtin && <Chip size="small" label="built-in" sx={{ ml: 0.5 }} />}</Typography>
              <Typography variant="caption" color="text.secondary">{r.is_builtin ? r.description : `based on ${r.based_on} -- ${r.capabilities.length} permissions`}</Typography>
            </Box>
          ))}
        </Paper>

        {role && (
          <Box sx={{ flex: 1, minWidth: 0 }} data-testid="app-role-detail">
            <Stack direction="row" alignItems="center" spacing={1}>
              <Typography variant="h6" sx={{ flex: 1 }}>{role.label} <Typography component="span" variant="caption" color="text.secondary">({role.name}, based on {role.based_on})</Typography></Typography>
              {!role.is_builtin && <Button size="small" color="error" onClick={switchOff} data-testid="app-role-switch-off">Switch off</Button>}
            </Stack>
            {role.description && <Typography variant="body2" color="text.secondary">{role.description}</Typography>}

            <Paper variant="outlined" sx={{ p: 1.5, mt: 1.5 }}>
              <Stack direction="row" alignItems="center">
                <Typography variant="overline" color="text.secondary" sx={{ flex: 1 }}>What this role may do ({caps.size})</Typography>
                {dirty && <Button size="small" variant="contained" onClick={saveCaps} disabled={saving} data-testid="app-role-caps-save">Save</Button>}
                {dirty && <Button size="small" onClick={() => setCapDraft(null)} disabled={saving}>Cancel</Button>}
              </Stack>
              {Object.entries(byArea).map(([area, list]) => (
                <Box key={area} sx={{ mt: 1 }}>
                  <Typography variant="subtitle2">{list[0] ? (page?.capabilities.find(c => c.area === area)?.area && (areaLabel(page, area))) : area}</Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap' }}>
                    {list.map(c => (
                      <Tooltip key={c.name} title={c.description}>
                        <FormControlLabel sx={{ mr: 2 }} control={
                          <Checkbox size="small" checked={caps.has(c.name)} data-testid={`app-role-cap-${c.name}`}
                            onChange={e => {
                              const next = new Set(caps);
                              if (e.target.checked) next.add(c.name); else next.delete(c.name);
                              setCapDraft(next);
                            }} />
                        } label={<Typography variant="body2">{c.label}</Typography>} />
                      </Tooltip>
                    ))}
                  </Box>
                </Box>
              ))}
            </Paper>

            <Paper variant="outlined" sx={{ p: 1.5, mt: 1.5 }}>
              <Typography variant="overline" color="text.secondary">Who gets this role</Typography>
              {role.people_in_settings.length > 0 && (
                <Typography variant="body2" sx={{ mt: 0.5 }}>Set in the users list: {role.people_in_settings.join(', ')}</Typography>
              )}
              <Table size="small" sx={{ mt: 0.5 }}>
                <TableHead><TableRow><TableCell>Source</TableCell><TableCell align="right" /></TableRow></TableHead>
                <TableBody>
                  {role.sources.length === 0 && role.people_in_settings.length === 0 && (
                    <TableRow><TableCell colSpan={2}><Typography variant="body2" color="text.secondary">Nobody gets this role yet{role.is_builtin ? ' from the screen (the AD group settings still apply)' : ''}.</Typography></TableCell></TableRow>
                  )}
                  {role.sources.map(s => (
                    <TableRow key={s.id} data-testid={`app-role-source-${s.id}`}>
                      <TableCell>{sourceWords(s)}</TableCell>
                      <TableCell align="right">
                        <IconButton size="small" aria-label={`Remove ${sourceWords(s)}`} onClick={() => removeSource(s.id, sourceWords(s))}><DeleteIcon fontSize="small" /></IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <Stack direction="row" spacing={1} sx={{ mt: 1 }} alignItems="center">
                <TextField select size="small" label="Give it to" value={src.source_kind} sx={{ minWidth: 220 }}
                  onChange={e => setSrc(s => ({ ...s, source_kind: e.target.value }))} inputProps={{ 'data-testid': 'app-role-source-kind' }}>
                  {SOURCE_KINDS.map(k => <MenuItem key={k.value} value={k.value}>{k.label}</MenuItem>)}
                </TextField>
                <TextField size="small" label="Group, person, claim value or key id" value={src.source_value} sx={{ flex: 1 }}
                  onChange={e => setSrc(s => ({ ...s, source_value: e.target.value }))} inputProps={{ 'data-testid': 'app-role-source-value' }} />
                <Button size="small" variant="outlined" onClick={addSource} disabled={saving || !src.source_value.trim()} data-testid="app-role-source-add">Add</Button>
              </Stack>
              <Typography variant="caption" color="text.secondary" data-testid="app-role-source-help">{sourceHelp(src.source_kind, page?.claim_attribute || '')}</Typography>
            </Paper>

            <Paper variant="outlined" sx={{ p: 1.5, mt: 1.5 }}>
              <Typography variant="overline" color="text.secondary">Reports assigned to this role ({role.reports.length})</Typography>
              {role.reports.length === 0
                ? <Typography variant="body2" color="text.secondary">None. A report is assigned when it is published, or under its Permissions tab.</Typography>
                : <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 0.5 }}>
                    {role.reports.map(r => <Chip key={r.id} size="small" label={r.name} variant={r.is_published ? 'filled' : 'outlined'} />)}
                  </Box>}
            </Paper>
          </Box>
        )}
      </Stack>

      <AppDialog open={createOpen} onClose={() => setCreateOpen(false)} size="sm" title="Add a role" testId="app-role-create"
        actions={<>
          <Button onClick={() => setCreateOpen(false)} disabled={saving}>Cancel</Button>
          <Button variant="contained" onClick={create} disabled={saving || !draft.name.trim()} data-testid="app-role-create-save">Add</Button>
        </>}>
        <Stack spacing={2} sx={{ mt: 0.5 }}>
          <TextField size="small" label="Name (letters, digits, underscores)" value={draft.name} inputProps={{ 'data-testid': 'app-role-name' }}
            onChange={e => setDraft(d => ({ ...d, name: e.target.value }))} helperText="The key reports and settings use; lower case." />
          <TextField size="small" label="Shown as" value={draft.label} inputProps={{ 'data-testid': 'app-role-label' }}
            onChange={e => setDraft(d => ({ ...d, label: e.target.value }))} />
          <TextField size="small" label="What it is for" value={draft.description} multiline
            onChange={e => setDraft(d => ({ ...d, description: e.target.value }))} />
          <TextField select size="small" label="Based on" value={draft.based_on} inputProps={{ 'data-testid': 'app-role-based-on' }}
            onChange={e => setDraft(d => ({ ...d, based_on: e.target.value }))}
            helperText="It starts with what this level may do; the level is also what every screen treats its holders as. Never admin: that would make its holders full admins whatever the role says.">
            {(page?.allowed_bases || ['viewer', 'support', 'analyst']).map(b => <MenuItem key={b} value={b}>{b}</MenuItem>)}
          </TextField>
        </Stack>
      </AppDialog>
      <Divider sx={{ mt: 2 }} />
    </Box>
  );
};

/** The plain name of an area, from the server's capability faces. */
export const areaLabel = (page: AppRolesAdminPage | null, area: string): string => {
  const words: Record<string, string> = {
    connections: 'Connections', datasets: 'Datasets', bqb: 'Query builder', sql: 'SQL page', reports: 'Reports',
    dashboards: 'Dashboards', published_api: 'Published APIs', feeds: 'Feeds', dataflows: 'Dataflows',
    clockwork: 'Scheduler', schedules: 'Schedules', data_quality: 'Data quality', etl: 'ETL and SAP',
    workspaces: 'Workspaces', releases: 'Configuration releases', brain: 'Caches and the pruning brain',
    row_security: 'Data security', entitlement: 'Permissions', admin: 'Administration', account: 'Your account',
  };
  void page;
  return words[area] || area;
};

export default AppRolesAdminSection;
