/**
 * Admin → Spark pods (2026-10-13; the owner: "why we did not create admin ui").
 *
 * The settings that shape the pods a LARGE feed runs in -- when a feed gets
 * its own pods, how big they are, where they run, the OpenShift user id --
 * plus how many processes write a big CSV.  GET/PUT
 * /api/admin/spark-pods/config; the server validates every value and every
 * pod reads the saved one (the audited cross-pod config path).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, FormControlLabel, Grid, IconButton, MenuItem, Paper, Stack,
  Switch, Table, TableBody, TableCell, TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import RefreshIcon from '@mui/icons-material/Refresh';
import { safeFetch } from '../../services/api/core';
import { describeLoadError } from '../../utils/loadError';

type SizeClass = {
  driver_memory?: string; executor_memory?: string; num_executors?: number;
  executor_cores?: number; job_timeout_seconds?: number;
};
interface PodSettings {
  namespace: string; image: string; image_pull_policy: string; image_pull_secrets: string[];
  service_account: string; submit_mode: string; callback_base_url: string;
  driver_cores: number; driver_memory: string; executor_cores: number; executor_memory: string;
  num_executors: number; job_timeout_seconds: number; max_retries: number;
  driver_run_as_user: string; size_classes: Record<string, SizeClass>;
}
interface LargeFeeds {
  auto_route_threshold_rows: number; csv_parallel_workers: number; csv_parallel_min_rows: number;
  // 2026-11-09 -- may SIZE send a Databricks feed to its own pods? Off: only when chosen for the feed or the run.
  spark_route_databricks?: boolean;
}
interface View { spark_k8s: PodSettings; large_feeds: LargeFeeds }

const ROUTE = '/api/admin/spark-pods/config';
const MEMORY_RE = /^[1-9][0-9]*(\.[0-9]+)?[mMgG]$/;

/** What the server will refuse, said before Save (the server checks too). */
export function settingsProblems(s: PodSettings, l: LargeFeeds): string[] {
  const out: string[] = [];
  if (!MEMORY_RE.test(s.driver_memory)) out.push('Driver memory must look like 4g or 512m.');
  if (!MEMORY_RE.test(s.executor_memory)) out.push('Executor memory must look like 8g or 512m.');
  if (!(s.num_executors >= 1)) out.push('At least one executor.');
  if (!(s.driver_cores >= 1) || !(s.executor_cores >= 1)) out.push('Cores must be 1 or more.');
  if (s.driver_run_as_user && !/^[1-9][0-9]{0,9}$/.test(s.driver_run_as_user)) {
    out.push('User id must be a number above 0, or blank to let OpenShift choose.');
  }
  if (!/^[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?$/.test(s.namespace)) {
    out.push('Namespace: lower case letters, digits and hyphens.');
  }
  if (!(l.auto_route_threshold_rows >= 1000)) out.push('The row count for own pods must be at least 1,000.');
  for (const [name, c] of Object.entries(s.size_classes || {})) {
    for (const k of ['driver_memory', 'executor_memory'] as const) {
      if (c[k] && !MEMORY_RE.test(c[k] as string)) out.push(`Size "${name}": ${k.replace('_', ' ')} must look like 8g.`);
    }
  }
  return out;
}

const num = (v: string) => (v === '' ? NaN : Number(v));

export default function SparkPodsSection() {
  const [view, setView] = useState<View | null>(null);
  const [pods, setPods] = useState<PodSettings | null>(null);
  const [large, setLarge] = useState<LargeFeeds | null>(null);
  const [lane, setLane] = useState<{ available: boolean; detail: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const v = await safeFetch(ROUTE) as View;
      setView(v); setPods({ ...v.spark_k8s, size_classes: { ...(v.spark_k8s.size_classes || {}) } });
      setLarge({ ...v.large_feeds });
      try {
        const o = await safeFetch('/api/feeds/backend-options') as any;
        const k = (o?.options || []).find((x: any) => x.value === 'spark_k8s');
        setLane(k ? { available: !!k.available, detail: k.availability_detail || '' } : null);
      } catch { setLane(null); }
    } catch (e) {
      setError(`The Spark pod settings could not be read. ${describeLoadError(e).message}`);
    } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  if (loading && !pods) return <Box sx={{ p: 3 }}><CircularProgress size={24} /></Box>;
  if (!pods || !large || !view) {
    return <Alert severity="error" action={<Button onClick={load}>Retry</Button>}>{error}</Alert>;
  }

  const problems = settingsProblems(pods, large);
  const set = <K extends keyof PodSettings>(k: K, v: PodSettings[K]) => setPods({ ...pods, [k]: v });
  const setL = <K extends keyof LargeFeeds>(k: K, v: LargeFeeds[K]) => setLarge({ ...large, [k]: v });

  const changes = (): Record<string, any> => {
    const out: Record<string, any> = {};
    for (const k of Object.keys(pods) as (keyof PodSettings)[]) {
      if (JSON.stringify(pods[k]) !== JSON.stringify((view.spark_k8s as any)[k])) out[k] = pods[k];
    }
    for (const k of Object.keys(large) as (keyof LargeFeeds)[]) {
      if (large[k] !== view.large_feeds[k]) out[k] = large[k];
    }
    return out;
  };
  const pending = changes();

  const save = async () => {
    setSaving(true); setError(null); setSaved(null);
    try {
      const r = await safeFetch(ROUTE, { method: 'PUT', headers: { 'Content-Type': 'application/json' },
                                         body: JSON.stringify(pending) }) as any;
      setSaved(r?.persisted === 'db'
        ? 'Saved. Every QueryStudio pod uses these settings for the next feed it starts.'
        : 'Saved on this server only — the database could not be written, so other pods keep the old values.');
      await load();
    } catch (e) {
      setError(`Not saved. ${describeLoadError(e).message}`);
    } finally { setSaving(false); }
  };

  const classes = Object.entries(pods.size_classes || {});
  const setClass = (name: string, k: keyof SizeClass, v: any) => set('size_classes', {
    ...pods.size_classes, [name]: { ...pods.size_classes[name], [k]: v === '' || Number.isNaN(v) ? undefined : v } });

  return (
    <Box data-testid="spark-pods-section">
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 1 }}>
        <Box sx={{ flexGrow: 1 }} />
        {lane && (
          <Tooltip title={lane.detail}>
            <Chip size="small" data-testid="spark-pods-lane"
                  color={lane.available ? 'success' : 'warning'}
                  label={lane.available ? 'Pods can be created now' : 'Pods cannot be created now'} />
          </Tooltip>
        )}
        <Tooltip title="Reload"><IconButton aria-label="Reload Spark pod settings" onClick={load}><RefreshIcon /></IconButton></Tooltip>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        A feed expected to send more rows than the number below runs in its own pods on the cluster, so the
        QueryStudio servers stay free. Changes apply to the next feed that starts; running feeds keep their pods.
      </Typography>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {saved && <Alert severity="success" sx={{ mb: 2 }} data-testid="spark-pods-saved">{saved}</Alert>}

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>When a feed gets its own pods</Typography>
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, sm: 6 }}>
            <TextField fullWidth type="number" label="Rows at which a feed runs in its own pods"
              value={large.auto_route_threshold_rows}
              onChange={e => setL('auto_route_threshold_rows', num(e.target.value))}
              helperText="Counted from the upstream message, else the last run. Default 500,000." />
          </Grid>
          <Grid size={{ xs: 12, sm: 3 }}>
            <TextField fullWidth type="number" label="Processes writing a large CSV"
              value={large.csv_parallel_workers}
              onChange={e => setL('csv_parallel_workers', num(e.target.value))}
              helperText="0 = one per CPU the server may use. 1 = one process." />
          </Grid>
          <Grid size={{ xs: 12, sm: 3 }}>
            <TextField fullWidth type="number" label="…from this many rows"
              value={large.csv_parallel_min_rows}
              onChange={e => setL('csv_parallel_min_rows', num(e.target.value))}
              helperText="Smaller files are written by one process." />
          </Grid>
          <Grid size={{ xs: 12 }}>
            {/* 2026-11-09 -- Databricks feeds have a Spark road now; size sends them there only when this is on */}
            <FormControlLabel
              control={<Switch checked={!!large.spark_route_databricks}
                               onChange={e => setL('spark_route_databricks', e.target.checked)}
                               inputProps={{ 'aria-label': 'Let the row count send Databricks feeds to their own pods' } as any} />}
              label="Let the row count send Databricks feeds to their own pods" />
            <Typography variant="caption" color="text.secondary" display="block" data-testid="spark-route-databricks-words">
              {large.spark_route_databricks
                ? 'On: a big Databricks feed runs in its own pods like any other source.'
                : 'Off: a Databricks feed runs in its own pods only when that is chosen for the feed or for a run; the row count keeps it on the server.'}
            </Typography>
          </Grid>
        </Grid>
      </Paper>

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>Pod size (every large feed, unless its size is set below)</Typography>
        <Grid container spacing={2}>
          <Grid size={{ xs: 6, sm: 2 }}><TextField fullWidth label="Driver memory" value={pods.driver_memory} onChange={e => set('driver_memory', e.target.value)} helperText="e.g. 4g" /></Grid>
          <Grid size={{ xs: 6, sm: 2 }}><TextField fullWidth type="number" label="Driver CPUs" value={pods.driver_cores} onChange={e => set('driver_cores', num(e.target.value))} /></Grid>
          <Grid size={{ xs: 6, sm: 2 }}><TextField fullWidth label="Executor memory" value={pods.executor_memory} onChange={e => set('executor_memory', e.target.value)} helperText="Raised automatically for very wide data" /></Grid>
          <Grid size={{ xs: 6, sm: 2 }}><TextField fullWidth type="number" label="Executor CPUs" value={pods.executor_cores} onChange={e => set('executor_cores', num(e.target.value))} /></Grid>
          <Grid size={{ xs: 6, sm: 2 }}><TextField fullWidth type="number" label="Executors" value={pods.num_executors} onChange={e => set('num_executors', num(e.target.value))} /></Grid>
          <Grid size={{ xs: 6, sm: 2 }}><TextField fullWidth type="number" label="Time limit (s)" value={pods.job_timeout_seconds} onChange={e => set('job_timeout_seconds', num(e.target.value))} /></Grid>
          <Grid size={{ xs: 6, sm: 2 }}><TextField fullWidth type="number" label="Retries" value={pods.max_retries} onChange={e => set('max_retries', num(e.target.value))} /></Grid>
        </Grid>
      </Paper>

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" alignItems="center" sx={{ mb: 1 }}>
          <Typography variant="subtitle1" sx={{ fontWeight: 600, flexGrow: 1 }}>Named sizes a feed can choose</Typography>
          <Button size="small" startIcon={<AddIcon />} onClick={() => {
            let n = 1; while (pods.size_classes[`size${n}`]) n += 1;
            set('size_classes', { ...pods.size_classes, [`size${n}`]: {} });
          }}>Add size</Button>
        </Stack>
        <Table size="small">
          <TableHead><TableRow>
            <TableCell>Name</TableCell><TableCell>Driver memory</TableCell><TableCell>Executor memory</TableCell>
            <TableCell>Executors</TableCell><TableCell>Time limit (s)</TableCell><TableCell align="right">Actions</TableCell>
          </TableRow></TableHead>
          <TableBody>
            {classes.length === 0 && <TableRow><TableCell colSpan={6}>No named sizes — every feed uses the pod size above.</TableCell></TableRow>}
            {classes.map(([name, c]) => (
              <TableRow key={name}>
                <TableCell>{name}</TableCell>
                <TableCell><TextField size="small" inputProps={{ 'aria-label': `Driver memory — ${name}` }} value={c.driver_memory ?? ''} placeholder="default" onChange={e => setClass(name, 'driver_memory', e.target.value)} /></TableCell>
                <TableCell><TextField size="small" inputProps={{ 'aria-label': `Executor memory — ${name}` }} value={c.executor_memory ?? ''} placeholder="default" onChange={e => setClass(name, 'executor_memory', e.target.value)} /></TableCell>
                <TableCell><TextField size="small" type="number" inputProps={{ 'aria-label': `Executors — ${name}` }} value={c.num_executors ?? ''} placeholder="default" onChange={e => setClass(name, 'num_executors', num(e.target.value))} /></TableCell>
                <TableCell><TextField size="small" type="number" inputProps={{ 'aria-label': `Time limit — ${name}` }} value={c.job_timeout_seconds ?? ''} placeholder="default" onChange={e => setClass(name, 'job_timeout_seconds', num(e.target.value))} /></TableCell>
                <TableCell align="right">
                  <IconButton aria-label={`Remove size ${name}`} onClick={() => {
                    const next = { ...pods.size_classes }; delete next[name]; set('size_classes', next);
                  }}><DeleteIcon fontSize="small" /></IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>

      <Paper variant="outlined" sx={{ p: 2, mb: 2 }}>
        <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>Where the pods run</Typography>
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, sm: 3 }}><TextField fullWidth label="Namespace" value={pods.namespace} onChange={e => set('namespace', e.target.value)} /></Grid>
          <Grid size={{ xs: 12, sm: 5 }}><TextField fullWidth label="Job image" value={pods.image} onChange={e => set('image', e.target.value)} /></Grid>
          <Grid size={{ xs: 12, sm: 2 }}>
            <TextField select fullWidth label="Pull image" value={pods.image_pull_policy} onChange={e => set('image_pull_policy', e.target.value)}>
              <MenuItem value="Always">Every time</MenuItem><MenuItem value="IfNotPresent">If missing</MenuItem><MenuItem value="Never">Never</MenuItem>
            </TextField>
          </Grid>
          <Grid size={{ xs: 12, sm: 2 }}><TextField fullWidth label="Service account" value={pods.service_account} onChange={e => set('service_account', e.target.value)} /></Grid>
          <Grid size={{ xs: 12, sm: 4 }}>
            <TextField select fullWidth label="How pods are created" value={pods.submit_mode} onChange={e => set('submit_mode', e.target.value)}
              helperText="Automatic uses the Spark operator when the cluster has it.">
              <MenuItem value="auto">Automatic</MenuItem>
              <MenuItem value="spark_application">Through the Spark operator</MenuItem>
              <MenuItem value="driver_pod">QueryStudio creates the driver pod</MenuItem>
            </TextField>
          </Grid>
          <Grid size={{ xs: 12, sm: 4 }}><TextField fullWidth label="Image pull secrets (comma-separated)" value={(pods.image_pull_secrets || []).join(', ')}
            onChange={e => set('image_pull_secrets', e.target.value.split(',').map(x => x.trim()).filter(Boolean))} /></Grid>
          <Grid size={{ xs: 12, sm: 4 }}><TextField fullWidth label="Address the pods report back to" value={pods.callback_base_url} onChange={e => set('callback_base_url', e.target.value)} /></Grid>
          <Grid size={{ xs: 12, sm: 4 }}>
            <TextField fullWidth label="Run as user id (OpenShift)" value={pods.driver_run_as_user}
              onChange={e => set('driver_run_as_user', e.target.value.trim())}
              helperText="Leave blank and OpenShift picks one from the project's range (recommended)." />
          </Grid>
        </Grid>
      </Paper>

      {problems.length > 0 && (
        <Alert severity="warning" sx={{ mb: 2 }} data-testid="spark-pods-problems">
          {problems.map(p => <div key={p}>{p}</div>)}
        </Alert>
      )}
      <Stack direction="row" spacing={1}>
        <Button variant="contained" onClick={save} data-testid="spark-pods-save"
                disabled={saving || problems.length > 0 || Object.keys(pending).length === 0}>
          {saving ? 'Saving…' : 'Save'}
        </Button>
        <Button onClick={load} disabled={saving || Object.keys(pending).length === 0}>Discard changes</Button>
        <Typography variant="body2" color="text.secondary" sx={{ alignSelf: 'center' }}>
          {Object.keys(pending).length === 0 ? 'No changes.' : `${Object.keys(pending).length} change(s) not saved.`}
        </Typography>
      </Stack>
    </Box>
  );
}
