/**
 * "Who may see this report" (2026-11-10).  Publish asks it for a report that was
 * never published; the Permissions tab opens it to change the assigned roles.
 * The roles come from the server (`GET /api/app-roles`); nothing here names one.
 * The answer is a list of role names, or [] for every signed-in person.
 */
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert, Button, Checkbox, CircularProgress, FormControlLabel, Stack, Typography,
} from '@mui/material';
import AppDialog from '../common/AppDialog';
import appRoles, { AppRolePick } from '../../services/api/appRoles';

interface Props {
  open: boolean;
  /** The roles already assigned (edit) -- [] = everyone. */
  initial?: string[];
  title?: string;
  confirmLabel?: string;
  busy?: boolean;
  onClose: () => void;
  onConfirm: (roles: string[], everyone: boolean) => void;
}

export const EVERYONE_WORDS = 'Every signed-in person';

const PublishRolesDialog: React.FC<Props> = ({
  open, initial, title = 'Who may see this report?', confirmLabel = 'Publish', busy, onClose, onConfirm,
}) => {
  const [roles, setRoles] = useState<AppRolePick[] | null>(null);
  const [loadError, setLoadError] = useState('');
  const [picked, setPicked] = useState<Set<string>>(new Set(initial || []));
  const [everyone, setEveryone] = useState<boolean>(!!initial && initial.length === 0);

  useEffect(() => {
    if (!open) return;
    setPicked(new Set(initial || []));
    setEveryone(!!initial && initial.length === 0);
    setLoadError('');
    appRoles.listAppRoles()
      .then(r => setRoles(r.roles || []))
      .catch(e => { setRoles([]); setLoadError(e?.message || 'The roles could not be read'); });
  }, [open]);   // eslint-disable-line react-hooks/exhaustive-deps

  const toggle = (name: string) => {
    setPicked(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name); else next.add(name);
      return next;
    });
    setEveryone(false);
  };

  const canConfirm = everyone || picked.size > 0;
  const chosenWords = useMemo(() => {
    if (everyone) return EVERYONE_WORDS;
    if (picked.size === 0) return 'Nobody yet -- pick at least one role, or every signed-in person.';
    const labels = (roles || []).filter(r => picked.has(r.name)).map(r => r.label);
    return `Shown to: ${labels.join(', ')}`;
  }, [everyone, picked, roles]);

  return (
    <AppDialog open={open} onClose={onClose} size="sm" title={title} testId="publish-roles-dialog"
      actions={<>
        <Button onClick={onClose} disabled={busy}>Cancel</Button>
        <Button variant="contained" disabled={!canConfirm || busy} data-testid="publish-roles-confirm"
          onClick={() => onConfirm(everyone ? [] : Array.from(picked), everyone)}>{confirmLabel}</Button>
      </>}>
      <Typography variant="body2" sx={{ mb: 1 }}>
        A report is shown only to the roles you pick. People who hold several roles see it when any one of them is on the list.
      </Typography>
      {loadError && <Alert severity="error" sx={{ mb: 1 }}>{loadError}</Alert>}
      {roles === null ? <CircularProgress size={18} /> : (
        <Stack spacing={0}>
          {roles.map(r => (
            <FormControlLabel key={r.name}
              control={<Checkbox size="small" checked={!everyone && picked.has(r.name)} onChange={() => toggle(r.name)}
                                 inputProps={{ 'aria-label': r.label } as any} data-testid={`publish-role-${r.name}`} />}
              label={<span>{r.label}{r.is_builtin ? '' : <Typography component="span" variant="caption" color="text.secondary"> -- based on {r.based_on}</Typography>}</span>} />
          ))}
          <FormControlLabel sx={{ mt: 1 }}
            control={<Checkbox size="small" checked={everyone} data-testid="publish-role-everyone"
                               onChange={e => { setEveryone(e.target.checked); if (e.target.checked) setPicked(new Set()); }} />}
            label={EVERYONE_WORDS} />
        </Stack>
      )}
      <Typography variant="caption" color="text.secondary" data-testid="publish-roles-words">{chosenWords}</Typography>
    </AppDialog>
  );
};

export default PublishRolesDialog;
