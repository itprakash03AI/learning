/**
 * WhoCanUsePanel -- who may use a thing (2026-11-10).
 *
 * docs/OBJECT_ACCESS_BY_ROLE_PLAN_2026_11_10.html: everyone, or only these --
 * application roles, AD groups, user groups, people.  One panel for every kind
 * of thing (connections first), so every screen asks the same way.  Its owner
 * and admins always have it; grants only add.
 */
import React, { useEffect, useState } from 'react';
import {
  Box, Button, Chip, FormControlLabel, MenuItem, Radio, RadioGroup, Stack, TextField, Typography,
} from '@mui/material';
import { Add as AddIcon } from '@mui/icons-material';
import appRoles, { AppRolePick } from '../../services/api/appRoles';
import api from '../../services/api';

export interface AccessGrant {
  principal_type: 'role' | 'ad_group' | 'user_group' | 'user';
  principal_name: string;
  label?: string;
}

export interface WhoCanUseValue {
  everyone: boolean;
  grants: AccessGrant[];
}

const KINDS: Array<{ value: AccessGrant['principal_type']; label: string; hint: string }> = [
  { value: 'role', label: 'Role', hint: 'Everyone who holds this role' },
  { value: 'ad_group', label: 'AD group', hint: 'A directory group name, e.g. FIN-Analysts' },
  { value: 'user_group', label: 'User group', hint: 'A QueryStudio user group' },
  { value: 'user', label: 'Person', hint: 'A username' },
];

const kindWord = (k: string) => KINDS.find(x => x.value === k)?.label || k;

interface Props {
  value: WhoCanUseValue;
  onChange: (v: WhoCanUseValue) => void;
  /** e.g. "connection" -- said in the help text */
  thing: string;
  /** what "use" means for this thing, in plain words */
  useMeans?: string;
  /** the kinds this thing may be given to (a connection: groups only -- never one person) */
  kinds?: AccessGrant['principal_type'][];
}

const WhoCanUsePanel: React.FC<Props> = ({ value, onChange, thing, useMeans, kinds }) => {
  const [roles, setRoles] = useState<AppRolePick[]>([]);
  const [groups, setGroups] = useState<Array<{ id: number; name: string }>>([]);
  const offered = KINDS.filter(k => !kinds || kinds.includes(k.value));
  const [kind, setKind] = useState<AccessGrant['principal_type']>(offered[0]?.value || 'role');
  const [name, setName] = useState('');

  useEffect(() => {
    appRoles.listAppRoles().then(r => setRoles(r?.roles || [])).catch(() => setRoles([]));
    Promise.resolve(api.listUserGroups({ is_active: true }))
      .then((r: any) => setGroups(Array.isArray(r) ? r : (r?.groups || [])))
      .catch(() => setGroups([]));
  }, []);

  const add = () => {
    const n = name.trim();
    if (!n) return;
    const key = kind === 'user_group' ? n : n.toLowerCase();
    if (value.grants.some(g => g.principal_type === kind && g.principal_name.toLowerCase() === key)) {
      setName('');
      return;
    }
    const label = kind === 'user_group' ? (groups.find(g => String(g.id) === n)?.name || n)
      : kind === 'role' ? (roles.find(r => r.name === n)?.label || n) : key;   // as it is saved
    onChange({ ...value, grants: [...value.grants, { principal_type: kind, principal_name: key, label }] });
    setName('');
  };

  const remove = (g: AccessGrant) =>
    onChange({ ...value, grants: value.grants.filter(x => !(x.principal_type === g.principal_type
      && x.principal_name === g.principal_name)) });

  const picker = kind === 'role' ? (
    <TextField select size="small" label="Role" value={name} onChange={e => setName(e.target.value)}
      sx={{ minWidth: 220 }} inputProps={{ 'data-testid': 'wcu-name' }}>
      {roles.map(r => <MenuItem key={r.name} value={r.name}>{r.label || r.name}</MenuItem>)}
    </TextField>
  ) : kind === 'user_group' ? (
    <TextField select size="small" label="User group" value={name} onChange={e => setName(e.target.value)}
      sx={{ minWidth: 220 }} inputProps={{ 'data-testid': 'wcu-name' }}>
      {groups.map(g => <MenuItem key={g.id} value={String(g.id)}>{g.name}</MenuItem>)}
    </TextField>
  ) : (
    <TextField size="small" label={kind === 'user' ? 'Username' : 'AD group'} value={name}
      onChange={e => setName(e.target.value)} sx={{ minWidth: 220 }}
      onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); add(); } }}
      inputProps={{ 'data-testid': 'wcu-name' }}
      placeholder={KINDS.find(k => k.value === kind)?.hint} />
  );

  return (
    <Box data-testid="who-can-use" sx={{ p: 1.5, border: 1, borderColor: 'divider', borderRadius: 1 }}>
      <Typography variant="subtitle2" fontWeight={700}>Who can use this {thing}</Typography>
      {useMeans && (
        <Typography variant="caption" color="text.secondary" display="block" sx={{ mb: 0.5 }}>
          {useMeans}
        </Typography>
      )}
      <RadioGroup row value={value.everyone ? 'everyone' : 'only'}
        onChange={e => onChange({ ...value, everyone: e.target.value === 'everyone' })}>
        <FormControlLabel value="everyone" control={<Radio size="small" />} label="Everyone" />
        <FormControlLabel value="only" control={<Radio size="small" />} label="Only the people below" />
      </RadioGroup>
      {!value.everyone && (
        <Stack spacing={1.25} sx={{ mt: 0.5 }}>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.75 }} data-testid="wcu-grants">
            {value.grants.length === 0 ? (
              <Typography variant="body2" color="text.secondary">
                Nobody yet — only its owner and admins can use it.
              </Typography>
            ) : value.grants.map(g => (
              <Chip key={`${g.principal_type}:${g.principal_name}`} size="small"
                label={offered.some(k => k.value === g.principal_type)
                  ? `${kindWord(g.principal_type)}: ${g.label || g.principal_name}`
                  // a grant of a kind no longer offered (a connection given to a person before
                  // 2026-11-10): kept until removed, never added again
                  : `${kindWord(g.principal_type)} (old grant): ${g.label || g.principal_name}`}
                onDelete={() => remove(g)} />
            ))}
          </Box>
          <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
            <TextField select size="small" label="Give it to" value={kind} sx={{ minWidth: 150 }}
              onChange={e => { setKind(e.target.value as AccessGrant['principal_type']); setName(''); }}
              inputProps={{ 'data-testid': 'wcu-kind' }}>
              {offered.map(k => <MenuItem key={k.value} value={k.value}>{k.label}</MenuItem>)}
            </TextField>
            {picker}
            <Button size="small" variant="outlined" startIcon={<AddIcon />} onClick={add}
              disabled={!name.trim()}>Add</Button>
          </Stack>
        </Stack>
      )}
    </Box>
  );
};

export default WhoCanUsePanel;
