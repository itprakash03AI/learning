import React from 'react';
import { Box } from '@mui/material';
import type { ResizableWidth } from '../../hooks/useResizableWidth';

/**
 * The thin bar on a side panel's edge that the person drags to change its
 * width (useResizableWidth).  Double-click puts the default width back; the
 * arrow keys move it when the bar has focus.  Drawn the same on every page.
 */
export default function PanelResizeHandle({
  resize, label, edge = 'right',
}: {
  resize: ResizableWidth;
  /** What the bar resizes, for screen readers: e.g. "Resize the objects panel". */
  label: string;
  edge?: 'right' | 'left';
}) {
  return (
    <Box
      {...resize.handleProps}
      aria-label={label}
      title="Drag to resize · double-click to reset"
      data-testid="panel-resize-handle"
      sx={{
        position: 'absolute', top: 0, bottom: 0, [edge]: 0, width: 6, zIndex: 2,
        cursor: 'col-resize', touchAction: 'none',
        '&::after': {
          content: '""', position: 'absolute', top: 0, bottom: 0, left: 2, width: 2,
          bgcolor: resize.dragging ? 'primary.main' : 'transparent',
          transition: 'background-color 0.15s',
        },
        '&:hover::after, &:focus-visible::after': { bgcolor: 'primary.light' },
        '&:focus-visible': { outline: 'none' },
      }}
    />
  );
}
