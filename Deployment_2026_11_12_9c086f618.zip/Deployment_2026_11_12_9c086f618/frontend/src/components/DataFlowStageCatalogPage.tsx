/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * DataFlowStageCatalogPage — browseable directory of every registered
 * stage type with its description, category, idempotency contract, and
 * config schema.
 *
 * End-user discovery: "what can I put into a DataFlow?"
 *
 * Layout:
 *   • Search box (filters by name / description across all stages)
 *   • Category filter chips
 *   • Card grid — one card per stage with click-to-expand config schema
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Card, CardContent, Chip, CircularProgress, IconButton,
  MenuItem, Paper, Select, Stack, TextField, Tooltip, Typography, Collapse,
  Button,
} from '@mui/material';
import {
  Search as SearchIcon, ExpandMore as ExpandIcon,
  ExpandLess as CollapseIcon, OpenInNew as OpenIcon,
  ArrowBack as BackIcon,
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import type { StageTypeManifest } from '../services/api/dataflows';
import { toArray } from '../utils/toArray';


const CATEGORY_COLOURS: Record<string, any> = {
  source:    'primary',
  transform: 'info',
  sink:      'warning',
  control:   'secondary',
  quality:   'success',
  notify:    'default',
};


// 2026-09-15 — `runnable === false` is a verdict from the backend that
// answered: registered, but it cannot execute in that image.  An absent
// field is a backend that was not asked, and renders as before.
const isRunnable = (s: StageTypeManifest) => s.runnable !== false;


function StageCard({ s }: { s: StageTypeManifest }) {
  const [open, setOpen] = useState(false);
  const schemaKeys = Object.keys(s.config_schema || {});
  const runnable = isRunnable(s);
  // 2026-09-24 -- the chevron is the only control on the card; a screen
  // reader announced "button" 50 times on this page.  Name it for THIS stage.
  const toggleLabel = `${open ? 'Collapse' : 'Expand'} ${s.display_name || s.name} config keys`;
  return (
    <Card variant="outlined" data-testid={`stage-card-${s.name}`}
          sx={runnable ? undefined : { opacity: 0.7, borderColor: 'error.main' }}>
      <CardContent>
        {!runnable && (
          <Alert severity="warning" sx={{ mb: 1, py: 0 }}
                 data-testid={`stage-card-${s.name}-unavailable`}>
            Not runnable in this image — {s.unavailable_reason || 'no reason given'}
          </Alert>
        )}
        <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
          <Box>
            <Typography variant="h6" sx={{ fontSize: 16, fontWeight: 600,
                                            color: runnable ? undefined : 'text.disabled' }}>
              {s.display_name || s.name}
            </Typography>
            <Typography variant="caption" color="text.secondary"
                          sx={{ display: 'block', fontFamily: 'monospace', fontSize: 11 }}>
              {s.name}
            </Typography>
            <Stack direction="row" spacing={0.5} sx={{ mt: 0.5 }}>
              <Chip label={s.category} size="small"
                     color={CATEGORY_COLOURS[s.category] || 'default'}
                     variant="outlined" sx={{ fontSize: 10, height: 20 }} />
              <Chip label={`idempotent: ${s.idempotency}`} size="small"
                     variant="outlined" sx={{ fontSize: 10, height: 20 }} />
              {s.is_control_flow && (
                <Chip label="control flow" size="small" variant="outlined"
                       sx={{ fontSize: 10, height: 20 }} />
              )}
              {!runnable && (
                <Tooltip title={s.unavailable_reason || 'no reason given'}>
                  <Chip label="not runnable here" size="small" color="error"
                         variant="outlined" sx={{ fontSize: 10, height: 20 }} />
                </Tooltip>
              )}
            </Stack>
          </Box>
          {schemaKeys.length > 0 && (
            <Tooltip title={toggleLabel}>
              <IconButton size="small" onClick={() => setOpen(o => !o)}
                          aria-label={toggleLabel} aria-expanded={open}>
                {open ? <CollapseIcon /> : <ExpandIcon />}
              </IconButton>
            </Tooltip>
          )}
        </Stack>

        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
          {s.description || 'No description.'}
        </Typography>

        <Collapse in={open}>
          <Box sx={{ mt: 2, pt: 2, borderTop: 1, borderColor: 'divider' }}>
            <Typography variant="caption" sx={{
              color: 'text.secondary', display: 'block', mb: 1,
              textTransform: 'uppercase', letterSpacing: 0.5,
            }}>Configuration keys</Typography>
            {schemaKeys.length === 0 ? (
              <Typography variant="body2" color="text.secondary"
                            sx={{ fontStyle: 'italic' }}>
                Takes no configuration.
              </Typography>
            ) : (
              <Stack spacing={0.5}>
                {schemaKeys.map(k => {
                  const def = s.config_schema?.[k] || {};
                  const t = def.type
                    || (def.enum ? `enum(${def.enum.join('|')})` : 'any');
                  return (
                    <Box key={k} sx={{ display: 'flex', gap: 1, fontSize: 13 }}>
                      <Typography component="span"
                                    sx={{ fontFamily: 'monospace', fontWeight: 500,
                                            minWidth: 200, color: 'primary.main' }}>
                        {k}
                      </Typography>
                      <Typography component="span" sx={{ fontFamily: 'monospace',
                                                            color: 'text.secondary' }}>
                        {t}
                      </Typography>
                      {def.description && (
                        <Typography component="span" color="text.secondary"
                                      sx={{ fontSize: 12 }}>
                          — {def.description}
                        </Typography>
                      )}
                    </Box>
                  );
                })}
              </Stack>
            )}
            <Typography variant="caption" color="text.secondary"
                          sx={{ mt: 2, display: 'block', fontFamily: 'monospace' }}>
              class_path: {s.class_path}
            </Typography>
          </Box>
        </Collapse>
      </CardContent>
    </Card>
  );
}


export default function DataFlowStageCatalogPage() {
  const nav = useNavigate();
  // `null` = not read.  An unreadable catalogue must never reach the
  // "No stages match." panel: 2026-09-05 this had `.then().finally()` and
  // no `.catch`, so a 500 left `stages` at its initial `[]` and the screen
  // said there were no stages — a failure wearing the shape of an answer.
  const [stages, setStages] = useState<StageTypeManifest[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<string>('');

  const load = useCallback(() => {
    setLoading(true);
    setLoadError(null);
    api.dataflows.listStageTypes()
      .then(d => { setStages(toArray<StageTypeManifest>(d)); })
      .catch((e: any) => {
        setStages(null);
        setLoadError(e?.message || String(e));
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const categories = useMemo(() => {
    const set = new Set((stages || []).map(s => s.category));
    return Array.from(set).sort();
  }, [stages]);

  const filtered = useMemo(() => {
    let out = stages || [];
    if (category) out = out.filter(s => s.category === category);
    if (search) {
      const q = search.toLowerCase();
      out = out.filter(s =>
        s.name.toLowerCase().includes(q) ||
        (s.description || '').toLowerCase().includes(q),
      );
    }
    return out;
  }, [stages, search, category]);

  const grouped = useMemo(() => {
    const g: Record<string, StageTypeManifest[]> = {};
    filtered.forEach(s => {
      g[s.category] = g[s.category] || [];
      g[s.category].push(s);
    });
    return g;
  }, [filtered]);

  return (
    <Box sx={{ p: 3 }}>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ mb: 2 }}>
        <Tooltip title="Back to DataFlows">
          <IconButton onClick={() => nav('/dataflows')} aria-label="Back to DataFlows">
            <BackIcon />
          </IconButton>
        </Tooltip>
        <Box sx={{ flex: 1 }}>
          <Typography variant="h5">Stage Catalogue</Typography>
          <Typography variant="caption" color="text.secondary">
            {stages == null
              ? 'stage count unknown — the catalogue has not been read'
              : `${stages.length} stage types available`}
            {stages != null && stages.some(s => !isRunnable(s)) && (
              <Typography component="span" variant="caption" color="error.main"
                          data-testid="stage-catalogue-unrunnable-count">
                {` (${stages.filter(s => !isRunnable(s)).length} registered but not runnable in this image)`}
              </Typography>
            )} — click expand to
            see config keys, then use them in the DataFlow builder.
          </Typography>
        </Box>
        <Button startIcon={<OpenIcon />} onClick={() => nav('/dataflows/new')}>
          New DataFlow
        </Button>
      </Stack>

      <Paper sx={{ p: 2, mb: 2 }}>
        <Stack direction="row" spacing={2} alignItems="center">
          <TextField fullWidth size="small" placeholder="Search by name or description…"
                      value={search} onChange={e => setSearch(e.target.value)}
                      InputProps={{ startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.disabled' }} /> }} />
          <Select inputProps={{ 'aria-label': 'Filter by category' }} size="small" displayEmpty value={category}
                   onChange={e => setCategory(e.target.value)}
                   sx={{ minWidth: 200 }}>
            <MenuItem value="">All categories</MenuItem>
            {categories.map(c => (
              <MenuItem key={c} value={c}>{c}</MenuItem>
            ))}
          </Select>
        </Stack>
      </Paper>

      {loading && <CircularProgress size={20} />}

      {!loading && loadError && (
        <Alert
          severity="error" sx={{ mb: 2 }} data-testid="stage-catalogue-error"
          action={(
            <Button size="small" color="inherit" onClick={() => load()}>
              Retry
            </Button>
          )}
        >
          Could not load the stage catalogue — that is NOT the same as there
          being no stages. {loadError}
        </Alert>
      )}

      {!loading && !loadError && Object.entries(grouped).map(([cat, items]) => (
        <Box key={cat} sx={{ mb: 3 }}>
          <Typography variant="overline" sx={{
            display: 'block', mb: 1, color: 'text.secondary',
            letterSpacing: 1.2,
          }}>{cat} · {items.length} stage{items.length === 1 ? '' : 's'}</Typography>
          <Box sx={{
            display: 'grid', gap: 2,
            gridTemplateColumns: { xs: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' },
          }}>
            {items.map(s => <StageCard key={s.name} s={s} />)}
          </Box>
        </Box>
      ))}

      {!loading && !loadError && filtered.length === 0 && (
        <Paper sx={{ p: 4, textAlign: 'center' }}
               data-testid="stage-catalogue-empty">
          <Typography color="text.secondary">No stages match.</Typography>
        </Paper>
      )}
    </Box>
  );
}
