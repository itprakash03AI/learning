/*
 * QueryStudio's JDBC dialect for Databricks on Spark 3.5 (2026-11-09).
 *
 * Spark quotes EVERY identifier it writes into a JDBC statement through the URL's dialect: the
 * SELECT list of a read (JDBCRDD.scanTable -> dialect.quoteIdentifier), the partition column of a
 * parallel read (JDBCRelation.verifyAndGetNormalizedPartitionColumn) and pushed-down filters.
 * Spark 3.5 has no dialect for "jdbc:databricks" and falls back to NoopDialect, which quotes with
 * DOUBLE QUOTES -- and Databricks SQL reads "ID" as the STRING 'ID', so a feed would have delivered
 * one constant per column with a 200 and no error anywhere.  Spark 4.x ships its own
 * DatabricksDialect (backticks); this class is the same rule for the 3.5 image.  The job
 * (spark/jobs/generic_feed.py::_ensure_jdbc_dialect) registers it ONLY when Spark's own answer for
 * the URL is the Noop dialect, and REFUSES the read when no backtick dialect can be had.
 *
 * Compiled at image build (spark/Dockerfile, stage "qsdialect") against the image's own Spark
 * jars; no Scala source, no build tool: javac + jar.
 */
package com.querystudio.spark;

import org.apache.spark.sql.jdbc.JdbcDialect;

public class QsDatabricksDialect extends JdbcDialect {

    @Override
    public boolean canHandle(String url) {
        return url != null && url.startsWith("jdbc:databricks");
    }

    /** Databricks: any character between backticks; a backtick is escaped by doubling it. */
    @Override
    public String quoteIdentifier(String colName) {
        return "`" + colName.replace("`", "``") + "`";
    }
}
