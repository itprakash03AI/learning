"""Phase 7 Part 3 — Forkserver template for DuckDB subprocess spawn.

flag: ``industrialization.forkserver`` (default OFF, and structurally
inert unless BOTH the flag is on AND the platform is POSIX with a
working ``os.fork``).

Kills per-query cold-start (interpreter boot + ``import duckdb`` +
extension dlopen/NFS-read) WITHOUT reintroducing the state-bleed risk
of a reusable warm worker pool (that's :mod:`core.duckdb_worker_pool`,
Phase 168 — a DIFFERENT, opt-in mechanism this module deliberately does
NOT reuse the shape of, per the Phase-7 "no warm pool" hard rule).

── Design: stateless template, one-shot forked children ────────────────

  1. ONE long-lived **template** process per pod, started lazily and
     supervised (:class:`ForkServerTemplate`).  Boot sequence:
       a. ``duckdb.connect(':memory:')``
       b. ``SET extension_directory=...`` — via the SAME
          ``core.file_formats.ensure_extension_directory`` helper every
          other DuckDB connection in this codebase uses (non-root /
          ``HOME=/`` read-only container constraint — the documented
          landmark).  MUST happen before any INSTALL/LOAD.
       c. ``LOAD`` each configured extension (default: ``httpfs``) —
          this ``dlopen()``s the extension's shared library into the
          template's address space.
       d. ``con.close()`` — the template now holds **zero open
          connections and zero query state**.  What remains resident is
          only the dlopen'd shared-library mapping — static, read-only-
          after-load, process-level linkage state, not query/data
          state.

  2. Each query calls :func:`try_spawn_via_forkserver`, which
     ``os.fork()``s a ONE-SHOT child from the template.  The child:
       a. ``os.setsid()`` — new session AND new process group (matches
          cold-spawn's ``start_new_session=True``; CRITICAL — without
          this the child shares the API/executor pod's own process
          group and ``core.duckdb_subprocess._kill_subprocess_tree``'s
          ``os.killpg`` would nuke the POD, not just the query).
       b. Redirects stdout/stderr to a pipe pair the parent reads (so
          the parent-side contract — crash decode from captured stderr,
          etc. — is byte-identical to cold-spawn).
       c. Applies per-query env overrides (``DUCKDB_MEMORY_LIMIT`` /
          ``DUCKDB_THREADS`` / sidecar path / …) via ``os.environ[...]
          = ...`` — safe: after ``fork()``, the child's environ is a
          private copy; mutating it can never leak back to the
          template or any sibling.
       d. Calls :func:`core.duckdb_subprocess._child_main` **directly,
          without exec** — the whole point: keeping the dlopen'd
          extension mapped via fork's copy-on-write.  ``_child_main``
          opens its OWN brand-new ``duckdb.connect(':memory:')`` (zero
          inherited rows / temp views / prior results — the anti-
          state-bleed guarantee) and re-applies the SAME static config
          a cold-spawned child would (memory_limit / threads /
          temp_directory / extension_directory) — this is the SAME
          function the legacy path calls, so a forked child is
          **byte-identical** in behaviour to a cold-spawned one.
       e. ``os._exit()`` — a true one-shot process, discarded after
          exactly one query.  There is no "return to pool": the next
          query forks a FRESH child from the template again.  This is
          the crash-isolation invariant carried over unchanged from
          today: a crashed/misbehaving child can never contaminate a
          future query.

  3. The template itself is recycled (stopped + rebooted) after
     ``forkserver_max_forks`` children OR ``forkserver_max_age_s``,
     whichever comes first — guards against extension-registry /
     allocator drift accumulating in a long-lived template (the
     "poisoned template" edge case in the plan).

── Fail-safe contract ───────────────────────────────────────────────────

:func:`try_spawn_via_forkserver` returns ``None`` (never raises) on:
  * non-POSIX platform (Windows / any platform without ``os.fork``),
  * the flag being off,
  * template boot failure (health-checked; alarms after N consecutive
    failures, logged once per threshold — never a per-query log storm),
  * ANY exception during setup (pipe creation, fork itself).

Callers (:func:`core.duckdb_subprocess.run_duckdb_copy_to`) MUST fall
back to the existing cold ``subprocess.Popen`` path whenever this
returns ``None`` — this module is a fast path, never a hard dependency.

Testing note: this module cannot be exercised end-to-end on a non-POSIX
dev box (no real ``os.fork``).  Tests mock ``os.name`` / ``os.fork`` /
the template boot to verify the DECISION and FALLBACK logic; the real
fork/setsid/pipe path needs a POSIX (Linux/OpenShift) CI lane before
the flag is flipped anywhere.

── KNOWN RESIDUAL RISK: forking a multi-threaded process ───────────────

``os.fork()`` is called directly from THIS pod's own (multi-threaded —
FastAPI/uvicorn workers, heartbeat threads, DB pool threads, …) process,
not from a dedicated single-threaded template subprocess the way
CPython's own ``multiprocessing.set_start_method('forkserver')`` does
it.  The well-known hazard: only the calling thread survives into the
child; if some OTHER thread held a C-level or Python-level lock (e.g.
the stdlib ``logging`` module's internal lock) at the exact instant of
``fork()``, that lock is held forever in the child and the FIRST call
that needs it (e.g. the child's own ``logger.info(...)`` inside
``_child_main``) hangs.

This is a genuine risk this module does NOT eliminate.  It is,
however, BOUNDED, not catastrophic: a hung forked child touches only
its own copy-on-write memory and its own freshly-opened files — it can
never corrupt another query's data or crash the pod.  The existing
timeout + ``_kill_subprocess_tree`` machinery in
``core.duckdb_subprocess.run_duckdb_copy_to`` (unchanged by this
module — ``ForkedChildHandle`` is a drop-in ``Popen`` shim, so that
machinery runs exactly as it does today) reaps a wedged child after the
query's normal timeout and surfaces a diagnosable timeout error, same
as any other stuck subprocess.  Net effect of a fork-time lock
collision: one query times out and fails; nothing else is affected.
A future hardening (out of scope here) would move the fork call into a
dedicated, early-forked, single-threaded template process reached via
a control socket — the same shape CPython's own forkserver start
method uses — eliminating this class of hang entirely.  Recommended
operational rule until then: validate under real concurrent load on a
POSIX staging pod before arming ``industrialization.forkserver`` in
production.

── L2-S2 fd hygiene on fork (2026-07-26) ────────────────────────────────

``fork()`` duplicates EVERY open fd of the parent into the child: PG
pool sockets, S3/http sockets, uvicorn listen/accept sockets, open
parquet/db files, log-file fds, epoll fds.  Left open in the child
that is (a) an fd/socket LEAK for the child's lifetime, (b) a
CONTAMINATION surface (two processes interleaving reads/writes on one
socket corrupts the protocol stream for BOTH sides), and (c) a
SECURITY surface (a worker holding another tenant's live PG/S3
connection socket).  The child-side fix, applied in
:func:`_run_forked_child` immediately post-fork and BEFORE any query
work:

  1. **PDEATHSIG** — ``prctl(PR_SET_PDEATHSIG, SIGKILL)`` via ctypes
     (Linux only, best-effort) so an orphaned worker dies with its
     parent — no zombie holding swept-survivor fds if the server
     process is killed.  A ``getppid() != parent_pid`` re-check closes
     the fork→prctl race window (parent died in between ⇒ exit now).
  2. **Keep-set sweep** — compute the SMALL set of fds the child must
     retain: stdio ``{0,1,2}`` (1/2 already ``dup2``'d onto the pipe
     write-ends — the child's only channel back to the parent) plus
     any explicit ``extra_keep_fds``.  Then close every OTHER open fd:
     primary enumeration via ``/proc/self/fd`` (exact — closes only
     fds that actually exist, no matter how high-numbered); fallback
     to a ``RLIMIT_NOFILE``/``SC_OPEN_MAX``-bounded ``os.closerange``
     between keep-fd gaps (capped — never a blind
     ``closerange(0, 1<<20)``).  ``EBADF`` ignored; idempotent.
  3. **Connection-pool isolation** — the sweep closes inherited
     pooled sockets at the OS level, so any code path that tried to
     reuse an inherited pooled connection FAILS CLOSED (``EBADF`` /
     broken pipe) instead of silently talking on a shared socket.  On
     top of that, :func:`_isolate_inherited_pools` best-effort calls
     ``engine.dispose(close=False)`` (the documented SQLAlchemy
     post-fork idiom — drops pool references WITHOUT touching the
     shared sockets) on already-imported engine singletons, so a
     checkout in the child creates a FRESH connection rather than
     erroring.  ``_child_main`` itself opens its own brand-new DuckDB
     connection — unchanged.
  4. **Log-handler detach** — inherited file-based log handlers now
     point at swept (closed) fds; they are detached in the child so
     the child can never interleave bytes into the parent's log files
     and never spams EBADF tracebacks.  stdio-backed handlers (which
     now write to the query's own stderr pipe) are kept.

Parent-side: the pipe fds are explicitly marked
``os.set_inheritable(False)`` (PEP 446 already defaults them so; the
explicit call is exec-hygiene so no OTHER ``Popen``/``exec`` spawned
elsewhere in the pod can ever inherit them).  Note ``fork()`` itself
ignores the inheritable flag — which is exactly why the child-side
keep-set sweep is the operative mechanism here, not ``CLOEXEC``.

Flag OFF ⇒ :func:`try_spawn_via_forkserver` returns ``None`` at the
``is_enabled()`` gate before ANY of this code runs — byte-for-byte
parity with the pre-existing cold-spawn path.
"""
from __future__ import annotations

import logging
import os
from core.fd_wait import wait_readable
import subprocess
import sys
import threading
import time
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_SECTION = "industrialization_duckdb"


def _cfg_int(key: str, default: int) -> int:
    try:
        from core.config import get as _cfg_get
        return int(_cfg_get(_SECTION, key, default) or default)
    except Exception:
        return default


def _cfg_list(key: str, default: List[str]) -> List[str]:
    try:
        from core.config import get as _cfg_get
        val = _cfg_get(_SECTION, key, default)
        if isinstance(val, list) and val:
            return [str(v) for v in val]
    except Exception:
        pass
    return list(default)


def posix_fork_available() -> bool:
    """Platform gate — POSIX with a real ``os.fork``.  Windows (and any
    platform lacking ``fork``) always returns False; this is a pure,
    side-effect-free check safe to call on every query."""
    return os.name == "posix" and hasattr(os, "fork") and hasattr(os, "setsid")


def is_enabled() -> bool:
    """flag AND platform both agree.  Never raises."""
    try:
        from core.industrialization.flags import is_enabled as _flag_enabled
        return bool(_flag_enabled("forkserver")) and posix_fork_available()
    except Exception as exc:
        logger.debug("[forkserver] is_enabled check failed (fail-open=False): %s", exc)
        return False


# ═══════════════════════════════════════════════════════════════════════════
# Template lifecycle
# ═══════════════════════════════════════════════════════════════════════════


class ForkServerTemplate:
    """A single booted, stateless template process (in-process object —
    the "process" here is THIS pod's own process; the template does not
    spawn a separate OS process of its own.  ``os.fork()`` duplicates
    the CURRENT process, so "the template" is really just "this
    process, at the moment its DuckDB extensions were warmed" — there
    is no separate template PID to manage, which is precisely why this
    design needs no IPC protocol the way :mod:`core.duckdb_worker_pool`
    does.)
    """

    def __init__(self) -> None:
        self.booted: bool = False
        self.healthy: bool = False
        self.booted_at: float = 0.0
        self.fork_count: int = 0
        self.boot_failures: int = 0
        self.extensions: List[str] = []
        self._lock = threading.Lock()

    def boot(self) -> bool:
        """Warm the extension dlopen.  Idempotent-ish: safe to call
        again after a recycle.  Returns True on success."""
        with self._lock:
            try:
                import duckdb
                con = duckdb.connect(database=":memory:")
                try:
                    from core.file_formats import ensure_extension_directory
                    ensure_extension_directory(con)
                    try:
                        con.execute("SET autoinstall_known_extensions=false;")
                    except Exception:
                        pass
                    autoinstall = (os.environ.get("QS_AUTOINSTALL_EXTENSIONS", "")
                                   .strip().lower() not in ("false", "0", "no", "off"))
                    exts = _cfg_list("forkserver_extensions", ["httpfs"])
                    loaded: List[str] = []
                    for ext in exts:
                        ext = str(ext).strip()
                        if not ext:
                            continue
                        try:
                            if autoinstall:
                                con.execute(f"INSTALL {ext};")
                            con.execute(f"LOAD {ext};")
                            loaded.append(ext)
                        except Exception as ext_exc:
                            logger.warning(
                                "[forkserver] template failed to LOAD "
                                "extension %r (non-fatal, that extension "
                                "just won't be pre-warmed): %s",
                                ext, ext_exc,
                            )
                    self.extensions = loaded
                finally:
                    try:
                        con.close()
                    except Exception:
                        pass
                self.booted = True
                self.healthy = True
                self.booted_at = time.monotonic()
                self.fork_count = 0
                self.boot_failures = 0
                logger.info(
                    "[forkserver] template booted — extensions=%s",
                    self.extensions,
                )
                return True
            except Exception as exc:
                self.booted = False
                self.healthy = False
                self.boot_failures += 1
                alarm_at = max(1, _cfg_int("forkserver_restart_alarm_threshold", 3))
                log_fn = logger.error if self.boot_failures >= alarm_at else logger.warning
                log_fn(
                    "[forkserver] template boot FAILED (attempt #%d, "
                    "extension_directory unavailable or duckdb import "
                    "error) — cold-spawn fallback stays in effect: %s",
                    self.boot_failures, exc,
                )
                return False

    def should_recycle(self) -> bool:
        if not self.booted or not self.healthy:
            return True
        max_forks = _cfg_int("forkserver_max_forks", 200)
        max_age = _cfg_int("forkserver_max_age_s", 1800)
        if max_forks > 0 and self.fork_count >= max_forks:
            return True
        if max_age > 0 and (time.monotonic() - self.booted_at) >= max_age:
            return True
        return False

    def mark_unhealthy(self, reason: str = "") -> None:
        self.healthy = False
        logger.warning("[forkserver] template marked unhealthy%s",
                        f" ({reason})" if reason else "")


_template: Optional[ForkServerTemplate] = None
_template_lock = threading.Lock()


def get_template() -> Optional[ForkServerTemplate]:
    """Lazily boot (or recycle) the process-wide template.  Returns
    ``None`` when boot failed — caller falls back to cold spawn."""
    global _template
    with _template_lock:
        if _template is None:
            _template = ForkServerTemplate()
        if _template.should_recycle():
            _template.boot()
        return _template if _template.healthy else None


def reset_template_for_tests() -> None:
    global _template
    with _template_lock:
        _template = None


# ═══════════════════════════════════════════════════════════════════════════
# Popen-shim over a forked one-shot child
# ═══════════════════════════════════════════════════════════════════════════


class ForkedChildHandle:
    """Exposes the subset of :class:`subprocess.Popen`'s interface that
    :func:`core.duckdb_subprocess.run_duckdb_copy_to` uses (``pid``,
    ``returncode``, ``poll()``, ``communicate(timeout=)``,
    ``send_signal()``), backed by a real forked PID + a pipe pair —
    so the caller's existing poll-loop / heartbeat / cancel / timeout /
    crash-decode logic runs UNCHANGED regardless of which spawn path
    produced the process handle.
    """

    def __init__(self, pid: int, out_r: int, err_r: int) -> None:
        self.pid = pid
        self.returncode: Optional[int] = None
        self._out_r = out_r
        self._err_r = err_r
        self._out_buf = bytearray()
        self._err_buf = bytearray()
        self._out_closed = False
        self._err_closed = False
        self._fds_closed = False

    def _set_returncode(self, status: int) -> None:
        if os.WIFEXITED(status):
            self.returncode = os.WEXITSTATUS(status)
        elif os.WIFSIGNALED(status):
            self.returncode = -os.WTERMSIG(status)
        else:  # pragma: no cover - stopped/continued, shouldn't happen for waitpid(0)
            self.returncode = -1

    def poll(self) -> Optional[int]:
        if self.returncode is not None:
            return self.returncode
        try:
            wpid, status = os.waitpid(self.pid, os.WNOHANG)
        except ChildProcessError:
            return self.returncode
        if wpid == 0:
            return None
        self._set_returncode(status)
        return self.returncode

    def communicate(self, timeout: Optional[float] = None):
        """Mirrors ``Popen.communicate(timeout=)`` — safe to call
        repeatedly after catching ``subprocess.TimeoutExpired`` (state
        persists on ``self``), exactly like the real Popen contract
        ``run_duckdb_copy_to`` already relies on."""
        deadline = None if timeout is None else time.monotonic() + timeout
        while not (self._out_closed and self._err_closed):
            remaining = 1.0
            if deadline is not None:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(
                        cmd="<forkserver-child>", timeout=timeout)
            rlist = [fd for fd, closed in (
                (self._out_r, self._out_closed),
                (self._err_r, self._err_closed),
            ) if not closed]
            if not rlist:
                break
            ready = wait_readable(rlist, max(0.0, remaining))
            for fd in ready:
                try:
                    chunk = os.read(fd, 65536)
                except OSError:
                    chunk = b""
                if fd == self._out_r:
                    if chunk:
                        self._out_buf += chunk
                    else:
                        self._out_closed = True
                else:
                    if chunk:
                        self._err_buf += chunk
                    else:
                        self._err_closed = True
        # Both pipes hit EOF (the child closed them, on exit) — reap.
        while self.returncode is None:
            try:
                _wpid, status = os.waitpid(self.pid, 0)
                self._set_returncode(status)
            except ChildProcessError:
                self.returncode = -1
        self._close_fds()
        return bytes(self._out_buf), bytes(self._err_buf)

    def _close_fds(self) -> None:
        if self._fds_closed:
            return
        self._fds_closed = True
        for fd in (self._out_r, self._err_r):
            try:
                os.close(fd)
            except OSError:
                pass

    def send_signal(self, sig: int) -> None:
        try:
            os.kill(self.pid, sig)
        except ProcessLookupError:
            pass

    def kill(self) -> None:
        import signal
        self.send_signal(signal.SIGKILL)


# ═══════════════════════════════════════════════════════════════════════════
# L2-S2 — child-side fd hygiene (keep-set sweep + PDEATHSIG + pool isolation)
# ═══════════════════════════════════════════════════════════════════════════

#: stdio fds every child keeps.  fd 1/2 are the dup2'd pipe write-ends —
#: the child's ONLY channel back to the parent — and must NEVER be swept.
_STDIO_FDS = (0, 1, 2)

#: Hard ceiling for the range-fallback sweep — never loop past this even
#: if RLIMIT_NOFILE claims a million fds (containers commonly do).  The
#: /proc/self/fd path (exact, unbounded) is the primary on Linux; this
#: cap only bounds the blind-range FALLBACK.
_SWEEP_FD_CAP = 65536

#: Conservative default when neither /proc, RLIMIT_NOFILE nor
#: SC_OPEN_MAX are usable.
_SWEEP_FD_DEFAULT = 4096

_PR_SET_PDEATHSIG = 1  # linux/prctl.h


def _list_open_fds() -> Optional[List[int]]:
    """Exact enumeration of THIS process's open fds via /proc/self/fd
    (Linux) or /dev/fd (BSD/macOS).  Returns ``None`` when neither is
    available — caller falls back to the bounded range sweep.  The
    directory-listing fd itself may appear in the result; it is closed
    by the time the caller acts, so closing it again is a harmless
    (ignored) EBADF."""
    for fd_dir in ("/proc/self/fd", "/dev/fd"):
        try:
            return [int(name) for name in os.listdir(fd_dir)]
        except Exception:
            continue
    return None


def _max_fd_bound() -> int:
    """Smart upper bound for the range-fallback sweep: the first FINITE
    positive limit among RLIMIT_NOFILE(soft), RLIMIT_NOFILE(hard),
    SC_OPEN_MAX — capped at :data:`_SWEEP_FD_CAP`; else
    :data:`_SWEEP_FD_DEFAULT`.  Never raises."""
    candidates: List[int] = []
    try:
        import resource
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        infinity = getattr(resource, "RLIM_INFINITY", -1)
        for lim in (soft, hard):
            if isinstance(lim, int) and lim != infinity and lim > 0:
                candidates.append(lim)
    except Exception:
        pass
    try:
        sc = os.sysconf("SC_OPEN_MAX")
        if isinstance(sc, int) and sc > 0:
            candidates.append(sc)
    except Exception:
        pass
    if candidates:
        return min(candidates[0], _SWEEP_FD_CAP)
    return _SWEEP_FD_DEFAULT


def _sweep_inherited_fds(keep_fds) -> int:
    """Close every open fd NOT in ``keep_fds``.  Robust (EBADF and any
    other per-fd OSError ignored) and idempotent (a second sweep is a
    no-op).  Returns the number of close attempts made (best-effort
    telemetry; 0 on total failure — the sweep itself NEVER raises).

    Primary: exact /proc-based enumeration — handles arbitrarily high
    fd numbers with zero wasted syscalls.  Fallback: ``os.closerange``
    over the gaps between sorted keep-fds, bounded by
    :func:`_max_fd_bound` — bounded, never a blind closerange to 2**20.
    """
    try:
        keep = {int(fd) for fd in keep_fds
                if isinstance(fd, int) and int(fd) >= 0}
        listed = _list_open_fds()
        closed = 0
        if listed is not None:
            for fd in listed:
                if fd in keep:
                    continue
                try:
                    os.close(fd)
                    closed += 1
                except OSError:
                    pass  # EBADF (already closed / listing artifact) — fine
            return closed
        # Range fallback: closerange over gaps between keep fds.
        bound = _max_fd_bound()
        prev = -1
        for kfd in sorted(keep | {bound}):
            lo, hi = prev + 1, min(kfd, bound)
            if lo < hi:
                try:
                    os.closerange(lo, hi)  # ignores EBADF internally
                    closed += hi - lo
                except Exception:
                    pass
            prev = kfd
        return closed
    except Exception:
        return 0  # sweep must never kill the child


def _set_pdeathsig(sig: Optional[int] = None) -> bool:
    """``prctl(PR_SET_PDEATHSIG, sig)`` via ctypes — Linux only.  The
    kernel delivers ``sig`` (default SIGKILL) to this process the
    moment its parent THREAD dies, so an orphaned worker can never
    outlive the server as a zombie holding fds.  Returns True on
    success, False on any other platform or failure — best-effort,
    never raises."""
    if not sys.platform.startswith("linux"):
        return False
    try:
        import ctypes
        import signal as _signal
        if sig is None:
            sig = _signal.SIGKILL
        libc = ctypes.CDLL(None, use_errno=True)
        return libc.prctl(_PR_SET_PDEATHSIG, int(sig), 0, 0, 0) == 0
    except Exception:
        return False


def _dispose_engine_pool_no_close(obj) -> bool:
    """If ``obj`` is a SQLAlchemy Engine, drop its pool WITHOUT closing
    the underlying (parent-shared, already-swept) sockets:
    ``dispose(close=False)`` — the documented post-fork idiom.  Older
    SQLAlchemy without the kwarg is SKIPPED (plain ``dispose()`` would
    try to close sockets the parent still owns; the fd sweep has
    already fail-closed them at the OS level anyway)."""
    try:
        if not type(obj).__module__.startswith("sqlalchemy"):
            return False
        dispose = getattr(obj, "dispose", None)
        if not callable(dispose):
            return False
        try:
            dispose(close=False)
            return True
        except TypeError:
            return False  # pre-1.4.33 signature — rely on the fd sweep
    except Exception:
        return False


def _isolate_inherited_pools() -> None:
    """Belt-and-suspenders pool isolation for the forked child.  The
    HARD guarantee is the fd sweep (inherited pooled sockets are closed
    ⇒ any reuse attempt fails closed).  This pass additionally empties
    already-imported engine pools via ``dispose(close=False)`` so a
    checkout in the child transparently opens a FRESH connection.
    Inspects ``sys.modules`` only — never triggers a new import."""
    try:
        for mod_name in ("core.database", "core.scheduler"):
            mod = sys.modules.get(mod_name)
            if mod is None:
                continue  # never imported in this process — nothing inherited
            try:
                for val in list(vars(mod).values()):
                    try:
                        if _dispose_engine_pool_no_close(val):
                            continue
                        # Holder objects (e.g. DatabaseManager.engine)
                        eng = getattr(val, "engine", None)
                        if eng is not None and eng is not val:
                            _dispose_engine_pool_no_close(eng)
                    except Exception:
                        pass
            except Exception:
                pass
    except Exception:
        pass  # isolation is best-effort; the sweep is the guarantee


def _detach_nonstdio_log_handlers() -> None:
    """The sweep just closed any inherited log-FILE fds; detach the
    handlers that pointed at them so the child (a) can never interleave
    bytes into the parent's log files and (b) doesn't spam EBADF
    tracebacks on every log call.  Handlers backed by stdio (which now
    write to this query's own stderr/stdout pipes) are kept — the
    parent's crash-decode contract reads exactly those."""
    try:
        stdio_streams = {sys.stdout, sys.stderr,
                         sys.__stdout__, sys.__stderr__}
        all_loggers: List[logging.Logger] = [logging.getLogger()]
        try:
            all_loggers += [lg for lg in
                            logging.Logger.manager.loggerDict.values()
                            if isinstance(lg, logging.Logger)]
        except Exception:
            pass
        for lg in all_loggers:
            for handler in list(getattr(lg, "handlers", ()) or ()):
                try:
                    if getattr(handler, "stream", None) in stdio_streams:
                        continue
                    lg.removeHandler(handler)
                except Exception:
                    pass
        logging.raiseExceptions = False
    except Exception:
        pass


def _run_forked_child(
    args_path: str,
    result_path: str,
    env_overrides: Dict[str, str],
    out_w: int,
    err_w: int,
    fds_to_close: List[int],
    parent_pid: int = -1,
    extra_keep_fds: Optional[List[int]] = None,
) -> None:
    """Runs INSIDE the forked child.  MUST NEVER return normally —
    every exit from this function is via ``os._exit()``.  A bare
    ``return`` here would leave a SECOND copy of the parent's whole
    Python call stack alive and executing, which is the classic
    fork-without-exec bug this function exists to avoid."""
    try:
        # ── L2-S2 step 1: die-with-parent, BEFORE anything else ──────
        # PDEATHSIG first so even a child that wedges mid-sweep is
        # reaped by the kernel if the server dies.  Then close the
        # fork→prctl race: if the parent already died in that window,
        # PDEATHSIG never fires — detect via getppid and exit now.
        _set_pdeathsig()
        if parent_pid > 0 and os.getppid() != parent_pid:
            os._exit(3)  # orphaned before we could arm PDEATHSIG
        os.setsid()
        # Explicit close of the fds the parent told us about (the pipe
        # READ ends) — the sweep below would catch them too; keeping
        # the explicit pass preserves the documented contract and
        # covers the range-fallback path exactly.
        for fd in fds_to_close:
            if fd not in _STDIO_FDS:
                try:
                    os.close(fd)
                except OSError:
                    pass
        # Wire this child's ONLY channels back to the parent onto 1/2
        # BEFORE the sweep, so the keep-set is just stdio.
        os.dup2(out_w, 1)
        os.dup2(err_w, 2)
        if out_w not in _STDIO_FDS:
            try:
                os.close(out_w)
            except OSError:
                pass
        if err_w not in _STDIO_FDS:
            try:
                os.close(err_w)
            except OSError:
                pass
        # ── L2-S2 step 2: keep-set sweep of EVERY other inherited fd ─
        # (PG pool sockets, S3/http sockets, uvicorn sockets, open
        # parquet/db files, log fds, epoll fds, …).  After this line
        # the child holds stdio + extra_keep_fds and NOTHING else.
        keep = set(_STDIO_FDS) | {int(fd) for fd in (extra_keep_fds or [])
                                  if isinstance(fd, int) and int(fd) >= 0}
        _sweep_inherited_fds(keep)
        # ── L2-S2 steps 3+4: pool + log-handler isolation ────────────
        # Inherited pooled sockets are now CLOSED (any reuse fails
        # closed with EBADF); make already-imported engine pools forget
        # them entirely so a checkout opens a FRESH connection instead.
        _isolate_inherited_pools()
        _detach_nonstdio_log_handlers()
        for k, v in (env_overrides or {}).items():
            os.environ[str(k)] = str(v)
        from core.duckdb_subprocess import _child_main
        try:
            _child_main(args_path, result_path)
            os._exit(0)
        except SystemExit as se:
            code = se.code
            os._exit(int(code) if isinstance(code, int) else (0 if code is None else 1))
    except BaseException:
        try:
            import traceback
            traceback.print_exc()
        except Exception:
            pass
        os._exit(3)
    os._exit(70)  # pragma: no cover - unreachable belt-and-suspenders


def try_spawn_via_forkserver(
    args_path: str,
    result_path: str,
    *,
    env_overrides: Optional[Dict[str, str]] = None,
) -> Optional[ForkedChildHandle]:
    """Attempt to run this query via a forked one-shot child of the
    template.  Returns ``None`` (never raises) on any unavailability or
    error — caller falls back to cold ``subprocess.Popen``.
    """
    if not is_enabled():
        return None
    template = get_template()
    if template is None:
        return None
    out_r = out_w = err_r = err_w = -1
    try:
        out_r, out_w = os.pipe()
        err_r, err_w = os.pipe()
        # PEP 446 already makes pipe fds non-inheritable; make it
        # EXPLICIT (exec-hygiene: no other Popen/exec elsewhere in the
        # pod can ever inherit these).  fork() ignores this flag — the
        # child-side keep-set sweep is the operative fork mechanism.
        for _fd in (out_r, out_w, err_r, err_w):
            try:
                os.set_inheritable(_fd, False)
            except OSError:
                pass
    except OSError as exc:
        logger.warning("[forkserver] pipe() failed — cold-spawn fallback: %s", exc)
        for fd in (out_r, out_w, err_r, err_w):
            if fd >= 0:
                try:
                    os.close(fd)
                except OSError:
                    pass
        return None

    parent_pid = os.getpid()  # captured PRE-fork for the child's
    #                           PDEATHSIG orphan-race re-check
    try:
        pid = os.fork()
    except OSError as exc:
        logger.warning("[forkserver] fork() failed — cold-spawn fallback: %s", exc)
        for fd in (out_r, out_w, err_r, err_w):
            try:
                os.close(fd)
            except OSError:
                pass
        return None

    if pid == 0:
        # ── CHILD ── never returns; always os._exit()s.
        _run_forked_child(
            args_path, result_path, env_overrides or {},
            out_w, err_w, fds_to_close=[out_r, err_r],
            parent_pid=parent_pid,
        )
        os._exit(70)  # pragma: no cover - unreachable, _run_forked_child always exits

    # ── PARENT ──
    for fd in (out_w, err_w):
        try:
            os.close(fd)
        except OSError:
            pass
    template.fork_count += 1
    logger.info(
        "[forkserver] forked child pid=%d (template fork_count=%d/%d)",
        pid, template.fork_count, _cfg_int("forkserver_max_forks", 200),
    )
    return ForkedChildHandle(pid, out_r, err_r)
