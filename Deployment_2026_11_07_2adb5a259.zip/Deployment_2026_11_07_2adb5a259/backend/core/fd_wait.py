"""Wait until a file descriptor can be read, at ANY descriptor number.

``select.select`` refuses a descriptor of 1024 or more (ValueError).  A busy pod can hold that many
open: found on the CI copy on 2026-11-07, where a long-lived test process with many files open failed
the same way a running query's child would.
"""
from __future__ import annotations

import selectors
from typing import Any, List, Sequence


def wait_readable(items: Sequence[Any], timeout: float) -> List[Any]:
    """Those of ``items`` (descriptor numbers, or objects with ``fileno()``) ready to read within
    ``timeout`` seconds; empty on a timeout.  Raises as ``select.select`` does for a closed one."""
    with selectors.DefaultSelector() as sel:
        for item in items:
            sel.register(item, selectors.EVENT_READ)
        return [key.fileobj for key, _events in sel.select(timeout)]
