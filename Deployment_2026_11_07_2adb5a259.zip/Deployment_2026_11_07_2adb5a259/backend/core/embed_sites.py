"""Which websites may show an embed or share link inside their own page.

The owner, 2026-11-05: a new site must not need a deployment.  The list lives in the database and an admin edits it on
Admin -> Embedding sites.  Every UI pod reads it through ``GET /api/embed-sites`` and sends it as the browser's
``frame-ancestors`` (``frontend/spa-server.cjs``).  Nothing saved here = the chart's ``config.frameAncestors`` still
applies, so a deployment that set that list keeps it until an admin saves one here.

An empty saved list means ANY site, the same as an empty chart list.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List

KEY = "embedding.allowed_sites"
#: what fits a response header on every proxy in front of the UI
MAX_SITES = 100
_ORIGIN = re.compile(r"^https?://(\*\.)?[a-z0-9]([a-z0-9.-]*[a-z0-9])?(:\d{1,5})?$")


def normalize(site: Any) -> str:
    """One site as the browser compares it, or a sentence saying what to type.  This text goes into a response
    header, so nothing outside the pattern may pass: a ``;`` or a space would add to the policy."""
    text = str(site if site is not None else "").strip().lower().rstrip("/")
    if not _ORIGIN.match(text):
        raise ValueError(f"'{str(site)[:80]}' is not a site address. Type it like https://portal.example.com "
                         "(https:// and the host name, no page after it).")
    return text


def clean(sites: Iterable[Any]) -> List[str]:
    """The list to store: each site checked, repeats dropped, order kept."""
    out: List[str] = []
    for site in sites:
        one = normalize(site)
        if one not in out:
            out.append(one)
    if len(out) > MAX_SITES:
        raise ValueError(f"That is {len(out)} sites; the most this list can hold is {MAX_SITES}.")
    return out


def read(db) -> Dict[str, Any]:
    """``configured`` False = nothing saved here, so the chart's list applies.  A failed read raises: an unknown list
    must not read as "no list", which would mean any site."""
    stored = db.get_system_setting(KEY, default=None)
    if stored is None:
        return {"configured": False, "sites": []}
    return {"configured": True, "sites": list(stored)}


def save(db, sites: Iterable[Any], by: str) -> Dict[str, Any]:
    cleaned = clean(sites)
    db.set_system_setting(KEY, cleaned, updated_by=by, description="Sites that may show embed and share links")
    return {"configured": True, "sites": cleaned}
