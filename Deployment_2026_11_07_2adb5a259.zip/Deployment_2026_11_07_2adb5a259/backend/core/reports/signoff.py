"""Commentary + sign-off on a report INSTANCE (2026-09-28).

A finance controller at close signs a RUN, not a report.  ``report_instances``
already carries the identity a sign-off needs -- execution id, params
fingerprint, row-security signature, semantic version, source version and
the parquet artifact -- so this module adds no second identity: it binds a
sign-off row and a comment thread to that instance and states, in one
place, three rules the routes and the DB layer both defer to.

THE THREE RULES
---------------
1. **Visibility follows the instance's row-security signature.**  A
   sign-off or a comment is stamped with the INSTANCE's ``rls_signature``
   (the scope the artifact was computed at), never the signer's.  A
   principal sees it iff their LIVE signature for the report equals it
   (:func:`scope_visible`).  Justification: the theorem instance serving
   already rests on -- identical rendered predicates <=> identical result
   bytes -- so equal signatures mean "the same rows"; a note about a row
   is shown exactly to those who see that row.  A different scope is
   simply a different instance, so an APAC viewer's header cannot show an
   EMEA sign-off: their instance has none.  Admin-tier and support
   principals see every scope, LABELLED (``scope_label``), because they
   already see every report; nobody else is widened, including the report
   OWNER when their own scope differs.

2. **Who may act.**  ``can_sign``: admin-tier, the report owner / owner
   group, or the holder of an ACTIVE explicit grant at any level
   (``business_report_grants``) -- the owner decides who signs by granting.
   ``can_comment``: anyone who can view the report AND is an admin or
   analyst, or holds an explicit grant, or owns it -- so a ``viewer``-role
   principal comments only when granted.  Both reuse the permission
   chokepoints (``core/reports/authorization.py``,
   ``core/business_report_permissions.py``); nothing here re-derives a
   grant.  Support observes; it neither signs nor comments.

3. **A sign-off LOCKS the instance** (``core/db/mixin_datasets.py``): the
   row is outside retention (not counted, not aged), cannot be expired or
   deleted, and the cleaner exempts its artifact with no bound
   (``DatabaseManager.get_live_artifact_refs``).  Revoking is a status
   change carrying who/when/why; the row is never deleted.  A later run
   with the same serve key records a NEW instance and is served as
   itself, with ``signoff.signed_version`` naming the signed one -- the
   signed bytes are never re-served under another run's identity.

ROLES
-----
``preparer`` / ``reviewer`` / ``approver`` -- the four-eyes vocabulary the
finance floor already uses.  One ACTIVE sign-off per (instance, role), and
one role per person per instance (a preparer does not also approve the
same run).  The roles are not sequenced: an approver may sign without a
preparer -- a workflow is a declaration this record does not make yet.
An instance is "signed" when it holds >= 1 active sign-off; the header
lists every role held.

Every action is audited through ``core/audit.py`` with the instance's
identity in ``details``.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

SIGNOFF_ROLES = ("preparer", "reviewer", "approver")

_AUDIT_SIGNED = "report_instance_signed"
_AUDIT_REVOKED = "report_instance_signoff_revoked"
_AUDIT_COMMENTED = "report_instance_commented"
_AUDIT_COMMENT_DELETED = "report_instance_comment_deleted"
_AUDIT_COMMENT_CHANGED = "report_instance_comment_changed"


class SignoffRefused(ValueError):
    """A refusal that carries the HTTP status the route should answer with.

    A ``ValueError`` so this module stays free of web types; the route maps
    ``status`` + ``str(exc)``.
    """

    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = int(status)


# ── scope ────────────────────────────────────────────────────────────────────

def sees_all_scopes(user: Optional[dict]) -> bool:
    """Admin-tier or support: every scope, labelled.  Fail-closed."""
    from core.reports.authorization import _resolve_sees_all
    return _resolve_sees_all(user)


def caller_scope(db, report: Dict[str, Any], user: Optional[dict]) -> Optional[str]:
    """The caller's LIVE row-security signature for this report, or ``None``
    when it cannot be signed (an unsignable scope matches nothing)."""
    from core.reports.instances import compute_caller_signature
    from core.row_security.signature import ScopeSignatureError
    try:
        return compute_caller_signature(db, report, user)
    except ScopeSignatureError as exc:
        logger.info("[signoff] caller scope unsignable for %s on report %s: %s",
                    (user or {}).get("username"), report.get("id"), exc)
        return None
    except Exception as exc:
        logger.warning("[signoff] caller scope failed for %s on report %s: %s",
                       (user or {}).get("username"), report.get("id"), exc)
        return None


def scope_visible(row_signature: Optional[str], caller_signature: Optional[str],
                  sees_all: bool) -> bool:
    """Rule 1.  A blank row signature is never visible (it could only have
    come from a broken write, and a blank must not wildcard)."""
    if sees_all:
        return True
    if not row_signature or not caller_signature:
        return False
    return str(row_signature) == str(caller_signature)


def scope_label(signature: Optional[str]) -> str:
    """A short human label for a scope: ``open`` for the unrestricted scope,
    else the first 10 characters of the signature.  Never the whole hash --
    a label is for telling two scopes apart, not for re-deriving one."""
    if not signature:
        return "unknown"
    try:
        from core.row_security.signature import SCOPE_OPEN
        if signature == SCOPE_OPEN:
            return "open"
    except Exception:  # pragma: no cover - import guard
        pass
    return str(signature)[:10]


# ── permissions ──────────────────────────────────────────────────────────────

def can_sign(report: Dict[str, Any], user: Optional[dict], db) -> bool:
    """Rule 2 -- admin-tier, owner / owner group, or an explicit grant."""
    if not user or not (user.get("username") or "").strip():
        return False
    try:
        from core import business_report_permissions as _perm
        if _perm._is_admin(user):
            return True
        if _perm._is_owner_or_owner_group(report, user, db):
            return True
        return bool(_perm._highest_grant_level(int(report.get("id") or 0), user, db))
    except Exception as exc:
        logger.debug("[signoff] can_sign fail-closed: %s", exc)
        return False


def can_comment(report: Dict[str, Any], user: Optional[dict], db) -> bool:
    """Rule 2 -- view access AND (admin/analyst role, owner, or a grant)."""
    if not user or not (user.get("username") or "").strip():
        return False
    try:
        from core.reports.authorization import can_view_business_report
        if not can_view_business_report(report, user, db):
            return False
        role = str(user.get("role") or "").lower()
        if role in ("admin", "super_admin", "analyst"):
            return True
        return can_sign(report, user, db)
    except Exception as exc:
        logger.debug("[signoff] can_comment fail-closed: %s", exc)
        return False


def can_revoke(signoff: Dict[str, Any], report: Dict[str, Any],
               user: Optional[dict], db) -> bool:
    """The signer, the report owner / owner group, or admin-tier."""
    if not user:
        return False
    username = str(user.get("username") or "")
    if username and username == str(signoff.get("signed_by") or ""):
        return True
    try:
        from core import business_report_permissions as _perm
        return bool(_perm._is_admin(user)
                    or _perm._is_owner_or_owner_group(report, user, db))
    except Exception as exc:
        logger.debug("[signoff] can_revoke fail-closed: %s", exc)
        return False


# ── instance resolution ──────────────────────────────────────────────────────

def resolve_instance(db, report: Dict[str, Any], user: Optional[dict],
                     instance_id: int) -> Dict[str, Any]:
    """The instance ``instance_id`` of THIS report, visible to ``user``.

    404 when it is not this report's; 403 (with the reason) when it was
    computed under a different row-security scope than the caller's live
    one and the caller does not see every scope.
    """
    inst = db.get_report_instance(int(instance_id))
    if not inst or int(inst.get("report_id") or 0) != int(report["id"]):
        raise SignoffRefused(f"Instance {instance_id} not found on report "
                             f"{report.get('id')}", 404)
    sees_all = sees_all_scopes(user)
    if not scope_visible(inst.get("rls_signature"),
                         caller_scope(db, report, user) if not sees_all else None,
                         sees_all):
        raise SignoffRefused(
            f"Instance {instance_id} was computed under a different "
            "row-security scope than yours; its commentary and sign-off "
            "are not about the rows you see", 403)
    return inst


def resolve_current_instance(db, report: Dict[str, Any], user: Optional[dict],
                             *, instance_id: Optional[int] = None,
                             execution_id: Optional[str] = None,
                             params: Optional[Dict[str, Any]] = None,
                             ) -> Optional[Dict[str, Any]]:
    """The instance the viewer is LOOKING AT, resolved once on the server.

    Precedence: an explicit ``instance_id`` (a served instance names itself
    on the wire) -> the ``execution_id`` of a live run (the sync and async
    lanes record under it) -> the newest instance the caller would be
    served for ``params`` (the probe's own key).  ``None`` = this view was
    not recorded as an instance, so there is nothing to sign.  Scope is
    enforced on every branch through :func:`resolve_instance`.
    """
    if instance_id is not None:
        return resolve_instance(db, report, user, int(instance_id))
    if execution_id:
        inst = db.find_report_instance_by_execution(int(report["id"]), execution_id)
        if inst:
            return resolve_instance(db, report, user, int(inst["id"]))
    if params is not None:
        from core.reports import instances as _ri
        try:
            pf = _ri.canonical_params_fingerprint(params)
            sig = _ri.compute_caller_signature(db, report, user)
            sv = _ri.compute_semantic_version(db, report)
        except Exception as exc:
            logger.info("[signoff] current-instance key uncomputable: %s", exc)
            return None
        inst = db.find_latest_report_instance(
            report_id=int(report["id"]), params_fingerprint=pf,
            rls_signature=sig, semantic_version=sv)
        return inst
    return None


# ── signing ──────────────────────────────────────────────────────────────────

def _parse_business_date(value: Any) -> Optional[str]:
    if value in (None, ""):
        return None
    try:
        return date.fromisoformat(str(value)).isoformat()
    except ValueError:
        raise SignoffRefused(
            f"business_date must be an ISO date (YYYY-MM-DD), got {value!r}", 400)


def sign_instance(db, report: Dict[str, Any], inst: Dict[str, Any],
                  user: dict, *, role: str, note: Optional[str] = None,
                  business_date: Optional[str] = None,
                  request: Any = None, accept_unexplained: bool = False) -> Dict[str, Any]:
    """Sign ``inst`` as ``role``.  Refuses, with the reason and a status:
    403 not permitted; 400 bad role / date; 409 role already held on this
    instance, the signer already holds another role on it, or the artifact
    is gone (there is nothing to vouch for)."""
    role = str(role or "").strip().lower()
    if role not in SIGNOFF_ROLES:
        raise SignoffRefused(
            f"role must be one of {list(SIGNOFF_ROLES)}, got {role!r}", 400)
    if not can_sign(report, user, db):
        raise SignoffRefused(
            "You may not sign this report: signing needs ownership, an "
            "explicit grant on the report, or an admin role", 403)
    bdate = _parse_business_date(business_date)
    # The bytes must exist: a signature over a vanished artifact vouches
    # for nothing (same chokepoint the serve and the probe use).
    from core.reports.contract import require_artifact
    try:
        require_artifact(str(inst.get("execution_id")), inst.get("artifact_path"))
    except Exception as exc:
        raise SignoffRefused(
            f"Instance {inst.get('id')} cannot be signed: its result "
            f"artifact is not retrievable ({exc})", 409)
    if str(inst.get("status") or "ready") == "expired":
        raise SignoffRefused(
            f"Instance {inst.get('id')} is expired and cannot be signed", 409)
    username = str(user.get("username"))
    for existing in db.list_report_instance_signoffs(
            instance_id=int(inst["id"]), active_only=True):
        if existing.get("role") == role:
            raise SignoffRefused(
                f"Instance {inst['id']} is already signed as {role} by "
                f"{existing.get('signed_by')} at {existing.get('signed_at')}; "
                "revoke that sign-off first", 409)
        if existing.get("signed_by") == username:
            raise SignoffRefused(
                f"You already signed instance {inst['id']} as "
                f"{existing.get('role')}; one role per person per instance", 409)
    # the movements nobody has explained (per report: warn, or refuse)
    from core.reports.commentary import sign_gate
    gate = sign_gate(db, report, inst, user, accepted=bool(accept_unexplained)) or {}
    row = db.create_report_instance_signoff(
        instance=inst, role=role, signed_by=username,
        note=(note or None), business_date=bdate, overrode=gate.get("overrode"), checked=gate.get("checked"))
    _audit(db, user, request, _AUDIT_SIGNED, report, inst, {
        "signoff_id": row.get("id"), "role": role, "business_date": bdate,
        "note": (note or None), "overrode": gate.get("overrode"), "checked": gate.get("checked"),
    })
    logger.info("[signoff] instance=%s report=%s signed as %s by %s",
                inst.get("id"), report.get("id"), role, username)
    return row


def revoke_signoff(db, report: Dict[str, Any], signoff: Dict[str, Any],
                   user: dict, *, reason: str, request: Any = None,
                   ) -> Dict[str, Any]:
    """Revoke an active sign-off with a reason (>= 3 characters).  409 when
    it is already revoked; 403 when the caller is neither the signer, the
    owner nor an admin."""
    reason = str(reason or "").strip()
    if len(reason) < 3:
        raise SignoffRefused("A revoke needs a reason (at least 3 characters)", 400)
    if not can_revoke(signoff, report, user, db):
        raise SignoffRefused(
            "Only the signer, the report owner or an admin may revoke a "
            "sign-off", 403)
    if signoff.get("status") != "active":
        raise SignoffRefused(
            f"Sign-off {signoff.get('id')} is already revoked by "
            f"{signoff.get('revoked_by')} at {signoff.get('revoked_at')}", 409)
    row = db.revoke_report_instance_signoff(
        int(signoff["id"]), revoked_by=str(user.get("username")), reason=reason)
    inst = db.get_report_instance(int(signoff["instance_id"])) or {
        "id": signoff.get("instance_id"),
        "execution_id": signoff.get("execution_id"),
        "params_fingerprint": signoff.get("params_fingerprint"),
        "rls_signature": signoff.get("rls_signature"),
        "semantic_version": signoff.get("semantic_version"),
    }
    _audit(db, user, request, _AUDIT_REVOKED, report, inst, {
        "signoff_id": signoff.get("id"), "role": signoff.get("role"),
        "signed_by": signoff.get("signed_by"), "reason": reason,
    })
    logger.info("[signoff] sign-off=%s on instance=%s revoked by %s: %s",
                signoff.get("id"), signoff.get("instance_id"),
                user.get("username"), reason)
    return row


# ── commentary ───────────────────────────────────────────────────────────────

def add_comment(db, report: Dict[str, Any], inst: Dict[str, Any], user: dict, *,
                text: str, parent_id: Optional[int] = None,
                anchor: Optional[Dict[str, Any]] = None,
                business_date: Optional[str] = None,
                request: Any = None, origin: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    from core.reports import commentary as _cm
    if not can_comment(report, user, db):
        raise SignoffRefused(
            "You may not comment on this report: commenting needs an "
            "analyst or admin role, ownership, or an explicit grant", 403)
    if not str(text or "").strip():
        raise SignoffRefused("Comment text must be non-empty", 400)
    bdate = _parse_business_date(business_date)
    try:
        clean = _cm.clean_anchor(anchor)
        clean.pop("label", None)
        words = _cm.label_for(db, report, clean)
        if words:
            clean["label"] = words
        row = db.create_report_instance_comment(
            instance=inst, username=str(user.get("username")), text=str(text),
            parent_id=parent_id, anchor=clean, business_date=bdate,
            origin=_cm.clean_origin(db, inst, clean, origin))
    except ValueError as exc:
        raise SignoffRefused(str(exc), 400)
    _audit(db, user, request, _AUDIT_COMMENTED, report, inst, {
        "comment_id": row.get("id"), "parent_id": parent_id,
        "anchor": row.get("anchor"), "business_date": bdate, "origin": row.get("origin"),
    })
    row = dict(row)
    row["told"] = _cm.tell_mentioned(db, report, inst, row, user)
    return row


def update_comment(db, report: Dict[str, Any], inst: Dict[str, Any], comment: Dict[str, Any],
                   user: dict, *, updates: Dict[str, Any], request: Any = None) -> Dict[str, Any]:
    """Change a comment's words (your own, or admin-tier) or resolve it (anyone who may
    comment).  Audited; someone newly mentioned is told."""
    from core.reports import commentary as _cm
    from core.roles import is_admin_like
    if "text" in updates and not (is_admin_like(user)
                                  or comment.get("username") == user.get("username")):
        raise SignoffRefused("You may only edit your own comments", 403)
    if not can_comment(report, user, db):
        raise SignoffRefused("You may not comment on this report", 403)
    try:
        row = db.update_report_instance_comment(int(comment["id"]), **updates,
                                                resolved_by=str(user.get("username")))
    except ValueError as exc:
        raise SignoffRefused(str(exc), 400)
    if row is None:
        raise SignoffRefused(f"Comment {comment.get('id')} not found", 404)
    _audit(db, user, request, _AUDIT_COMMENT_CHANGED, report, inst, {
        "comment_id": comment.get("id"), "author": comment.get("username"),
        "changed": sorted(updates), "is_resolved": updates.get("is_resolved"),
    })
    row = dict(row)
    fresh = sorted(set(row.get("mentions") or []) - set(comment.get("mentions") or []))
    row["told"] = _cm.tell_mentioned(db, report, inst, row, user, names=fresh)
    return row


def visible_comments(db, report: Dict[str, Any], inst: Dict[str, Any],
                     user: Optional[dict]) -> List[Dict[str, Any]]:
    """The instance's thread, filtered by Rule 1 row by row (a comment
    row's own signature decides -- it equals the instance's, but the rule
    is applied to the ROW so a mis-stamped row cannot widen)."""
    sees_all = sees_all_scopes(user)
    sig = None if sees_all else caller_scope(db, report, user)
    out = []
    for c in db.list_report_instance_comments(int(inst["id"])):
        if scope_visible(c.get("rls_signature"), sig, sees_all):
            c = dict(c)
            c["scope_label"] = scope_label(c.get("rls_signature"))
            out.append(c)
    return out


def delete_comment(db, report: Dict[str, Any], inst: Dict[str, Any],
                   comment: Dict[str, Any], user: dict,
                   request: Any = None) -> None:
    """Own comment, or admin-tier.  The report owner may not erase another
    person's note -- commentary is evidence too."""
    from core.roles import is_admin_like
    if not (is_admin_like(user)
            or str(comment.get("username")) == str(user.get("username"))):
        raise SignoffRefused("You may only delete your own comments", 403)
    db.delete_report_instance_comment(int(comment["id"]))
    _audit(db, user, request, _AUDIT_COMMENT_DELETED, report, inst, {
        "comment_id": comment.get("id"), "author": comment.get("username"),
    })


# ── disclosure ───────────────────────────────────────────────────────────────

def _public_signoff(row: Dict[str, Any]) -> Dict[str, Any]:
    """What the wire carries about a sign-off: identity, no signature hash
    beyond its label."""
    return {
        "id": row.get("id"),
        "instance_id": row.get("instance_id"),
        "execution_id": row.get("execution_id"),
        "role": row.get("role"),
        "signed_by": row.get("signed_by"),
        "signed_at": row.get("signed_at"),
        "business_date": row.get("business_date"),
        "note": row.get("note"),
        "status": row.get("status"),
        "revoked_by": row.get("revoked_by"),
        "revoked_at": row.get("revoked_at"),
        "revoke_reason": row.get("revoke_reason"),
        "overrode": row.get("overrode"),
        "checked": row.get("checked"),
        "semantic_version": row.get("semantic_version"),
        "source_version": row.get("source_version"),
        "row_count": row.get("row_count"),
        "scope_label": scope_label(row.get("rls_signature")),
    }


def signed_version_for(db, inst: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The newest ACTIVE sign-off under this instance's serve key (report,
    params fingerprint, row-security signature) -- across semantic
    versions, so a definition change after a sign-off still names the
    signed run.  ``None`` when nothing under this key is signed."""
    rows = db.list_report_instance_signoffs(
        report_id=int(inst["report_id"]),
        params_fingerprint=inst.get("params_fingerprint"),
        rls_signature=inst.get("rls_signature"),
        active_only=True, limit=1)
    return rows[0] if rows else None


def serve_disclosure(db, inst: Dict[str, Any]) -> Dict[str, Any]:
    """The ``signoff`` block on a served instance's wire envelope.

    ``signed`` is about THIS instance; ``signed_version`` names the signed
    instance under the same key when this one is not it ("signed version
    is <id> from <time>; this run is newer").  Unreadable state is
    disclosed as ``status: "unknown"`` with the reason -- never as
    "unsigned" (unknown is not empty).
    """
    try:
        active = db.list_report_instance_signoffs(
            instance_id=int(inst["id"]), active_only=True)
        out: Dict[str, Any] = {
            "status": "known",
            "instance_id": inst.get("id"),
            "signed": bool(active),
            "signoffs": [_public_signoff(r) for r in active],
            "signed_version": None,
            "newer_than_signed": False,
            "definition_changed_since_signed": False,
        }
        if not active:
            sv = signed_version_for(db, inst)
            if sv and int(sv.get("instance_id") or 0) != int(inst["id"]):
                out["signed_version"] = _public_signoff(sv)
                out["newer_than_signed"] = _is_newer(inst, sv)
                out["definition_changed_since_signed"] = (
                    str(sv.get("semantic_version") or "")
                    != str(inst.get("semantic_version") or ""))
        return out
    except Exception as exc:
        logger.warning("[signoff] disclosure unreadable for instance %s: %s",
                       inst.get("id"), exc)
        return {"status": "unknown", "instance_id": inst.get("id"),
                "reason": f"sign-off state could not be read: {exc}"}


def _is_newer(inst: Dict[str, Any], signoff: Dict[str, Any]) -> bool:
    """Is ``inst`` a later run than the signed instance?  By instance id
    (monotonic per table); the signed row copied the id."""
    try:
        return int(inst.get("id") or 0) > int(signoff.get("instance_id") or 0)
    except (TypeError, ValueError):
        return False


def header_state(db, report: Dict[str, Any], user: Optional[dict],
                 inst: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Everything the viewer's instance header renders, resolved once."""
    base = {
        "report_id": report.get("id"),
        "instance": None,
        "can_sign": can_sign(report, user, db),
        "can_comment": can_comment(report, user, db),
        "sees_all_scopes": sees_all_scopes(user),
        "roles": list(SIGNOFF_ROLES),
    }
    if not inst:
        base["signoff"] = {"status": "no_instance",
                           "reason": "this run was not recorded as a report "
                                     "instance, so there is nothing to sign"}
        base["comments"] = []
        return base
    disclosure = serve_disclosure(db, inst)
    for s in disclosure.get("signoffs") or []:
        s["can_revoke"] = can_revoke(s, report, user, db)
    base["instance"] = {
        "id": inst.get("id"),
        "execution_id": inst.get("execution_id"),
        "created_at": inst.get("created_at"),
        "created_by": inst.get("created_by"),
        "status": inst.get("status"),
        "row_count": inst.get("row_count"),
        "semantic_version": inst.get("semantic_version"),
        "source_version": inst.get("source_version"),
        "scope_label": scope_label(inst.get("rls_signature")),
    }
    base["signoff"] = disclosure
    base["comments"] = visible_comments(db, report, inst, user)
    return base


def list_signed_runs(db, report: Dict[str, Any], user: Optional[dict],
                     *, include_revoked: bool = False,
                     limit: int = 200) -> List[Dict[str, Any]]:
    """The "signed runs" list for a report, Rule 1 applied per row."""
    sees_all = sees_all_scopes(user)
    sig = None if sees_all else caller_scope(db, report, user)
    rows = db.list_report_instance_signoffs(
        report_id=int(report["id"]), active_only=not include_revoked,
        limit=limit)
    out = []
    for r in rows:
        if not scope_visible(r.get("rls_signature"), sig, sees_all):
            continue
        pub = _public_signoff(r)
        pub["can_revoke"] = (r.get("status") == "active"
                             and can_revoke(r, report, user, db))
        out.append(pub)
    return out


# ── audit ────────────────────────────────────────────────────────────────────

def _audit(db, user: dict, request: Any, action: str, report: Dict[str, Any],
           inst: Dict[str, Any], extra: Dict[str, Any]) -> None:
    from core.audit import audit_event
    details = {
        "report_id": report.get("id"),
        "instance_id": inst.get("id"),
        "execution_id": inst.get("execution_id"),
        "params_fingerprint": inst.get("params_fingerprint"),
        "rls_signature": inst.get("rls_signature"),
        "semantic_version": inst.get("semantic_version"),
        "source_version": inst.get("source_version"),
        "at": datetime.now(timezone.utc).isoformat(),
    }
    details.update(extra or {})
    audit_event(db, user, request, action, "report_instance",
                inst.get("id"), details)
