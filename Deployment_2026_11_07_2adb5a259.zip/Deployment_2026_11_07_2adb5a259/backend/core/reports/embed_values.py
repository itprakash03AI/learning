"""Values an embed LINK fixes (2026-11-05, docs/EMBEDDING_MODEL_2026_11_05.html).

A value in the URL can be edited by whoever holds the link, so it is a convenience and never a limit.  A team that must
see one system gets a link that FIXES it: the value is stored on the token, on the server, and overrides whatever the
URL, the request body or an export's ``?params=`` says.  This module is the one reading of that rule; every road that
runs a token's report goes through :func:`applied` or :func:`applied_json`.

2026-11-06 (adversarial review): being the parameter's VALUE is not a limit.  The parameter layer may replace it: a period
anchored on a fixed date, or a comparison on its column, read other dates; a parameter that is not shown runs its default.
So a fixed value is ALSO its own filter, added after the parameters are resolved
(``business_reports_api._fixed_filters_or_problem``), and an AND can only narrow.  :func:`fixed_problem` refuses what no
filter can hold, when the link is made and again on each run, since the report may have been re-published since.  Every
value must produce a filter or a condition's value, and only a report kind known to apply them may have one at all.
"""
from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Sequence


def fixed_problem(param: Dict[str, Any], params: Sequence[Dict[str, Any]]) -> Optional[str]:
    """Why this parameter cannot be held to a fixed value; None = it can."""
    from core.reports.param_contract import targets_of
    label = param.get("label") or param.get("name")
    if param.get("visible") is False:
        return f"'{label}' is hidden, so the report's own default already decides it."
    if isinstance(param.get("show_when"), dict) and param["show_when"].get("param"):
        return f"'{label}' shows only when another value is set, and otherwise runs its default, so it cannot be fixed."
    if param.get("parameter_type") in ("period", "cob_compare"):
        return f"'{label}' is a period or a comparison, which does not limit the rows. Fix the date itself."

    def keys(p: Dict[str, Any]) -> set:
        return {str(t.get("source_column") or "").strip().lower() for t in targets_of(p)
                if t.get("to") == "source" and t.get("source_column")}
    mine = keys(param)
    for other in params or []:
        if other.get("name") != param.get("name") and mine & keys(other):
            return (f"'{label}' and '{other.get('label') or other.get('name')}' set the same condition of the query, "
                    "so it cannot be fixed.")
    return None


def check(params: Sequence[Dict[str, Any]], fixed: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """What to store, or a sentence: a typo would otherwise fix nothing and show every row."""
    out: Dict[str, Any] = {}
    by_name = {str(p.get("name")): p for p in params or []}
    for name, value in (fixed or {}).items():
        param = by_name.get(str(name))
        if param is None:
            raise ValueError(f"This report asks for no value called '{name}'.")
        why = fixed_problem(param, params)
        if why:
            raise ValueError(why)
        if isinstance(value, list):
            value = [v for v in value if v not in (None, "")]
        if value in (None, "", []):
            continue
        if isinstance(value, list) and param.get("parameter_type") != "multi_select":
            raise ValueError(f"'{param.get('label') or name}' takes one value.")
        out[str(name)] = value
    return out


#: what a link does unless its maker says otherwise: the safe road, as every link before this option
DEFAULT_OPTIONS = {"controls": False, "full_report": False, "downloads": True, "details": False}


def clean_options(raw: Optional[Dict[str, Any]]) -> Dict[str, bool]:
    """What to store.  A name this does not know is refused: a typo in "downloads" would leave them on."""
    unknown = set(raw or {}) - set(DEFAULT_OPTIONS)
    if unknown:
        raise ValueError(f"A link has no option called '{sorted(unknown)[0]}'.")
    return {k: bool((raw or {}).get(k, d)) for k, d in DEFAULT_OPTIONS.items()}


def options(token_row: Optional[Dict[str, Any]]) -> Dict[str, bool]:
    """controls: the page shows the values to change.  full_report: no 'latest date' rule fills an empty value, and the
    higher row ceiling applies.  downloads: the link may export.  details: a click opens the rows behind it
    (api/canvas_actions_api.py, its checks at the bottom of that module)."""
    return {**DEFAULT_OPTIONS, **((token_row or {}).get("link_options") or {})}


def _fixed(token_row: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    return dict((token_row or {}).get("fixed_values") or {})


def applied(token_row: Optional[Dict[str, Any]], values: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """The values a run uses: what was sent, then what the link fixes on top."""
    return {**(values or {}), **_fixed(token_row)}


def applied_json(token_row: Optional[Dict[str, Any]], params_json: Optional[str]) -> Optional[str]:
    """The same for an export's ``?params=`` text.  Unreadable text from an anonymous caller still runs fixed."""
    fixed = _fixed(token_row)
    if not fixed:
        return params_json
    try:
        sent = json.loads(params_json) if params_json else {}
    except (TypeError, ValueError):
        sent = {}
    return json.dumps({**(sent if isinstance(sent, dict) else {}), **fixed})


def choices(token_row: Optional[Dict[str, Any]], param_name: str) -> Optional[List[Any]]:
    """The only choices a fixed parameter has; None = it is not fixed.  The other values of that column are data the
    link does not show, so its list must not hand them out."""
    fixed = _fixed(token_row)
    if param_name not in fixed:
        return None
    value = fixed[param_name]
    return list(value) if isinstance(value, list) else [value]
