/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * EmbeddedBusinessReportPage — iframe-safe embedded report viewer (no auth, minimal chrome).
 *
 * Route: /embedded-business-report/:token
 *
 * Features:
 *  - No navigation bar or header (iframe-friendly)
 *  - Auto-execute on load
 *  - Parameter override via URL search params
 *  - Compact results table
 *  - Respects embed row limit
 */
import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { getUserFriendlyError } from '../utils/errorMessages';
import { linkParamValue, tokenParamDefault } from '../utils/parameterUtils';
import { useParams, useSearchParams } from 'react-router-dom';
import {
  Alert, Box, Button, CircularProgress, IconButton, Menu, MenuItem,
  ListItemIcon, ListItemText, TableContainer, Table, TableHead,
  TableRow, TableCell, TableBody, TablePagination, Typography, Tooltip,
} from '@mui/material';
import {
  GetApp as GetAppIcon,
  PictureAsPdf as PictureAsPdfIcon,
  TableView as TableViewIcon,
} from '@mui/icons-material';
import api from '../services/api';
import { formatPublicCell } from '../utils/formatters';
import TokenCanvas, { tokenPageShowsRows } from './reports/canvas/TokenCanvas';
import ReportParamControl from './reports/ReportParamControl';

const ROWS_PER_PAGE_OPTIONS = [25, 50, 100];

export default function EmbeddedBusinessReportPage() {
  const { token } = useParams<{ token: string }>();
  const [searchParams] = useSearchParams();

  const [report, setReport] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [result, setResult] = useState<any>(null);
  const [executing, setExecuting] = useState(false);
  const [execError, setExecError] = useState('');
  const [usedParams, setUsedParams] = useState<Record<string, any>>({});
  // 2026-11-05: what this link allows (the server decides; this only draws it)
  const [link, setLink] = useState<{ controls: boolean; downloads: boolean; details?: boolean }>({ controls: false, downloads: true });
  const [fixed, setFixed] = useState<Record<string, any>>({});
  const [inputs, setInputs] = useState<Record<string, any>>({});

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(50);
  const [exportAnchor, setExportAnchor] = useState<null | HTMLElement>(null);
  const [exportError, setExportError] = useState('');

  const run = useCallback(async (values: Record<string, any>) => {
    setUsedParams(values);
    setExecuting(true);
    setExecError('');
    try {
      setResult(await api.executeEmbeddedBusinessReport(token!, { parameter_values: values }));
      setPage(0);
    } catch (e: any) {
      setExecError(getUserFriendlyError(e, 'Execution failed'));
    } finally { setExecuting(false); }
  }, [token]);
  const fetchValues = useCallback(
    (body: any) => (token ? api.getEmbeddedReportParamValues(token, body) : Promise.resolve({ values: [] })), [token]);

  // Load metadata + auto-execute
  useEffect(() => {
    if (!token) return;
    (async () => {
      setLoading(true);
      try {
        const res = await api.getEmbeddedBusinessReport(token);
        setReport(res.report);

        // FIX 4 (Phase 81): URL params with p_* prefix override defaults
        // e.g. /embedded-business-report/abc123?p_region=West
        const paramValues: Record<string, any> = {};
        (res.report.parameters || []).forEach((p: any) => {
          const urlVal = linkParamValue(searchParams, p);
          if (urlVal != null) {
            paramValues[p.name] = urlVal;
          } else if (tokenParamDefault(p) !== undefined) {
            paramValues[p.name] = tokenParamDefault(p);
          }
        });

        // what this link fixes wins over the address, as it does on the server; the band says it
        Object.assign(paramValues, res.fixed_values || {});
        const opts = { controls: false, downloads: true, ...(res.link || {}) };
        setLink(opts);
        setFixed(res.fixed_values || {});
        setInputs(paramValues);

        // Auto-execute.  A page where the reader picks the values waits for a required one.
        const needed = (res.report.parameters || []).some((p: any) => p.is_required && p.visible !== false
          && (paramValues[p.name] == null || paramValues[p.name] === ''));
        if (!(opts.controls && needed)) await run(paramValues);
      } catch (e: any) {
        setError(getUserFriendlyError(e, 'Embed token not found or expired'));
      } finally { setLoading(false); }
    })();
  }, [token]); // eslint-disable-line react-hooks/exhaustive-deps

  const columns = result?.columns || [];
  const allRows = result?.rows || [];
  const paginatedRows = allRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  if (loading || executing) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center',
        minHeight: '100vh', flexDirection: 'column', gap: 1 }}>
        <CircularProgress />
        <Typography variant="body2" color="text.secondary">
          {loading ? 'Loading report...' : 'Running report...'}
        </Typography>
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center',
        minHeight: '100vh', flexDirection: 'column', gap: 1, p: 2 }}>
        <Typography variant="h6" color="error">Embed Error</Typography>
        <Typography variant="body2" color="text.secondary">{error}</Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      {/* Compact header */}
      <Box sx={{ px: 2, py: 1, bgcolor: 'grey.50', borderBottom: '1px solid', borderColor: 'divider',
        display: 'flex', alignItems: 'center', gap: 1 }}>
        <Typography variant="subtitle2" fontWeight={600} noWrap sx={{ flex: 1 }}>
          {report?.name}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          {allRows.length} row{allRows.length !== 1 ? 's' : ''}
          {/* F-P3A-14: disclose the cut — a clipped embed must not read as
              the whole result. */}
          {result?.truncated && Number(result?.total_rows) > allRows.length
            ? ` (first ${allRows.length.toLocaleString()} of ${Number(result.total_rows).toLocaleString()})`
            : ''}
        </Typography>
        {allRows.length > 0 && link.downloads && (
          <>
            <Tooltip title="Download">
              <IconButton size="small" onClick={(e) => setExportAnchor(e.currentTarget)}>
                <GetAppIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            <Menu anchorEl={exportAnchor} open={Boolean(exportAnchor)}
              onClose={() => setExportAnchor(null)}>
              <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadEmbeddedReportExcel(token!, usedParams); } catch (e: any) { setExportError(e?.message || 'Excel export failed'); } }}>
                <ListItemIcon><TableViewIcon fontSize="small" /></ListItemIcon>
                <ListItemText>Excel</ListItemText>
              </MenuItem>
              <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadEmbeddedReportPDF(token!, usedParams); } catch (e: any) { setExportError(e?.message || 'PDF export failed'); } }}>
                <ListItemIcon><PictureAsPdfIcon fontSize="small" /></ListItemIcon>
                <ListItemText>PDF</ListItemText>
              </MenuItem>
              <MenuItem onClick={async () => { setExportAnchor(null); try { await api.downloadEmbeddedReportCSV(token!, usedParams); } catch (e: any) { setExportError(e?.message || 'CSV export failed'); } }}>
                <ListItemIcon><GetAppIcon fontSize="small" /></ListItemIcon>
                <ListItemText>CSV</ListItemText>
              </MenuItem>
            </Menu>
          </>
        )}
      </Box>

      {link.controls && (
        <Box sx={{ px: 2, pt: 1, display: 'flex', flexWrap: 'wrap', gap: 1, alignItems: 'center' }} data-testid="embed-controls">
          {(report?.parameters || []).filter((p: any) => p.visible !== false && !(p.name in fixed)).map((p: any) => (
            <ReportParamControl key={p.id} param={p} params={report.parameters} values={inputs} onValues={setInputs} fetchValues={fetchValues} />
          ))}
          <Button variant="contained" size="small" onClick={() => run({ ...inputs, ...fixed })} disabled={executing} data-testid="embed-run">
            {executing ? <CircularProgress size={16} /> : 'Run'}
          </Button>
        </Box>
      )}
      {execError && <Alert severity="error" sx={{ mx: 2, mt: 1 }}>{execError}</Alert>}
      {exportError && <Alert severity="error" sx={{ mx: 2, mt: 1 }} onClose={() => setExportError('')}>{exportError}</Alert>}

      {/* 2026-10-26 -- the report canvas: the tiles of THIS embed's run */}
      {result && token && (
        <Box sx={{ px: 2, pt: 1, overflow: 'auto', ...(tokenPageShowsRows(report, result) ? { maxHeight: '55%', flexShrink: 0 } : { flex: 1 }) }}>
          <TokenCanvas report={report} result={result} values={usedParams} cube={(b) => api.queryEmbeddedReportCube(token, b)}
            detail={link.details ? { token, downloads: link.downloads } : undefined} />
        </Box>
      )}
      {/* Results table */}
      {result && tokenPageShowsRows(report, result) && (
        <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <TableContainer sx={{ flex: 1 }}>
            <Table stickyHeader size="small">
              <TableHead>
                <TableRow>
                  {columns.map((col: string, i: number) => (
                    <TableCell key={i} sx={{
                      fontWeight: 600, bgcolor: '#00aeef', color: '#fff',
                      textTransform: 'uppercase', fontSize: 11,
                    }}>{col}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedRows.map((row: any[], ri: number) => (
                  <TableRow key={ri} hover>
                    {row.map((v: any, ci: number) => (
                      <TableCell key={ci} sx={{ fontSize: 12 }}>
                        {formatPublicCell(v)}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <TablePagination
            component="div" count={allRows.length}
            page={page} onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={e => { setRowsPerPage(+e.target.value); setPage(0); }}
            rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
            sx={{ flexShrink: 0 }}
          />
        </Box>
      )}

      {/* Footer attribution */}
      <Box sx={{ px: 2, py: 0.5, bgcolor: 'grey.50', borderTop: '1px solid', borderColor: 'divider',
        textAlign: 'right' }}>
        <Typography variant="caption" color="text.disabled">Powered by QueryStudio</Typography>
      </Box>
    </Box>
  );
}
