import React, { useState, useEffect, useCallback } from 'react';
import {
  Drawer, Box, Typography, IconButton, List, ListItem, ListItemIcon,
  ListItemText, Button, Divider, Chip, CircularProgress, Tooltip,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import InboxIcon from '@mui/icons-material/Inbox';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

interface NotificationItem {
  id: number;
  event_type: string;
  title: string | null;
  message: string | null;
  is_read: boolean;
  created_at: string | null;
  execution_id: string | null;
  payload?: { link?: string } | null;
}

const EVENT_ICON: Record<string, React.ReactNode> = {
  execution_completed: <CheckCircleOutlineIcon sx={{ color: '#2e7d32', fontSize: 20 }} />,
  execution_failed: <ErrorOutlineIcon sx={{ color: '#d32f2f', fontSize: 20 }} />,
  execution_cancelled: <WarningAmberIcon sx={{ color: '#ed6c02', fontSize: 20 }} />,
  schedule_completed: <CheckCircleOutlineIcon sx={{ color: '#1565c0', fontSize: 20 }} />,
  schedule_failed: <ErrorOutlineIcon sx={{ color: '#d32f2f', fontSize: 20 }} />,
};

function timeAgo(dateStr: string | null): string {
  if (!dateStr) return '';
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onUnreadCountChange?: (count: number) => void;
}

const NotificationDrawer: React.FC<Props> = ({ open, onClose, onUnreadCountChange }) => {
  const navigate = useNavigate();
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  // 2026-08-31 -- what is running RIGHT NOW.  A notification says a report
  // finished; nothing said what was still going.  That gap matters most
  // after a long run is detached: the viewer stops watching at ten minutes
  // and leaves the job alive, so without this the user sees nothing at all
  // until the completion notification arrives.
  const [running, setRunning] = useState<any[]>([]);
  const [runningKnown, setRunningKnown] = useState(false);

  const fetchNotifications = useCallback(async (offset = 0, append = false) => {
    setLoading(true);
    try {
      const res = await api.listNotifications(false, 30, offset);
      const newItems = res.items || [];
      setItems(prev => append ? [...prev, ...newItems] : newItems);
      setUnreadCount(res.unread_count || 0);
      onUnreadCountChange?.(res.unread_count || 0);
      setHasMore(newItems.length >= 30);
    } catch {
      // silent
    } finally {
      setLoading(false);
    }
  }, [onUnreadCountChange]);

  const fetchRunning = useCallback(async () => {
    try {
      const res: any = await (api as any).listRunningBusinessReports();
      setRunning(Array.isArray(res?.items) ? res.items : []);
      setRunningKnown(true);
    } catch {
      // Fail OPEN, but do NOT claim "nothing is running" — an unreachable
      // endpoint and an idle account look identical otherwise, and the
      // second is the reassuring one to show by mistake.
      setRunning([]);
      setRunningKnown(false);
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    fetchNotifications(0, false);
    fetchRunning();
    // While the drawer is open, keep the in-flight list current: these rows
    // are the ones that change on their own.
    const t = setInterval(fetchRunning, 10000);
    return () => clearInterval(t);
  }, [open, fetchNotifications, fetchRunning]);

  const handleMarkRead = async (id: number) => {
    try {
      await api.markNotificationRead(id);
      setItems(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
      onUnreadCountChange?.(Math.max(0, unreadCount - 1));
    } catch { /* silent */ }
  };

  const handleMarkAllRead = async () => {
    try {
      await api.markAllNotificationsRead();
      setItems(prev => prev.map(n => ({ ...n, is_read: true })));
      setUnreadCount(0);
      onUnreadCountChange?.(0);
    } catch { /* silent */ }
  };

  const handleLoadMore = () => {
    fetchNotifications(items.length, true);
  };

  return (
    <Drawer anchor="right" open={open} onClose={onClose} PaperProps={{ sx: { width: { xs: '100%', sm: 380 } } }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 2, py: 1.5, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '1rem' }}>Notifications</Typography>
          {unreadCount > 0 && (
            <Chip label={unreadCount} size="small" color="error" sx={{ height: 20, fontSize: 11, fontWeight: 700 }} />
          )}
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          {unreadCount > 0 && (
            <Tooltip title="Mark all notifications as read">
              <IconButton size="small" onClick={handleMarkAllRead}>
                <DoneAllIcon sx={{ fontSize: 18 }} />
              </IconButton>
            </Tooltip>
          )}
          <Tooltip title="Close notifications">
            <IconButton size="small" onClick={onClose}>
              <CloseIcon sx={{ fontSize: 18 }} />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>

      {/* Running now — above the history, because it is the part the user
          can still act on. */}
      {running.length > 0 && (
        <Box sx={{ px: 2, py: 1.25, bgcolor: 'action.hover',
                   borderBottom: '1px solid', borderColor: 'divider' }}>
          <Typography variant="caption" sx={{ fontWeight: 700, letterSpacing: '.06em',
                                              textTransform: 'uppercase', color: 'text.secondary' }}>
            Running now ({running.length})
          </Typography>
          {running.map((j: any) => (
            <Box key={j.execution_id}
                 sx={{ display: 'flex', alignItems: 'center', gap: 1, mt: 0.75 }}>
              <CircularProgress size={14} thickness={5} />
              <Typography variant="body2" sx={{ flex: 1, minWidth: 0,
                                                overflow: 'hidden',
                                                textOverflow: 'ellipsis',
                                                whiteSpace: 'nowrap' }}>
                {j.report_name}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {j.progress_pct ? `${j.progress_pct}%` : ''} {timeAgo(j.started_at)}
              </Typography>
            </Box>
          ))}
        </Box>
      )}
      {!runningKnown && (
        <Box sx={{ px: 2, py: 1, bgcolor: 'action.hover',
                   borderBottom: '1px solid', borderColor: 'divider' }}>
          <Typography variant="caption" color="text.secondary">
            Couldn&rsquo;t check what&rsquo;s running right now.
          </Typography>
        </Box>
      )}

      {/* List */}
      {items.length === 0 && !loading ? (
        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', py: 8, color: 'text.secondary' }}>
          <InboxIcon sx={{ fontSize: 48, mb: 1, opacity: 0.3 }} />
          <Typography variant="body2">No notifications yet</Typography>
        </Box>
      ) : (
        <List sx={{ py: 0, overflowY: 'auto', flex: 1 }}>
          {items.map((n) => (
            <React.Fragment key={n.id}>
              <ListItem
                sx={{
                  px: 2, py: 1.25, alignItems: 'flex-start', cursor: 'pointer',
                  bgcolor: n.is_read ? 'transparent' : 'action.hover',
                  '&:hover': { bgcolor: 'action.selected' },
                  transition: 'background 0.15s',
                }}
                onClick={() => {
                  if (!n.is_read) handleMarkRead(n.id);
                  // a mention opens its note (2026-11-07): the link only; the note is read under the reader's access
                  const link = n.payload?.link;
                  if (n.event_type === 'report_comment_mention' && typeof link === 'string' && link.startsWith('/')) {
                    onClose();
                    navigate(link);
                  }
                }}
              >
                <ListItemIcon sx={{ minWidth: 32, mt: 0.5 }}>
                  {EVENT_ICON[n.event_type] || <InfoOutlinedIcon sx={{ fontSize: 20, color: 'text.secondary' }} />}
                </ListItemIcon>
                <ListItemText
                  primary={
                    <Typography variant="body2" sx={{ fontWeight: n.is_read ? 400 : 700, fontSize: '0.8rem', lineHeight: 1.4 }}>
                      {n.title || n.event_type}
                    </Typography>
                  }
                  secondary={
                    <Box>
                      {n.message && (
                        <Typography variant="caption" sx={{ display: 'block', color: 'text.secondary', fontSize: '0.72rem', lineHeight: 1.35, mt: 0.25, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 260 }}>
                          {n.message}
                        </Typography>
                      )}
                      <Typography variant="caption" sx={{ color: 'text.disabled', fontSize: '0.65rem', mt: 0.25, display: 'block' }}>
                        {timeAgo(n.created_at)}
                      </Typography>
                    </Box>
                  }
                />
                {!n.is_read && (
                  <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: 'primary.main', mt: 1, flexShrink: 0 }} />
                )}
              </ListItem>
              <Divider component="li" />
            </React.Fragment>
          ))}
          {hasMore && (
            <Box sx={{ display: 'flex', justifyContent: 'center', py: 1.5 }}>
              <Button size="small" onClick={handleLoadMore} disabled={loading}>
                {loading ? <CircularProgress size={16} /> : 'Load more'}
              </Button>
            </Box>
          )}
        </List>
      )}
    </Drawer>
  );
};

export default NotificationDrawer;
