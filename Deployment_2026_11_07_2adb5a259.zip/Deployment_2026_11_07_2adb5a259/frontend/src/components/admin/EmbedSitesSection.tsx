/**
 * Admin -> Embedding sites (2026-11-05).  Which websites may show an embed or share link inside their own page.
 * A new site needs no deployment: every UI pod reads this list within 30 seconds (frontend/spa-server.cjs).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, Paper, Stack, TextField, Typography,
} from '@mui/material';
import { Save as SaveIcon } from '@mui/icons-material';
import api from '../../services/api';

interface Props {
  addNotification: (n: { type: string; title: string; message: string }) => void;
}

/** What the UI server is sending right now for an embed page: the sites, 'any', or null when it could not be read. */
export function sentByHeader(csp: string | null): string[] | 'any' | null {
  const m = (csp || '').match(/frame-ancestors\s+([^;]+)/);
  if (!m) return null;
  const v = m[1].trim();
  return v === '*' ? 'any' : v.split(/\s+/);
}

/** Does what the UI server sends match what is saved?  Order does not matter; an empty list means any site. */
export function sameAsSaved(sent: string[] | 'any' | null, saved: string[]): boolean {
  if (sent === null) return false;
  if (sent === 'any') return saved.length === 0;
  return sent.length === saved.length && sent.every(s => saved.includes(s));
}

async function readSent(): Promise<string[] | 'any' | null> {
  try {
    const r = await fetch(`${window.location.origin}/embedded-business-report/check`, { method: 'HEAD', cache: 'no-store' });
    return sentByHeader(r.headers.get('content-security-policy'));
  } catch {
    return null;
  }
}

const EmbedSitesSection: React.FC<Props> = ({ addNotification }) => {
  const [saved, setSaved] = useState<string[] | null>(null);
  const [configured, setConfigured] = useState(false);
  const [sites, setSites] = useState<string[]>([]);
  const [typed, setTyped] = useState('');
  const [error, setError] = useState('');
  const [loadError, setLoadError] = useState('');
  const [saving, setSaving] = useState(false);
  const [sent, setSent] = useState<string[] | 'any' | null | undefined>(undefined);

  const load = useCallback(async () => {
    try {
      const r = await (api as any).getEmbedSites();
      setSaved(r.sites || []);
      setSites(r.sites || []);
      setConfigured(!!r.configured);
      setLoadError('');
    } catch (e: any) {
      setLoadError(e?.message || 'The list could not be read.');
    }
    setSent(await readSent());
  }, []);
  useEffect(() => { load(); }, [load]);

  const add = () => {
    const site = typed.trim().toLowerCase().replace(/\/+$/, '');
    if (!site) return;
    if (!sites.includes(site)) setSites([...sites, site]);
    setTyped('');
    setError('');
  };

  const save = async () => {
    setSaving(true);
    setError('');
    try {
      const r = await (api as any).setEmbedSites(sites);
      setSaved(r.sites);
      setSites(r.sites);
      setConfigured(true);
      addNotification({ type: 'success', title: 'Embedding sites saved', message: 'Every screen picks this up within 30 seconds.' });
    } catch (e: any) {
      setError(e?.message || 'The list could not be saved.');
    } finally {
      setSaving(false);
    }
  };

  if (loadError) return <Alert severity="error" data-testid="embed-sites-load-error">{loadError}</Alert>;
  if (saved === null) return <Typography variant="body2">Reading the list…</Typography>;
  const changed = JSON.stringify(sites) !== JSON.stringify(saved);

  return (
    <Paper sx={{ p: 2 }} data-testid="embed-sites">
      <Typography variant="h6" gutterBottom>Embedding sites</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        Which websites may show an embedded or shared report inside their own page. Add a site here and it works
        within 30 seconds, with no deployment. Every other page of this product can never be shown inside another site.
      </Typography>

      <Alert severity={sites.length ? 'info' : 'warning'} sx={{ mb: 2 }} data-testid="embed-sites-meaning">
        {sites.length
          ? 'Only the sites below may show these links.'
          : 'The list is empty, so ANY website may show these links. Whoever has a link still sees only what that link allows.'}
      </Alert>

      <Stack direction="row" gap={1} flexWrap="wrap" sx={{ mb: 2 }} data-testid="embed-sites-list">
        {sites.map(s => (
          <Chip key={s} label={s} onDelete={() => setSites(sites.filter(x => x !== s))} data-testid={`embed-site-${s}`} />
        ))}
      </Stack>

      <Stack direction="row" gap={1} alignItems="flex-start" sx={{ mb: 2 }}>
        <TextField size="small" label="Site address" placeholder="https://portal.example.com" value={typed} sx={{ minWidth: 340 }}
          onChange={e => setTyped(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); add(); } }}
          inputProps={{ 'data-testid': 'embed-site-input' }} />
        <Button onClick={add} disabled={!typed.trim()} data-testid="embed-site-add">Add</Button>
        <Box sx={{ flex: 1 }} />
        <Button variant="contained" startIcon={<SaveIcon />} onClick={save} disabled={saving || !changed} data-testid="embed-sites-save">
          Save
        </Button>
      </Stack>
      {error && <Alert severity="error" sx={{ mb: 2 }} data-testid="embed-sites-error">{error}</Alert>}

      {!configured && (
        <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 1 }} data-testid="embed-sites-chart-note">
          Nothing has been saved here yet, so the list in the deployment settings still applies. Saving here replaces it.
        </Typography>
      )}
      {sent !== undefined && !changed && (
        <Typography variant="caption" component="div" data-testid="embed-sites-sent"
          color={!configured || sameAsSaved(sent, saved) ? 'text.secondary' : 'warning.main'}>
          {'This screen’s server is sending now: '}
          {sent === null ? 'could not be read' : sent === 'any' ? 'any site' : sent.join(', ')}.
          {configured && !sameAsSaved(sent, saved) && (
            ' That is not the saved list yet. It should match within 30 seconds; if it stays different, this server cannot '
            + 'read the list, so the saved list is NOT in force on it. Check that the UI pod can reach the API.'
          )}
        </Typography>
      )}
      <Button size="small" sx={{ mt: 1 }} onClick={load} data-testid="embed-sites-recheck">Check again</Button>
    </Paper>
  );
};

export default EmbedSitesSection;
