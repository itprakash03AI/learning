/**
 * A mention's link (2026-11-07): `?note=<comment>&note_run=<run>` opens that note, read now,
 * under the reader's access at this moment.  The notice itself carries no note text
 * (`core/reports/commentary.py`), so a person whose access has changed sees the server's
 * refusal here and nothing else.
 */
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Alert, Button, Chip, CircularProgress, Typography } from '@mui/material';
import AppDialog from '../common/AppDialog';
import api from '../../services/api';
import type { InstanceComment } from '../../services/api/businessReports';

interface Props {
  reportId: number;
  /** a note on the report itself, not a run: the viewer's report thread shows it */
  onReportNote: () => void;
}

export default function NoteFromLink({ reportId, onReportNote }: Props) {
  const [params, setParams] = useSearchParams();
  const noteId = Number(params.get('note') || 0);
  const runId = Number(params.get('note_run') || 0);
  const [thread, setThread] = useState<InstanceComment[] | null>(null);
  const [error, setError] = useState('');

  const close = () => {
    const next = new URLSearchParams(params);
    next.delete('note');
    next.delete('note_run');
    setParams(next, { replace: true });
  };

  useEffect(() => {
    if (!noteId) return undefined;
    if (!runId) {
      onReportNote();
      close();
      return undefined;
    }
    let live = true;
    setThread(null); setError('');
    api.listInstanceComments(reportId, runId).then(r => {
      if (!live) return;
      const note = r.comments.find(c => c.id === noteId);
      if (!note) {
        setError('That comment is no longer there.');
        return;
      }
      const root = note.parent_id ?? note.id;
      setThread(r.comments.filter(c => c.id === root || c.parent_id === root));
    }).catch((e: any) => { if (live) setError(e?.message || 'That comment could not be read.'); });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reportId, noteId, runId]);

  if (!noteId || !runId) return null;
  const root = thread?.[0];
  return (
    <AppDialog open size="sm" onClose={close} title="The comment you were told about" testId="note-from-link"
      actions={<Button onClick={close} data-testid="note-from-link-close">Close</Button>}>
      {error && <Alert severity="warning" data-testid="note-from-link-error">{error}</Alert>}
      {!thread && !error && <CircularProgress size={18} />}
      {root?.anchor && root.anchor.kind !== 'instance' && root.anchor.label && (
        <Chip size="small" variant="outlined" label={`On ${root.anchor.label}`} sx={{ mb: 1 }} data-testid="note-from-link-on" />
      )}
      {thread?.map(c => (
        <div key={c.id} data-testid="note-from-link-note">
          <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap', pl: c.parent_id ? 2 : 0 }}>{c.text}</Typography>
          <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 1, pl: c.parent_id ? 2 : 0 }}>
            {c.username}{c.business_date ? ` · for ${c.business_date}` : ''}
          </Typography>
        </div>
      ))}
      {thread && (
        <Typography variant="caption" color="text.secondary" component="div">
          To reply, run the report for that date and open Comments.
        </Typography>
      )}
    </AppDialog>
  );
}
