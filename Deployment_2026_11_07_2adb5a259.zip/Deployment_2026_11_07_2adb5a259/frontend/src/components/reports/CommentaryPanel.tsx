/**
 * One Commentary panel (2026-11-07, docs/REPORT_COMMENTARY_PLAN_2026_11_06.html).
 *
 * "This run" is `report_instance_comments` (read by the run's row-security scope), "This
 * report" is `report_comments` (read by the report's authors); the two stay two tables with
 * their own rules, under one panel.  "Needs explaining" is the movements over the report's
 * limit.  Everything shown is the server's answer; it offers what the server said it accepts.
 */
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, IconButton, List, ListItemButton, Paper, Stack, Tab, Tabs,
  TextField, ToggleButton, ToggleButtonGroup, Tooltip, Typography,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ReplyIcon from '@mui/icons-material/Reply';
import DeleteIcon from '@mui/icons-material/DeleteOutline';
import ResolveIcon from '@mui/icons-material/CheckCircleOutline';
import ReopenIcon from '@mui/icons-material/CheckCircle';
import DraftIcon from '@mui/icons-material/AutoAwesomeOutlined';
import api from '../../services/api';
import type {
  CarryCandidate, CommentDraft, InstanceComment, NeedsExplaining, NoteAnchor,
} from '../../services/api/businessReports';
import { toldWords } from './commentaryWords';
import ReportCommentPanel from '../ReportCommentPanel';
import { noteIdentity } from './canvas/canvasCommentary';
import NeedsExplainingSettings from './NeedsExplainingSettings';

const when = (iso: string | null | undefined): string => {
  if (!iso) return 'an unknown time';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? 'an unknown time' : d.toLocaleString();
};

const anchorWords = (a: NoteAnchor | undefined | null): string => {
  if (!a || a.kind === 'instance') return 'the whole run';
  if (a.label) return a.label;
  const parts = Object.values(a.key ?? {}).map(v => (v === null || v === undefined ? '(no value)' : String(v)));
  if (a.column) parts.push(a.column);
  return parts.join(' · ');
};

const MENTION = /(?<![\w.@\\])(@\w(?:[\w.\-\\@]*\w)?)/g;

function NoteText({ text }: { text: string }) {
  const parts = text.split(MENTION);
  return (
    <>
      {parts.map((p, i) => (p.startsWith('@') && i % 2 === 1
        ? <Typography key={i} component="span" sx={{ color: 'primary.main', fontWeight: 600, font: 'inherit' }}>{p}</Typography>
        : <span key={i}>{p}</span>))}
    </>
  );
}

/** The box: `@` offers people who may read the note, Draft fills it, nothing posts by itself. */
function Composer({ reportId, instanceId, anchor, parentId, businessDate, onPosted, onCancel, autoFocus }: {
  reportId: number; instanceId: number; anchor: NoteAnchor | null; parentId?: number | null;
  businessDate?: string | null; onPosted: (c: InstanceComment) => void; onCancel?: () => void; autoFocus?: boolean;
}) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [draftNote, setDraftNote] = useState('');
  const [origin, setOrigin] = useState<Record<string, any> | null>(null);
  const [carry, setCarry] = useState<CarryCandidate | null>(null);
  const [people, setPeople] = useState<string[]>([]);
  const [peopleFor, setPeopleFor] = useState<string | null>(null);
  const [lookupNote, setLookupNote] = useState('');
  const boxRef = useRef<HTMLTextAreaElement | null>(null);
  const anchorKey = JSON.stringify(anchor ?? null);

  // the note on this number from an earlier run (never copied by itself)
  useEffect(() => {
    let live = true;
    setCarry(null); setOrigin(null); setDraftNote(''); setLookupNote('');
    if (parentId || !anchor || anchor.kind === 'instance') return () => { live = false; };
    api.findCarryForward(reportId, instanceId, anchor, businessDate ?? null)
      .then(c => { if (live) setCarry(c.found ? c : null); })
      .catch(() => { if (live) setLookupNote('An earlier note on this number could not be looked up.'); });
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reportId, instanceId, anchorKey, businessDate, parentId]);

  useEffect(() => {
    if (peopleFor === null) { setPeople([]); return undefined; }
    let live = true;
    const t = setTimeout(() => {
      api.findPeopleToMention(reportId, instanceId, peopleFor)
        .then(r => { if (live) { setPeople(r.people); setLookupNote(''); } })
        .catch(() => { if (live) { setPeople([]); setLookupNote('The list of people could not be read. You can still type a name.'); } });
    }, 200);
    return () => { live = false; clearTimeout(t); };
  }, [reportId, instanceId, peopleFor]);

  const typed = (value: string, caret: number) => {
    setText(value);
    const m = /(?:^|\s)@([\w.\-\\@]*)$/.exec(value.slice(0, caret));
    setPeopleFor(m ? m[1] : null);
  };

  const pick = (name: string) => {
    const caret = boxRef.current?.selectionStart ?? text.length;
    const before = text.slice(0, caret).replace(/@([\w.\-\\@]*)$/, () => `@${name} `);
    setText(before + text.slice(caret));
    setPeopleFor(null);
    boxRef.current?.focus();
  };

  const draft = async () => {
    setBusy(true); setError(''); setDraftNote('');
    try {
      const d: CommentDraft = await api.draftInstanceComment(reportId, instanceId, anchor);
      if (d.refused) { setError(d.refused); return; }
      setText(d.text ?? '');
      setOrigin({ kind: 'draft', source: d.source });
      setDraftNote(d.source === 'assistant' ? 'The assistant worded this from the numbers. Check it, change it, then post it.'
        : `Written from the numbers. Check it, change it, then post it.${d.reason ? ` ${d.reason}` : ''}`);
    } catch (e: any) {
      setError(e?.message || 'The draft could not be written.');
    } finally { setBusy(false); }
  };

  const useCarried = () => {
    if (!carry) return;
    setText(carry.text ?? '');
    setOrigin({ kind: 'carried', from_comment_id: carry.comment_id });
    setCarry(null);
    setDraftNote('Carried from an earlier run. Change it if it is not true today, then post it.');
  };

  const post = async () => {
    if (!text.trim()) return;
    setBusy(true); setError('');
    try {
      const c = await api.postInstanceComment(reportId, instanceId, {
        text: text.trim(),
        ...(parentId ? { parent_id: parentId } : {}),
        ...(!parentId && anchor ? { anchor } : {}),
        ...(businessDate ? { business_date: businessDate } : {}),
        ...(origin ? { origin } : {}),
      });
      setText(''); setOrigin(null); setDraftNote('');
      onPosted(c);
    } catch (e: any) {
      setError(e?.message || 'The comment could not be posted.');
    } finally { setBusy(false); }
  };

  return (
    <Box data-testid="commentary-composer">
      {carry && (
        <Alert severity="info" icon={false} sx={{ mb: 1, py: 0 }} data-testid="commentary-carry"
          action={<Button size="small" color="inherit" onClick={useCarried} data-testid="commentary-carry-use">Use it</Button>}>
          From {carry.business_date ?? when(carry.created_at)}: {carry.text}
        </Alert>
      )}
      <TextField size="small" fullWidth multiline minRows={2} maxRows={6}
        label={parentId ? 'Reply' : 'Add a comment'} value={text} autoFocus={autoFocus}
        inputRef={boxRef} disabled={busy}
        helperText="Type @ to tell someone."
        inputProps={{ 'data-testid': 'commentary-input' }}
        onChange={e => typed(e.target.value, e.target.selectionStart ?? e.target.value.length)} />
      {peopleFor !== null && people.length > 0 && (
        <Paper variant="outlined" sx={{ maxHeight: 160, overflowY: 'auto' }} data-testid="commentary-people">
          <List dense disablePadding>
            {people.map(p => (
              <ListItemButton key={p} onClick={() => pick(p)} data-testid={`commentary-person-${p}`}>{p}</ListItemButton>
            ))}
          </List>
        </Paper>
      )}
      {lookupNote && <Typography variant="caption" color="warning.main" component="div" data-testid="commentary-lookup-note">{lookupNote}</Typography>}
      {draftNote && <Typography variant="caption" color="text.secondary" component="div" data-testid="commentary-draft-note">{draftNote}</Typography>}
      {error && <Alert severity="warning" sx={{ mt: 0.5, py: 0 }} data-testid="commentary-error">{error}</Alert>}
      {/* the right-hand gap keeps Post clear of the assistant's round button, which floats over the panel */}
      <Stack direction="row" spacing={1} sx={{ mt: 0.5, pr: parentId ? 0 : 7 }} alignItems="center">
        {!parentId && (
          <Button size="small" startIcon={<DraftIcon />} onClick={draft} disabled={busy} data-testid="commentary-draft">
            Draft it for me
          </Button>
        )}
        <Box sx={{ flex: 1 }} />
        {busy && <CircularProgress size={16} />}
        {onCancel && <Button size="small" onClick={onCancel} disabled={busy}>Cancel</Button>}
        <Button size="small" variant="contained" onClick={post} disabled={busy || !text.trim()} data-testid="commentary-post">Post</Button>
      </Stack>
    </Box>
  );
}

type Show = 'open' | 'resolved' | 'all';

interface Props {
  reportId: number;
  instanceId: number | null;
  comments: InstanceComment[];
  canComment: boolean;
  /** an author of the report: the report-level thread is theirs */
  canAuthor?: boolean;
  seesAllScopes?: boolean;
  username: string;
  isAdmin: boolean;
  businessDate?: string | null;
  /** what the panel was opened on */
  focus: { anchor: NoteAnchor | null; commentId?: number | null } | null;
  onClearFocus: () => void;
  onChanged: () => Promise<void> | void;
  onClose: () => void;
  /** the movements' count changed: the sign-off header asks again */
  columns?: { id: number; label: string; physical_name?: string }[];
}

export default function CommentaryPanel({
  reportId, instanceId, comments, canComment, canAuthor, seesAllScopes, username, isAdmin, businessDate,
  focus, onClearFocus, onChanged, onClose, columns,
}: Props) {
  const [tab, setTab] = useState<'run' | 'report' | 'explain'>('run');
  const [show, setShow] = useState<Show>('open');
  const [replyTo, setReplyTo] = useState<number | null>(null);
  const [told, setTold] = useState('');
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState<number | null>(null);
  const [needs, setNeeds] = useState<NeedsExplaining | null>(null);
  const [needsError, setNeedsError] = useState('');
  const [onScreen, setOnScreen] = useState<Set<number> | null>(null);
  const [explainFocus, setExplainFocus] = useState<NoteAnchor | null>(null);

  const anchor = explainFocus ?? focus?.anchor ?? null;
  const focused = anchor && anchor.kind !== 'instance' ? noteIdentity(anchor.key, anchor.column) : null;

  const loadNeeds = useCallback(async () => {
    if (!instanceId) return;
    setNeedsError('');
    try {
      setNeeds(await api.getNeedsExplaining(reportId, instanceId));
    } catch (e: any) {
      setNeeds(null);
      setNeedsError(e?.message || 'The movements to explain could not be read.');
    }
  }, [reportId, instanceId]);

  useEffect(() => { loadNeeds(); }, [loadNeeds, comments.length]);

  // which notes are drawn on the screen right now (a drill or a page can take one away)
  useEffect(() => {
    const ids = new Set<number>();
    document.querySelectorAll('[data-comment-ids]').forEach(el => {
      (el.getAttribute('data-comment-ids') || '').split(' ').forEach(x => { if (x) ids.add(Number(x)); });
    });
    setOnScreen(ids);
  }, [comments, focus]);

  useEffect(() => {
    if (focus) { setTab('run'); setShow('all'); setExplainFocus(null); }
  }, [focus]);

  const roots = useMemo(() => comments.filter(c => !c.parent_id), [comments]);
  const repliesOf = useMemo(() => {
    const m = new Map<number, InstanceComment[]>();
    for (const c of comments) if (c.parent_id) m.set(c.parent_id, [...(m.get(c.parent_id) ?? []), c]);
    return m;
  }, [comments]);
  const openCount = roots.filter(c => !c.is_resolved).length;
  const listed = roots.filter(c => {
    if (focused && noteIdentity(c.anchor?.key, c.anchor?.column) !== focused) return false;
    return show === 'all' || (show === 'open' ? !c.is_resolved : c.is_resolved);
  });

  const act = async (id: number, fn: () => Promise<any>) => {
    setBusyId(id); setError('');
    try { await fn(); await onChanged(); }
    catch (e: any) { setError(e?.message || 'That could not be done.'); }
    finally { setBusyId(null); }
  };

  const posted = async (c: InstanceComment) => {
    setTold(toldWords(c.told));
    setReplyTo(null);
    await onChanged();
  };

  const renderNote = (c: InstanceComment, nested = false): React.ReactNode => {
    const anchored = c.anchor && c.anchor.kind !== 'instance';
    return (
      <Box key={c.id} data-testid="commentary-note" data-comment-id={c.id} data-resolved={c.is_resolved ? 'yes' : 'no'}
        sx={{ pl: nested ? 2 : 0, py: 0.75, borderTop: nested ? 'none' : '1px solid', borderColor: 'divider',
              opacity: c.is_resolved ? 0.65 : 1 }}>
        <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}><NoteText text={c.text} /></Typography>
        <Typography variant="caption" color="text.secondary" component="div">
          {c.username} · {when(c.created_at)}
          {c.business_date ? ` · for ${c.business_date}` : ''}
          {seesAllScopes && c.scope_label && c.scope_label !== 'open' ? ` · scope ${c.scope_label}` : ''}
        </Typography>
        <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap alignItems="center">
          {!nested && anchored && <Chip size="small" variant="outlined" label={`On ${anchorWords(c.anchor)}`} data-testid="commentary-on" />}
          {!nested && anchored && onScreen && !onScreen.has(c.id) && (
            <Chip size="small" variant="outlined" color="default" label="Not in this view" data-testid="commentary-not-in-view" />
          )}
          {c.origin?.kind === 'draft' && <Chip size="small" variant="outlined" label="Began as a draft" data-testid="commentary-began-draft" />}
          {c.origin?.kind === 'carried' && (
            <Chip size="small" variant="outlined" data-testid="commentary-carried"
              label={`Carried from ${c.origin.from_business_date ?? 'an earlier run'}`} />
          )}
          {c.is_resolved && c.resolved_by && (
            <Typography variant="caption" color="text.secondary">Resolved by {c.resolved_by}</Typography>
          )}
          <Box sx={{ flex: 1 }} />
          {canComment && !nested && (
            <Tooltip title="Reply"><IconButton size="small" aria-label={`Reply to ${c.username}`} data-testid="commentary-reply"
              onClick={() => setReplyTo(replyTo === c.id ? null : c.id)}><ReplyIcon fontSize="inherit" /></IconButton></Tooltip>
          )}
          {canComment && !nested && (
            <Tooltip title={c.is_resolved ? 'Open it again' : 'Resolve'}>
              <span>
                <IconButton size="small" disabled={busyId === c.id} data-testid="commentary-resolve"
                  aria-label={c.is_resolved ? `Open again, ${c.username}'s comment` : `Resolve ${c.username}'s comment`}
                  onClick={() => act(c.id, () => api.updateInstanceComment(reportId, instanceId!, c.id, { is_resolved: !c.is_resolved }))}>
                  {c.is_resolved ? <ReopenIcon fontSize="inherit" color="success" /> : <ResolveIcon fontSize="inherit" />}
                </IconButton>
              </span>
            </Tooltip>
          )}
          {(isAdmin || c.username === username) && (
            <Tooltip title="Delete">
              <span>
                <IconButton size="small" disabled={busyId === c.id} aria-label={`Delete comment by ${c.username}`} data-testid="commentary-delete"
                  onClick={() => act(c.id, () => api.deleteInstanceComment(reportId, instanceId!, c.id))}>
                  <DeleteIcon fontSize="inherit" />
                </IconButton>
              </span>
            </Tooltip>
          )}
        </Stack>
        {(repliesOf.get(c.id) ?? []).map(r => renderNote(r, true))}
        {replyTo === c.id && instanceId && (
          <Box sx={{ pl: 2, pt: 0.5 }}>
            <Composer reportId={reportId} instanceId={instanceId} anchor={c.anchor} parentId={c.id}
              businessDate={businessDate} onPosted={posted} onCancel={() => setReplyTo(null)} autoFocus />
          </Box>
        )}
      </Box>
    );
  };

  const needsCount = needs?.status === 'ok' ? needs.unexplained : 0;
  const showExplain = !!instanceId && (needs?.status !== 'off' || needs?.may_change_settings || !!needsError);

  return (
    <Box data-testid="commentary-panel" sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Stack direction="row" alignItems="center" sx={{ mb: 0.5 }}>
        <Typography variant="h6" sx={{ flex: 1 }}>Commentary</Typography>
        <IconButton aria-label="Close comments" onClick={onClose}><CloseIcon /></IconButton>
      </Stack>
      <Tabs value={tab} onChange={(_e, v) => setTab(v)} variant="fullWidth" sx={{ minHeight: 36, mb: 1 }}>
        <Tab value="run" label={`This run (${openCount})`} sx={{ minHeight: 36 }} data-testid="commentary-tab-run" />
        {canAuthor && <Tab value="report" label="This report" sx={{ minHeight: 36 }} data-testid="commentary-tab-report" />}
        {showExplain && (
          <Tab value="explain" label={`Needs explaining${needsCount ? ` (${needsCount.toLocaleString()})` : ''}`} sx={{ minHeight: 36 }} data-testid="commentary-tab-explain" />
        )}
      </Tabs>

      {tab === 'run' && (
        <>
          {!instanceId && (
            <Typography variant="body2" color="text.secondary" data-testid="commentary-no-run">
              This run was not kept as a run of the report, so nothing can be said about it here.
            </Typography>
          )}
          {instanceId && (
            <>
              {focused && (
                <Alert severity="info" icon={false} sx={{ mb: 1, py: 0 }} data-testid="commentary-focus"
                  action={<Button size="small" color="inherit" onClick={() => { setExplainFocus(null); onClearFocus(); }}
                    data-testid="commentary-focus-clear">Show all</Button>}>
                  On {anchorWords(anchor)}
                </Alert>
              )}
              <ToggleButtonGroup size="small" exclusive value={show} sx={{ mb: 1 }}
                onChange={(_e, v) => { if (v) setShow(v); }} aria-label="Which comments to show">
                <ToggleButton value="open" data-testid="commentary-show-open">Open</ToggleButton>
                <ToggleButton value="resolved" data-testid="commentary-show-resolved">Resolved</ToggleButton>
                <ToggleButton value="all" data-testid="commentary-show-all">All</ToggleButton>
              </ToggleButtonGroup>
              {error && <Alert severity="error" sx={{ mb: 1, py: 0 }} data-testid="commentary-action-error">{error}</Alert>}
              <Box sx={{ flex: 1, overflowY: 'auto', mb: 1 }}>
                {listed.length === 0 && (
                  <Typography variant="body2" color="text.secondary" data-testid="commentary-empty">
                    {focused ? 'No comments on this number yet.'
                      : show === 'resolved' ? 'Nothing resolved yet.'
                      : show === 'open' && roots.length > 0 ? 'Every comment here is resolved.'
                      : 'No comments on this run yet. Right-click a number on the report to comment on it.'}
                  </Typography>
                )}
                {listed.map(c => renderNote(c))}
              </Box>
              {told && <Alert severity="info" sx={{ mb: 1, py: 0 }} onClose={() => setTold('')} data-testid="commentary-told">{told}</Alert>}
              {canComment ? (
                <Composer reportId={reportId} instanceId={instanceId} anchor={anchor}
                  businessDate={businessDate} onPosted={posted} autoFocus={!!focused} />
              ) : (
                <Typography variant="caption" color="text.secondary" data-testid="commentary-read-only">
                  You can read these but not post. Commenting needs an analyst or admin role, ownership, or a grant on this report.
                </Typography>
              )}
            </>
          )}
        </>
      )}

      {tab === 'report' && canAuthor && (
        <Box sx={{ flex: 1, overflowY: 'auto' }} data-testid="commentary-report-thread">
          <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 1 }}>
            About the report itself, not one run. Everyone who authors this report reads these.
          </Typography>
          <ReportCommentPanel reportId={reportId} />
        </Box>
      )}

      {tab === 'explain' && (
        <Box sx={{ flex: 1, overflowY: 'auto' }} data-testid="commentary-explain">
          {needsError && <Alert severity="warning" data-testid="explain-unreadable">{needsError}</Alert>}
          {!needs && !needsError && <CircularProgress size={18} />}
          {needs?.status === 'off' && (
            <Typography variant="body2" color="text.secondary" data-testid="explain-off" sx={{ mb: 1 }}>
              This report does not list movements to explain yet.
            </Typography>
          )}
          {(needs?.status === 'no_comparison' || needs?.status === 'unknown') && (
            <Alert severity="warning" sx={{ mb: 1 }} data-testid="explain-unknown">
              The movements could not be checked: {needs.reason}
            </Alert>
          )}
          {needs?.status === 'ok' && (
            <>
              <Typography variant="body2" sx={{ mb: 1 }} data-testid="explain-summary">
                {needs.total === 0
                  ? `No movement over ${needs.limit_words} against ${needs.against}.`
                  : `${needs.unexplained.toLocaleString()} of ${needs.total.toLocaleString()} movement${needs.total === 1 ? '' : 's'} over ${needs.limit_words} against ${needs.against} ${needs.unexplained === 1 ? 'has' : 'have'} no comment.`}
              </Typography>
              {needs.items.map(i => {
                const explained = i.comment_ids.length > 0;
                const target: NoteAnchor = { kind: 'cell', key: i.key, column: i.column, label: `${i.label} · ${needs.measure_words ?? i.column}` };
                return (
                  <Stack key={JSON.stringify(i.key)} direction="row" alignItems="center" spacing={1}
                    data-testid="explain-item" data-explained={explained ? 'yes' : 'no'}
                    sx={{ py: 0.5, borderTop: '1px solid', borderColor: 'divider' }}>
                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography variant="body2" noWrap title={i.label}>{i.label}</Typography>
                      <Typography variant="caption" color="text.secondary" data-testid="explain-change">
                        {Number(i.change) > 0 ? '+' : ''}{Number(i.change).toLocaleString()} ({Number(i.a).toLocaleString()} to {Number(i.b).toLocaleString()})
                      </Typography>
                    </Box>
                    {canComment && (
                      <Button size="small" data-testid="explain-open" onClick={() => {
                        setExplainFocus(target); setShow('all'); setTab('run');
                      }}>{explained ? 'Read' : 'Explain'}</Button>
                    )}
                  </Stack>
                );
              })}
              {needs.total > needs.items.length && (
                <Typography variant="caption" color="text.secondary">
                  Showing the first {needs.items.length} of {needs.total}.
                </Typography>
              )}
            </>
          )}
          {needs?.may_change_settings && (
            <NeedsExplainingSettings reportId={reportId} columns={columns ?? []} settings={needs.settings ?? null}
              onSaved={loadNeeds} />
          )}
        </Box>
      )}
    </Box>
  );
}
