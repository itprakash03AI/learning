import type { CommentTold } from '../../services/api/businessReports';

/** What a post's `told` says, in words; empty when there is nothing to say. */
export function toldWords(told: CommentTold | undefined | null): string {
  if (!told) return '';
  const out: string[] = [];
  if (told.told?.length) out.push(`${told.told.join(', ')} ${told.told.length === 1 ? 'was' : 'were'} told.`);
  if (told.cannot_see?.length) out.push(`${told.cannot_see.join(', ')} cannot read this, so ${told.cannot_see.length === 1 ? 'was' : 'were'} not told.`);
  if (told.not_known?.length) out.push(`Nobody called ${told.not_known.join(', ')} is known here.`);
  if (told.not_told?.length) out.push(`${told.not_told.join(', ')} could not be told just now.`);
  return out.join(' ');
}
