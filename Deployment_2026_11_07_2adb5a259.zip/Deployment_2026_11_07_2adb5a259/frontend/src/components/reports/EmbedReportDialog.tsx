/**
 * Embed a report on another web page (2026-11-05, docs/EMBEDDING_MODEL_2026_11_05.html).  One dialog for the report list and
 * the report itself: the links, what each one fixes, which values a page may pass, and the code to copy.
 */
import { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, Chip, CircularProgress, FormControlLabel, IconButton, Stack, Table, TableBody, TableCell,
  TableHead, TableRow,
  TextField, Typography,
} from '@mui/material';
import { Delete as DeleteIcon } from '@mui/icons-material';
import AppDialog from '../common/AppDialog';
import api from '../../services/api';

export interface EmbedParam {
  name: string; label?: string; parameter_type?: string; is_required?: boolean; visible?: boolean;
  source_column?: string | null;
  show_when?: { param?: string } | null;
}

/** Can a link fix this value?  The server's rule (embed_values.fixed_problem) is the gate; this only leaves out what it refuses. */
export const canFix = (p: EmbedParam) => p.visible !== false && !p.show_when?.param
  && p.parameter_type !== 'period' && p.parameter_type !== 'cob_compare';

/** The name a page uses in the URL.  A source filter's own name already starts p_, so it reads p_p_<column>. */
export const urlName = (p: EmbedParam) => `p_${p.name}`;

export function howToSend(p: EmbedParam): { what: string; example: string } {
  const key = urlName(p);
  switch (p.parameter_type) {
    case 'multi_select': return { what: 'One or several: repeat it', example: `${key}=A&${key}=B` };
    case 'date': return { what: 'One date', example: `${key}=2026-10-30` };
    case 'date_range': return { what: 'From and to', example: `${key}=2026-10-01..2026-10-30` };
    case 'cob_compare': return { what: 'Two dates to compare', example: `${key}=2026-10-29..2026-10-30` };
    default: return { what: 'One value', example: `${key}=A` };
  }
}

/** The address for a link.  A hidden parameter ignores a sent value and a fixed one cannot change, so neither appears. */
export function embedAddress(origin: string, token: string, params: EmbedParam[], fixed: Record<string, any> = {}): string {
  const base = `${origin}/embedded-business-report/${token}`;
  const parts = params.filter(p => p.visible !== false && !(p.name in fixed)).map(p => howToSend(p).example);
  return parts.length ? `${base}?${parts.join('&')}` : base;
}

export const iframeCode = (url: string) => `<iframe src="${url.replace(/&/g, '&amp;')}" width="100%" height="600" frameBorder="0"></iframe>`;

/** What the form typed, as the server stores it: several lines for a multi-select, one value otherwise. */
export function fixedFromForm(params: EmbedParam[], typed: Record<string, string>): Record<string, any> {
  const out: Record<string, any> = {};
  for (const p of params) {
    const text = (typed[p.name] || '').trim();
    if (!text) continue;
    out[p.name] = p.parameter_type === 'multi_select' ? text.split('\n').map(s => s.trim()).filter(Boolean) : text;
  }
  return out;
}

/** The words on a link for how it behaves; a link that does what every link did says nothing. */
export function optionWords(o: { controls?: boolean; full_report?: boolean; downloads?: boolean; details?: boolean } = {}): string[] {
  return [
    ...(o.full_report ? ['Whole report'] : []),
    ...(o.controls ? ['Reader can change values'] : []),
    ...(o.downloads === false ? ['No downloads'] : []),
    ...(o.details ? ['Opens detail rows'] : []),
  ];
}

export default function EmbedReportDialog({ open, report, onClose }: { open: boolean; report: any; onClose: () => void }) {
  const [tokens, setTokens] = useState<any[]>([]);
  const [params, setParams] = useState<EmbedParam[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [copied, setCopied] = useState('');
  const [error, setError] = useState('');
  const [typed, setTyped] = useState<Record<string, string>>({});
  const [groups, setGroups] = useState('');
  const [options, setOptions] = useState({ controls: false, full_report: false, downloads: true, details: false });

  const load = useCallback(async () => {
    if (!report?.id) return;
    setLoading(true);
    setError('');
    try {
      const [links, full] = await Promise.all([api.listBusinessReportEmbeds(report.id), (api as any).getBusinessReport(report.id)]);
      setTokens(links.tokens || []);
      setParams(full?.parameters || []);
    } catch (e: any) {
      setTokens([]);
      setError(e?.message || 'Embed links could not be listed');
    } finally { setLoading(false); }
  }, [report?.id]);
  useEffect(() => { if (open) load(); }, [open, load]);

  const shown = params.filter(p => p.visible !== false);

  const create = async () => {
    setCreating(true);
    setError('');
    try {
      const names = groups.split(',').map(s => s.trim()).filter(Boolean);
      await (api as any).createBusinessReportEmbed(report.id, undefined,
        names.length ? { allowed_user_groups: names } : undefined, fixedFromForm(params, typed), options);
      setTyped({});
      setGroups('');
      setOptions({ controls: false, full_report: false, downloads: true, details: false });
      await load();
    } catch (e: any) {
      setError(e?.message || 'The link could not be made');
    } finally { setCreating(false); }
  };

  const revoke = async (token: string) => {
    try {
      await api.revokeBusinessReportEmbed(token);
      await load();
    } catch (e: any) { setError(e?.message || 'The link could not be removed'); }
  };

  const copy = (what: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(what);
    setTimeout(() => setCopied(''), 2000);
  };

  return (
    <AppDialog open={open} onClose={onClose} size="md" testId="embed-dialog" title={<>Embed: {report?.name}</>}
      actions={<Button onClick={onClose}>Close</Button>}>
      {loading ? <CircularProgress size={20} /> : (
        <>
          {error && <Alert severity="error" sx={{ mb: 2 }} data-testid="embed-error">{error}</Alert>}

          {shown.length > 0 && (
            <>
              <Typography variant="subtitle2">Values a page can pass in the address</Typography>
              <Table size="small" sx={{ mb: 2 }} data-testid="embed-params">
                <TableHead>
                  <TableRow><TableCell>Value</TableCell><TableCell>Name in the address</TableCell><TableCell>Takes</TableCell><TableCell>Example</TableCell></TableRow>
                </TableHead>
                <TableBody>
                  {shown.map(p => {
                    const how = howToSend(p);
                    return (
                      <TableRow key={p.name} data-testid={`embed-param-${p.name}`}>
                        <TableCell>{p.label || p.name}{p.is_required ? ' (required)' : ''}</TableCell>
                        <TableCell sx={{ fontFamily: 'monospace' }}>{urlName(p)}</TableCell>
                        <TableCell>{how.what}</TableCell>
                        <TableCell sx={{ fontFamily: 'monospace', overflowWrap: 'anywhere' }}>{how.example}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              <Alert severity="warning" sx={{ mb: 2 }} data-testid="embed-url-warning">
                Anyone holding a link can change a value in its address. To limit a team to certain values, fix them on
                the team&apos;s own link below: then nothing in the address can change them.
              </Alert>
            </>
          )}

          <Typography variant="subtitle2" sx={{ mb: 1 }}>New link</Typography>
          <Stack gap={1} sx={{ mb: 2 }} data-testid="embed-new-link">
            {shown.filter(canFix).map(p => (
              <TextField key={p.name} size="small" fullWidth multiline={p.parameter_type === 'multi_select'}
                label={`Fix ${p.label || p.name}`} value={typed[p.name] || ''}
                helperText={p.parameter_type === 'multi_select' ? 'One value on each line. Empty: the page may choose.' : 'Empty: the page may choose.'}
                onChange={e => setTyped({ ...typed, [p.name]: e.target.value })}
                inputProps={{ 'data-testid': `embed-fix-${p.name}` }} />
            ))}
            <TextField size="small" fullWidth label="Row security groups (optional)" value={groups}
              helperText="QueryStudio group names, separated by commas. The link shows what row security allows these groups."
              onChange={e => setGroups(e.target.value)} inputProps={{ 'data-testid': 'embed-groups' }} />
            <FormControlLabel label="The reader can change the values on the page" control={
              <Checkbox size="small" checked={options.controls} inputProps={{ 'data-testid': 'embed-opt-controls' } as any}
                onChange={e => setOptions({ ...options, controls: e.target.checked })} />} />
            <FormControlLabel label="Whole report: no latest-date rule, higher row limit" control={
              <Checkbox size="small" checked={options.full_report} inputProps={{ 'data-testid': 'embed-opt-full' } as any}
                onChange={e => setOptions({ ...options, full_report: e.target.checked })} />} />
            <FormControlLabel label="Allow downloads (Excel, PDF, CSV)" control={
              <Checkbox size="small" checked={options.downloads} inputProps={{ 'data-testid': 'embed-opt-downloads' } as any}
                onChange={e => setOptions({ ...options, downloads: e.target.checked })} />} />
            <FormControlLabel label="A click opens the detail rows behind it (detail popups)" control={
              <Checkbox size="small" checked={options.details} inputProps={{ 'data-testid': 'embed-opt-details' } as any}
                onChange={e => setOptions({ ...options, details: e.target.checked })} />} />
            {options.details && (
              <Alert severity="warning" data-testid="embed-details-warning">
                Anyone holding this link can open detail rows, which may show columns the report does not. Row security
                on the link&apos;s groups and any fixed values above still apply. A detail from a Published API needs groups.
              </Alert>
            )}
            {options.full_report && (
              <Alert severity="warning" data-testid="embed-full-warning">
                With no value chosen, this link reads every row row security allows, which can be slow and large. Anyone
                holding the link can do this. Use groups or fixed values above if it should show less.
              </Alert>
            )}
            <Box>
              <Button variant="contained" onClick={create} disabled={creating} data-testid="embed-create">
                {creating ? <CircularProgress size={16} /> : 'Make the link'}
              </Button>
            </Box>
          </Stack>

          <Typography variant="subtitle2" sx={{ mb: 1 }}>Links</Typography>
          {!error && tokens.length === 0 && (
            <Typography variant="body2" color="text.secondary" data-testid="embed-none">No links yet.</Typography>
          )}
          {tokens.map((t: any) => {
            const url = embedAddress(window.location.origin, t.token, params, t.fixed_values || {});
            return (
              <Box key={t.token} sx={{ mb: 1, p: 1, bgcolor: 'action.hover', borderRadius: 1 }} data-testid={`embed-link-${t.token}`}>
                <Stack direction="row" alignItems="center" gap={1} flexWrap="wrap">
                  <Typography variant="caption" sx={{ flex: 1, fontFamily: 'monospace' }}>...{t.token.slice(-12)}</Typography>
                  <Typography variant="caption" color="text.secondary">{t.access_count} loads</Typography>
                  <Button size="small" onClick={() => copy(`a${t.token}`, url)} data-testid="embed-copy-address">
                    {copied === `a${t.token}` ? 'Copied' : 'Copy address'}
                  </Button>
                  <Button size="small" onClick={() => copy(`c${t.token}`, iframeCode(url))} data-testid="embed-copy-code">
                    {copied === `c${t.token}` ? 'Copied' : 'Copy code'}
                  </Button>
                  <IconButton aria-label="Remove link" size="small" color="error" onClick={() => revoke(t.token)}>
                    <DeleteIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                </Stack>
                <Stack direction="row" gap={0.5} flexWrap="wrap">
                  {Object.entries(t.fixed_values || {}).map(([k, v]) => (
                    <Chip key={k} size="small" label={`Fixed: ${k} = ${Array.isArray(v) ? v.join(', ') : String(v)}`} data-testid={`embed-fixed-${k}`} />
                  ))}
                  {optionWords(t.link_options).map(w => <Chip key={w} size="small" color="info" variant="outlined" label={w} />)}
                  {(t.allowed_user_groups || []).concat(t.allowed_ad_groups || []).map((g: string) => (
                    <Chip key={g} size="small" variant="outlined" label={`Group: ${g}`} />
                  ))}
                </Stack>
              </Box>
            );
          })}
          <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 1 }}>
            Which websites may show these links is set under Admin &rarr; Embedding sites.
          </Typography>
        </>
      )}
    </AppDialog>
  );
}
