/**
 * A comment on a number (2026-11-07, docs/REPORT_COMMENTARY_PLAN_2026_11_06.html).
 *
 * The tile asks one question, "which notes sit on this row and column?", and draws a
 * marker; the panel that reads and writes them is `CommentaryPanel`, which the sign-off
 * header owns.  A note is named by the row's KEY VALUES and the column (the server's
 * `core/reports/commentary.py::anchor_identity`), never by a row index, so a re-sort or a
 * page keeps it, and the same number on two tiles carries the same note.
 *
 * With no provider (a share or embed link, the builder) nothing here draws anything.
 */
import React, { createContext, useCallback, useContext, useMemo } from 'react';
import { Box, Chip, Tooltip, Typography } from '@mui/material';
import CommentIcon from '@mui/icons-material/ChatBubble';
import type { InstanceComment, NoteAnchor } from '../../../services/api/businessReports';
import type { CanvasColumn, CanvasTile } from './canvasModel';

export interface CommentaryApi {
  /** the run on the screen: an export's comments are this run's */
  instanceId: number;
  comments: InstanceComment[];
  canComment: boolean;
  /** open the panel: on this number (the box is ready for it), or at one note */
  open: (anchor: NoteAnchor | null, commentId?: number | null) => void;
}

export const CommentaryContext = createContext<CommentaryApi | null>(null);

/** One spelling of a key value: the twin of the server's `commentary.canon_value`. */
export function canonValue(v: any): string {
  if (v === null || v === undefined) return '\u0000null';
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  const text = String(v);
  const moment = /^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(?:\.(\d+))?$/.exec(text);
  if (moment) {
    const frac = (moment[3] ?? '').replace(/0+$/, '');
    return `${moment[1]}T${moment[2]}${frac ? `.${frac}` : ''}`;
  }
  if (/^-?(?:0|[1-9]\d*)(?:\.\d+)?$/.test(text)) {
    const out = text.includes('.') ? text.replace(/\.?0+$/, '') : text;
    return out === '-0' ? '0' : out;
  }
  return text;
}

/** What makes two notes be about the same number: the server's `anchor_identity`. */
export function noteIdentity(key: Record<string, any> | undefined | null, column?: string | null): string {
  const pairs = Object.entries(key ?? {})
    .map(([k, v]) => [String(k), canonValue(v)])
    .sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
  return JSON.stringify([pairs, column ?? '']);
}

const fieldIds = (tile: CanvasTile): number[] =>
  (tile.kind === 'outline' ? (tile.levels ?? []) : tile.dimensions) ?? [];

/** The row's key, by column NAME: every row field of the tile this row has a value for. */
export function noteKey(tile: CanvasTile, cols: Map<number, CanvasColumn>, row: Record<string, any>): Record<string, any> {
  const key: Record<string, any> = {};
  for (const id of fieldIds(tile)) {
    const name = cols.get(id)?.physical_name;
    if (name && name in row) key[name] = row[name];
  }
  return key;
}

/** The anchor for this row, and this column when the click was on a number. */
export function noteAnchor(tile: CanvasTile, cols: Map<number, CanvasColumn>, row: Record<string, any>,
                           col?: CanvasColumn | null, extraKey?: Record<string, any>): NoteAnchor {
  const key = { ...noteKey(tile, cols, row), ...(extraKey ?? {}) };
  const hasKey = Object.keys(key).length > 0;
  const column = col?.physical_name || undefined;
  const words = Object.values(key).map(v => (v === null || v === undefined ? '(no value)' : String(v)));
  if (col?.label) words.push(col.label);
  return {
    kind: hasKey && column ? 'cell' : hasKey ? 'row' : column ? 'column' : 'instance',
    ...(hasKey ? { key } : {}),
    ...(column ? { column } : {}),
    tile_id: String(tile.id),
    label: (words.join(' · ') || 'This tile').slice(0, 200),
  };
}

/** The notes of this run, by the number they are on (replies travel with their note). */
export function notesByNumber(comments: InstanceComment[]): Map<string, InstanceComment[]> {
  const out = new Map<string, InstanceComment[]>();
  for (const c of comments) {
    if (c.parent_id || !c.anchor || c.anchor.kind === 'instance') continue;
    const id = noteIdentity(c.anchor.key, c.anchor.column);
    out.set(id, [...(out.get(id) ?? []), c]);
  }
  return out;
}

/** The marker: a note icon, the words on hover, the thread on a click. */
export function CommentMark({ notes, onOpen }: { notes: InstanceComment[]; onOpen: () => void }) {
  const open = notes.filter(n => !n.is_resolved).length;
  return (
    <Tooltip title={
      <Box>
        {notes.slice(0, 3).map(n => (
          <Typography key={n.id} variant="caption" component="div">
            <b>{n.username}:</b> {n.text.length > 140 ? `${n.text.slice(0, 140)}…` : n.text}
          </Typography>
        ))}
        {notes.length > 3 && <Typography variant="caption" component="div">and {notes.length - 3} more</Typography>}
      </Box>
    }>
      <Box component="button" type="button"
        data-testid="comment-mark" data-comment-ids={notes.map(n => n.id).join(' ')} data-open={open}
        aria-label={`${notes.length} comment${notes.length === 1 ? '' : 's'} on this number`}
        onClick={(e: React.MouseEvent) => { e.stopPropagation(); onOpen(); }}
        sx={{ all: 'unset', cursor: 'pointer', display: 'inline-flex', verticalAlign: 'middle', ml: 0.5,
              color: open > 0 ? 'warning.main' : 'text.disabled', '&:focus-visible': { outline: '2px solid' } }}>
        <CommentIcon sx={{ fontSize: 13 }} />
      </Box>
    </Tooltip>
  );
}

/** A tile's notes: the marker for a row + column, and what the right-click menu offers. */
export function useTileNotes(tile: CanvasTile, cols: Map<number, CanvasColumn>) {
  const ctx = useContext(CommentaryContext);
  const index = useMemo(() => notesByNumber(ctx?.comments ?? []), [ctx?.comments]);

  const notesAt = useCallback((row: Record<string, any>, col?: CanvasColumn | null, extraKey?: Record<string, any>) =>
    index.get(noteIdentity({ ...noteKey(tile, cols, row), ...(extraKey ?? {}) }, col?.physical_name)) ?? [],
  [index, tile, cols]);

  const mark = (row: Record<string, any>, col?: CanvasColumn | null, extraKey?: Record<string, any>): React.ReactNode => {
    if (!ctx) return null;
    const notes = notesAt(row, col, extraKey);
    if (!notes.length) return null;
    return <CommentMark notes={notes} onOpen={() => ctx.open(noteAnchor(tile, cols, row, col, extraKey), notes[0].id)} />;
  };

  /** the notes a chart cannot draw on a bar: listed under it, each opening its thread */
  const drawsOnCells = ['table', 'pivot', 'outline', 'number'].includes(String(tile.kind));
  const chips: React.ReactNode = ctx && !drawsOnCells ? (() => {
    const mine = [...index.values()].filter(ns => ns.some(n => String(n.anchor?.tile_id) === String(tile.id)));
    if (!mine.length) return null;
    return (
      <Box data-testid={`tile-note-chips-${tile.id}`} sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, pt: 0.5 }}>
        {mine.map(ns => (
          <Tooltip key={ns[0].id} title={ns[0].text}>
            <Chip size="small" variant="outlined" icon={<CommentIcon sx={{ fontSize: 12 }} />}
              data-comment-ids={ns.map(n => n.id).join(' ')} data-testid="tile-note-chip"
              label={`${ns[0].anchor?.label ?? 'A comment'}${ns.length > 1 ? ` (${ns.length})` : ''}`}
              onClick={() => ctx.open(ns[0].anchor as NoteAnchor, ns[0].id)} />
          </Tooltip>
        ))}
      </Box>
    );
  })() : null;

  return { on: !!ctx, canComment: !!ctx?.canComment, mark, chips, notesAt, open: ctx?.open };
}
