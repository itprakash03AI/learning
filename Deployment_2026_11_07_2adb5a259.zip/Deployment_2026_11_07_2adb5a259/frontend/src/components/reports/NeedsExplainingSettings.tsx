/**
 * Which movements need explaining, per report (2026-11-07): the number to watch, what to
 * split it by, the limit, and whether a sign-off warns or refuses.  The server checks it
 * (`core/reports/commentary.py::settings_problems`) and shows its reason.
 */
import React, { useEffect, useState } from 'react';
import {
  Alert, Box, Button, FormControl, InputLabel, MenuItem, Select, Stack, TextField, Typography,
} from '@mui/material';
import api from '../../services/api';
import type { CommentarySettings } from '../../services/api/businessReports';

interface Props {
  reportId: number;
  columns: { id: number; label: string; physical_name?: string; column_type?: string }[];
  settings: CommentarySettings | null;
  onSaved: () => void;
}

export default function NeedsExplainingSettings({ reportId, columns, settings, onSaved }: Props) {
  const [measure, setMeasure] = useState<number | ''>('');
  const [dim, setDim] = useState<number | ''>('');
  const [amount, setAmount] = useState('');
  const [percent, setPercent] = useState('');
  const [mode, setMode] = useState<'warn' | 'block'>('warn');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setMeasure(settings?.measure_column_id ?? '');
    setDim(settings?.dimensions?.[0] ?? '');
    setAmount(settings?.limit_amount != null ? String(settings.limit_amount) : '');
    setPercent(settings?.limit_percent != null ? String(settings.limit_percent) : '');
    setMode(settings?.at_signoff === 'block' ? 'block' : 'warn');
  }, [settings]);

  const save = async (off: boolean) => {
    setBusy(true); setError(''); setSaved(false);
    try {
      await api.setCommentarySettings(reportId, off ? null : {
        measure_column_id: measure === '' ? null : measure,
        dimensions: dim === '' ? [] : [dim],
        limit_amount: amount.trim() === '' ? null : Number(amount),
        limit_percent: percent.trim() === '' ? null : Number(percent),
        at_signoff: mode,
      });
      setSaved(true);
      onSaved();
    } catch (e: any) {
      setError(e?.message || 'The settings could not be saved.');
    } finally { setBusy(false); }
  };

  return (
    <Box data-testid="explain-settings" sx={{ mt: 2, pt: 1, borderTop: '1px solid', borderColor: 'divider' }}>
      <Typography variant="subtitle2" sx={{ mb: 1 }}>Which movements need a comment</Typography>
      <Stack spacing={1}>
        <FormControl size="small" fullWidth>
          <InputLabel id="explain-measure-label">Number to watch</InputLabel>
          <Select labelId="explain-measure-label" label="Number to watch" value={measure}
            inputProps={{ 'data-testid': 'explain-measure' }}
            onChange={e => setMeasure(e.target.value as number | '')}>
            {columns.map(c => <MenuItem key={c.id} value={c.id}>{c.label}</MenuItem>)}
          </Select>
        </FormControl>
        <FormControl size="small" fullWidth>
          <InputLabel id="explain-dim-label">Split by</InputLabel>
          <Select labelId="explain-dim-label" label="Split by" value={dim}
            inputProps={{ 'data-testid': 'explain-dim' }}
            onChange={e => setDim(e.target.value as number | '')}>
            {columns.map(c => <MenuItem key={c.id} value={c.id}>{c.label}</MenuItem>)}
          </Select>
        </FormControl>
        <Stack direction="row" spacing={1}>
          <TextField size="small" fullWidth type="number" label="Amount over" value={amount}
            inputProps={{ 'data-testid': 'explain-amount', min: 0 }} onChange={e => setAmount(e.target.value)} />
          <TextField size="small" fullWidth type="number" label="Or % over" value={percent}
            inputProps={{ 'data-testid': 'explain-percent', min: 0 }} onChange={e => setPercent(e.target.value)} />
        </Stack>
        <FormControl size="small" fullWidth>
          <InputLabel id="explain-mode-label">At sign-off</InputLabel>
          <Select labelId="explain-mode-label" label="At sign-off" value={mode}
            inputProps={{ 'data-testid': 'explain-mode' }}
            onChange={e => setMode(e.target.value as 'warn' | 'block')}>
            <MenuItem value="warn">Warn, and record it if they sign anyway</MenuItem>
            <MenuItem value="block">Do not allow signing until explained</MenuItem>
          </Select>
        </FormControl>
        {error && <Alert severity="warning" sx={{ py: 0 }} data-testid="explain-settings-error">{error}</Alert>}
        {saved && !error && <Typography variant="caption" color="success.main" data-testid="explain-settings-saved">Saved.</Typography>}
        <Stack direction="row" spacing={1}>
          <Button size="small" variant="outlined" disabled={busy} onClick={() => save(false)} data-testid="explain-save">Save</Button>
          {settings && <Button size="small" disabled={busy} onClick={() => save(true)} data-testid="explain-turn-off">Stop listing movements</Button>}
        </Stack>
      </Stack>
    </Box>
  );
}
