/**
 * SQL Query Page — Enterprise SQL editor for Trino/Starburst, Snowflake, Databricks
 *
 * Layout: Superset-style
 *   Left  (300px) — Connection + Schema Browser (catalogs → schemas → tables → columns)
 *   Center         — Primary SQL editor + optional secondary SQL editor for cross-source joins
 *   Results        — DataGridViewer (same as Query Builder)
 */

import { appAlert, appConfirm } from './common/appDialogs';
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { alpha } from '@mui/material/styles';
import {
  Box, Typography, Button, Paper, Chip, CircularProgress,
  Dialog,
  TextField, MenuItem, IconButton, Tooltip, Stack, Divider,
  List, ListItem, ListItemButton, ListItemText, ListItemIcon,
  Collapse, InputAdornment, Alert, LinearProgress,
  ToggleButton, ToggleButtonGroup, Tabs, Tab,
  useMediaQuery,
  Autocomplete,
} from '@mui/material';
import AppDialog from './common/AppDialog';
import {
  PlayArrow as RunIcon, Save as SaveIcon, Add as AddIcon,
  Delete as DeleteIcon, Edit as EditIcon, Refresh as RefreshIcon,
  Storage as CatalogIcon, Schema as SchemaIcon, TableChart as TableIcon,
  ViewColumn as ColumnIcon, ExpandMore as ExpandMoreIcon,
  ChevronRight as ChevronRightIcon, ContentCopy as CopyIcon,
  Link as JoinIcon, Close as CloseIcon, Search as SearchIcon,
  Bookmark as BookmarkIcon, Code as CodeIcon, CheckCircle as CheckIcon,
  Cancel as CancelIcon, Menu as MenuIcon,
  Stream as StreamIcon, CloudDownload as CloudDownloadIcon,
  AutoAwesome as NLIcon,
} from '@mui/icons-material';
import { useNotifications } from '../context/NotificationContext';
import { useWebSocket } from '../context/WebSocketContext';
import { useQueuedWait, queuedWaitLabel } from '../hooks/useQueuedWait';
import { useComponentVisible } from '../context/UIVisibilityContext';
import { useAssistantContext } from '../context/AssistantContext';
import DataGridViewer from './DataGridViewer';
import NLToSQLPanel from './NLToSQLPanel';
import QueryWarningBanner from './QueryWarningBanner';
import AgentSuggestionInline, { type AgentSuggestion } from './AgentSuggestionInline';
import TableVersionsPanel, { VersionsReadLine } from './sql/TableVersionsPanel';
import { agentSuggestionOf, applyAgentSqlFix, isSqlRewriteSuggestion } from '../utils/agentSuggestion';
import api from '../services/api';
import { toArray } from '../utils/toArray';
import { safeFetch } from '../services/api/core';
import { useServerDraft } from '../hooks/useServerDraft';
import RunOnPanel, {
  RunOnResultHeader, pruneSourceMaps, runOnIsActive, runOnPayload,
  type RunOnPlan, type SourceMaps,
} from './sql-run-on/RunOnPanel';

const SCHEMA_PANEL_W = 300;
const fmtSecs = (s: number) => {
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60), sec = s % 60;
  return sec > 0 ? `${m}m ${sec}s` : `${m}m`;
};

// ── Type badge ────────────────────────────────────────────────────────────────
const ConnTypeBadge = ({ type }) => {
  const colors = {
    trino: '#3b82f6', starburst: '#f59e0b', snowflake: '#22d3ee', databricks: '#f97316',
    s3: '#22c55e', oracle: '#ef4444', athena: '#8b5cf6',
  };
  return (
    <Chip
      label={(type || '').toUpperCase()}
      size="small"
      sx={{
        fontSize: 10, height: 18, fontWeight: 700,
        bgcolor: colors[type] || 'grey.400', color: 'white',
        '& .MuiChip-label': { px: 0.75 },
      }}
    />
  );
};

// Phase 142 — replaced the legacy plain-textarea SQL editor with the proper
// CodeMirror-based ``./SqlEditor`` component so SqlQueryPage gets the same
// syntax highlighting + schema-aware autocomplete as CQB / BQB.  The
// local wrapper preserves the prior API (value, onChange, label, schema).
import RealSqlEditor from './SqlEditor';

const SqlEditor = ({
  value, onChange, label, placeholder, schema,
}: {
  value: string; onChange: (v: string) => void;
  label?: string; placeholder?: string;
  schema?: Record<string, string[]>;
}) => (
  <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
    {label && (
      <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary', px: 1.5, py: 0.5, borderBottom: 1, borderColor: 'divider', display: 'block', textTransform: 'uppercase', letterSpacing: 0.5, bgcolor: 'grey.50' }}>
        {label}
      </Typography>
    )}
    <RealSqlEditor
      value={value}
      onChange={onChange}
      schema={schema}
      placeholder={placeholder}
      minHeight="240px"
      maxHeight="60vh"
      showFormatButton
      showTemplatesButton
    />
  </Box>
);

// ── Schema tree node ──────────────────────────────────────────────────────────
const SchemaTreeNode = ({ label, icon, children, onInsert, depth = 0, loading = false, count = undefined, type }: {
  label: any; icon: any; children: any; onInsert: any;
  depth?: number; loading?: boolean; count?: any; type: any;
}) => {
  const [open, setOpen] = useState(false);
  const hasChildren = !!children;
  const iconColor = { catalog: 'primary.main', schema: 'warning.main', table: 'success.main', column: 'text.secondary' }[type] || 'text.secondary';

  return (
    <>
      <ListItem disablePadding>
        <ListItemButton
          onClick={() => { if (hasChildren) setOpen(o => !o); if (onInsert) onInsert(); }}
          sx={{
            pl: 1 + depth * 1.5,
            py: 0.4,
            '&:hover .insert-hint': { opacity: 1 },
          }}
          dense
        >
          <ListItemIcon sx={{ minWidth: 24, color: iconColor }}>
            {loading ? <CircularProgress size={14} /> : icon}
          </ListItemIcon>
          <ListItemText
            primary={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Typography variant="body2" sx={{ fontSize: 13, lineHeight: 1.4, flexGrow: 1 }} noWrap>
                  {label}
                </Typography>
                {count !== undefined && (
                  <Typography variant="caption" color="text.disabled" sx={{ fontSize: 10, flexShrink: 0 }}>{count}</Typography>
                )}
              </Box>
            }
          />
          {hasChildren && (
            open ? <ExpandMoreIcon sx={{ fontSize: 16, color: 'text.disabled' }} />
                 : <ChevronRightIcon sx={{ fontSize: 16, color: 'text.disabled' }} />
          )}
        </ListItemButton>
      </ListItem>
      {hasChildren && (
        <Collapse in={open} unmountOnExit>
          {children}
        </Collapse>
      )}
    </>
  );
};

// ── Column list (leaf) ────────────────────────────────────────────────────────
const ColumnList = ({ columns, onInsert }) => (
  <List disablePadding>
    {columns.map(col => (
      <ListItem key={col.name} disablePadding>
        <ListItemButton
          onClick={() => onInsert(col.name)}
          sx={{ pl: 7, py: 0.25 }}
          dense
        >
          <ListItemIcon sx={{ minWidth: 20 }}>
            <ColumnIcon sx={{ fontSize: 13, color: 'text.disabled' }} />
          </ListItemIcon>
          <ListItemText
            primary={
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                <Typography variant="caption" sx={{ fontFamily: 'monospace', fontSize: 12, flexGrow: 1 }} noWrap>{col.name}</Typography>
                <Typography variant="caption" color="text.disabled" sx={{ fontSize: 10, flexShrink: 0, fontFamily: 'monospace' }}>{col.type}</Typography>
              </Box>
            }
          />
        </ListItemButton>
      </ListItem>
    ))}
  </List>
);

// ── Table tree with lazy-load ─────────────────────────────────────────────────
// `isS3`: when true, tables are registered parquet/iceberg tables — click-to-insert
// produces a starter `SELECT * FROM <table> WHERE <partition>='...' LIMIT 500` snippet
// using the first partition column from the backend response (Phase 108).
const TableTree = ({ connectionId, catalog, schema, onInsertTable, onInsertColumn, isS3 }) => {
  const [tables, setTables] = useState(null);
  const [columns, setColumns] = useState({});
  const [loadingTables, setLoadingTables] = useState(false);
  const [loadingCols, setLoadingCols] = useState({});

  useEffect(() => {
    setLoadingTables(true);
    api.listSqlTables(connectionId, catalog, schema)
      .then(setTables)
      .catch(() => setTables([]))
      .finally(() => setLoadingTables(false));
  }, [connectionId, catalog, schema]);

  const loadColumns = (tableName) => {
    if (columns[tableName] !== undefined) return;
    setLoadingCols(p => ({ ...p, [tableName]: true }));
    api.listSqlColumns(connectionId, catalog, schema, tableName)
      .then(cols => setColumns(p => ({ ...p, [tableName]: cols })))
      .catch(() => setColumns(p => ({ ...p, [tableName]: [] })))
      .finally(() => setLoadingCols(p => ({ ...p, [tableName]: false })));
  };

  const buildInsertText = (t) => {
    if (!isS3) return `${catalog}.${schema}.${t.name}`;
    const partCols = t.partition_columns || [];
    const partCol = partCols[0];
    if (partCol) {
      return `SELECT *\nFROM ${t.name}\nWHERE ${partCol} = 'value'\nLIMIT 500`;
    }
    return `SELECT *\nFROM ${t.name}\nLIMIT 500`;
  };

  if (loadingTables) return <Box sx={{ pl: 6, py: 1 }}><CircularProgress size={14} /></Box>;
  if (!tables) return null;

  return (
    <List disablePadding>
      {tables.map(t => (
        <SchemaTreeNode
          key={t.name}
          label={t.name}
          icon={<TableIcon sx={{ fontSize: 14 }} />}
          depth={3}
          type="table"
          onInsert={() => { onInsertTable(buildInsertText(t), isS3); loadColumns(t.name); }}
          loading={loadingCols[t.name]}
          count={columns[t.name]?.length}
        >
          {(columns[t.name] !== undefined) && (
            <ColumnList
              columns={columns[t.name]}
              onInsert={col => onInsertColumn(isS3 ? col : `${catalog}.${schema}.${t.name}.${col}`)}
            />
          )}
        </SchemaTreeNode>
      ))}
    </List>
  );
};

// ── Schema tree ───────────────────────────────────────────────────────────────
const SchemaTree = ({ connectionId, catalog, onInsert, isS3 }) => {
  const [schemas, setSchemas] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    api.listSqlSchemas(connectionId, catalog)
      .then(setSchemas)
      .catch(() => setSchemas([]))
      .finally(() => setLoading(false));
  }, [connectionId, catalog]);

  if (loading) return <Box sx={{ pl: 5, py: 1 }}><CircularProgress size={14} /></Box>;
  if (!schemas) return null;

  return (
    <List disablePadding>
      {schemas.map(s => (
        <SchemaTreeNode
          key={s}
          label={s}
          icon={<SchemaIcon sx={{ fontSize: 14 }} />}
          depth={2}
          type="schema"
          onInsert={() => onInsert(`${catalog}.${s}`)}
        >
          <TableTree
            connectionId={connectionId}
            catalog={catalog}
            schema={s}
            onInsertTable={onInsert}
            onInsertColumn={onInsert}
            isS3={isS3}
          />
        </SchemaTreeNode>
      ))}
    </List>
  );
};

// ── Catalog tree ──────────────────────────────────────────────────────────────
const CatalogTree = ({ connectionId, onInsert, isS3 }) => {
  const [catalogs, setCatalogs] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const load = () => {
    setLoading(true);
    setError(null);
    api.listSqlCatalogs(connectionId)
      .then(setCatalogs)
      .catch(e => setError(e.message || 'Failed to load catalogs'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { if (connectionId) load(); }, [connectionId]);

  if (!connectionId) return (
    <Box sx={{ p: 2 }}>
      <Typography variant="caption" color="text.disabled">Select a connection to browse schema</Typography>
    </Box>
  );

  if (loading && !catalogs) return <Box sx={{ p: 2 }}><CircularProgress size={20} /></Box>;
  if (error) return (
    <Box sx={{ p: 1 }}>
      <Alert severity="error" sx={{ fontSize: 12 }} action={<Button size="small" onClick={load}>Retry</Button>}>{error}</Alert>
    </Box>
  );

  return (
    <List disablePadding>
      {(catalogs || []).map(cat => (
        <SchemaTreeNode
          key={cat}
          label={cat}
          icon={<CatalogIcon sx={{ fontSize: 14 }} />}
          depth={1}
          type="catalog"
          onInsert={() => onInsert(cat)}
        >
          <SchemaTree connectionId={connectionId} catalog={cat} onInsert={onInsert} isS3={isS3} />
        </SchemaTreeNode>
      ))}
    </List>
  );
};

// ── Save Query Dialog ─────────────────────────────────────────────────────────
const SaveSqlQueryDialog = ({ open, onClose, onSaved, primaryConnectionId, primarySql, secondaryConnectionId, secondarySql, joinConfig, editingQuery, sourceMaps = {} }: any) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const { addNotification } = useNotifications();

  useEffect(() => {
    if (open) {
      setName(editingQuery?.name || '');
      setDescription(editingQuery?.description || '');
    }
  }, [open, editingQuery]);

  const handleSave = async () => {
    if (!name.trim()) { void appAlert('Enter a query name'); return; }
    try {
      const payload = {
        name:                   name.trim(),
        description:            description || null,
        primary_connection_id:  primaryConnectionId,
        primary_sql:            primarySql,
        secondary_connection_id: secondaryConnectionId || null,
        secondary_sql:          secondaryConnectionId ? secondarySql : null,
        join_config:            secondaryConnectionId ? joinKeysOf(joinConfig) : null,
        // 2026-10-04: JOIN or UNION -- the backend's one cross-source road.
        combine_mode:           secondaryConnectionId ? combineModeOf(joinConfig) : null,
        // 2026-11-01: the SQL once + where each table is on every "Run on" source
        source_maps:            sourceMaps,
      };
      let result;
      if (editingQuery?.id) {
        result = await api.updateSqlQuery(editingQuery.id, payload);
        addNotification({ type: 'success', title: 'Query Updated', message: `"${name}" updated` });
      } else {
        result = await api.createSqlQuery(payload);
        addNotification({ type: 'success', title: 'Query Saved', message: `"${name}" saved` });
      }
      onSaved(result);
      onClose();
    } catch (e) {
      addNotification({ type: 'error', title: 'Save Error', message: e.message });
    }
  };

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="sm"
      title={<>
        <SaveIcon fontSize="small" />
        {editingQuery?.id ? 'Update SQL Query' : 'Save SQL Query'}
      </>}
      actions={<>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSave} startIcon={<SaveIcon />}>
          {editingQuery?.id ? 'Update' : 'Save'}
        </Button>
      </>}>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField label="Name" required fullWidth value={name} onChange={e => setName(e.target.value)} />
          <TextField label="Description" fullWidth multiline rows={2} value={description} onChange={e => setDescription(e.target.value)} />
          {secondaryConnectionId && (
            <Alert severity="info" sx={{ fontSize: 12 }}>
              Cross-source join configuration will be saved with this query.
            </Alert>
          )}
        </Stack>
    </AppDialog>
  );
};

// ── Join Config Dialog ────────────────────────────────────────────────────────
/**
 * 2026-09-04 -- the two join keys were free-text boxes ("e.g. customer_id")
 * whose helper text already said what they had to be: "Column from primary
 * source query".  A name that is not in that query's output produces a join
 * on nothing -- an empty result, or a failure at the source -- and the
 * author had no way to see which columns were available.
 *
 * They are derivable without running anything: a SELECT states its own
 * output columns, and POST /api/datasets/preview returns them from the
 * SAME offline parser the backend uses for saved queries and dataset
 * detection (core.sql_output_columns).  Parsing the SQL in the browser
 * instead would be a second parser, disagreeing with the first the day
 * either changed.
 *
 * freeSolo is kept: `SELECT *` has no readable shape, and the author must
 * still be able to name a column rather than be blocked by an empty list.
 */
/** ``joinConfig`` carries the combine mode beside the join keys in the page's
 *  state; the API takes them as two fields (2026-10-04). */
const combineModeOf = (jc: any): 'join' | 'union' =>
  (jc?.combine_mode === 'union' ? 'union' : 'join');
const joinKeysOf = (jc: any) => {
  const { combine_mode: _m, ...keys } = jc || {};
  return keys;
};

const JoinConfigDialog = ({ open, onClose, config, onChange,
                           primarySql, secondarySql,
                           primaryConnId, secondaryConnId }) => {
  const [local, setLocal] = useState({ how: 'inner', left_on: '', right_on: '', combine_mode: 'join', ...config });
  const [leftCols, setLeftCols] = useState<string[]>([]);
  const [rightCols, setRightCols] = useState<string[]>([]);

  useEffect(() => { if (open) setLocal({ how: 'inner', left_on: '', right_on: '', combine_mode: 'join', ...config }); }, [open]);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const load = async (sql, connId, set) => {
      const text = String(sql || '').trim();
      if (!text) { set([]); return; }
      try {
        const res: any = await api.previewDatasetSource({
          connection_id: Number(connId) || 0, sql: text, limit: 1,
        });
        const cols = (res?.columns || []).map((c: any) =>
          typeof c === 'string' ? c : String(c?.name ?? c?.physical_name ?? ''));
        if (!cancelled) set(cols.filter(Boolean));
      } catch {
        // Unreadable shape (SELECT *) or an unreachable source: fall back
        // to typing rather than showing an empty dropdown.
        if (!cancelled) set([]);
      }
    };
    load(primarySql, primaryConnId, setLeftCols);
    load(secondarySql, secondaryConnId, setRightCols);
    return () => { cancelled = true; };
  }, [open, primarySql, secondarySql, primaryConnId, secondaryConnId]);

  const keyPicker = (label, valueKey, options, hint) => (
    <Autocomplete
      freeSolo
      size="small"
      options={options}
      value={local[valueKey] || ''}
      onInputChange={(_e, v) => setLocal(p => ({ ...p, [valueKey]: v }))}
      renderInput={(params) => (
        <TextField {...params} fullWidth size="small" label={label}
          placeholder={options.length ? 'Pick a column' : 'e.g. customer_id'}
          helperText={options.length
            ? hint
            : `${hint} — its columns could not be read, so type the name`} />
      )}
    />
  );

  return (
    <AppDialog open={open}
      onClose={onClose}
      size="xs"
      title="Cross-Source Combine"
      actions={<>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={() => { onChange(local); onClose(); }}>Apply</Button>
      </>}>
        <Stack spacing={2} sx={{ mt: 1 }}>
          <TextField select label="Combine" fullWidth size="small"
            value={local.combine_mode === 'union' ? 'union' : 'join'}
            onChange={e => setLocal(p => ({ ...p, combine_mode: e.target.value }))}>
            <MenuItem value="join">JOIN (match rows on key columns)</MenuItem>
            <MenuItem value="union">UNION ALL (stack rows, aligned by column name)</MenuItem>
          </TextField>
          {local.combine_mode !== 'union' && (
            <>
              <TextField select label="Join Type" fullWidth size="small"
                value={local.how === 'outer' ? 'full' : local.how}
                onChange={e => setLocal(p => ({ ...p, how: e.target.value }))}>
                {[['inner', 'INNER'], ['left', 'LEFT'], ['right', 'RIGHT'],
                  ['full', 'FULL OUTER']].map(([h, label]) => (
                  <MenuItem key={h} value={h}>{label} JOIN</MenuItem>
                ))}
              </TextField>
              {keyPicker('Primary Key Column', 'left_on', leftCols,
                         'Column from primary source query')}
              {keyPicker('Secondary Key Column', 'right_on', rightCols,
                         'Column from secondary source query')}
            </>
          )}
        </Stack>
    </AppDialog>
  );
};

// ── Saved Queries Panel ───────────────────────────────────────────────────────
const SavedQueriesPanel = ({ onLoad, onClose }) => {
  const [queries, setQueries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const { addNotification } = useNotifications();

  useEffect(() => {
    api.listSqlQueries(true).then(d => setQueries(toArray(d))).catch(() => setQueries([])).finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return q ? queries.filter(r => r.name.toLowerCase().includes(q)) : queries;
  }, [queries, search]);

  const handleDelete = async (query) => {
    if (!await appConfirm(`Delete "${query.name}"? It is switched off, not erased -- an admin or its owner can switch it back on under Admin -> Switched off.`)) return;
    try {
      await api.deleteSqlQuery(query.id);
      setQueries(prev => prev.filter(q => q.id !== query.id));
      addNotification({ type: 'success', title: 'Deleted', message: `"${query.name}" deleted` });
    } catch (e) {
      addNotification({ type: 'error', title: 'Delete Error', message: e.message });
    }
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <Box sx={{ p: 1.5, borderBottom: 1, borderColor: 'divider', display: 'flex', alignItems: 'center', gap: 1 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 700, flexGrow: 1 }}>Saved SQL Queries</Typography>
        <Tooltip title="Close saved queries">
          <IconButton size="small" onClick={onClose} aria-label="Close saved queries">
            <CloseIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      </Box>
      <Box sx={{ p: 1 }}>
        <TextField
          size="small" fullWidth placeholder="Search…" value={search}
          onChange={e => setSearch(e.target.value)}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon sx={{ fontSize: 16 }} /></InputAdornment> }}
        />
      </Box>
      <Box sx={{ flex: 1, overflowY: 'auto' }}>
        {loading ? <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress size={24} /></Box> : (
          filtered.map(q => (
            <Box key={q.id} sx={{ px: 1.5, py: 1, borderBottom: 1, borderColor: 'divider', '&:hover': { bgcolor: 'action.hover' } }}>
              <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 0.5 }}>
                <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                  <Typography variant="body2" fontWeight={600} noWrap>{q.name}</Typography>
                  {q.secondary_connection_id && (
                    <Chip label="Cross-source" size="small" color="warning" sx={{ fontSize: 10, height: 16, mt: 0.25 }} />
                  )}
                  <Typography variant="caption" color="text.disabled" display="block">
                    {q.execution_count} runs · {q.created_at ? new Date(q.created_at).toLocaleDateString() : ''}
                  </Typography>
                </Box>
                <Tooltip title="Load into editor"><IconButton size="small" color="primary" onClick={() => onLoad(q)}><EditIcon fontSize="small" /></IconButton></Tooltip>
                <Tooltip title="Delete"><IconButton size="small" color="error" onClick={() => handleDelete(q)}><DeleteIcon fontSize="small" /></IconButton></Tooltip>
              </Box>
            </Box>
          ))
        )}
        {!loading && filtered.length === 0 && (
          <Box sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="caption" color="text.disabled">No saved SQL queries found</Typography>
          </Box>
        )}
      </Box>
    </Box>
  );
};

// ══════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ══════════════════════════════════════════════════════════════════════════════
const SqlQueryPage = () => {
  const { addNotification } = useNotifications();
  const { lastMessage } = useWebSocket();
  // H1 (2026-10-07): the slot wait BEFORE the execute POST answers.
  const queuedWait = useQueuedWait();
  // 2026-11-01: the version each Iceberg table of the last run was read at
  // (the status route's iceberg_versions), shown in the result header.
  const [versionsRead, setVersionsRead] = useState<Array<{ view: string; words: string }> | null>(null);
  const isCompactScreen = useMediaQuery('(max-width:1280px)');
  const { setAssistantCtx } = useAssistantContext();

  // SQL connector connections (trino, starburst, snowflake, databricks) + all for type lookups
  const [sqlConnections, setSqlConnections] = useState([]);
  const allConnectionsRef = useRef<any[]>([]);
  const [connectionsLoading, setConnectionsLoading] = useState(true);
  const [schemaOpen, setSchemaOpen] = useState(!isCompactScreen);

  // Schema browser
  const [primaryConnId, setPrimaryConnId] = useState(null);
  const [schemaTarget, setSchemaTarget] = useState('primary'); // 'primary' | 'secondary'

  // SQL editors — Phase 142: server-side draft persistence (DB-backed).
  // Replaces the prior localStorage bandage with /api/user/drafts/* so
  // drafts survive refresh / device switch / cookie clear / pod restart.
  // Keys are namespaced by primary connection so each connection keeps
  // its own primary + secondary drafts independent.
  const _DEFAULT_PRIMARY = '-- Primary SQL Query\nSELECT *\nFROM catalog.schema.table\nLIMIT 1000';
  const _DEFAULT_SECONDARY = '-- Secondary SQL Query (optional cross-source join)\nSELECT *\nFROM catalog.schema.table\nLIMIT 1000';
  const _primaryDraftKey = `sqlpage.primary.${primaryConnId ?? 'none'}`;
  const _secondaryDraftKey = `sqlpage.secondary.${primaryConnId ?? 'none'}`;
  const [primarySql, setPrimarySql] = useServerDraft<string>(_primaryDraftKey, _DEFAULT_PRIMARY);
  const [secondaryConnId, setSecondaryConnId] = useState(null);
  const [secondarySql, setSecondarySql] = useServerDraft<string>(_secondaryDraftKey, _DEFAULT_SECONDARY);

  // Phase 142 — Schema-aware autocomplete: prefetch catalog/schema/table
  // metadata for the active SQL connector so the SqlEditor's CodeMirror
  // completion engine knows table + column names.  Keys: table → columns.
  // Lazy: only fetches if user has the connection selected.
  const [primarySchema, setPrimarySchema] = useState<Record<string, string[]>>({});
  const [secondarySchema, setSecondarySchema] = useState<Record<string, string[]>>({});

  useEffect(() => {
    if (!primaryConnId) { setPrimarySchema({}); return; }
    let cancelled = false;
    (async () => {
      try {
        const cats: any[] = await api.listSqlCatalogs(String(primaryConnId)).catch(() => []);
        if (!cats?.length || cancelled) return;
        const out: Record<string, string[]> = {};
        // Fetch only the FIRST catalog + first schema to keep it cheap.
        // The user usually queries one schema at a time; broader autocomplete
        // is a Phase 143 improvement that scans on-demand as they type.
        const cat = cats[0]?.name || cats[0];
        const schs: any[] = await api.listSqlSchemas(String(primaryConnId), cat).catch(() => []);
        if (!schs?.length || cancelled) return;
        const sch = schs[0]?.name || schs[0];
        const tabs: any[] = await api.listSqlTables(String(primaryConnId), cat, sch).catch(() => []);
        for (const t of (tabs || []).slice(0, 50)) {
          const tname = t?.name || t;
          // Bare name AND fully-qualified — user can type either form
          out[tname] = [];
          out[`${cat}.${sch}.${tname}`] = [];
        }
        if (!cancelled) setPrimarySchema(out);
      } catch { /* fail-open: no schema → no autocomplete */ }
    })();
    return () => { cancelled = true; };
  }, [primaryConnId]);

  useEffect(() => {
    if (!secondaryConnId) { setSecondarySchema({}); return; }
    let cancelled = false;
    (async () => {
      try {
        const cats: any[] = await api.listSqlCatalogs(String(secondaryConnId)).catch(() => []);
        if (!cats?.length || cancelled) return;
        const out: Record<string, string[]> = {};
        const cat = cats[0]?.name || cats[0];
        const schs: any[] = await api.listSqlSchemas(String(secondaryConnId), cat).catch(() => []);
        if (!schs?.length || cancelled) return;
        const sch = schs[0]?.name || schs[0];
        const tabs: any[] = await api.listSqlTables(String(secondaryConnId), cat, sch).catch(() => []);
        for (const t of (tabs || []).slice(0, 50)) {
          const tname = t?.name || t;
          out[tname] = [];
          out[`${cat}.${sch}.${tname}`] = [];
        }
        if (!cancelled) setSecondarySchema(out);
      } catch {}
    })();
    return () => { cancelled = true; };
  }, [secondaryConnId]);
  // 2026-10-23 -- the owner's case is the SAME rows from two connections
  // stacked (UNION ALL by column name): a NEW combine starts there; a saved
  // query keeps its own mode (loadSavedQuery).
  const [joinConfig, setJoinConfig] = useState({ how: 'inner', left_on: '', right_on: '', combine_mode: 'union' });
  const [showSecondary, setShowSecondary] = useState(false);
  // 2026-11-01 -- "Run on" (sql-run-on/RunOnPanel): the same SQL on another source.
  const [runOnId, setRunOnId] = useState<number | null>(null);
  const [sourceMaps, setSourceMaps] = useState<SourceMaps>({});
  const [runOnPlan, setRunOnPlan] = useState<RunOnPlan | null>(null);
  const [runOnResult, setRunOnResult] = useState<{ plan: RunOnPlan; engine?: string | null } | null>(null);

  // Dialogs
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showJoinConfig, setShowJoinConfig] = useState(false);
  const [showSavedPanel, setShowSavedPanel] = useState(false);
  const [editingQuery, setEditingQuery] = useState(null);

  // Execution
  const [executing, setExecuting] = useState(false);
  const [executionId, setExecutionId] = useState(null);
  const [progress, setProgress] = useState(null);
  const [showResults, setShowResults] = useState(false);
  const [resultsExecutionId, setResultsExecutionId] = useState(null);
  const [elapsed, setElapsed] = useState(0);
  const [etaSeconds, setEtaSeconds] = useState(null);
  const execStartRef = useRef<number | null>(null);
  const elapsedTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Phase 47: Query warnings from pre-execution analysis
  const [queryWarnings, setQueryWarnings] = useState<any[]>([]);
  // BF-571/572: agent format-string auto-fixes (Starburst %i → DuckDB %M etc.)
  const [agentFormatFixes, setAgentFormatFixes] = useState<any[]>([]);

  // Phase 48: NL-to-SQL panel toggle + tables for schema context
  const [showNLPanel, setShowNLPanel] = useState(false);
  const [nlTables, setNlTables] = useState<string[]>([]);

  // Streaming source — enables DataGridViewer to paginate directly from S3
  // In-page visibility (admin declutter — NOT authorization): when hidden,
  // the toggles below leave the DOM and the defaults apply unchanged.
  const visStreamingToggles = useComponentVisible('sql_editor.streaming');
  const [enableStreaming, setEnableStreaming] = useState(true); // default ON for S3 connections
  const [streamBgDownload, setStreamBgDownload] = useState(true); // also run background S3→local download
  const [streamingSource, setStreamingSource] = useState<{ queryConfig?: any; rawSql?: string; connectionId: number } | null>(null);
  const [resultKey] = useState(0);

  // Cache strategy
  const [cacheStrategy, setCacheStrategy] = useState<'auto' | 'bypass' | 'refresh'>('auto');

  // Row limit
  const [rowLimit, setRowLimit] = useState(10000);

  // Active editor tab
  const [activeTab, setActiveTab] = useState(0);

  // Pick up SQL generated by GlobalAssistantPanel (navigate from any page)
  useEffect(() => {
    const pending = sessionStorage.getItem('nl_sql_pending');
    if (pending) {
      setPrimarySql(pending);
      sessionStorage.removeItem('nl_sql_pending');
    }
  }, []);

  // Load SQL connector connections on mount.
  // 2026-08-23 — the eligible-type list comes from the BACKEND declaration
  // (GET /api/sql/connector-types → editor_types, declared next to the
  // connector registry).  The previous hardcoded copy here had drifted:
  // it was missing 'oracle' and 'athena', so every Oracle/Athena
  // connection was invisible on this page even though /api/sql/execute
  // fully supports them.  The static list below is only the offline
  // fallback when that endpoint is unreachable.
  useEffect(() => {
    Promise.all([api.listConnections(true), api.getSqlConnectorTypes()])
      .then(([conns, types]) => {
        allConnectionsRef.current = conns || [];
        const editorTypes: string[] =
          (types as any)?.editor_types?.length
            ? (types as any).editor_types
            : ['trino', 'starburst', 'snowflake', 'databricks', 'oracle', 'athena'];
        const SQL_TYPES = [...editorTypes, 's3'];
        setSqlConnections((conns || []).filter(c => SQL_TYPES.includes(c.connection_type)));
      })
      .catch(() => setSqlConnections([]))
      .finally(() => setConnectionsLoading(false));
  }, []);

  // Cleanup elapsed timer on unmount
  useEffect(() => {
    return () => { if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current); };
  }, []);

  // Load top-tables for NL panel when it opens or connection changes
  useEffect(() => {
    if (!showNLPanel || !primaryConnId) return;
    (api as any).getTopTables(primaryConnId)
      .then((r: any) => setNlTables((r?.tables || r || []).map((t: any) => t.table_name || t.object_name || t)))
      .catch(() => setNlTables([]));
  }, [showNLPanel, primaryConnId]);

  // Keep GlobalAssistantPanel context in sync with current SQL editor connection
  useEffect(() => {
    const conn = (sqlConnections as any[]).find((c: any) => c.id === primaryConnId);
    setAssistantCtx({
      connectionId: primaryConnId ?? undefined,
      connectionType: conn?.connection_type || 'duckdb',
      pageName: 'sql',
    });
  }, [primaryConnId, sqlConnections]);

  // WebSocket progress handler
  useEffect(() => {
    if (!lastMessage || lastMessage.execution_id !== executionId) return;
    const msg = lastMessage as any;
    if (msg.type === 'execution_progress') {
      setProgress({ status: msg.data?.status || 'processing', ...msg.data });
      if (msg.data?.status === 'completed') {
        if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
        const finalElapsed = execStartRef.current ? Math.floor((Date.now() - execStartRef.current) / 1000) : 0;
        setExecuting(false);
        setProgress({ status: 'completed', total_rows: msg.data.total_rows, elapsed: finalElapsed });
        setResultsExecutionId(executionId);
        setShowResults(true);
        // Seamless transition: clear streaming, DataGridViewer picks up executionId
        setStreamingSource(null);
      }
    } else if (msg.type === 'execution_completed') {
      api.getExecutionStatus(executionId)
        .then((st: any) => setVersionsRead(Array.isArray(st?.iceberg_versions) ? st.iceberg_versions : null))
        .catch(() => setVersionsRead(null));
      if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
      const finalElapsed = execStartRef.current ? Math.floor((Date.now() - execStartRef.current) / 1000) : 0;
      setExecuting(false);
      setProgress({
        status: 'completed',
        total_rows: msg.stats?.total_rows,
        elapsed: finalElapsed,
        stale_warning: msg.stale_warning || null,
      });
      setRunOnResult(r => (r ? { ...r, engine: msg.engine_label || msg.engine || r.engine } : r));
      setResultsExecutionId(executionId);
      setShowResults(true);
      // Seamless transition: clear streaming, DataGridViewer picks up executionId
      setStreamingSource(null);
    } else if (msg.type === 'execution_failed') {
      if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
      setExecuting(false);
      setStreamingSource(null);  // clear streaming so error is visible
      // 2026-10-07: /api/sql/execute now sends the backend's agent
      // suggestion on execution_failed (core/agents/inline_suggestion.py);
      // rendered below with the same Auto-fix path as the query builders.
      const _sug = agentSuggestionOf(msg);
      setProgress({ status: 'failed', error: msg.error, ...(_sug ? { agentSuggestion: _sug } : {}) });
    } else if (msg.type === 'execution_cancelled') {
      setStreamingSource(null);
    }
  }, [lastMessage, executionId]);

  const handleInsertText = useCallback((text, replace = false) => {
    const target = schemaTarget === 'secondary' ? secondarySql : primarySql;
    const setter = schemaTarget === 'secondary' ? setSecondarySql : setPrimarySql;
    // Phase 108: when `replace` is true (e.g. clicking an S3 starter snippet)
    // and the editor still holds the default placeholder, swap the content
    // entirely instead of appending a second SELECT block.
    const isPlaceholder = target.trim().startsWith('-- Primary SQL Query') ||
                          target.trim().startsWith('-- Secondary SQL Query') ||
                          target.trim() === '';
    if (replace && isPlaceholder) {
      setter(text);
      return;
    }
    setter(target + (target.endsWith('\n') ? '' : '\n') + text);
  }, [schemaTarget, primarySql, secondarySql]);

  const stopRunUi = () => {
    if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
    setExecuting(false);
    setProgress(null);
    setStreamingSource(null);
  };

  // H1 (2026-10-07): this page had no Cancel at all.  While the POST waits
  // for a slot the wait is ended by its correlation id; once the run has an
  // execution id, by that id (the shared cancel route).
  const handleCancel = () => {
    if (!queuedWait.cancel() && executionId) {
      api.cancelExecution(executionId).catch(() => { /* fail-open */ });
    }
    stopRunUi();
  };

  const handleExecute = async () => {
    if (!primaryConnId) {
      addNotification({ type: 'warning', title: 'No Connection', message: 'Select a primary data source connection' });
      return;
    }
    if (!primarySql.trim()) {
      addNotification({ type: 'warning', title: 'Empty Query', message: 'Enter a SQL query to execute' });
      return;
    }
    if (showSecondary && secondaryConnId && combineModeOf(joinConfig) === 'join'
        && (!joinConfig.left_on || !joinConfig.right_on)) {
      addNotification({ type: 'warning', title: 'Join Config Incomplete', message: 'Configure join columns before executing cross-source query' });
      setShowJoinConfig(true);
      return;
    }

    // Determine if stream-only (no background download)
    // Phase 108: reuse the memoized isPrimaryS3 derived flag.
    // "Run on" goes through the server's mapping: never the S3 stream of the raw text.
    const runOnActive = runOnIsActive(runOnId, primaryConnId) && !showSecondary;
    const streamOnly = enableStreaming && !streamBgDownload && isPrimaryS3 && !showSecondary && !runOnActive;
    setRunOnResult(null);

    try {
      setExecuting(true);
      setShowResults(false);
      setProgress({ status: 'starting' });
      setElapsed(0);
      execStartRef.current = Date.now();
      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
      elapsedTimerRef.current = setInterval(() => {
        setElapsed(Math.floor((Date.now() - (execStartRef.current ?? Date.now())) / 1000));
      }, 1000);

      if (streamOnly) {
        // ── Stream-only: no background S3→local download ──
        if (elapsedTimerRef.current) { clearInterval(elapsedTimerRef.current); elapsedTimerRef.current = null; }
        setStreamingSource({ rawSql: primarySql, connectionId: primaryConnId! });
        setShowResults(true);
        setExecuting(false);
        setProgress(null);
        addNotification({ type: 'info', title: 'Stream Only', message: 'Streaming directly from S3 — no background download' });
        return;
      }

      // ── Normal path: background download (+ optional streaming preview) ──
      safeFetch(`/api/admin/query-eta${primaryConnId ? `?connection_id=${primaryConnId}` : ''}`)
        .then(d => setEtaSeconds(d.p75_seconds ?? null)).catch(() => {});

      const payload = {
        primary_connection_id: primaryConnId,
        primary_sql: primarySql,
        row_limit: rowLimit || null,
        ...(runOnActive ? runOnPayload(runOnId, primaryConnId, sourceMaps) : {}),
        ...(showSecondary && secondaryConnId
          ? {
              secondary_connection_id: secondaryConnId,
              secondary_sql: secondarySql,
              join_config: joinKeysOf(joinConfig),
              combine_mode: combineModeOf(joinConfig),
            }
          : {}),
      };

      if (cacheStrategy !== 'auto') (payload as any).cache_strategy = cacheStrategy;
      // H1: the POST carries a correlation id -- while it waits for a slot the
      // queued events are recognisable as this run's and Cancel can end it.
      const sub = await queuedWait.submit((crid) =>
        api.executeSqlQuery({ ...payload, client_request_id: crid }) as Promise<any>);
      if (sub.cancelled) {
        if (sub.current) stopRunUi();
        return;
      }
      const response: any = sub.response;
      setExecutionId(response.execution_id);
      // Phase 47: capture query warnings from backend analysis
      setQueryWarnings(response.query_warnings || []);
      // BF-571/572: surface agent format-string auto-fixes — Starburst
      // %i → DuckDB %M, DATE_FORMAT → STRFTIME, etc.  Backend repairs
      // the SQL in-flight; this banner tells the user what changed.
      const _ff = (response as any).agent_format_fixes || [];
      setAgentFormatFixes(Array.isArray(_ff) ? _ff : []);
      setRunOnResult(response.run_on ? { plan: response.run_on } : null);
      // 2026-09-24: no "SQL Query Started" toast -- the page already shows the
      // run in progress, and the toast sat over the results grid it announced.

      // ── Streaming preview alongside background download ──
      if (enableStreaming && primaryConnId && !showSecondary && isPrimaryS3 && !runOnActive) {
        setStreamingSource({ rawSql: primarySql, connectionId: primaryConnId });
        setShowResults(true);
      }
    } catch (e) {
      setExecuting(false);
      setProgress(null);
      addNotification({ type: 'error', title: 'Execution Failed', message: e.message });
    }
  };

  const loadSavedQuery = (q) => {
    setPrimaryConnId(q.primary_connection_id);
    setPrimarySql(q.primary_sql || '');
    if (q.secondary_connection_id) {
      setSecondaryConnId(q.secondary_connection_id);
      setSecondarySql(q.secondary_sql || '');
      setJoinConfig({ how: 'inner', left_on: '', right_on: '', ...(q.join_config || {}),
                      combine_mode: q.combine_mode === 'union' ? 'union' : 'join' });
      setShowSecondary(true);
    } else {
      setSecondaryConnId(null);
      setShowSecondary(false);
    }
    setEditingQuery(q);
    setSourceMaps(q.source_maps || {});
    setRunOnId(null);
    setShowSavedPanel(false);
    addNotification({ type: 'info', title: 'Query Loaded', message: `Editing "${q.name}"` });
  };

  // Phase 108: memoize connection lookups — avoids 4 .find() scans + .toLowerCase()
  // on every render; recomputes only when the connection list or selected IDs change.
  const { primaryConn, secondaryConn, browsedConnId, isBrowsedS3, isPrimaryS3 } = useMemo(() => {
    const pConn = sqlConnections.find(c => c.id === primaryConnId);
    const sConn = sqlConnections.find(c => c.id === secondaryConnId);
    const bId = schemaTarget === 'secondary' ? secondaryConnId : primaryConnId;
    const bConn = schemaTarget === 'secondary' ? sConn : pConn;
    return {
      primaryConn: pConn,
      secondaryConn: sConn,
      browsedConnId: bId,
      isBrowsedS3: (bConn?.connection_type || '').toLowerCase() === 's3',
      isPrimaryS3: (pConn?.connection_type || '').toLowerCase() === 's3',
    };
  }, [sqlConnections, primaryConnId, secondaryConnId, schemaTarget]);

  const statusColor = { starting: 'info', processing: 'warning', completed: 'success', failed: 'error' };

  return (
    <Box sx={{ height: '100%', display: 'flex', overflow: 'hidden' }}>

      {/* ─── Left: Schema Browser ──────────────────────────────────────────── */}
      <Box sx={{
        width: schemaOpen ? SCHEMA_PANEL_W : 0,
        minWidth: schemaOpen ? SCHEMA_PANEL_W : 0,
        // 2026-09-24 (click crawl): collapsed to width 0, its controls were
        // still in the page -- under the toolbar and the editor, where Tab
        // reached them and a click could not.  Hidden once collapsed (after
        // the width animation, so the collapse still looks the same).
        visibility: schemaOpen ? 'visible' : 'hidden',
        transition: `width 0.2s ease, min-width 0.2s ease, visibility 0s linear ${schemaOpen ? '0s' : '0.2s'}`,
        display: 'flex', flexDirection: 'column', borderRight: schemaOpen ? 1 : 0, borderColor: 'divider', bgcolor: 'background.paper', overflow: 'hidden',
      }}>

        {/* Header */}
        <Box sx={{ px: 1.5, py: 1, borderBottom: 1, borderColor: 'divider', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Typography variant="caption" sx={{ fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>
            Schema Browser
          </Typography>
          <Tooltip title="Hide schema browser">
            <IconButton size="small" onClick={() => setSchemaOpen(false)} sx={{ p: 0.25 }}
                        aria-label="Hide schema browser">
              <ChevronRightIcon sx={{ fontSize: 16, transform: 'rotate(180deg)' }} />
            </IconButton>
          </Tooltip>
        </Box>

        {/* Connection pickers */}
        <Box sx={{ p: 1, borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
            Browse schema for:
          </Typography>
          <ToggleButtonGroup size="small" value={schemaTarget} exclusive onChange={(_, v) => v && setSchemaTarget(v)} sx={{ mb: 1 }}>
            <ToggleButton value="primary" sx={{ fontSize: 11 }}>Primary</ToggleButton>
            {showSecondary && <ToggleButton value="secondary" sx={{ fontSize: 11 }}>Secondary</ToggleButton>}
          </ToggleButtonGroup>

          {/* Primary connection */}
          <TextField
            select fullWidth size="small" label="Primary Source"
            value={primaryConnId || ''}
            onChange={e => { setPrimaryConnId(e.target.value || null); setRunOnId(null); setSchemaTarget('primary'); setResultsExecutionId(null); setStreamingSource(null); setShowResults(false); }}
            sx={{ mb: 1 }}
          >
            <MenuItem value=""><em>Select connection…</em></MenuItem>
            {sqlConnections.map(c => (
              <MenuItem key={c.id} value={c.id}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <ConnTypeBadge type={c.connection_type} />
                  <Typography variant="body2" noWrap>{c.name}</Typography>
                </Box>
              </MenuItem>
            ))}
          </TextField>

          {/* 2026-11-01: "Run on" -- the same SQL on another source (one query only) */}
          {!showSecondary && primaryConnId && (
            <RunOnPanel
              connections={sqlConnections}
              homeConnectionId={primaryConnId}
              sql={primarySql}
              runOnId={runOnId}
              onRunOnChange={setRunOnId}
              sourceMaps={sourceMaps}
              onSourceMapsChange={setSourceMaps}
              onPlan={setRunOnPlan}
            />
          )}

          {/* Secondary connection (cross-source) */}
          {showSecondary && (
            <TextField
              select fullWidth size="small" label="Secondary Source"
              value={secondaryConnId || ''}
              onChange={e => { setSecondaryConnId(e.target.value || null); setSchemaTarget('secondary'); }}
            >
              <MenuItem value=""><em>Select connection…</em></MenuItem>
              {sqlConnections.map(c => (
                <MenuItem key={c.id} value={c.id}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <ConnTypeBadge type={c.connection_type} />
                    <Typography variant="body2" noWrap>{c.name}</Typography>
                  </Box>
                </MenuItem>
              ))}
            </TextField>
          )}
        </Box>

        {/* Catalog/schema tree */}
        <Box sx={{ flex: 1, overflowY: 'auto' }}>
          <CatalogTree
            connectionId={browsedConnId}
            onInsert={handleInsertText}
            isS3={isBrowsedS3}
          />
        </Box>

        {connectionsLoading && (
          <Box sx={{ p: 1 }}><LinearProgress /></Box>
        )}
        {!connectionsLoading && sqlConnections.length === 0 && (
          <Box sx={{ p: 2 }}>
            <Alert severity="info" sx={{ fontSize: 12 }}>
              No SQL connections found. Add a Trino, Snowflake, or Databricks connection first.
            </Alert>
          </Box>
        )}
      </Box>

      {/* ─── Right: Editor + Results ────────────────────────────────────────── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'row', overflow: 'hidden' }}>

      {/* ─── Center: Editor + Results ──────────────────────────────────────── */}
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* Toolbar */}
        <Box sx={{ px: 1.5, py: 0.75, borderBottom: 1, borderColor: 'divider', display: 'flex', alignItems: 'center', gap: 1, flexShrink: 0, bgcolor: 'background.paper', flexWrap: 'wrap' }}>

          {/* Schema panel toggle */}
          {!schemaOpen && (
            <Tooltip title="Show schema browser">
              <IconButton size="small" onClick={() => setSchemaOpen(true)} sx={{ border: 1, borderColor: 'divider' }}>
                <MenuIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          )}

          {/* Saved queries toggle */}
          <Tooltip title="Saved SQL Queries">
            <IconButton size="small" color={showSavedPanel ? 'primary' : 'default'} onClick={() => setShowSavedPanel(p => !p)}>
              <BookmarkIcon fontSize="small" />
            </IconButton>
          </Tooltip>

          <Divider orientation="vertical" flexItem />

          {/* Cross-source toggle.  2026-10-23: S3 on either side runs (the one
              cross-source capability since 2026-10-04); the S3 block was stale. */}
          <Tooltip title={showSecondary
            ? 'Remove the second connection'
            : 'Run on a second connection too, and combine the two results (UNION ALL or JOIN)'}>
            <span>
              <Button
                size="small"
                startIcon={<JoinIcon />}
                variant={showSecondary ? 'contained' : 'outlined'}
                color={showSecondary ? 'warning' : 'inherit'}
                onClick={() => setShowSecondary(p => !p)}
                sx={{ fontSize: 12 }}
              >
                Cross-Source
              </Button>
            </span>
          </Tooltip>

          {showSecondary && secondaryConnId && (
            <Tooltip title="Configure join keys">
              <Button
                size="small"
                startIcon={<CodeIcon />}
                variant="outlined"
                color={combineModeOf(joinConfig) === 'union'
                       || (joinConfig.left_on && joinConfig.right_on) ? 'success' : 'warning'}
                onClick={() => setShowJoinConfig(true)}
                sx={{ fontSize: 12 }}
              >
                {combineModeOf(joinConfig) === 'union' ? 'Union ALL' : (
                  <>
                    Join: {joinConfig.how.toUpperCase()}
                    {joinConfig.left_on && joinConfig.right_on && (
                      <> · {joinConfig.left_on} = {joinConfig.right_on}</>
                    )}
                  </>
                )}
              </Button>
            </Tooltip>
          )}

          <Box sx={{ flexGrow: 1 }} />

          {/* Row limit */}
          <TextField
            select size="small" label="Row Limit" value={rowLimit}
            onChange={e => setRowLimit(Number(e.target.value))}
            sx={{ minWidth: 120 }}
          >
            {[1000, 5000, 10000, 50000, 100000].map(n => (
              <MenuItem key={n} value={n}>{n.toLocaleString()}</MenuItem>
            ))}
          </TextField>

          {/* Save */}
          <Tooltip title="Save query">
            <IconButton size="small" onClick={() => setShowSaveDialog(true)} disabled={!primaryConnId}>
              <SaveIcon fontSize="small" />
            </IconButton>
          </Tooltip>

          {/* NL-to-SQL toggle */}
          <Tooltip title="Describe your query in plain English and get SQL instantly">
            <Button
              size="small"
              variant={showNLPanel ? 'contained' : 'outlined'}
              color="secondary"
              startIcon={<NLIcon sx={{ fontSize: 15 }} />}
              onClick={() => setShowNLPanel(v => !v)}
              sx={{ whiteSpace: 'nowrap', fontSize: '0.75rem', py: 0.4 }}
            >
              NL→SQL
            </Button>
          </Tooltip>

          {/* Execute */}
          <Button
            variant="contained"
            startIcon={executing ? <CircularProgress size={16} color="inherit" /> : <RunIcon />}
            onClick={handleExecute}
            disabled={executing || !primaryConnId}
            size="small"
            sx={{ minWidth: 100 }}
          >
            {executing ? 'Running…' : 'Run SQL'}
          </Button>

          {/* Streaming toggles — only for S3 connections.  Admin-hideable via
              the `sql_editor.streaming` visibility key (declutter, not a
              permission): hidden means the page's default streaming
              behaviour applies and the toggles leave the DOM. */}
          {visStreamingToggles && (() => {
            const conn = sqlConnections.find((c: any) => c.id === primaryConnId);
            return conn?.connection_type === 's3' ? (
              <>
                <Tooltip title={enableStreaming
                  ? 'Streaming ON — preview data from S3 while query runs.'
                  : 'Streaming OFF — wait for full query to complete.'
                }>
                  <Chip
                    icon={<StreamIcon sx={{ fontSize: 16 }} />}
                    label="Stream"
                    size="small"
                    variant={enableStreaming ? 'filled' : 'outlined'}
                    color={enableStreaming ? 'info' : 'default'}
                    onClick={() => setEnableStreaming(!enableStreaming)}
                    sx={{ cursor: 'pointer', fontWeight: enableStreaming ? 700 : 400 }}
                  />
                </Tooltip>
                {enableStreaming && (
                  <Tooltip title={streamBgDownload
                    ? 'Download ON — also downloads full results to local file in background (for export/history).'
                    : 'Download OFF — stream only, no local file created. Faster, saves disk space.'
                  }>
                    <Chip
                      icon={<CloudDownloadIcon sx={{ fontSize: 16 }} />}
                      label="Download"
                      size="small"
                      variant={streamBgDownload ? 'filled' : 'outlined'}
                      color={streamBgDownload ? 'warning' : 'default'}
                      onClick={() => setStreamBgDownload(!streamBgDownload)}
                      sx={{ cursor: 'pointer', fontWeight: streamBgDownload ? 700 : 400 }}
                    />
                  </Tooltip>
                )}
              </>
            ) : null;
          })()}
        </Box>

        {/* Saved queries panel */}
        {showSavedPanel && (
          <Box sx={{ height: 340, borderBottom: 1, borderColor: 'divider', overflow: 'hidden', flexShrink: 0 }}>
            <SavedQueriesPanel
              onLoad={loadSavedQuery}
              onClose={() => setShowSavedPanel(false)}
            />
          </Box>
        )}

        {/* Connection badges */}
        {(primaryConn || secondaryConn) && (
          <Box sx={{ px: 1.5, py: 0.5, display: 'flex', alignItems: 'center', gap: 1, bgcolor: 'grey.50', borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
            {primaryConn && (
              <Chip
                icon={<ConnTypeBadge type={primaryConn.connection_type} />}
                label={`Primary: ${primaryConn.name}`}
                size="small"
                variant="outlined"
                sx={{ fontSize: 12 }}
              />
            )}
            {secondaryConn && (
              <>
                <Typography variant="caption" color="text.disabled">→ {combineModeOf(joinConfig) === 'union' ? 'UNION ALL' : `${joinConfig.how?.toUpperCase()} JOIN`} →</Typography>
                <Chip
                  icon={<ConnTypeBadge type={secondaryConn.connection_type} />}
                  label={`Secondary: ${secondaryConn.name}`}
                  size="small"
                  color="warning"
                  variant="outlined"
                  sx={{ fontSize: 12 }}
                />
              </>
            )}
            {editingQuery && (
              <Chip label={`Editing: ${editingQuery.name}`} size="small" color="info" onDelete={() => setEditingQuery(null)} />
            )}
          </Box>
        )}

        {/* Progress bar */}
        {executing && (
          <Box sx={{ flexShrink: 0 }}>
            <LinearProgress color={statusColor[progress?.status] || 'primary'} />
            <Box sx={{ px: 2, py: 0.5, bgcolor: 'grey.50', display: 'flex', alignItems: 'center', gap: 2 }}>
              {queuedWait.queued ? (
                /* H1: the POST is waiting for a slot -- told under the
                   correlation id it sent; role=status announces it. */
                <Typography role="status" data-testid="queued-wait" variant="caption"
                  color="warning.main" sx={{ flex: 1, fontWeight: 600 }}>
                  {queuedWaitLabel(queuedWait.queued)} · {fmtSecs(elapsed)} waited
                </Typography>
              ) : (
              <Typography variant="caption" color="text.secondary" sx={{ flex: 1 }}>
                {progress?.message || progress?.status || 'Executing…'} · {fmtSecs(elapsed)} elapsed
              </Typography>
              )}
              {etaSeconds != null && elapsed < etaSeconds && (
                <Typography variant="caption" color="primary.main" sx={{ fontWeight: 500 }}>
                  ~{fmtSecs(Math.max(1, Math.round(etaSeconds - elapsed)))} remaining
                </Typography>
              )}
              <Button size="small" variant="text" color="error" onClick={handleCancel}
                sx={{ textTransform: 'none', py: 0 }}>Cancel</Button>
            </Box>
          </Box>
        )}
        {!executing && progress?.status === 'completed' && !progress?.stale_warning && (
          <Box sx={{ px: 2, py: 0.5, bgcolor: 'success.50', borderBottom: 1, borderColor: 'divider', flexShrink: 0 }}>
            <Typography variant="caption" color="success.main" sx={{ fontWeight: 600 }}>
              Completed in {fmtSecs(progress.elapsed ?? 0)} · {(progress.total_rows || 0).toLocaleString()} rows
            </Typography>
            <VersionsReadLine versions={versionsRead} />
          </Box>
        )}
        {!executing && progress?.stale_warning && (
          <Alert severity="warning" sx={{ mx: 1, mt: 0.5, py: 0.4, flexShrink: 0, fontSize: '0.8rem' }}
            onClose={() => setProgress((p: any) => p ? { ...p, stale_warning: null } : p)}>
            <strong>Showing cached result</strong> — {progress.stale_warning}
          </Alert>
        )}

        {/* Error */}
        {progress?.status === 'failed' && (
          <Box sx={{ m: 1, flexShrink: 0 }}>
            <Alert severity="error" onClose={() => setProgress(null)}>
              {progress.error}
            </Alert>
            {/* 2026-10-07: the agent suggestion /api/sql/execute sends.  The
                "Auto-fix SQL" button rewrites the PRIMARY editor's SQL on the
                primary connection -- the same apply path as the builders. */}
            <AgentSuggestionInline
              suggestion={progress.agentSuggestion as AgentSuggestion | undefined}
              onApply={async (s) => {
                if (!isSqlRewriteSuggestion(s)) {
                  addNotification({
                    type: 'info', title: s.strategy.replace(/_/g, ' '),
                    message: s.reason || 'Apply this suggestion by editing the query.',
                  });
                  return;
                }
                const fix = await applyAgentSqlFix(primarySql, primaryConnId);
                if (fix.fixed) {
                  setPrimarySql(fix.sql);
                  setProgress(null);  // dismiss the error
                  addNotification({ type: 'success', title: 'SQL auto-fixed', message: fix.message });
                } else {
                  addNotification({ type: 'warning', title: 'Could not auto-fix', message: fix.message });
                }
              }}
            />
          </Box>
        )}

        {/* SQL Editors */}
        <Box sx={{ display: 'flex', flex: showResults ? '0 0 280px' : 1, minHeight: 180, borderBottom: showResults ? 1 : 0, borderColor: 'divider', overflow: 'hidden', flexShrink: showResults ? 0 : 1 }}>
          {showSecondary ? (
            <Box sx={{ display: 'flex', width: '100%' }}>
              <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', borderRight: 1, borderColor: 'divider' }}>
                <SqlEditor
                  value={primarySql}
                  onChange={setPrimarySql}
                  schema={primarySchema}
                  label={`Primary: ${primaryConn?.name || 'select a connection'}`}
                />
              </Box>
              <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                {/* 2026-10-23 -- the owner: "union all should be same query or
                    other with same columns for [the] second connection". */}
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', px: 1, pt: 0.5 }}>
                  <Tooltip title="Copy the first query here, to run the SAME query on the second connection (then edit it if its tables are named differently)">
                    <span>
                      <Button size="small" data-testid="secondary-same-sql"
                              disabled={!primarySql.trim() || secondarySql === primarySql}
                              onClick={() => setSecondarySql(primarySql)}>
                        Same SQL as the first
                      </Button>
                    </span>
                  </Tooltip>
                </Box>
                <SqlEditor
                  value={secondarySql}
                  onChange={setSecondarySql}
                  schema={secondarySchema}
                  label={`Secondary: ${secondaryConn?.name || 'select a connection'}`}
                />
              </Box>
            </Box>
          ) : (
            <SqlEditor
              value={primarySql}
              onChange={setPrimarySql}
              schema={primarySchema}
              label={primaryConn ? `${primaryConn.name} (${primaryConn.connection_type})` : 'Select a connection'}
            />
          )}
        </Box>

        {/* 2026-11-01: "Table version" -- one row per Iceberg table the SQL reads */}
        <TableVersionsPanel connectionId={primaryConnId} sql={primarySql} onSqlChange={setPrimarySql}
                            sideLabel={showSecondary ? primaryConn?.name : undefined} />
        {showSecondary && (
          <TableVersionsPanel connectionId={secondaryConnId} sql={secondarySql}
                              onSqlChange={setSecondarySql} sideLabel={secondaryConn?.name} />
        )}

        {/* Phase 108: S3 helper text — reminds users that partition filters prune scans */}
        {isPrimaryS3 && !showResults && (
          <Box sx={{ px: 1.5, pt: 1, flexShrink: 0 }}>
            <Alert severity="info" sx={{ fontSize: 12, py: 0.4 }}>
              <strong>S3 / Parquet</strong> — use registered table names directly (no catalog/schema prefix).
              Add a partition column to WHERE (e.g. <code>dt = '2025-01-15'</code>) to avoid full-table scans.
            </Alert>
          </Box>
        )}

        {/* Phase 47: Query warning banner */}
        {queryWarnings.length > 0 && (
          <Box sx={{ px: 1.5, pt: 1, flexShrink: 0 }}>
            <QueryWarningBanner warnings={queryWarnings} onDismiss={() => setQueryWarnings([])} />
          </Box>
        )}

        {/* BF-571/572 (2026-05-29): agent format-string auto-fixes.
            Shown when the backend rewrote Starburst/Trino/MySQL specifiers
            so DuckDB can run the SQL.  Dismissable. */}
        {agentFormatFixes.length > 0 && (
          <Box sx={{ px: 1.5, pt: 1, flexShrink: 0 }}>
            <Alert
              severity="info"
              onClose={() => setAgentFormatFixes([])}
              sx={{ fontSize: '0.8rem', py: 0.4 }}
            >
              <strong>Agent auto-corrected {agentFormatFixes.length} format issue
                {agentFormatFixes.length === 1 ? '' : 's'} in your SQL:</strong>
              {' '}{agentFormatFixes.map((f: any, i: number) => (
                <span key={i}>
                  {i > 0 ? ' · ' : ''}
                  <code style={{ background: 'rgba(0,0,0,0.06)', padding: '0 4px', borderRadius: 3 }}>
                    {f.original_format}
                  </code>
                  {' → '}
                  <code style={{ background: 'rgba(0,0,0,0.06)', padding: '0 4px', borderRadius: 3 }}>
                    {f.repaired_format}
                  </code>
                  {f.function_rewritten && <em> ({f.function} → STRFTIME)</em>}
                </span>
              ))}
            </Alert>
          </Box>
        )}

        {/* Results — single DataGridViewer handles both streaming and local */}
        {showResults && (streamingSource || resultsExecutionId) && (
          <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <RunOnResultHeader plan={runOnResult?.plan || null} engineLabel={runOnResult?.engine} />
            {streamingSource && executing && (
              <Paper elevation={0} sx={(theme) => ({ p: 1.5, display: 'flex', alignItems: 'center', gap: 1.5, bgcolor: alpha(theme.palette.primary.main, 0.08), border: `1px solid ${alpha(theme.palette.primary.main, 0.3)}`, borderRadius: 1, mx: 1, mt: 1, flexShrink: 0 })}>
                <CircularProgress size={18} thickness={5} sx={{ color: 'primary.main' }} />
                <Box>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: 'primary.dark' }}>
                    Streaming from S3 — query is being processed
                  </Typography>
                  <Typography variant="caption" sx={{ color: 'primary.main' }}>
                    You can paginate, sort, and filter while results are loading.
                  </Typography>
                </Box>
              </Paper>
            )}
            <Box sx={{ flex: 1, overflow: 'hidden' }}>
              <DataGridViewer
                key={resultKey}
                executionId={resultsExecutionId}
                streamingSource={streamingSource}
                onClose={() => { setShowResults(false); setResultsExecutionId(null); setStreamingSource(null); }}
              />
            </Box>
          </Box>
        )}
      </Box>{/* end center column */}

      {/* ─── Right: NL-to-SQL Panel (Phase 48) ─────────────────────────────── */}
      {showNLPanel && (
        <Box sx={{
          width: 340, flexShrink: 0,
          borderLeft: 1, borderColor: 'divider',
          display: 'flex', flexDirection: 'column', overflow: 'hidden',
          bgcolor: 'background.paper',
        }}>
          <NLToSQLPanel
            connectionId={primaryConnId ?? undefined}
            connectionType={sqlConnections.find((c: any) => c.id === primaryConnId)?.connection_type}
            tables={nlTables}
            onUseSql={(sql) => {
              setPrimarySql(sql);
              setShowNLPanel(false);
            }}
          />
        </Box>
      )}

      </Box>{/* end outer flex row */}

      {/* ─── Dialogs ─────────────────────────────────────────────────────────── */}
      <SaveSqlQueryDialog
        open={showSaveDialog}
        onClose={() => setShowSaveDialog(false)}
        onSaved={(q) => setEditingQuery(q)}
        primaryConnectionId={primaryConnId}
        primarySql={primarySql}
        secondaryConnectionId={showSecondary ? secondaryConnId : null}
        secondarySql={secondarySql}
        joinConfig={joinConfig}
        sourceMaps={pruneSourceMaps(sourceMaps, runOnId, runOnPlan)}
        editingQuery={editingQuery}
      />

      <JoinConfigDialog
        open={showJoinConfig}
        onClose={() => setShowJoinConfig(false)}
        config={joinConfig}
        onChange={setJoinConfig}
        primarySql={primarySql}
        secondarySql={secondarySql}
        primaryConnId={primaryConnId}
        secondaryConnId={secondaryConnId}
      />
    </Box>
  );
};

export default SqlQueryPage;
